package com.headunit.launcher

import android.content.Context
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import org.json.JSONObject

/**
 * Tiny observable key/value store (Compose-aware).
 * Every key has its own state, so changing one setting only redraws the screens that actually read that setting
 * (a single shared map would redraw everything that read any setting).
 */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("drive_launcher", Context.MODE_PRIVATE)
    // one set of values for the whole app: the phone's screen, the Android Auto screen and the services all see a change at once
    private val raw: HashMap<String, String> = synchronized(LOCK) {
        RAW ?: HashMap<String, String>().apply { sp.all.forEach { (k, v) -> put(k, v.toString()) } }.also { RAW = it }
    }
    private val states get() = STATES

    private companion object {
        val LOCK = Any()
        var RAW: HashMap<String, String>? = null
        val STATES = HashMap<String, MutableState<String?>>()
    }

    private fun state(k: String): MutableState<String?> = synchronized(LOCK) { states.getOrPut(k) { mutableStateOf(raw[k]) } }

    fun s(k: String, d: String) = state(k).value ?: d
    fun b(k: String, d: Boolean) = state(k).value?.toBooleanStrictOrNull() ?: d
    fun i(k: String, d: Int) = state(k).value?.toIntOrNull() ?: d
    fun f(k: String, d: Float) = state(k).value?.toFloatOrNull() ?: d

    /** Everything except the API key, as JSON text (settings, saved places, logs...). */
    fun exportJson(): String = synchronized(LOCK) {
        val o = JSONObject()
        raw.forEach { (k, v) -> if (k != "apikey") o.put(k, v) }
        o.toString(2)
    }

    /** Restores values from [exportJson] output; returns how many entries were applied. */
    fun importJson(text: String): Int {
        val o = JSONObject(text)
        var n = 0
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k == "apikey") continue
            put(k, o.get(k))
            n++
        }
        return n
    }

    fun put(k: String, v: Any) {
        val s = v.toString()
        // nothing changed: no disk write and nothing on screen is redrawn
        synchronized(LOCK) { if (raw[k] == s) return; raw[k] = s }
        state(k).value = s
        sp.edit().putString(k, s).apply()
    }
}

/**
 * The map source: whatever was picked in Settings; until something is picked, TomTom once a TomTom key has been entered
 * (otherwise this build's default).
 */
fun Prefs.mapSource(): String = s("mapstyle", BuildConfig.DEFAULT_MAP).let { if (it == "google") "mapbox" else it }

/**
 * Once, on the first start after updating from a Horizon Nav from before the Mapbox map: switch the map to Mapbox (the old
 * TomTom / OpenStreetMap / Google choice was for the old map engine) and drop the Google key, which nothing uses now. Your places,
 * keys, settings and downloaded packs are all kept.
 */
fun Prefs.migrateToMapbox() {
    if (b("mbmigrated", false)) return
    put("mapstyle", "mapbox")
    put("gkey", "")
    // no Mapbox token yet (an update from the old map): setup shows once more, to ask for it (and the TomTom key)
    if (s("mbtoken", "").isBlank()) put("forcesetup", true)
    put("mbmigrated", true)
}

/** Saves a TomTom key; entering one where there was none switches the map to TomTom (it can be switched back in Settings). */
fun Prefs.setApiKey(k: String) {
    val was = s("apikey", "").isNotBlank()
    put("apikey", k.trim())
    if (!was && k.isNotBlank()) put("mapstyle", "tomtom")
}

/** The locator setting as the map takes it: its style and colour ("model" takes "<arrow|car>|<colour>"). */
fun Prefs.locatorSpec(): Pair<String, String> {
    val loc = s("locator", "arrow")
    return when (loc) {
        "custom" -> loc to (s("locimg", "0") + "|" + (if (b("locimgturn", true)) "1" else "0") + "|" + (if (b("locimgcircle", false)) "1" else "0"))
        "model" -> {
            val shape = s("modelshape", "arrow")
            loc to (shape + "|" + s(if (shape == "car") "carcolour" else "arrowcolour", if (shape == "car") "#F4F5F7" else "#F2F2F6"))
        }
        "car" -> loc to s("carcolour", "#F4F5F7")
        else -> loc to s("arrowcolour", "#F2F2F6")
    }
}

/** Settings > Map > Map detail: "full", "lite" or "lightest" (the old "Light map" switch counts as lite). */
fun Prefs.mapDetail(): String = s("mapdetail", if (b("maplite", false)) "lite" else "full")
