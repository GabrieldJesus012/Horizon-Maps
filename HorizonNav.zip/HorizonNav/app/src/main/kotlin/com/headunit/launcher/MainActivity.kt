package com.headunit.launcher

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.snapshotFlow
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.headunit.launcher.ui.App
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var map: MapBinding
    private lateinit var engine: NavEngine

    private val perm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    private fun hasLocation() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** A route is being followed (not just previewed) or the demo drive is on, so guidance should carry on when another app is in front. */
    private fun guiding() = (engine.route != null && !engine.previewing) || engine.simMode != 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // keep the last crash so it can be read in Settings > About & backup
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        val crashFile = java.io.File(applicationContext.filesDir, "lastcrash.txt")
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { crashFile.writeText("Thread ${t.name}\n" + android.util.Log.getStackTraceString(e).take(3000)) } catch (x: Throwable) { }
            prev?.uncaughtException(t, e)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val prefs = Prefs(applicationContext)
        map = MapBinding(this, prefs.b("mapfast", true), (prefs.s("mapres", "80").toIntOrNull() ?: 80) / 100f).also { it.setArrowScale((prefs.s("arrowpct", "240").toIntOrNull() ?: 240) / 100f) }
        lifecycle.addObserver(map)
        engine = NavEngine(applicationContext, prefs, map)

        setContent { App(prefs, engine, map) }

        // while a route runs, a foreground service keeps GPS and voice going in the background; it stops when the route ends
        lifecycleScope.launch {
            snapshotFlow { if (guiding()) (engine.dest?.name ?: "your destination") else null }
                .distinctUntilChanged()
                .collect { to ->
                    if (to != null && hasLocation()) NavService.start(applicationContext, "Navigating to $to")
                    else if (to == null) {
                        NavService.stop(applicationContext)
                        // the route ended (arrived or cancelled) while another app was in front: GPS can rest too
                        if (!lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED)) engine.stopLocation()
                    }
                }
        }

        val wanted = arrayListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) wanted += Manifest.permission.POST_NOTIFICATIONS
        val missing = wanted.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) perm.launch(missing.toTypedArray())
    }

    override fun onResume() {
        super.onResume()
        // after the permission dialog closes, wait a beat so the UI is settled before starting GPS
        if (hasLocation()) window.decorView.postDelayed({ if (!isFinishing && !isDestroyed) engine.startLocation() }, 400)
    }

    override fun onStop() {
        super.onStop()
        // with no route there is nothing to guide, so GPS is switched off while the app is in the background
        if (!guiding()) engine.stopLocation()
    }

    override fun onDestroy() {
        super.onDestroy()
        NavService.stop(applicationContext)
        engine.shutdown()
    }
}
