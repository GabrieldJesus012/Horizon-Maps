package com.headunit.launcher.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.WbCloudy
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs

/** True when the temperature unit is Fahrenheit. */
fun isImperial(prefs: Prefs): Boolean = prefs.s("tempunit", "C") == "F"

/** Colour for a weather code (Open-Meteo / WMO codes). */
internal fun wxTint(code: Int): Color = when (code) {
    0 -> Color(0xFFFFC233)
    1, 2 -> Color(0xFFFFD27A)
    3, 45, 48 -> Color(0xFFA9B4C4)
    in 51..67, in 80..82 -> Color(0xFF4DA3FF)
    in 71..77, in 85..86 -> Color(0xFFDCEBFF)
    in 95..99 -> Color(0xFFFFB020)
    else -> Color(0xFFA9B4C4)
}

internal fun wxIcon(code: Int): ImageVector = when (code) {
    0 -> Icons.Rounded.WbSunny
    1, 2 -> Icons.Rounded.WbCloudy
    3, 45, 48 -> Icons.Rounded.Cloud
    in 51..67, in 80..82 -> Icons.Rounded.WaterDrop
    in 71..77, in 85..86 -> Icons.Rounded.AcUnit
    in 95..99 -> Icons.Rounded.Bolt
    else -> Icons.Rounded.Cloud
}

/** One settings row: a label on the left, its controls on the right, and a hairline under it. */
@Composable
internal fun Row2(title: String, content: @Composable () -> Unit) {
    val c = LocalVw.current
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f).padding(end = 18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) { content() }
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(c.line.copy(alpha = 0.28f)))
}

/** Opens an Android settings screen, falling back to the main settings app. */
internal fun openSystemSettings(ctx: android.content.Context, action: String, uri: Uri? = null) {
    try {
        val i = Intent(action)
        if (uri != null) i.data = uri
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try { ctx.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
    }
}

/** Light rain streaks drawn over the map (purely cosmetic, off by default). */
@Composable
fun RainOverlay(modifier: Modifier = Modifier) {
    val drops = remember { List(70) { floatArrayOf(Math.random().toFloat(), Math.random().toFloat(), 0.6f + Math.random().toFloat() * 0.8f) } }
    val t by rememberInfiniteTransition(label = "rain").animateFloat(
        0f, 1f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "rainT",
    )
    val night = LocalVw.current.dark
    androidx.compose.foundation.Canvas(modifier) {
        for (d in drops) {
            val x = d[0] * size.width
            val y = ((d[1] + t * d[2]) % 1f) * size.height
            val len = 16.dp.toPx() * d[2]
            drawLine(
                if (night) Color.White.copy(alpha = 0.30f * d[2]) else Color(0xFF3F5F80).copy(alpha = 0.50f * d[2]),
                Offset(x, y), Offset(x - len * 0.25f, y + len), 1.5.dp.toPx(),
            )
        }
    }
}

/** Snow drifting down the screen, slowly and with a little sway. */
@Composable
fun SnowOverlay(modifier: Modifier = Modifier, heavy: Boolean = false) {
    val flakes = remember { List(if (heavy) 80 else 50) { floatArrayOf(Math.random().toFloat(), Math.random().toFloat(), 0.5f + Math.random().toFloat() * 0.8f, Math.random().toFloat() * 6.28f) } }
    val t by rememberInfiniteTransition(label = "snow").animateFloat(
        0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "snowT",
    )
    androidx.compose.foundation.Canvas(modifier) {
        for (f in flakes) {
            val y = ((f[1] + t * f[2]) % 1f) * size.height
            val x = f[0] * size.width + kotlin.math.sin(t * 12.56f + f[3]) * 14.dp.toPx() * f[2]
            drawCircle(Color.White.copy(alpha = 0.55f * f[2]), (1.6f + 1.8f * f[2]) * density, Offset(x, y))
        }
    }
}

/** Fog: a soft white haze that thickens towards the horizon. Nothing moves, so it costs nothing to draw. */
@Composable
fun FogOverlay(modifier: Modifier = Modifier) {
    val night = LocalVw.current.dark
    val col = if (night) Color(0xFF9AA3B5) else Color(0xFFF2F4F7)
    androidx.compose.foundation.Canvas(modifier) {
        drawRect(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(col.copy(alpha = 0.55f), col.copy(alpha = 0.22f), col.copy(alpha = 0.08f))), Offset.Zero, size)
    }
}

/** The weather effect for an Open-Meteo weather code: rain (heavier in a downpour or storm), snow or fog. */
@Composable
fun WeatherFx(code: Int, modifier: Modifier = Modifier) {
    when (code) {
        45, 48 -> FogOverlay(modifier)
        in 71..77, 85, 86 -> SnowOverlay(modifier, heavy = code == 75 || code == 86)
        in 51..67, in 80..82, in 95..99 -> {
            RainOverlay(modifier)
            if (code == 65 || code == 82 || code >= 95 || code == 63 || code == 81) RainOverlay(modifier)
        }
        else -> { }
    }
}

// ------------------------------------------------------------------ share ETA by text message
@Composable
fun rememberPhonePicker(onPicked: (String, String) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data ?: return@rememberLauncherForActivityResult
        try {
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) onPicked(it.getString(0) ?: "", it.getString(1) ?: "")
            }
        } catch (e: Exception) { }
    }
    return {
        try { pick.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)) } catch (e: Exception) { }
    }
}

@Composable
fun rememberEtaContactPicker(prefs: Prefs, onPicked: () -> Unit = {}): () -> Unit =
    rememberPhonePicker { num, name ->
        prefs.put("etanum", num)
        prefs.put("etaname", name)
        onPicked()
    }

@Composable
fun rememberShareEta(engine: NavEngine): () -> Unit {
    val ctx = LocalContext.current
    val prefs = engine.prefs
    fun message(): String {
        val d = engine.dest?.name ?: "my destination"
        val e = engine.eta
        val p = engine.fix?.pos
        return "I'm on my way to $d" + (if (e != null) ", arriving about ${e.arrive}" else "") +
            (if (p != null) ". Where I am now: https://maps.google.com/?q=${p.lat},${p.lon}" else ".")
    }
    fun sendNow() {
        val num = prefs.s("etanum", "")
        if (num.isBlank()) return
        val msg = message()
        try {
            val sms = if (android.os.Build.VERSION.SDK_INT >= 31) ctx.getSystemService(android.telephony.SmsManager::class.java) else android.telephony.SmsManager.getDefault()
            sms.sendMultipartTextMessage(num, null, sms.divideMessage(msg), null, null)
            engine.toast("ETA sent to ${prefs.s("etaname", num)}", 3000)
        } catch (e: Exception) {
            try {
                ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).putExtra("sms_body", msg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e2: Exception) { engine.toast("No messaging app available", 3000) }
        }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { sendNow() }
    val pickContact = rememberEtaContactPicker(prefs) { engine.toast("Contact saved. Tap share again to send.", 3500) }
    return {
        if (prefs.s("etanum", "").isBlank()) {
            engine.toast("Choose who to send your ETA to", 3000)
            pickContact()
        } else if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) sendNow()
        else perm.launch(Manifest.permission.SEND_SMS)
    }
}
