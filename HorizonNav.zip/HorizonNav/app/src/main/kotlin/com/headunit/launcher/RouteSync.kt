package com.headunit.launcher

import java.util.Collections
import java.util.WeakHashMap

/**
 * Keeps the app on the phone's screen and the one on the Android Auto screen on the same trip: starting a route on either starts it
 * on the other, and ending it on either ends both. Only one of them speaks (the car's, while it's connected), so directions and
 * alerts aren't said twice.
 */
object RouteSync {
    private val engines: MutableSet<NavEngine> = Collections.newSetFromMap(WeakHashMap())
    @Volatile private var applying = false
    /** The trip under way (destination and stops), so an engine that starts later joins it. */
    @Volatile var current: Pair<Place, List<Place>>? = null
        private set

    fun register(e: NavEngine) {
        synchronized(engines) { engines.add(e) }
        val cur = current
        if (cur != null && e.route == null) apply { e.followRoute(cur.first, cur.second) }
    }

    fun unregister(e: NavEngine) { synchronized(engines) { engines.remove(e) } }

    private fun others(e: NavEngine) = synchronized(engines) { engines.filter { it !== e } }

    private inline fun apply(block: () -> Unit) {
        applying = true
        try { block() } finally { applying = false }
    }

    /** [from] has started guidance to [dest]: the others follow. */
    fun started(from: NavEngine, dest: Place, via: List<Place>) {
        if (applying) return
        current = dest to via
        for (e in others(from)) apply { e.followRoute(dest, via) }
    }

    /** [from] has ended its route: the others end theirs. */
    fun ended(from: NavEngine) {
        if (applying) return
        current = null
        for (e in others(from)) if (e.route != null) apply { e.endRoute() }
    }

    /** True when an Android Auto screen is connected (then the phone stays quiet and the car does the talking). */
    fun carConnected(): Boolean = synchronized(engines) { engines.any { it.isCar } }
}
