package com.headunit.launcher

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class Fix(val pos: LL, val heading: Double, val speed: Double, val alt: Double, val acc: Double = 0.0)
class RouteWx(val minutes: Int, val code: Int, val temp: Double, val rain: Int)

class TurnInfo(
    val dist: Double, val street: String, val maneuver: String, val thenManeuver: String?, val thenText: String, val lanes: LaneSec? = null,
    /** "2nd exit" for a roundabout, "Exit 12" for a motorway exit. */
    val tag: String = "", val laneAdvice: String? = null, val exit: Int = 0,
    /** Text from the road sign at the junction, when the route data has it. */
    val sign: String = "",
)
class AlertInfo(val kind: String, val text: String, val ms: Long = 5000)
/** Shown after you arrive: how the trip went. */
class ArrivalInfo(val place: Place?, val name: String, val dist: Double, val secs: Double, val avgMs: Double, val side: String = "")
/** Another way to the destination, drawn grey on the map while you drive, with how it compares (minutes, negative = quicker). */
class LiveAlt(val route: Route, val diffMin: Int, val bubble: LL, val divergeOff: Double)
/** Something in the next couple of miles for the hazard radar: what it is and how far away (m). */
class RadarItem(val kind: String, val dist: Double, val label: String)
/** "Work · 23 min · light traffic": where you are probably going now, with the live time. */
class Prediction(val place: Place, val title: String, val mins: Int, val delayMin: Int, val note: String)
class IncidentAhead(val label: String, val dist: Double, val delaySec: Int)
class EtaInfo(val arrive: String, val dist: Double, val secs: Double, val delayMin: Int)
private class Snap(val dist: Double, val i: Int, val progress: Double, val pt: LL)

class NavEngine(private val ctx: Context, val prefs: Prefs, val map: MapBinding) : LocationListener {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // ---- observable state ----
    var fix by mutableStateOf<Fix?>(null)
    var routes by mutableStateOf<List<Route>>(emptyList())
    var routeFrac by mutableStateOf(0f)
    var active by mutableIntStateOf(0)
    var dest by mutableStateOf<Place?>(null)
    var turn by mutableStateOf<TurnInfo?>(null)
    var eta by mutableStateOf<EtaInfo?>(null)
    var following by mutableStateOf(true)
    var tilt3d by mutableStateOf(true)
    var simMode by mutableIntStateOf(0)
    var message by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)
    var previewing by mutableStateOf(false)
    var northUp by mutableStateOf(false)
    var results by mutableStateOf<List<Place>>(emptyList())
    var alternatives by mutableStateOf(false)
    var weather by mutableStateOf<Weather.Now?>(null)
    var zoomOffset by mutableDoubleStateOf(0.0)

    // saved places, departure planner, road info
    val places = PlaceStore(prefs)
    val trips = TripStore(prefs)
    var pendingSave by mutableStateOf<String?>(null)
    var departMin by mutableIntStateOf(0)
    var departAtMs by mutableLongStateOf(0L)
    var speedLimit by mutableStateOf<Double?>(null)     // m/s
    var limitEstimated by mutableStateOf(false)
    private var limitOkAt = 0L
    private var limitOkPos: LL? = null
    private var limitFails = 0
    var cameraDist by mutableStateOf<Int?>(null)
    var incidentAhead by mutableStateOf<IncidentAhead?>(null)
    private var incAt = 0L
    private var incMatches: List<Triple<Incident, Double, String>> = emptyList()
    private var routeCams: List<Pair<LL, Double>> = emptyList()
    private var camsRoute: Route? = null
    private var camsAt = 0L
    private var hazardSig = 0
    private var hzProgress = 0.0
    private var policeSig = 0
    private val policeAlerted = HashSet<Long>()
    private val incAlerted = HashSet<String>()
    var nearby by mutableStateOf<List<Nearby>>(emptyList())
    var nearbyKind by mutableStateOf<String?>(null)
    var nearbyBusy by mutableStateOf(false)

    // trip computer (real GPS only)
    var tripDist by mutableDoubleStateOf(0.0)
    var tripMax by mutableDoubleStateOf(0.0)
    var tripMoving by mutableDoubleStateOf(0.0)
    var tripStart by mutableStateOf(System.currentTimeMillis())

    // extras
    val habits = HabitStore(prefs)
    var overLimit by mutableStateOf(false)
    var via by mutableStateOf<List<Place>>(emptyList())
    var stopMode by mutableStateOf(false)
    var destRain by mutableStateOf<String?>(null)
    var routeWx by mutableStateOf<List<RouteWx>>(emptyList())
    var arriveFlash by mutableStateOf(false)
    var arrival by mutableStateOf<ArrivalInfo?>(null)
    /** A quicker route than the one being followed, found while driving. */
    class FasterRoute(val route: Route, val savedMin: Int)
    var faster by mutableStateOf<FasterRoute?>(null)
    var liveAlts by mutableStateOf<List<LiveAlt>>(emptyList())
    var radar by mutableStateOf<List<RadarItem>>(emptyList())
    private var radarSig = 0
    private var bendsFor: Route? = null
    private var bends: List<Pair<Double, Int>> = emptyList()
    var prediction by mutableStateOf<Prediction?>(null)
    private var predictionAt = 0L
    var arrivalParking by mutableStateOf<Nearby?>(null)
    /** Roads driven on this trip, counted into the familiar-roads list when the trip ends. */
    private val tripRoads = HashSet<String>()
    private val roadFam: HashMap<String, Int> by lazy {
        val m = HashMap<String, Int>()
        try { val o = org.json.JSONObject(prefs.s("roadfam", "{}")); for (k in o.keys()) m[k] = o.optInt(k) } catch (e: Exception) { }
        m
    }
    private var lastFasterCheck = 0L
    /** Destination of a trip that was still running when the app last closed. */
    var resume by mutableStateOf<Place?>(null)
    private var navStartMs = 0L
    private var navStartDist = 0.0
    var brakeFlash by mutableStateOf(false)
    /** True for a few seconds after the speed limit changes, so the sign can pulse. */
    var limitPulse by mutableStateOf(false)
    /** The alert banner currently on screen (camera, speed limit, incident, rain, break). */
    var alert by mutableStateOf<AlertInfo?>(null)
    private var alertToken = 0

    // ---- route extras: average speed checks, services, bumps, schools, zones, the route bar ----
    /** The average speed check you are in (or about to enter), or null. */
    var avgInfo by mutableStateOf<AvgInfo?>(null)
    /** The next motorway services ahead on the route (up to two). */
    var servicesAhead by mutableStateOf<List<ServiceAhead>>(emptyList())
    /** Markers for the route bar, and how far along the route you are (updated about once a second). */
    var barEvents by mutableStateOf<List<BarEvent>>(emptyList())
    var barProgress by mutableDoubleStateOf(0.0)
    /** Clean air / low emission zones the chosen route goes into (shown on the route options). */
    var routeZones by mutableStateOf<List<String>>(emptyList())
    /** True while the GPS has dropped out (a tunnel) and the position is being estimated along the route. */
    var deadReckoning by mutableStateOf(false)
    /** Text shared from another app, to be put in the search box. */
    var externalQuery by mutableStateOf<String?>(null)
    /** Goes up each time another app hands over a destination (closes the settings screen). */
    var externalTick by mutableIntStateOf(0)
    /** The stops editor is open. */
    var stopsEditor by mutableStateOf(false)
    /** How the fuel list is sorted: "near" or "cheap". */
    var nearbySort by mutableStateOf("near")
    /** Name of the road you are on (route or map data), for the free-driving card. */
    var roadNow by mutableStateOf("")
    /** Roads you asked to avoid on this trip (as boxes). */
    private val sessionAvoid = ArrayList<Pair<LL, LL>>()

    /** A trip planned with "arrive by": where, when to be there, and when to leave (kept until it starts or is cancelled). */
    class PlannedTrip(val dest: Place, val arriveBy: Long, val leaveBy: Long)
    var planned by mutableStateOf<PlannedTrip?>(null)
    private var plannedJob: Job? = null
    /** A good place to fill up on a long trip (cheapest around the middle of the route, or the quickest detour). */
    var fuelSuggestion by mutableStateOf<Nearby?>(null)
    /** The junction you are coming up to, for the overview inset (null when there is nothing to show). */
    class JunctionView(val centre: LL, val heading: Double, val roads: List<List<LL>>, val path: List<LL>, val step: Int)
    var junction by mutableStateOf<JunctionView?>(null)
    private var wrongCount = 0
    private var wrongAt = 0L

    private class Placed(
        val route: Route, val services: List<PoiOnRoute>, val serviceFuel: Map<RoutePoi, String>, val hz: List<PoiOnRoute>,
        val avg: List<AvgOnRoute>, val stops: List<Double>, val zones: List<Pair<String, Double>>,
    )
    private var rawServices: List<RoutePoi> = emptyList()
    private var servicesFor: Place? = null
    private var servicesBusy = false
    private var servicesRetryAt = 0L
    private var rawHz: List<RoutePoi> = emptyList()
    private var rawAvg: List<AvgDef> = emptyList()
    private var hzWinEnd = -1.0
    private var hzWinRoute: Route? = null
    private var hzBusy = false
    private var hzRetryAt = 0L
    private var hzLastAt = 0L
    private var placed: Placed? = null
    private var placing = false
    private var placedSig = 0
    private var zonesVersion = 0
    private var avgIn: AvgOnRoute? = null
    private var avgEnterAt = 0L
    private var avgEnterProg = 0.0
    private var avgOverWarned = false
    private val avgAlerted = HashSet<Long>()
    private val hzAlerted = HashSet<String>()
    private var lastBumpAt = 0L
    private val zoneAlerted = HashSet<String>()
    private var barSig = 0
    private var servicesSig = 0
    /** Moving at speed on a route: the map UI simplifies itself. */
    val driving: Boolean get() = route != null && (fix?.speed ?: 0.0) > 8.0
    private var lastSpd = 0.0
    private var lastSpdAt = 0L
    private var limitCandidate = -1
    private var candidateHits = 0
    private var announcedLimit = -1
    private var lastBeep = 0L
    private var breakNext = 7200L
    private var tripPts = ArrayList<LL>()

    val route: Route? get() = routes.getOrNull(active)
    val imperial: Boolean get() = prefs.s("distunit", if (defaultUnits() == "imperial") "mi" else "km") == "mi"
    /** 0 = all sound, 1 = alerts only, 2 = off. Falls back to the old on/off voice setting. */
    val soundMode: Int get() = prefs.i("soundmode", if (prefs.b("voice", true)) 0 else 2).coerceIn(0, 2)
    val voiceOn: Boolean get() = soundMode != 2
    fun cycleSound() {
        val n = (soundMode + 1) % 3
        prefs.put("soundmode", n)
        toast(listOf("Sound: all", "Sound: alerts only", "Sound: off")[n], 1800)
    }

    private fun defaultUnits() = "imperial"

    val apiKey: String
        get() = prefs.s("apikey", "").ifBlank { BuildConfig.TOMTOM_API_KEY }.trim()
    val hasKey: Boolean get() = apiKey.isNotEmpty() && !apiKey.startsWith("YOUR_")

    // ---- internals ----
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val said = HashSet<String>()
    private var lastIdx = 0
    private var offCount = 0
    private var lastReroute = 0L
    private var lastDraw = 0L
    private var lastDrawProg = 0.0
    private var simJob: Job? = null
    private var simDist = 0.0
    private var lastRaw: LL? = null
    private var lastGpsTime = 0L
    private var msgToken = 0
    private var lm: LocationManager? = null
    private var weatherAt = 0L
    private var limitAt = 0L
    private var limitPos: LL? = null
    private var camAt = 0L
    private var camPos: LL? = null
    private var cameras: List<LL> = emptyList()
    private val camAlerted = HashSet<LL>()
    private var drove = false
    private var stillSince = 0L
    private var posSavedAt = 0L
    private var tripOn = false
    private var tripT0 = 0L
    private var tripDistance = 0.0
    private var tripMoveSec = 0L
    private var tripTop = 0.0
    private var tripLast: LL? = null
    private var tripDest = ""

    init {
        try {
            val o = org.json.JSONObject(prefs.s("resume", "{}"))
            if (o.has("la") && System.currentTimeMillis() - o.optLong("t") < 3 * 3_600_000L)
                resume = Place(o.optString("n"), o.optString("s"), LL(o.getDouble("la"), o.getDouble("lo")))
        } catch (e: Exception) { }
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                val r = tts?.setLanguage(Locale.getDefault())
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts?.setLanguage(Locale.UK)
                tts?.setAudioAttributes(speechAttrs)
                tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { unduck() }
                    @Deprecated("Deprecated in Java") override fun onError(id: String?) { unduck() }
                })
            }
        }
        map.onLongPress = { p -> startRoute(Place("Dropped pin", "", p)) }
        map.onUserGesture = { if (following) { following = false }; scheduleRecentre(12_000) }
        map.onAltTap = { i -> switchToAlt(i) }
        // the parked-car spot is no longer used (the app lives in the car): drop any old one
        if (prefs.s("place_parked", "").isNotBlank()) places.clearParked()
        map.onError = { msg -> if (hasKey) toast("Map: $msg") else toast("No TomTom key: using the free OpenStreetMap style") }
        try {
            val o = org.json.JSONObject(prefs.s("planned", "{}"))
            if (o.has("la") && o.optLong("a") > System.currentTimeMillis())
                planned = PlannedTrip(Place(o.optString("n"), o.optString("s"), LL(o.getDouble("la"), o.getDouble("lo"))), o.getLong("a"), o.getLong("l"))
        } catch (e: Exception) { }
        if (planned != null) watchPlanned()
        // clean air zones are downloaded once and refreshed monthly
        scope.launch {
            delay(15_000)
            try { if (Zones.needsRefresh(ctx) && online()) { withContext(Dispatchers.IO) { Zones.fetch(ctx) }; zonesVersion++ } } catch (e: Exception) { }
        }
    }

    private val speechAttrs = android.media.AudioAttributes.Builder()
        .setUsage(android.media.AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build()
    private val audioMgr = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
    private var focusReq: android.media.AudioFocusRequest? = null

    /** Lowers the music while a spoken instruction plays, so it can be heard. */
    private fun duck() {
        try {
            val req = android.media.AudioFocusRequest.Builder(android.media.AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(speechAttrs).build()
            focusReq = req
            audioMgr.requestAudioFocus(req)
        } catch (e: Exception) { }
    }

    private fun unduck() {
        try { focusReq?.let { audioMgr.abandonAudioFocusRequest(it) } } catch (e: Exception) { }
        focusReq = null
    }

    /** Puts an alert on screen as a prominent banner. */
    fun raiseAlert(kind: String, text: String, ms: Long = 5000) {
        alert = AlertInfo(kind, text, ms)
        val t = ++alertToken
        scope.launch { delay(ms); if (t == alertToken) alert = null }
    }

    /** Plays a sample alert (chime, banner and voice) so the sound can be checked. */
    fun testAlert() {
        chime(android.media.ToneGenerator.TONE_PROP_PROMPT)
        raiseAlert("camera", "Test alert: speed camera ahead")
        speak("Speed camera ahead", true)
    }

    fun shutdown() {
        stopLocation(); simJob?.cancel(); tts?.shutdown()
    }

    fun toast(msg: String, ms: Long = 4000) {
        message = msg
        val token = ++msgToken
        scope.launch { delay(ms); if (token == msgToken) message = null }
    }

    // ---- style ----
    fun styleUrl(dark: Boolean): String {
        val traffic = prefs.b("traffic", true)
        return if (hasKey && prefs.s("mapstyle", "tomtom") == "tomtom") TomTomRest.styleUrl(apiKey, dark, traffic)
        else if (dark) "https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json"
        else "https://tiles.openfreemap.org/styles/liberty"
    }

    /** ISO country the place search is limited to; blank means anywhere. */
    private fun countryCode(): String = prefs.s("country", "GB")

    private var styleJob: kotlinx.coroutines.Job? = null

    private var lastDark = true

    // ---- offline pack download (runs here so it carries on when you leave the settings page) ----
    var packBusy by mutableStateOf(false)
    var packStatus by mutableStateOf("")
    var packRev by mutableStateOf(0)

    fun downloadPack(url: String) {
        if (packBusy || url.isBlank()) return
        packBusy = true; packStatus = "Starting…"
        scope.launch {
            try {
                withContext(Dispatchers.IO) { OfflineRouter.download(ctx, url) { packStatus = it } }
                packStatus = "Pack ready"
                toast("Offline pack ready", 3000)
            } catch (e: Throwable) {
                packStatus = "Download failed: ${e.message ?: e.javaClass.simpleName}. Tap Download again to carry on."
            } finally { packBusy = false; packRev++; restyle() }
        }
    }

    fun deletePack() {
        if (packBusy) return
        OfflineRouter.deleteAll(ctx)
        packStatus = ""; packRev++; restyle()
    }
    fun restyle() = applyStyle(lastDark)

    /** True when the map should be drawn from the downloaded pack: always, or (in auto) when there is no signal. */
    fun useOfflineMap(): Boolean {
        if (!OfflineMap.installed(ctx) || !OfflineMap.hasFonts(ctx)) return false
        return when (prefs.s("offmap", "auto")) { "always" -> true; "never" -> false; else -> !online() }
    }

    private var netWatching = false
    /** Switches between the online and downloaded map by itself when the connection comes or goes. */
    fun watchNetwork() {
        if (netWatching) return
        netWatching = true
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            cm.registerDefaultNetworkCallback(object : android.net.ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: android.net.Network) { scope.launch { delay(2000); applyStyle(lastDark) } }
                override fun onLost(network: android.net.Network) { scope.launch { delay(800); applyStyle(lastDark) } }
            })
        } catch (e: Exception) { }
    }

    fun applyStyle(dark: Boolean) {
        lastDark = dark
        map.nightStyle = dark
        watchNetwork()
        styleJob?.cancel()
        if (useOfflineMap()) { map.setStyleUrl(OfflineMap.styleJson(ctx, dark)); return }
        if (prefs.s("mapstyle", "tomtom") != "google") { map.setStyleUrl(styleUrl(dark)); return }
        val gkey = prefs.s("gkey", "").trim()
        if (gkey.isEmpty()) { toast("Add a Google Maps API key in Settings", 4000); map.setStyleUrl(styleUrl(dark)); return }
        styleJob = scope.launch {
            val json = withContext(Dispatchers.IO) { GoogleTiles.styleJson(gkey, dark, prefs.b("traffic", true), Locale.getDefault()) }
            if (json == null) {
                toast("Google Maps failed: check the key and that Map Tiles API is enabled", 6000)
                map.setStyleUrl(styleUrl(dark))
            } else map.setStyleUrl(json)
        }
    }

    // ---- location ----
    @SuppressLint("MissingPermission")
    fun startLocation() {
        if (lm != null) return
        val m = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        lm = m
        try {
            if (m.allProviders.contains(LocationManager.GPS_PROVIDER))
                m.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper())
            if (m.allProviders.contains(LocationManager.NETWORK_PROVIDER))
                m.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 0f, this, Looper.getMainLooper())
            (m.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: m.getLastKnownLocation(LocationManager.NETWORK_PROVIDER))
                ?.let { handleLocation(it, true) }
        } catch (e: SecurityException) {
            lm = null
            toast("Location permission is needed for navigation")
        } catch (e: Exception) {
            lm = null
            android.util.Log.w("NavEngine", "startLocation failed", e)
        }
    }

    fun stopLocation() {
        try { lm?.removeUpdates(this) } catch (_: Exception) {}
        lm = null
    }

    override fun onLocationChanged(l: Location) = handleLocation(l, false)

    private fun handleLocation(l: Location, first: Boolean) {
        try { handleLocationInner(l, first) } catch (e: Exception) { android.util.Log.w("NavEngine", "location handling failed", e) }
    }

    private fun handleLocationInner(l: Location, first: Boolean) {
        run {
            val t = System.currentTimeMillis()
            if (t - posSavedAt > 600_000) {
                posSavedAt = t
                prefs.put("lastlat", Math.round(l.latitude * 10) / 10.0)
                prefs.put("lastlon", Math.round(l.longitude * 10) / 10.0)
            }
        }
        if (simMode != 0) return
        val now = System.currentTimeMillis()
        if (l.provider == LocationManager.GPS_PROVIDER) lastGpsTime = now
        else if (now - lastGpsTime < 10000) return
        // with the GPS gone (a tunnel) a rough mobile-network position would throw the route off: keep estimating along the route instead
        else if (route != null && !previewing && glideOnRoute && now - lastGpsTime < 120_000 && (!l.hasAccuracy() || l.accuracy > 30f)) return
        val cur = LL(l.latitude, l.longitude)
        var h = fix?.heading ?: 0.0
        if (l.hasBearing() && l.hasSpeed() && l.speed > 1.0f) h = l.bearing.toDouble()
        else lastRaw?.let { if (Geo.dist(it, cur) > 6) h = Geo.bearing(it, cur) }
        val prev = lastRaw
        if (prev == null || Geo.dist(prev, cur) > 6) lastRaw = cur
        val speed = if (l.hasSpeed()) l.speed.toDouble() else 0.0
        if (prev != null && speed > 0.8) {
            val d = Geo.dist(prev, cur)
            if (d in 3.0..200.0) { tripDist += d; tripMoving += 1.0 }
        }
        if (speed > tripMax) tripMax = speed
        val firstFix = fix == null
        onPosition(Fix(cur, h, speed, if (l.hasAltitude()) l.altitude else 0.0, if (l.hasAccuracy()) l.accuracy.toDouble() else 0.0), firstFix || first)
        if (firstFix) {
            map.cameraTo(cur, null, if (tilt3d) 55.0 else 0.0, 15.5, 0, 0.0)
        }
        // current weather is only used for the rain effect on the map, so it is only fetched when that is switched on
        if (prefs.b("rainfx", false) && now - weatherAt > 20 * 60 * 1000L) {
            weatherAt = now
            scope.launch { weather = withContext(Dispatchers.IO) { Weather.fetch(cur) } ?: weather }
        }
    }

    // ---- extras: journey times, rain at destination, stops, arriving home ----
    private fun loadRain(to: Place, routeSecs: Double) {
        destRain = null
        scope.launch {
            val f = withContext(Dispatchers.IO) { Weather.forecast(to.pos) } ?: return@launch
            val idx = Math.round(routeSecs / 3600.0).toInt().coerceIn(0, f.hours.size - 1)
            val h = f.hours.getOrNull(idx) ?: return@launch
            val wet = h.code in 51..67 || h.code in 80..82 || h.code in 95..99
            val snow = h.code in 71..77 || h.code in 85..86
            if (h.rain >= 50 || wet || snow) destRain = (if (snow) "Snow" else "Rain") + " likely at arrival (${h.rain}%)"
        }
    }

    /** Forecast at points along the route, timed for when you will be there. */
    private fun loadRouteWeather(r: Route) {
        routeWx = emptyList()
        if (!prefs.b("routewx", true) || r.cum.isEmpty()) return
        val total = r.cum.last()
        if (total < 10_000) return
        val fracs = if (total < 40_000) listOf(0.5, 1.0) else listOf(0.25, 0.5, 0.75, 1.0)
        scope.launch {
            val out = ArrayList<RouteWx>()
            for (fr in fracs) {
                val secs = r.time * fr
                val pos = pointAt(r, total * fr).first
                val f = withContext(Dispatchers.IO) { Weather.forecast(pos) } ?: continue
                val h = f.hours.getOrNull(Math.round(secs / 3600.0).toInt().coerceIn(0, f.hours.size - 1)) ?: continue
                out += RouteWx(Math.round(secs / 60.0).toInt(), h.code, h.temp, h.rain)
            }
            routeWx = out
        }
    }

    private fun chime(tone: Int = android.media.ToneGenerator.TONE_PROP_ACK) {
        if (soundMode == 2) return
        try { android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 100).startTone(tone, 250) } catch (e: Exception) { }
    }

    private fun checkLimitChange(newMs: Double, estimated: Boolean) {
        if (!prefs.b("limitchange", true) || estimated) return
        val k = if (imperial) 2.23694 else 3.6
        val n = (Math.round(newMs * k / 5.0) * 5).toInt()
        if (announcedLimit < 0) { announcedLimit = n; return }
        if (n == announcedLimit) { candidateHits = 0; limitCandidate = -1; return }
        if (n == limitCandidate) candidateHits++ else { limitCandidate = n; candidateHits = 1 }
        if (candidateHits >= 2 && (fix?.speed ?: 0.0) > 3.0) {
            announcedLimit = n; candidateHits = 0; limitCandidate = -1
            chime()
            raiseAlert("limit", "Speed limit $n")
            speak("Speed limit $n", true)
            limitPulse = true
            scope.launch { delay(3500); limitPulse = false }
        }
    }

    fun addStop(p: Place) {
        val d = dest ?: return
        via = via + p
        stopMode = false
        clearNearby()
        toast("Stop added: ${p.name}", 2500)
        startRoute(d, departMin, true, startNow = route != null && !previewing)
    }

    /** Replaces the stops on the way (in order) and works the route out again. */
    fun setStops(stops: List<Place>) {
        val d = dest ?: return
        via = stops
        startRoute(d, departMin, true, startNow = route != null && !previewing)
    }

    /** Which clean air / low emission zones the chosen route goes into, for the route options. */
    private fun updateRouteZones() {
        val r = route ?: run { routeZones = emptyList(); return }
        scope.launch {
            val names = withContext(Dispatchers.Default) { try { Zones.entries(r, Zones.all(ctx)).map { it.first.name }.distinct() } catch (e: Exception) { emptyList() } }
            if (route === r) routeZones = names
        }
    }

    /** Works the route out again without the road you are on now (the stretch up to the next turn). */
    fun avoidRoadAhead() {
        val r = route ?: return
        if (previewing) return
        val d = dest ?: return
        if (fix == null) { toast("No GPS fix yet"); return }
        val p0 = curProgress + 60.0
        val toTurn = turn?.dist ?: 1500.0
        val p1 = p0 + toTurn.coerceIn(300.0, 3000.0)
        var minLat = 90.0; var maxLat = -90.0; var minLon = 180.0; var maxLon = -180.0
        for (i in r.pts.indices) {
            if (r.cum[i] < p0 || r.cum[i] > p1) continue
            val q = r.pts[i]
            minLat = min(minLat, q.lat); maxLat = max(maxLat, q.lat); minLon = min(minLon, q.lon); maxLon = max(maxLon, q.lon)
        }
        if (minLat > maxLat) { toast("Nothing to avoid ahead", 2500); return }
        val pad = 0.0004
        sessionAvoid += LL(minLat - pad, minLon - pad) to LL(maxLat + pad, maxLon + pad)
        toast("Looking for a way round…", 2500)
        startRoute(d, 0, true, startNow = true)
    }

    fun resetTrip() { tripDist = 0.0; tripMax = 0.0; tripMoving = 0.0; tripStart = System.currentTimeMillis() }

    // ---- search + routing ----
    /** True when the device has a network that claims internet access (it can still be too weak to use). */
    fun online(): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val n = cm.activeNetwork
            if (n == null) false else cm.getNetworkCapabilities(n)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        } catch (e: Exception) { true }
    }

    /** True on Wi-Fi or another network that isn't metered (safe for the big offline download). */
    fun onWifi(): Boolean = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        caps != null && (caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET) ||
            caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_METERED))
    } catch (e: Exception) { false }

    /** How many days old the downloaded offline pack is, or null when there isn't one. */
    fun packAgeDays(): Int? {
        if (!OfflineRouter.installed(ctx)) return null
        val t = java.io.File(OfflineRouter.dir(ctx), "tiles.tar").lastModified()
        if (t <= 0L) return null
        return ((System.currentTimeMillis() - t) / 86_400_000L).toInt()
    }

    /** The offline pack is old enough to be worth updating (about 4 months), and the reminder wasn't put off in the last 30 days. */
    fun packNeedsUpdate(): Boolean {
        val age = packAgeDays() ?: return false
        if (age < 120 || packBusy) return false
        val snoozed = prefs.s("packnag", "0").toLongOrNull() ?: 0L
        return System.currentTimeMillis() - snoozed > 30L * 86_400_000L
    }

    fun snoozePackUpdate() { prefs.put("packnag", System.currentTimeMillis().toString()) }

    /** Updates the offline pack for the area chosen in Settings. */
    fun updatePack() = downloadPack(if (prefs.s("packregion", "ew") == "gb") OfflineRouter.DEFAULT_PACK_GB else OfflineRouter.DEFAULT_PACK)

    /** Places that can be found without signal: saved, favourite and previously used ones, then the downloaded UK towns and villages. */
    private suspend fun offlineMatches(q: String, near: LL?): List<Place> = withContext(Dispatchers.IO) {
        try {
            val own = places.searchLocal(q, near)
            val addr = OfflineRouter.searchAddresses(ctx, q, near).filter { t -> own.none { Geo.dist(it.pos, t.pos) < 30 } }
            val pack = OfflineRouter.searchPlaces(ctx, q, near).filter { t -> own.none { Geo.dist(it.pos, t.pos) < 150 } }
            val towns = OfflinePlaces.search(ctx, q, near).filter { t -> own.none { Geo.dist(it.pos, t.pos) < 400 } && pack.none { Geo.dist(it.pos, t.pos) < 1500 && it.name.equals(t.name, true) } }
            own + addr + pack + towns
        } catch (e: Throwable) { emptyList() }
    }

    private var searchJob: kotlinx.coroutines.Job? = null

    /** Puts exact and "starts with" name matches first (nearest first), then the rest with online results ahead of offline ones. */
    private fun rankResults(q: String, near: LL?, net: List<Place>, extra: List<Place>): List<Place> {
        val full = q.trim().lowercase()
        val all = ArrayList<Pair<Place, Int>>()
        net.forEachIndexed { i, p -> all += p to i }
        extra.forEachIndexed { i, p -> if (all.none { it.first.name.equals(p.name, true) && Geo.dist(it.first.pos, p.pos) < 300 || Geo.dist(it.first.pos, p.pos) < 40 }) all += p to (1000 + i) }
        fun strong(p: Place) = p.name.lowercase().let { it == full || it.startsWith(full) }
        fun d(p: Place) = if (near != null) Geo.dist(near, p.pos) else 0.0
        val top = all.filter { strong(it.first) }.sortedBy { d(it.first) }
        val rest = all.filter { !strong(it.first) }.sortedBy { it.second }
        return (top + rest).map { it.first }.take(15)
    }

    fun search(q: String) {
        if (q.length < 2) { results = emptyList(); return }
        val near = fix?.pos ?: map.center()
        searchJob?.cancel()
        searchJob = scope.launch {
            val offline = !online() || !hasKey
            if (offline) {
                val local = offlineMatches(q, near)
                results = local
                if (!hasKey) toast("Search needs a TomTom API key (Settings)")
                else if (local.isEmpty()) toast(if (OfflinePlaces.installed(ctx) || OfflineRouter.hasPlaces(ctx) || OfflineRouter.hasAddresses(ctx)) "No signal, and nothing saved or downloaded matches" else "No signal. Download UK places in Map settings > Data & keys to search towns offline", 4500)
                else toast("No signal: showing saved places and offline towns", 3000)
                return@launch
            }
            // the online search and the saved / downloaded places run at the same time, and their results are merged
            val localJob = async { offlineMatches(q, near) }
            val net = try { withContext(Dispatchers.IO) { TomTomRest.geocode(apiKey, countryCode(), q, near) } } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { null }
            val local = localJob.await()
            val merged = rankResults(q, near, net ?: emptyList(), local)
            results = merged
            if (merged.isEmpty()) toast(if (net == null) "Search failed: weak or no signal" else "No matches. Try adding a town or postcode.", 3500)
            else if (net == null) toast("Weak signal: showing saved places and offline towns", 3500)
        }
    }

    /** Search used by the stops editor: the same sources as the search box, returned instead of shown. */
    suspend fun findPlaces(q: String): List<Place> {
        val near = fix?.pos ?: map.center()
        if (!online() || !hasKey) return offlineMatches(q, near)
        val local = offlineMatches(q, near)
        val net = try { withContext(Dispatchers.IO) { TomTomRest.geocode(apiKey, countryCode(), q, near) } } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { null }
        return rankResults(q, near, net ?: emptyList(), local)
    }

    // a destination chosen with no signal is kept and routed as soon as the connection comes back
    var waitingFor by mutableStateOf<Place?>(null)
    private var waitJob: kotlinx.coroutines.Job? = null

    private fun waitForSignal(to: Place, departInMin: Int, keepVia: Boolean) {
        waitingFor = to
        waitJob?.cancel()
        waitJob = scope.launch {
            var tries = 0
            while (waitingFor === to && tries < 150) {
                delay(8000); tries++
                if (online() && !busy) { startRoute(to, departInMin, keepVia); delay(6000) }
            }
            if (waitingFor === to) waitingFor = null
        }
    }

    fun cancelWaiting() { waitingFor = null; waitJob?.cancel() }

    fun pickPlace(p: Place) {
        val slot = pendingSave
        if (slot != null) {
            places.setSlot(slot, p)
            pendingSave = null
            results = emptyList()
            toast("${if (slot == "home") "Home" else "Work"} saved: ${p.name}", 3500)
        } else startRoute(p)
    }

    fun setDeparture(minutes: Int) {
        val d = dest ?: return
        startRoute(d, minutes, true)
    }

    /** Pushes the route preferences from Settings into the routing client. */
    private fun syncRoutePrefs(from: LL? = null, to: LL? = null) {
        // areas to keep out of: roads you asked to avoid on this trip, and clean air zones when that is switched on
        // (a zone you start or finish in cannot be avoided, so it is left out)
        val rects = ArrayList<Pair<LL, LL>>(sessionAvoid)
        val rings = ArrayList<List<LL>>()
        for ((sw, ne) in sessionAvoid) rings += listOf(sw, LL(sw.lat, ne.lon), ne, LL(ne.lat, sw.lon), sw)
        if (prefs.b("avoidzones", false)) {
            for (z in Zones.all(ctx)) {
                if ((from != null && Zones.inside(z, from)) || (to != null && Zones.inside(z, to))) continue
                if (z.maxLat - z.minLat > 1.2 || z.maxLon - z.minLon > 1.8) continue
                rects += LL(z.minLat, z.minLon) to LL(z.maxLat, z.maxLon)
                rings.addAll(z.rings)
            }
        }
        TomTomRest.avoidRects = rects.take(10)
        OfflineRouter.exclude = rings
        TomTomRest.avoid = listOfNotNull(
            if (prefs.b("avoid_toll", false)) "tollRoads" else null,
            if (prefs.b("avoid_motorway", false)) "motorways" else null,
            if (prefs.b("avoid_ferry", false)) "ferries" else null,
            if (prefs.b("avoid_unpaved", true)) "unpavedRoads" else null,
        )
        TomTomRest.routeType = if (prefs.b("route_eco", false)) "eco" else "fastest"
    }

    fun startRoute(to: Place, departInMin: Int = 0, keepVia: Boolean = false, startNow: Boolean = false) {
        syncRoutePrefs(fix?.pos ?: map.center(), to.pos)
        resume = null
        if (!keepVia) via = emptyList()
        if (!hasKey && !OfflineRouter.installed(ctx)) { toast("Routing needs a TomTom API key (Settings)"); return }
        val from = fix?.pos ?: map.center() ?: return
        if (fix == null) toast("No GPS fix yet: routing from the map centre. Use the demo drive to simulate.", 5000)
        busy = true
        scope.launch {
            try {
                val departMs = if (departInMin > 0) System.currentTimeMillis() + departInMin * 60_000L else 0L
                var usedOffline = false
                val rs = withContext(Dispatchers.IO) {
                    val haveOffline = OfflineRouter.installed(ctx)
                    if (haveOffline && (!hasKey || !online())) { usedOffline = true; OfflineRouter.routes(ctx, from, to.pos, via.map { it.pos }) }
                    else try { TomTomRest.routes(apiKey, from, to.pos, true, departMs, via.map { it.pos }) }
                    catch (e: Exception) {
                        if (haveOffline && (e.message ?: "").contains("signal")) { usedOffline = true; OfflineRouter.routes(ctx, from, to.pos, via.map { it.pos }) } else throw e
                    }
                }
                if (rs.isEmpty()) throw IllegalStateException("No route found")
                if (usedOffline) toast("Offline route: no traffic or live data", 4000)
                if (rs[0].steps.isEmpty()) toast("This key returned no turn instructions. Check it has TomTom Routing API access", 6000)
                if (departInMin > 0 && !usedOffline && !TomTomRest.departApplied) toast("Departure time not supported here: showing live traffic", 4000)
                departMin = departInMin
                departAtMs = if (!usedOffline && TomTomRest.departApplied) departMs else 0L
                if (to.name != "Dropped pin") places.addRecent(to)
                if (!keepVia) habits.record(to)
                loadRain(to, rs[0].time)
                loadRouteWeather(rs[0])
                fuelSuggestion = null
                clearLiveAlts()
                if (prefs.b("smartfuel", true)) suggestFuel(rs[0])
                clearNearby()
                results = emptyList()
                stopSim()
                if (TomTomRest.avoidDropped && !usedOffline) toast("Couldn't find a way round the areas you're avoiding, so the route goes through them", 5000)
                dest = to; routes = rs; active = 0
                prediction = null; predictionAt = 0L
                updateRouteZones()
                said.clear(); offCount = 0; lastIdx = 0
                turn = null; eta = null; routeFrac = 0f
                map.setDest(to.pos)
                drawRoutes()
                following = false
                previewing = true
                val allPts = rs.take(3).flatMap { r -> r.pts.filterIndexed { i, _ -> i % 8 == 0 } + r.pts.last() }
                delay(350)
                // a short fly-through along the new route first (not when stops change mid-drive)
                if (!startNow && prefs.b("cinematic", true)) {
                    val r0 = rs[0]
                    map.flyRoute(r0.pts, r0.cum, r0.len, if (prefs.b("maplite", true)) 50.0 else 60.0) { if (previewing && routes === rs) map.fit(allPts) }
                } else map.fit(allPts)
                waitingFor = null; waitJob?.cancel()
                // changing stops while already driving carries straight on, without the route options in between
                if (startNow) beginNavigation()
            } catch (e: Exception) {
                val m = e.message ?: ""
                if (m.contains("signal")) {
                    toast("No signal: this route will start by itself as soon as there is a connection", 6000)
                    if (waitingFor !== to) waitForSignal(to, departInMin, keepVia)
                } else toast("Route failed: $m", 6000)
            } finally { busy = false }
        }
    }

    fun selectRoute(i: Int) {
        if (i !in routes.indices) return
        map.stopFly()
        active = i; lastIdx = 0
        updateRouteZones()
        drawRoutes()
        val r = routes[i]
        map.fit(r.pts.filterIndexed { n, _ -> n % 6 == 0 } + r.pts.last())
    }

    fun beginNavigation() {
        if (!previewing) return
        map.stopFly()
        previewing = false
        said.clear(); lastIdx = 0; zoomOffset = 0.0
        navStartMs = System.currentTimeMillis(); navStartDist = tripDist
        lastFasterCheck = System.currentTimeMillis(); faster = null; lastTrafficAt = 0L
        dest?.let { d -> prefs.put("resume", org.json.JSONObject().put("n", d.name).put("s", d.sub).put("la", d.pos.lat).put("lo", d.pos.lon).put("t", System.currentTimeMillis()).toString()) }
        following = true
        routeWx.firstOrNull { it.code in 51..67 || it.code in 80..82 || it.code in 95..99 || it.code in 71..77 || it.code in 85..86 || it.rain >= 70 }?.let {
            val snow = it.code in 71..77 || it.code in 85..86
            raiseAlert("rain", (if (snow) "Snow" else "Rain") + " expected in about ${it.minutes} min on your route", 6000)
            speak((if (snow) "Snow" else "Rain") + " expected in about ${it.minutes} minutes on your route", true)
        }
        val f = fix
        if (f != null) onPosition(f, true)
        else { updateGuidance(0.0); toast("No GPS fix yet. Use the play button for a demo drive.", 5000) }
    }

    private fun drawRoutes() {
        val r = route ?: return
        map.setRoute(r.pts, routes.filterIndexed { i, _ -> i != active }.map { it.pts }, r.sev)
    }

    fun cycleRoute() {
        if (routes.size < 2) { toast("No alternative routes. Switch on 'Alternatives' first."); return }
        active = (active + 1) % routes.size
        said.clear(); lastIdx = 0
        drawRoutes()
        fix?.let { onPosition(it, true) } ?: updateGuidance(0.0)
    }

    fun toggleAlternatives() {
        alternatives = !alternatives
        toast(if (alternatives) "Alternative routes on" else "Alternative routes off", 2500)
        val d = dest
        if (d != null) startRoute(d, 0, true)
    }

    private var rerouting = false

    private fun reroute() {
        val d = dest ?: return
        if (rerouting || fix == null) return
        if (System.currentTimeMillis() - lastReroute < 4000) return
        lastReroute = System.currentTimeMillis()
        rerouting = true
        syncRoutePrefs(fix?.pos, d.pos); faster = null
        toast("Rerouting…", 2500)
        scope.launch {
            var err: String? = null
            try {
                for (attempt in 1..3) {
                    val f = fix ?: break
                    try {
                        val hd = if (f.speed > 2.0) f.heading else -1.0
                        val rs = withContext(Dispatchers.IO) {
                            val haveOffline = OfflineRouter.installed(ctx)
                            if (haveOffline && (!hasKey || !online())) OfflineRouter.routes(ctx, f.pos, d.pos, via.map { it.pos }, hd)
                            else try { TomTomRest.routes(apiKey, f.pos, d.pos, false, 0L, via.map { it.pos }, hd, true) }
                            catch (e: Exception) {
                                if (haveOffline && (e.message ?: "").contains("signal")) OfflineRouter.routes(ctx, f.pos, d.pos, via.map { it.pos }, hd) else throw e
                            }
                        }
                        if (rs.isNotEmpty()) { routes = rs; active = 0; said.clear(); offCount = 0; lastIdx = 0; clearLiveAlts(); drawRoutes(); err = null; break }
                        err = "no route found"
                    } catch (e: Exception) { err = e.message ?: "unknown error" }
                    if (attempt < 3) delay(2500)
                }
            } finally { rerouting = false; lastReroute = System.currentTimeMillis() }
            // it keeps trying on its own while you are still off the route, so this is only a heads-up
            if (err != null) toast(if (err.contains("signal")) "Rerouting: weak signal, still trying…" else "Reroute failed ($err), trying again…", 3500)
        }
    }

    fun endRoute() {
        cancelWaiting()
        map.stopFly()
        faster = null; resume = null; prefs.put("resume", "{}")
        incMatches = emptyList(); incidentAhead = null; incAt = 0L; incAlerted.clear()
        routeCams = emptyList(); camsRoute = null; camsAt = 0L; hazardSig = 0; policeSig = 0; map.setHazards(emptyList())
        via = emptyList(); stopMode = false; destRain = null; routeWx = emptyList()
        routes = emptyList(); active = 0; dest = null; turn = null; eta = null; lastIdx = 0; previewing = false; routeFrac = 0f; onRoad = ""
        departMin = 0; departAtMs = 0L
        fuelSuggestion = null; junction = null
        clearLiveAlts(); liveSaid.clear(); radar = emptyList(); radarSig = 0; bendsFor = null; bends = emptyList()
        flushRoads()
        sessionAvoid.clear(); routeZones = emptyList(); avgInfo = null; avgIn = null; servicesAhead = emptyList(); barEvents = emptyList()
        rawServices = emptyList(); servicesFor = null; rawHz = emptyList(); rawAvg = emptyList(); hzWinRoute = null; hzWinEnd = -1.0
        placed = null; placedSig = 0; avgAlerted.clear(); hzAlerted.clear(); zoneAlerted.clear(); stopsEditor = false
        map.setRoute(emptyList(), emptyList()); map.setDest(null); map.setTurnPulse(false); laneKey = null; map.setLanes(emptyList())
        stopSim()
        tts?.stop()
        glideRoute = null; glideOnRoute = false
        refreshRoad()
        map.setTilt(if (tilt3d) 55.0 else 0.0)
    }

    // ---- camera controls ----
    fun recenter() {
        following = true
        zoomOffset = 0.0
        val f = fix
        if (f != null) onPosition(f, true) else toast("No GPS fix yet")
    }

    private var recentreToken = 0

    /** While navigating, snaps the map back to the car after you stop moving it for [ms]. */
    private fun scheduleRecentre(ms: Long) {
        if (route == null || previewing) return
        val t = ++recentreToken
        scope.launch { delay(ms); if (t == recentreToken && !following && route != null && !previewing) recenter() }
    }

    /** Shows the rest of the route on screen, then goes back to following the car after a few seconds. */
    fun overview() {
        val r = route ?: return
        val pts = listOfNotNull(fix?.pos) + r.pts.drop(lastIdx.coerceIn(0, max(0, r.pts.size - 2))).filterIndexed { n, _ -> n % 6 == 0 } + r.pts.last()
        following = false
        map.fit(pts)
        scheduleRecentre(10_000)
    }

    fun toggleNorthUp() {
        northUp = !northUp
        if (northUp) map.resetNorth() else fix?.let { onPosition(it, true) }
    }

    fun toggleTilt() {
        tilt3d = !tilt3d
        map.setTilt(if (tilt3d) 55.0 else 0.0)
        if (following) fix?.let { onPosition(it, true) }
    }

    fun zoom(delta: Double) {
        if (following && fix != null) { zoomOffset = (zoomOffset + delta).coerceIn(-4.0, 3.0); fix?.let { onPosition(it, true) } }
        else map.zoomBy(delta)
    }


    // ---- speed limit, speed cameras (real GPS + OpenStreetMap) ----
    private fun updateRoadInfo(p: Fix) {
        val now = System.currentTimeMillis()
        if (simMode == 0) {
            val dt = (now - lastSpdAt) / 1000.0
            if (lastSpdAt > 0 && dt in 0.3..2.5 && lastSpd > 8.0 && (lastSpd - p.speed) / dt > 3.2 && !brakeFlash) {
                brakeFlash = true
                scope.launch { delay(1400); brakeFlash = false }
            }
            lastSpd = p.speed; lastSpdAt = now
        }
        run {
            val lim = speedLimit
            val tolUnits = prefs.s("warntol", "5").toIntOrNull() ?: 5
            val tol = tolUnits * (if (imperial) 0.44704 else 0.27778)
            val over = prefs.b("speedwarn", true) && lim != null && !limitEstimated && p.speed > lim + tol && p.speed > 4.0
            overLimit = over
            if (over && soundMode != 2 && now - lastBeep > 9000) {
                lastBeep = now
                try { android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 100).startTone(android.media.ToneGenerator.TONE_PROP_BEEP2, 250) } catch (e: Exception) { }
            }
        }
        val lp = limitPos
        if (now - limitAt > 12000 && (lp == null || Geo.dist(lp, p.pos) > 50) && (p.speed > 0.5 || lp == null)) {
            limitAt = now; limitPos = p.pos
            scope.launch {
                val hd = if (p.speed > 2.0) p.heading else -1.0
                val r = withContext(Dispatchers.IO) {
                    // OpenStreetMap supplies the road name and a fallback; TomTom's own road data supplies the posted limit when it has one
                    val osm = Overpass.speedLimit(p.pos, hd)
                    val tt = if (hasKey && online()) try { TomTomRest.speedLimit(apiKey, p.pos, hd) } catch (e: Exception) { null } else null
                    if (tt != null) Overpass.Limit(tt, false, osm?.road ?: "") else osm
                }
                if (r != null) { limitRoad = r.road; refreshRoad(); checkLimitChange(r.ms, r.estimated); speedLimit = r.ms; limitEstimated = r.estimated; limitOkAt = System.currentTimeMillis(); limitOkPos = p.pos; limitFails = 0 }
                else {
                    // keep showing the last known limit through a failed lookup; only drop it once it is clearly out of date (10 minutes or 3 km)
                    val okPos = limitOkPos
                    if (System.currentTimeMillis() - limitOkAt > 600_000 || (okPos != null && Geo.dist(okPos, p.pos) > 3000)) { speedLimit = null; limitEstimated = false }
                    val err = Overpass.lastError
                    if (err != null) {
                        // the lookup itself failed: try again soon instead of waiting until the car has moved
                        limitFails++
                        limitPos = null
                        limitAt = System.currentTimeMillis() + minOf(limitFails * 8000L, 60_000L)
                    }
                }
            }
        }
        try { checkPolice(p) } catch (e: Exception) { }
        try { checkWrongWay(p) } catch (e: Exception) { }
        if (!prefs.b("cameras", true)) { cameraDist = null; return }
        val cp = camPos
        if (now - camAt > 120000 && (cp == null || Geo.dist(cp, p.pos) > 1500)) {
            camAt = now; camPos = p.pos
            scope.launch { cameras = withContext(Dispatchers.IO) { Overpass.cameras(p.pos, 3000) } }
        }
        var best: LL? = null
        var bestD = 1e9
        if (p.speed > 4.0) {
            for (c in cameras) {
                val d = Geo.dist(p.pos, c)
                if (d > 450 || d >= bestD) continue
                val diff = abs(((Geo.bearing(p.pos, c) - p.heading + 540.0) % 360.0) - 180.0)
                if (diff < 45) { best = c; bestD = d }
            }
        }
        cameraDist = if (best != null) bestD.toInt() else null
        if (best != null) {
            if (camAlerted.size > 100) camAlerted.clear()
            if (camAlerted.add(best)) { chime(android.media.ToneGenerator.TONE_PROP_PROMPT); raiseAlert("camera", "Speed camera ahead"); speak("Speed camera ahead", true) }
        }
    }

    private fun trackParking(p: Fix) {
        if (simMode != 0) return
        val now = System.currentTimeMillis()
        // ---- trip recording ----
        if (tripOn) {
            val last = tripLast
            if (last != null) {
                val d = Geo.dist(last, p.pos)
                if (d in 2.0..250.0) tripDistance += d
            }
            tripLast = p.pos
            if (p.speed > 1.0) tripMoveSec += 1
            if (p.speed > tripTop) tripTop = p.speed
            val lp = tripPts.lastOrNull()
            if ((lp == null || Geo.dist(lp, p.pos) > 80) && tripPts.size < 3000) tripPts.add(p.pos)
            if (tripMoveSec >= breakNext && prefs.b("breakremind", true)) {
                val hrs = breakNext / 3600
                breakNext += 7200
                raiseAlert("break", "You have been driving for $hrs hours. Time for a break?", 8000)
                speak("You have been driving for $hrs hours. Consider taking a break.", true)
                if (route == null) loadNearby("fuel", false)
            }
        } else if (p.speed > 3.0) {
            tripOn = true; tripT0 = now; tripDistance = 0.0; tripMoveSec = 0; tripTop = p.speed; tripLast = p.pos
            breakNext = 7200L; tripPts = arrayListOf(p.pos)
        }
        // ---- end of trip (stopped for two minutes) ----
        if (p.speed > 4.0) { drove = true; stillSince = 0L }
        else if (p.speed < 0.8 && drove) {
            if (stillSince == 0L) stillSince = now
            else if (now - stillSince > 120_000) {
                if (tripOn && tripDistance > 300) {
                    trips.add(Trip(tripT0, stillSince, tripDistance, tripMoveSec, tripTop, tripDest))
                }
                tripOn = false
                drove = false; stillSince = 0L
            }
        }
        if (dest != null) tripDest = dest?.name.orEmpty()
    }

    /** Finds [q] and starts routing there (used for calendar appointments). */
    fun routeToText(q: String, then: () -> Unit) {
        if (!hasKey) { toast("Search needs a TomTom API key (Settings)"); return }
        scope.launch {
            try {
                val p = withContext(Dispatchers.IO) { TomTomRest.geocode(apiKey, countryCode(), q, fix?.pos ?: map.center()) }.firstOrNull()
                if (p == null) toast("Could not find \"$q\"", 3500) else { then(); startRoute(p) }
            } catch (e: Exception) { toast("Search failed: ${e.message}", 4000) }
        }
    }

    /** Finds a place by text and returns it with the driving time in minutes from here. */
    suspend fun travelTo(q: String): Pair<Place, Int>? = withContext(Dispatchers.IO) {
        try {
            val from = fix?.pos ?: return@withContext null
            val pl = TomTomRest.geocode(apiKey, countryCode(), q, from).firstOrNull() ?: return@withContext null
            val r = TomTomRest.routes(apiKey, from, pl.pos, false).firstOrNull() ?: return@withContext null
            Pair(pl, Math.round(r.time / 60.0).toInt())
        } catch (e: Exception) { null }
    }

    // ---- nearby fuel / charging / parking ----
    fun clearNearby() { nearby = emptyList(); nearbyKind = null; nearbyBusy = false; stopMode = false }

    private fun distToRoute(r: Route, p: LL): Double {
        var best = 1e9
        var i = lastIdx.coerceIn(0, max(0, r.pts.size - 1))
        while (i < r.pts.size) { best = min(best, Geo.dist(r.pts[i], p)); i += 3 }
        return best
    }

    /**
     * Finds fuel, chargers, parking, food, coffee, toilets or services. With a route, it looks along the road ahead
     * (sorted by how far ahead, with roughly how long the detour adds); otherwise around you.
     * Fuel uses live Fuel Finder prices when you have added your Fuel Finder details in Settings.
     */
    fun loadNearby(kind: String, nearDest: Boolean) {
        val centre = (if (nearDest) dest?.pos else null) ?: fix?.pos ?: map.center() ?: run { toast("No position yet"); return }
        val origin = fix?.pos ?: centre
        val rt = route
        val alongRoute = rt != null && !nearDest && kind != "parking"
        val progress = if (rt != null && !previewing) curProgress else 0.0
        val radius = if (nearDest) 900 else if (kind == "parking") 2000 else if (kind == "toilets" || kind == "coffee") 3000 else 6000
        val fuelLive = kind == "fuel" && FuelFinder.configured(prefs)
        val fuelType = prefs.s("fueltype", "E10")
        nearbyKind = kind; nearbyBusy = true; nearby = emptyList()
        scope.launch {
            try {
                val list = kotlinx.coroutines.withTimeoutOrNull(30_000L) { withContext(Dispatchers.IO) {
                    if (fuelLive) {
                        try { FuelFinder.refresh(ctx, prefs) } catch (e: Exception) { /* use what is stored */ }
                        val st = FuelFinder.stations(ctx)
                        if (st.isNotEmpty()) {
                            val out = ArrayList<Nearby>()
                            // only stations inside the box around the next 120 km of route are checked against the route itself
                            var bMinLat = 90.0; var bMaxLat = -90.0; var bMinLon = 180.0; var bMaxLon = -180.0
                            if (alongRoute && rt != null) for (i in rt.pts.indices) {
                                if (rt.cum[i] < progress - 200 || rt.cum[i] > progress + 120_000) continue
                                val q = rt.pts[i]
                                bMinLat = min(bMinLat, q.lat); bMaxLat = max(bMaxLat, q.lat); bMinLon = min(bMinLon, q.lon); bMaxLon = max(bMaxLon, q.lon)
                            }
                            for (s0 in st) {
                                if (alongRoute && rt != null) {
                                    if (s0.pos.lat < bMinLat - 0.015 || s0.pos.lat > bMaxLat + 0.015 || s0.pos.lon < bMinLon - 0.025 || s0.pos.lon > bMaxLon + 0.025) continue
                                    val pr = RouteExtras.project(rt, s0.pos, 1500.0, progress) ?: continue
                                    if (pr.first < progress - 100 || pr.first - progress > 120_000) continue
                                    val price = FuelFinder.priceOf(ctx, s0.id, fuelType)
                                    out += Nearby(Place(s0.name, listOf(s0.brand, s0.postcode).filter { it.isNotBlank() && it != s0.name }.joinToString(" · "), s0.pos),
                                        pr.first - progress, priceExtra(price, s0.motorway), price?.pence, detour(pr.second), true)
                                } else {
                                    val dd = Geo.dist(centre, s0.pos)
                                    if (dd > radius) continue
                                    val price = FuelFinder.priceOf(ctx, s0.id, fuelType)
                                    out += Nearby(Place(s0.name, listOf(s0.brand, s0.postcode).filter { it.isNotBlank() && it != s0.name }.joinToString(" · "), s0.pos),
                                        Geo.dist(origin, s0.pos), priceExtra(price, s0.motorway), price?.pence)
                                }
                            }
                            if (out.isNotEmpty()) return@withContext out
                        }
                    }
                    // TomTom's place search first (quick, and it knows the detour time along a route); OpenStreetMap if that fails
                    if (hasKey && online()) {
                        val tt = try {
                            if (alongRoute && rt != null) {
                                val line = RouteExtras.line(rt, progress, progress + 80_000.0, 600.0, 140)
                                TomTomRest.poiAlong(apiKey, kind, line).mapNotNull { (n, secs) ->
                                    val pr = RouteExtras.project(rt, n.place.pos, 3000.0, progress) ?: return@mapNotNull null
                                    if (pr.first < progress - 100) null
                                    else n.copy(dist = pr.first - progress, detourMin = if (secs >= 0) Math.round(secs / 60.0).toInt() else detour(pr.second), ahead = true)
                                }
                            } else TomTomRest.poiNearby(apiKey, kind, centre, radius).map { it.copy(dist = Geo.dist(origin, it.place.pos)) }
                        } catch (e: Exception) { null }
                        if (!tt.isNullOrEmpty()) return@withContext tt
                    }
                    if (alongRoute && rt != null) {
                        val line = RouteExtras.line(rt, progress, progress + 60_000.0, 1500.0, 45)
                        val raw = Overpass.nearbyAlong(kind, line, if (kind == "services") 400 else 900)
                        raw.mapNotNull { n ->
                            val pr = RouteExtras.project(rt, n.place.pos, 1200.0, progress) ?: return@mapNotNull null
                            if (pr.first < progress - 100) null else n.copy(dist = pr.first - progress, detourMin = detour(pr.second), ahead = true)
                        }
                    } else Overpass.nearby(kind, centre, radius).map { it.copy(dist = Geo.dist(origin, it.place.pos)) }
                } }
                if (list == null) { toast("Search took too long. Check the signal and try again.", 4000); clearNearby(); return@launch }
                nearby = sortNearby(list).take(15)
                if (nearby.isEmpty()) toast(if (alongRoute) "Nothing found along the route ahead" else "Nothing found nearby", 3000)
            } catch (e: Exception) { toast("Search failed: ${e.message}", 4000) }
            finally { nearbyBusy = false }
        }
    }

    private fun priceExtra(p: FuelFinder.Price?, motorway: Boolean): String =
        listOfNotNull(p?.let { FuelFinder.ageText(it.updated).let { a -> if (a.isNotBlank()) "updated $a" else null } }, if (motorway) "Motorway services" else null).joinToString(" · ")

    /** Rough extra minutes to call somewhere [off] metres from the route: there and back at town speed, plus a minute. */
    private fun detour(off: Double): Int = Math.round((2.0 * off / 11.0 + 60.0) / 60.0).toInt()

    private fun sortNearby(l: List<Nearby>): List<Nearby> =
        if (nearbySort == "cheap" && l.any { it.price != null }) l.sortedWith(compareBy<Nearby> { it.price ?: 9999.0 }.thenBy { it.dist }) else l.sortedBy { it.dist }

    fun changeNearbySort(mode: String) { nearbySort = mode; nearby = sortNearby(nearby) }

    /** A destination shared from another app: routes straight to coordinates, or puts text in the search box. */
    fun openShared(t: SharedTarget) {
        externalTick++
        val p = t.pos
        if (p != null) startRoute(Place(t.name, "Shared from another app", p))
        else if (!t.query.isNullOrBlank()) externalQuery = t.query
    }

    // ---- guidance ----
    private fun snap(r: Route, p: LL): Snap {
        val pts = r.pts
        var bd = 1e12; var bi = 0; var bt = 0.0
        val k = cos(Geo.rad(p.lat)) * 111320.0
        val k2 = 110574.0
        fun scan(a: Int, b: Int) {
            for (i in a until min(b, pts.size - 1)) {
                val ax = (pts[i].lon - p.lon) * k; val ay = (pts[i].lat - p.lat) * k2
                val bx = (pts[i + 1].lon - p.lon) * k; val by = (pts[i + 1].lat - p.lat) * k2
                val dx = bx - ax; val dy = by - ay
                val l2 = dx * dx + dy * dy
                var t = if (l2 > 0) -(ax * dx + ay * dy) / l2 else 0.0
                t = t.coerceIn(0.0, 1.0)
                val d = hypot(ax + dx * t, ay + dy * t)
                if (d < bd) { bd = d; bi = i; bt = t }
            }
        }
        scan(max(0, lastIdx - 20), lastIdx + 500)
        if (bd > 60) scan(0, pts.size)
        lastIdx = bi
        val seg = r.cum[bi + 1] - r.cum[bi]
        val a = pts[bi]; val b = pts[bi + 1]
        return Snap(bd, bi, r.cum[bi] + bt * seg, LL(a.lat + (b.lat - a.lat) * bt, a.lon + (b.lon - a.lon) * bt))
    }

    private var lastPosAt = 0L
    private var posDt = 1000L
    private var lastMeasured: Fix? = null

    // ---- glide: the arrow and camera are moved every frame by dead reckoning, and only gently corrected by each GPS fix ----
    private var gPos: LL? = null
    private var gHead = 0.0
    private var gSpeed = 0.0
    private var gProg = 0.0
    private var glideRoute: Route? = null
    private var glideOnRoute = false
    private var mAt = 0L
    private var mProg = 0.0
    private var mSpeed = 0.0
    private var mPos: LL? = null
    private var mHead = 0.0
    // camera targets (set once per fix) and the eased values actually shown
    private var tBMode = 2
    private var tTilt = 0.0
    private var tZoom = 16.0
    private var tPad = 0.0
    private var tLeft = 0.0
    private var camTargetAt = 0L
    private var camReady = false
    private var camCatchUp = false
    private var glCamPos: LL = LL(0.0, 0.0)
    private var camB = 0.0
    private var camT = 0.0
    private var camZ = 16.0
    private var camPad = 0.0
    private var camLeft = 0.0

    private fun angDiff(a: Double, b: Double): Double = ((a - b + 540.0) % 360.0 + 360.0) % 360.0 - 180.0
    private fun easeAngle(cur: Double, tgt: Double, dt: Double, tau: Double): Double =
        ((cur + angDiff(tgt, cur) * (1.0 - Math.exp(-dt / tau))) % 360.0 + 360.0) % 360.0

    private var glideRunning = false
    private var gLastNs = 0L
    private var gGuideAt = 0L
    private var gFullAt = 0L

    /** Runs the glide once per screen refresh (vsync), so the arrow and camera advance in step with what is actually drawn. */
    private fun ensureGlide() {
        if (glideRunning) return
        glideRunning = true
        gLastNs = 0L
        val ch = android.view.Choreographer.getInstance()
        ch.postFrameCallback(object : android.view.Choreographer.FrameCallback {
            private var lastFrame = 0L
            override fun doFrame(frameTimeNanos: Long) {
                val before = PerfStats.ticks
                val t0 = System.nanoTime()
                try { glideTick(frameTimeNanos) } catch (e: Exception) { android.util.Log.w("NavEngine", "glide failed", e) }
                if (PerfStats.on) {
                    if (lastFrame != 0L) PerfStats.gapMsMax = maxOf(PerfStats.gapMsMax, (frameTimeNanos - lastFrame) / 1_000_000L)
                    if (PerfStats.ticks != before) { val d = System.nanoTime() - t0; PerfStats.tickNsSum += d; PerfStats.tickNsMax = maxOf(PerfStats.tickNsMax, d) }
                }
                lastFrame = frameTimeNanos
                ch.postFrameCallback(this)
            }
        })
    }

    private fun glideTick(frameNs: Long) {
        // never do more work than the map can actually draw: on a slow head unit this frees the CPU for rendering
        val fps = (prefs.s("mapfps", "30").toIntOrNull() ?: 30).coerceIn(15, 60)
        if (gLastNs != 0L && frameNs - gLastNs < 1_000_000_000L / fps - 3_000_000L) return
        PerfStats.ticks++
        val now = android.os.SystemClock.elapsedRealtime()
        val dt = if (gLastNs == 0L) 0.016 else ((frameNs - gLastNs) / 1e9).coerceIn(0.002, 0.1)
        gLastNs = frameNs
        val f = fix ?: return
        // in a tunnel (no fix for a while) the arrow keeps going along the route at the last speed for up to two minutes,
        // instead of stopping and then jumping when the signal comes back
        val drOk = glideOnRoute && glideRoute != null && mSpeed > 3.0 && !previewing && simMode == 0
        val rawAge = (now - mAt) / 1000.0
        val age = rawAge.coerceIn(0.0, if (drOk) 120.0 else 2.5)
        val dr = drOk && rawAge > 3.0 && rawAge < 120.0
        if (dr != deadReckoning) deadReckoning = dr
        if (dr) camTargetAt = now
        gSpeed += (mSpeed - gSpeed) * (1.0 - Math.exp(-dt / 1.2))
        if (mSpeed < 0.2 && gSpeed < 0.15) gSpeed = 0.0
        val r = glideRoute
        var lookB = gHead
        if (glideOnRoute && r != null) {
            // distance along the route: run on at the current speed, nudge towards where the latest fix says we are, and never go backwards
            val target = mProg + gSpeed * age
            var np = gProg + gSpeed * dt
            val err = target - np
            np = if (abs(err) > 60.0) target else np + (err * (1.0 - Math.exp(-dt / 2.5))).coerceIn(-(0.3 * gSpeed + 0.4) * dt, (0.3 * gSpeed + 0.4) * dt)
            if (np < gProg && abs(err) <= 60.0) np = gProg
            gProg = min(np, r.len)
            val cur = pointAt(r, gProg).first
            val ahead = pointAt(r, gProg + 12.0).first
            if (Geo.dist(cur, ahead) > 2.0) gHead = easeAngle(gHead, Geo.bearing(cur, ahead), dt, 0.18)
            gPos = cur
            // the camera looks further ahead (and further still through a roundabout) so it follows the road, not every wiggle of the wheel
            val round = turn?.let { it.maneuver.uppercase().contains("ROUNDABOUT") && it.dist < 90.0 } == true
            val la = pointAt(r, gProg + (if (round) 60.0 else 30.0)).first
            lookB = if (Geo.dist(cur, la) > 3.0) Geo.bearing(cur, la) else gHead
        } else {
            val gp = gPos ?: f.pos
            val mp = mPos ?: f.pos
            val rad = Math.toRadians(mHead)
            val kLon = 111320.0 * cos(Geo.rad(gp.lat))
            val predLat = (mp.lat) + cos(rad) * gSpeed * age / 110574.0
            val predLon = (mp.lon) + Math.sin(rad) * gSpeed * age / kLon
            var nLat = gp.lat + cos(rad) * gSpeed * dt / 110574.0
            var nLon = gp.lon + Math.sin(rad) * gSpeed * dt / kLon
            val eN = (predLat - nLat) * 110574.0; val eE = (predLon - nLon) * kLon
            if (hypot(eN, eE) > 80.0) { nLat = predLat; nLon = predLon }
            else { val k = 1.0 - Math.exp(-dt / 0.9); nLat += (predLat - nLat) * k; nLon += (predLon - nLon) * k }
            gPos = LL(nLat, nLon)
            if (mSpeed > 1.5) gHead = easeAngle(gHead, mHead, dt, 0.35)
            lookB = gHead
        }
        val gp = gPos ?: return
        map.setMe(gp, gHead, 0)
        if (glideOnRoute && r != null && !previewing) {
            if (now - gDoneAt >= 350L) { gDoneAt = now; updateDone(r, gProg) }
        } else if (doneShown) { map.setDone(emptyList()); doneShown = false }

        // guidance (distance to the next turn, lane info, spoken prompts) follows the glided position, a few times a second
        if (glideOnRoute && !previewing && now - gGuideAt >= 250L) { gGuideAt = now; val full = now - gFullAt >= 1000L; if (full) gFullAt = now; updateGuidance(gProg, !full) }

        // camera
        val fresh = now - camTargetAt < 4000
        if (!following || previewing || !fresh) { camReady = false; return }
        if (!camReady) {
            val c = map.cameraNow()
            if (c != null) { glCamPos = LL(c[0], c[1]); camB = c[2]; camT = c[3]; camZ = c[4]; camPad = c[5]; camLeft = c[6] }
            else { glCamPos = gp; camB = lookB; camT = tTilt; camZ = tZoom; camPad = tPad; camLeft = tLeft }
            camCatchUp = true; camReady = true
        }
        if (camCatchUp) {
            val k = 1.0 - Math.exp(-dt / 0.25)
            glCamPos = LL(glCamPos.lat + (gp.lat - glCamPos.lat) * k, glCamPos.lon + (gp.lon - glCamPos.lon) * k)
            if (Geo.dist(glCamPos, gp) < 1.5) camCatchUp = false
        } else glCamPos = gp
        fun ease(c: Double, t: Double, tau: Double) = c + (t - c) * (1.0 - Math.exp(-dt / tau))
        camZ = ease(camZ, tZoom, 0.5)
        camT = ease(camT, tTilt, 0.45)
        camPad = ease(camPad, tPad, 0.45)
        camLeft = ease(camLeft, tLeft, 0.45)
        val tb = when (tBMode) { 0 -> 0.0; 1 -> lookB; else -> camB }
        var d = angDiff(tb, camB)
        // a small dead-band and a gentle turn rate: slight wheel movements and small roundabouts no longer swing the map around
        if (tBMode == 1) d = if (abs(d) < 5.0) 0.0 else d - 5.0 * Math.signum(d)
        val step = d * (1.0 - Math.exp(-dt / 0.9))
        val maxStep = (if (camCatchUp) 140.0 else 32.0) * dt
        camB = ((camB + step.coerceIn(-maxStep, maxStep)) % 360.0 + 360.0) % 360.0
        map.cameraSet(glCamPos, camB, camT, camZ, camPad, camLeft)
    }

    private fun onPosition(p: Fix, force: Boolean) {
        fix = p
        val tNow = android.os.SystemClock.elapsedRealtime()
        val newFix = p !== lastMeasured
        if (newFix) {
            lastMeasured = p
            posDt = if (lastPosAt == 0L) 1000L else (tNow - lastPosAt).coerceIn(500L, 2500L)
            lastPosAt = tNow
            try { updateRoadInfo(p); trackParking(p) } catch (e: Exception) { android.util.Log.w("NavEngine", "road info failed", e) }
        }
        val r = route
        val s = if (!previewing && r != null && r.pts.size >= 2) snap(r, p.pos) else null
        // how far from the route counts as having left it: tighter than before, but widened when the GPS is less certain
        val offLim = max(30.0, (if (p.acc > 0) p.acc else 8.0) * 1.5 + 12.0)
        val onR = r != null && s != null && s.dist < (if (glideOnRoute) offLim + 12.0 else 45.0)
        if (newFix) {
            mAt = tNow; mSpeed = p.speed
            if (onR && r != null && s != null) {
                if (glideRoute !== r || gPos == null) { glideRoute = r; gProg = s.progress; gPos = s.pt; gHead = p.heading }
                mProg = s.progress
                glideOnRoute = true
            } else {
                glideRoute = null; glideOnRoute = false
                mPos = if (p.speed > 2.0 && prefs.b("snaproad", true)) (map.snapToRoad(p.pos, p.heading) ?: p.pos) else p.pos
                mHead = p.heading
                val gp = gPos
                if (gp == null || Geo.dist(gp, p.pos) > 150.0) { gPos = p.pos; gHead = p.heading }
            }
        }
        ensureGlide()
        // camera target for this fix; the glide loop eases the shown camera towards it every frame
        if (!previewing && following) {
            val hdg = if (onR && r != null && s != null) gHead else p.heading
            followCamera(Fix(gPos ?: p.pos, hdg, p.speed, p.alt, p.acc), onR)
        }
        if (previewing) return
        if (r == null || r.pts.size < 2 || s == null) return
        if (s.dist > offLim) {
            if (newFix) {
                // well off the route counts double, so a wrong turn is noticed in about two seconds instead of four or more
                offCount += if (s.dist > offLim * 2.0) 2 else 1
                if (offCount >= 3) reroute()
            }
        } else if (s.dist > 15.0 && p.speed > 4.0 && newFix) {
            // still close, but heading away from the way the route goes
            val seg = Geo.bearing(r.pts[s.i], r.pts[min(s.i + 1, r.pts.size - 1)])
            if (abs(angDiff(seg, p.heading)) > 70.0) { if (++offCount >= 3) reroute() } else offCount = 0
        } else if (newFix) offCount = 0
        val now = System.currentTimeMillis()
        if (force || lastDraw == 0L || abs(s.progress - lastDrawProg) > 500.0 || now - lastDraw > 30_000L) {
            lastDraw = now; lastDrawProg = s.progress
            // a window of the route: a little behind the car (hidden under the grey trail) to a few km ahead, so redrawing it stays cheap
            val i0 = idxAt(r, s.progress - 900.0)
            val i1 = min(r.pts.size - 1, idxAt(r, s.progress + 8000.0) + 1)
            if (i1 > i0) map.setMainOnly(r.pts.subList(i0, i1 + 1), r.sev, i0)
        }
        updateGuidance(if (onR) gProg else s.progress, onR && android.os.SystemClock.elapsedRealtime() - gFullAt < 1500L)
        syncPulse()
    }

    /** Makes the route line pulse on the map when a turn is close. */
    private var nearTurn = false
    private var pulseUntil = 0L

    private fun syncPulse() {
        val near = !previewing && route != null && (turn?.dist ?: 1e9) < 150.0
        val now = System.currentTimeMillis()
        if (!near) nearTurn = false
        else if (!nearTurn) { nearTurn = true; pulseUntil = now + 5000 }
        map.setTurnPulse(prefs.b("ambreact", true) && prefs.b("ambmap", true) && near && now < pulseUntil)
    }

    /** Zoom that adapts: closer when a turn is near or the destination is close, wider on fast roads with a long way to go. */
    private var smoothZ = 0.0

    private fun speedZoom(sp: Double): Double {
        // slower means closer: crawling in traffic zooms right in, motorway speed pulls back
        val xs = doubleArrayOf(0.0, 3.0, 6.0, 11.0, 17.0, 24.0, 31.0, 40.0)
        val ys = doubleArrayOf(18.4, 18.1, 17.8, 17.3, 16.9, 16.5, 16.2, 16.0)
        if (sp >= xs.last()) return ys.last()
        for (i in 1 until xs.size) if (sp <= xs[i]) return ys[i - 1] + (ys[i] - ys[i - 1]) * ((sp - xs[i - 1]) / (xs[i] - xs[i - 1]))
        return ys.last()
    }

    private fun autoZoom(sp: Double, navigating: Boolean): Double {
        var z = speedZoom(sp)
        if (navigating) {
            val t = turn
            if (t != null) {
                val near = ((700.0 - t.dist) / 700.0).coerceIn(0.0, 1.0)     // 1 = at the turn
                z += 1.1 * near
                if (sp > 18) z -= 0.3 * ((t.dist - 2500.0) / 2500.0).coerceIn(0.0, 1.0)   // long straight stretch
            }
            val e = eta
            if (e != null && e.dist < 500) z = max(z, 17.6)
        }
        // free-drive map (no route): pulled back at speed to see the surroundings, plus one zoom-out step (the same as pressing the minus button once)
        if (!navigating) z -= 1.0 * (1.0 - (sp / 8.0).coerceIn(0.0, 1.0))   // one step out only when stopped or crawling; at road speed it matches the driving zoom (about z17 at 30 mph, z16 at 70)
        // lane view: with lane strips showing, close in on the approach so the lanes are big enough to read at a glance
        var top = 18.8
        val lt = turn
        if (navigating && laneKey != null && lt != null && lt.dist < 260.0 && prefs.b("laneview", true)) { z = max(z, 19.0); top = 19.4 }
        val target = z.coerceIn(15.4, top)
        smoothZ = if (smoothZ == 0.0) target else smoothZ + (target - smoothZ) * 0.3
        return smoothZ
    }

    private fun followCamera(p: Fix, navigating: Boolean) {
        val sp = p.speed
        val im = prefs.s("maptheme", "immersive") == "immersive"
        // Immersive shows more of the road ahead: the car sits lower on a steeper view
        // The padding pushes the locator down the window (centre sits at (1 + pad) / 2 of the height), in 2D and 3D, on and off a route
        val moving = navigating || sp > 2.0
        val flatPad = if (moving) 0.34 else 0.2
        var pad = if (tilt3d) (if (moving) (if (im) 0.54 else 0.48) else 0.3) else flatPad
        var tilt = if (tilt3d) (if (im) 64.0 else 60.0) else 0.0
        // a lower view shows far fewer distant tiles and labels, which is a large saving on a slow GPU
        val lite = prefs.b("maplite", true)
        // the full map stays a touch lower than it used to (fewer distant tiles to draw), the light map lower still
        tilt = minOf(tilt, if (lite) 52.0 else 58.0)
        // tilt with speed: a little flatter when slow (easier to read streets), lower and further-looking at speed
        // (with the lighter map it only ever flattens, so it never draws more than before)
        if (tilt3d && prefs.b("speedtilt", true)) {
            val f = (sp / 31.0).coerceIn(0.0, 1.0)          // 0 when stopped, 1 at about 70 mph
            tilt += -9.0 * (1.0 - f) + (if (lite) 0.0 else 4.0 * f)
        }
        // coming up to a junction or roundabout the view eases down to a flat 2D map so the turn is easy to read, then tilts back up once you are away from it
        if (navigating && tilt3d && prefs.b("turn2d", true)) {
            val t = turn
            // only for a real turn or roundabout, only in the last stretch before it, and not at speed
            if (t != null && sp < 22.0 && t.maneuver.uppercase().let { it.contains("ROUNDABOUT") || it.contains("TURN") || it.startsWith("SHARP") }) {
                val reach = (sp * 5.0).coerceIn(80.0, 130.0)
                val f = ((t.dist - 25.0) / (reach - 25.0)).coerceIn(0.0, 1.0)     // 0 at the turn, 1 when it is still a way off
                tilt *= f
                pad = pad * f + flatPad * (1.0 - f)
            }
        }
        tBMode = if (northUp) 0 else if (navigating || sp > 2.0) 1 else 2
        tTilt = tilt; tPad = pad
        tZoom = autoZoom(sp, navigating) + zoomOffset
        tLeft = if (navigating && turn != null) 0.2 else 0.0
        camTargetAt = android.os.SystemClock.elapsedRealtime()
    }

    private fun incidentLabel(i: Incident): String = when (i.cat) {
        "roadWorks" -> "Roadworks"; "roadClosed" -> "Road closed"; "accident" -> "Accident"
        "jam" -> "Traffic jam"; "laneClosed" -> "Lane closed"; "danger" -> "Hazard"
        else -> i.text.ifBlank { "Incident" }
    }

    /** Speed cameras along the next 15 km of the route (OpenStreetMap), refreshed every few minutes. */
    private fun updateRouteCams(r: Route, progress: Double) {
        val now = System.currentTimeMillis()
        if (camsRoute === r && now - camsAt < 300_000) return
        camsRoute = r; camsAt = now
        scope.launch {
            val found = withContext(Dispatchers.IO) {
                try {
                    var minLat = 90.0; var maxLat = -90.0; var minLon = 180.0; var maxLon = -180.0
                    var any = false
                    for (n in r.pts.indices) {
                        if (r.cum[n] < progress - 200 || r.cum[n] > progress + 15_000) continue
                        val q = r.pts[n]; any = true
                        minLat = min(minLat, q.lat); maxLat = max(maxLat, q.lat); minLon = min(minLon, q.lon); maxLon = max(maxLon, q.lon)
                    }
                    if (!any) emptyList() else {
                        val out = ArrayList<Pair<LL, Double>>()
                        for (c in Overpass.camerasIn(minLat - 0.0005, minLon - 0.0008, maxLat + 0.0005, maxLon + 0.0008)) {
                            var bestD = 25.0; var off = -1.0
                            for (n in r.pts.indices) {
                                if (r.cum[n] < progress - 200 || r.cum[n] > progress + 15_000) continue
                                val d = Geo.dist(r.pts[n], c)
                                if (d < bestD) { bestD = d; off = r.cum[n] }
                            }
                            if (off >= 0) out += c to off
                        }
                        out
                    }
                } catch (e: Exception) { null }
            }
            if (found != null) routeCams = found else camsAt = 0L
        }
    }

    /** A report you made from the map: what it is, where, and when. They are kept on this device only. */
    class Report(val kind: String, val pos: LL, val t: Long)

    /** How long each kind of report lasts, its map icon, and what is said when you come up to it. */
    private fun reportLife(k: String) = when (k) { "hazard" -> 3_600_000L; "accident", "breakdown" -> 2 * 3_600_000L; "mobilecam" -> 4 * 3_600_000L; else -> 3 * 3_600_000L }
    private fun reportIcon(k: String) = when (k) { "accident" -> 4; "hazard" -> 5; "breakdown" -> 6; "mobilecam" -> 7; else -> 3 }
    fun reportName(k: String) = when (k) { "accident" -> "Accident"; "hazard" -> "Hazard"; "breakdown" -> "Broken-down vehicle"; "mobilecam" -> "Mobile speed camera"; else -> "Police" }

    /** Reports still in force (older police-only reports are read too). */
    fun reportsActive(): List<Report> {
        val now = System.currentTimeMillis()
        val out = ArrayList<Report>()
        for (r in prefs.s("policerep", "").split(";")) {
            val q = r.split(",")
            val la = q.getOrNull(0)?.toDoubleOrNull(); val lo = q.getOrNull(1)?.toDoubleOrNull(); val t = q.getOrNull(2)?.toLongOrNull()
            if (la != null && lo != null && t != null && now - t < reportLife("police")) out += Report("police", LL(la, lo), t)
        }
        for (r in prefs.s("reports", "").split(";")) {
            val q = r.split(",")
            val k = q.getOrNull(0).orEmpty()
            val la = q.getOrNull(1)?.toDoubleOrNull(); val lo = q.getOrNull(2)?.toDoubleOrNull(); val t = q.getOrNull(3)?.toLongOrNull()
            if (k.isNotBlank() && la != null && lo != null && t != null && now - t < reportLife(k)) out += Report(k, LL(la, lo), t)
        }
        return out
    }

    fun report(kind: String) {
        val p = fix?.pos
        if (p == null) { toast("Waiting for GPS", 2500); return }
        val keep = reportsActive().takeLast(29)
        val list = keep + Report(kind, p, System.currentTimeMillis())
        prefs.put("reports", list.joinToString(";") { "${it.kind},${it.pos.lat},${it.pos.lon},${it.t}" })
        prefs.put("policerep", "")
        toast("${reportName(kind)} report saved here", 3000)
        pushHazards(hzProgress)
    }

    fun reportPolice() = report("police")

    fun clearReports() { prefs.put("reports", ""); prefs.put("policerep", ""); pushHazards(hzProgress); toast("Reports cleared", 2000) }

    /** Refreshes the map icons when reports change or expire, and warns when one is just ahead. */
    private fun checkPolice(p: Fix) {
        val list = reportsActive()
        var sig = list.size
        for (r in list) sig = sig * 31 + (r.t % 100000).toInt()
        if (sig != policeSig) { policeSig = sig; pushHazards(hzProgress) }
        if (!prefs.b("policealerts", true) || p.speed < 4.0) return
        for (r in list) {
            val d = Geo.dist(p.pos, r.pos)
            if (d < 40 || d > 600) continue
            val diff = abs(((Geo.bearing(p.pos, r.pos) - p.heading + 540.0) % 360.0) - 180.0)
            if (diff < 50 && policeAlerted.add(r.t)) {
                chime(android.media.ToneGenerator.TONE_PROP_PROMPT)
                raiseAlert(if (r.kind == "mobilecam") "camera" else "report", "${reportName(r.kind)} reported ahead")
                speak("${reportName(r.kind)} reported ahead", true)
            }
        }
    }

    /** Pushes the camera, roadworks and closure icons for what is still ahead on the route (only when something changed). */
    private fun pushHazards(progress: Double) {
        hzProgress = progress
        val list = ArrayList<Pair<LL, Int>>()
        if (prefs.b("hazardicons", true)) {
            for (r in reportsActive()) list += r.pos to reportIcon(r.kind)
            if (prefs.b("cameras", true)) for ((p, off) in routeCams) if (off > progress - 20) list += p to 0
            for ((inc, off, _) in incMatches) {
                if (off <= progress - 20) continue
                val k = when (inc.cat.lowercase()) { "roadclosed" -> 2; "roadworks", "laneclosed" -> 1; else -> -1 }
                if (k >= 0) list += inc.pts.first() to k
            }
        }
        var sig = list.size
        for ((p, k) in list) sig = sig * 31 + (p.lat * 1e5).toInt() * 7 + (p.lon * 1e5).toInt() + k
        if (sig == hazardSig) return
        hazardSig = sig
        map.setHazards(list)
    }

    private fun checkIncidents(r: Route, progress: Double) {
        try { if (prefs.b("hazardicons", true) && simMode == 0) updateRouteCams(r, progress); pushHazards(progress) } catch (e: Exception) { }
        if (!hasKey || simMode != 0 || !prefs.b("incidents", true)) { incidentAhead = null; return }
        val now = System.currentTimeMillis()
        if (now - incAt > 180_000) {
            incAt = now
            scope.launch {
                val found = withContext(Dispatchers.IO) {
                    try {
                        var minLat = 90.0; var maxLat = -90.0; var minLon = 180.0; var maxLon = -180.0
                        var any = false
                        for (n in r.pts.indices) {
                            if (r.cum[n] < progress - 200 || r.cum[n] > progress + 40_000) continue
                            val q = r.pts[n]; any = true
                            minLat = min(minLat, q.lat); maxLat = max(maxLat, q.lat); minLon = min(minLon, q.lon); maxLon = max(maxLon, q.lon)
                        }
                        if (!any) emptyList() else {
                            val list = TomTomRest.incidents(apiKey, minLon - 0.01, minLat - 0.01, maxLon + 0.01, maxLat + 0.01)
                            val out = ArrayList<Triple<Incident, Double, String>>()
                            for (inc in list) {
                                var bestOff = -1.0; var bestD = 70.0
                                val q = inc.pts.first()
                                for (n in r.pts.indices) {
                                    if (r.cum[n] < progress - 200 || r.cum[n] > progress + 40_000) continue
                                    val d = Geo.dist(r.pts[n], q)
                                    if (d < bestD) { bestD = d; bestOff = r.cum[n] }
                                }
                                if (bestOff >= 0) out += Triple(inc, bestOff, incidentLabel(inc))
                            }
                            out
                        }
                    } catch (e: Exception) { null }
                }
                if (found != null) { incMatches = found; try { applyIncidentSev(r, found) } catch (e: Exception) { } }
            }
        }
        val next = incMatches.filter { it.second > progress - 30 }.minByOrNull { it.second }
        if (next == null) { incidentAhead = null; return }
        val d = max(0.0, next.second - progress)
        if (d > 15_000) { incidentAhead = null; return }
        incidentAhead = IncidentAhead(next.third, d, next.first.delaySec)
        if (d < 8000 && incAlerted.add(next.first.id)) {
            val mins = next.first.delaySec / 60
            val extra = if (mins >= 2) ", about $mins minutes delay" else ""
            raiseAlert("incident", "${next.third} ahead, ${Geo.fmtDist(d, imperial)}$extra", 7000)
            speak("${next.third} ahead in ${Geo.spoken(d, imperial)}$extra", true)
        }
    }

    private var sevBase: IntArray? = null
    private var sevBaseRoute: Route? = null

    /** Colours the stretch of road around each live incident amber (slow) or red (heavy), on top of the route's own traffic data. */
    private fun applyIncidentSev(r: Route, found: List<Triple<Incident, Double, String>>) {
        if (sevBaseRoute !== r) { sevBase = r.sev.copyOf(); sevBaseRoute = r }
        val base = sevBase ?: return
        if (base.size != r.sev.size) return
        System.arraycopy(base, 0, r.sev, 0, base.size)
        for ((inc, startOff, _) in found) {
            val level = when {
                inc.cat.contains("close", true) || inc.delaySec >= 300 -> 2
                inc.delaySec >= 90 || (inc.cat.contains("jam", true) && inc.delaySec >= 40) -> 1
                else -> 0
            }
            if (level == 0) continue
            var endOff = startOff + 250.0
            if (inc.pts.size > 1) {
                val last = inc.pts.last()
                var bd = 70.0
                for (n in r.pts.indices) {
                    if (r.cum[n] < startOff - 50) continue
                    val d = Geo.dist(r.pts[n], last)
                    if (d < bd) { bd = d; endOff = r.cum[n] }
                }
            }
            if (endOff < startOff) endOff = startOff + 250.0
            for (i in r.sev.indices) if (r.cum[i] >= startOff - 20 && r.cum[i] <= endOff + 20) r.sev[i] = max(r.sev[i], level)
        }
    }

    private fun p0Speed(): Double = fix?.speed ?: 0.0

    /** Every few minutes while driving, asks for fresh routes and offers a different one if it saves a few minutes. */
    private fun checkFaster(cur: Route, remainingSecs: Double) {
        val now = System.currentTimeMillis()
        val f = fix ?: return
        val d = dest ?: return
        val live = prefs.b("livealts", true)
        if (previewing || simMode != 0 || faster != null || !prefs.b("fasterroute", true)) return
        if (remainingSecs < (if (live) 600 else 900) || now - lastFasterCheck < (if (live) 180_000L else 240_000L) || f.speed < 3.0) return
        lastFasterCheck = now
        val ahead = cur.pts.drop(lastIdx.coerceIn(0, max(0, cur.pts.size - 2))).filterIndexed { i, _ -> i % 3 == 0 }
        val viaPts = via.map { it.pos }
        scope.launch {
            try {
                syncRoutePrefs(f.pos, d.pos)
                val rs = withContext(Dispatchers.IO) { TomTomRest.routes(apiKey, f.pos, d.pos, true, 0L, viaPts) }
                if (rs.size < 2 || route !== cur) return@launch
                // how much of each candidate runs along the road we are already following
                fun overlap(r: Route): Double {
                    val s = r.pts.filterIndexed { i, _ -> i % 10 == 0 }
                    if (s.isEmpty()) return 0.0
                    return s.count { p -> ahead.any { Geo.dist(p, it) < 40.0 } }.toDouble() / s.size
                }
                val same = rs.maxByOrNull { overlap(it) } ?: return@launch
                try { refreshTraffic(cur, same) } catch (e: Exception) { }
                if (live) {
                    // live comparison: every other way stays on the map in grey with how it compares, to tap any time
                    val others = rs.filter { it !== same && overlap(it) < 0.8 }.take(2)
                    val list = withContext(Dispatchers.Default) {
                        others.mapNotNull { alt ->
                            // where it leaves the road you are on, and a spot a little way along its own road for the bubble
                            val curPts = cur.pts
                            var div = -1
                            for (i in alt.pts.indices step 2) {
                                if (alt.cum[i] > 60_000.0) break
                                val q = alt.pts[i]
                                if (RouteExtras.project(cur, q, 35.0, curProgress) == null) { div = i; break }
                            }
                            if (div < 0 || curPts.isEmpty()) return@mapNotNull null
                            val divOff = RouteExtras.project(cur, alt.pts[max(0, div - 2)], 60.0, curProgress)?.first ?: curProgress
                            val own = alt.cum[div]
                            val bi = alt.cum.indexOfFirst { it >= own + min(6000.0, (alt.len - own) * 0.3) }.let { if (it < 0) alt.pts.size / 2 else it }
                            LiveAlt(alt, Math.round((alt.time - same.time) / 60.0).toInt(), alt.pts[bi], divOff)
                        }
                    }
                    if (route !== cur) return@launch
                    liveAlts = list
                    map.setLiveAlts(list.map { it.route.pts.filterIndexed { i, _ -> i % 2 == 0 } + it.route.pts.last() }, list.map { it.bubble }, list.map { it.diffMin })
                    val best = list.minByOrNull { it.diffMin }
                    if (best != null && best.diffMin <= -3 && liveSaid.add(best.diffMin / 2)) speak("A faster route is available, saving ${-best.diffMin} minutes. Tap it on the map to switch.", true)
                    return@launch
                }
                val best = rs.filter { it !== same && overlap(it) < 0.8 }.minByOrNull { it.time } ?: return@launch
                val saved = ((same.time - best.time) / 60.0).toInt()
                if (saved >= 3 && best.time < same.time * 0.95) {
                    faster = FasterRoute(best, saved)
                    speak("A faster route is available, saving $saved minutes", true)
                    val shown = faster
                    delay(25_000)
                    if (faster === shown) { faster = null; lastFasterCheck = System.currentTimeMillis() + 300_000L }
                }
            } catch (e: Exception) { }
        }
    }

    private var curProgress = 0.0
    private var lastTrafficAt = 0L
    private var trafficBusy = false

    /** Every few minutes asks TomTom for the same trip again, so the amber/red road and the time left follow the traffic as it changes. */
    private fun checkTraffic(cur: Route) {
        val now = System.currentTimeMillis()
        val f = fix ?: return
        val d = dest ?: return
        if (previewing || simMode != 0 || trafficBusy || !hasKey) return
        if (lastTrafficAt == 0L) { lastTrafficAt = now - 120_000L }   // first refresh about a minute after setting off
        if (now - lastTrafficAt < 180_000L) return
        lastTrafficAt = now
        trafficBusy = true
        val viaPts = via.map { it.pos }
        val at = curProgress
        scope.launch {
            try {
                syncRoutePrefs(f.pos, d.pos)
                val rs = withContext(Dispatchers.IO) { TomTomRest.routes(apiKey, f.pos, d.pos, false, 0L, viaPts, -1.0, true) }
                val fresh = rs.firstOrNull() ?: return@launch
                if (route !== cur) return@launch
                refreshTraffic(cur, fresh, at)
            } catch (e: Exception) { }
            finally { trafficBusy = false }
        }
    }

    /** Copies the latest traffic colouring from a fresh request for the same road onto the route being driven, so amber and red stay current. */
    private fun refreshTraffic(cur: Route, fresh: Route, at: Double = curProgress) {
        if (fresh.sev.isEmpty() || cur.sev.isEmpty()) return
        fun key(p: LL) = Math.round(p.lat * 1e4) * 1000003L + Math.round(p.lon * 1e4)
        val m = HashMap<Long, Int>(fresh.sev.size * 2)
        for (i in fresh.sev.indices) m[key(fresh.pts[i])] = fresh.sev[i]
        var hit = 0
        val base = IntArray(cur.sev.size)
        for (i in cur.sev.indices) { val v = m[key(cur.pts[i])]; if (v != null) { base[i] = v; hit++ } else base[i] = cur.sev[i] }
        // only trust it when it is the same road: a good share of the points still ahead must line up with the fresh route
        val firstAhead = max(0, idxAt(cur, at))
        var ahead = 0; var match = 0
        for (i in firstAhead until cur.sev.size) { ahead++; if (m.containsKey(key(cur.pts[i]))) match++ }
        if (ahead > 0 && match < ahead * 0.6) return
        // fresh offsets count from where you were when it was asked, so shift them onto the full route
        if (fresh.len > 0) {
            cur.freeFlow = max(0.0, fresh.time - fresh.delay) / fresh.len * cur.len
            cur.delays = fresh.delays.map { DelaySeg(it.off + at, it.end + at, it.secs) }
        }
        sevBase = base.copyOf(); sevBaseRoute = cur
        System.arraycopy(base, 0, cur.sev, 0, base.size)
        try { applyIncidentSev(cur, incMatches) } catch (e: Exception) { }
        lastDraw = 0L
    }

    fun acceptFaster() {
        val fr = faster ?: return
        routes = listOf(fr.route); active = 0
        said.clear(); offCount = 0; lastIdx = 0
        faster = null
        drawRoutes()
        toast("Switched to the faster route", 2500)
    }

    fun dismissFaster() { faster = null; lastFasterCheck = System.currentTimeMillis() + 300_000L }

    private val liveSaid = HashSet<Int>()

    /** Switches to one of the grey alternatives on the map. */
    fun switchToAlt(i: Int) {
        val a = liveAlts.getOrNull(i) ?: return
        routes = listOf(a.route); active = 0
        said.clear(); offCount = 0; lastIdx = 0; liveSaid.clear()
        clearLiveAlts()
        lastFasterCheck = System.currentTimeMillis()
        drawRoutes()
        updateRouteZones()
        toast(if (a.diffMin < 0) "Switched: about ${-a.diffMin} min quicker" else if (a.diffMin > 0) "Switched: about ${a.diffMin} min longer" else "Switched route", 3000)
        fix?.let { onPosition(it, true) }
    }

    private fun clearLiveAlts() { if (liveAlts.isNotEmpty()) liveAlts = emptyList(); map.setLiveAlts(emptyList(), emptyList(), emptyList()) }

    /** Drops alternatives whose turn-off is already behind you. */
    private fun pruneLiveAlts(progress: Double) {
        val l = liveAlts
        if (l.isEmpty()) return
        val keep = l.filter { it.divergeOff > progress - 15.0 }
        if (keep.size != l.size) {
            liveAlts = keep
            map.setLiveAlts(keep.map { it.route.pts.filterIndexed { i, _ -> i % 2 == 0 } + it.route.pts.last() }, keep.map { it.bubble }, keep.map { it.diffMin })
        }
    }

    private fun updateGuidance(progress: Double, light: Boolean = false) {
        val r = route ?: return
        val rem = max(0.0, r.len - progress)
        val frac = if (r.len > 0) rem / r.len else 0.0
        if (!light) {
            try { checkIncidents(r, progress) } catch (e: Exception) { }
            fix?.let { f -> if (via.isNotEmpty() && Geo.dist(f.pos, via[0].pos) < 80) { toast("Stop reached: ${via[0].name}", 3000); via = via.drop(1) } }
            curProgress = progress
            // time left = what the rest of the road takes with no traffic + the delays that are still ahead of you
            val ahead = if (r.delays.isEmpty()) r.delay * frac else r.delays.sumOf { d ->
                val span = max(1.0, d.end - d.off)
                d.secs * ((d.end - max(progress, d.off)) / span).coerceIn(0.0, 1.0)
            }
            val secs = r.freeFlow * frac + ahead
            val delayMin = Math.round(ahead / 60.0).toInt()
            val arrive = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(System.currentTimeMillis() + (secs * 1000).toLong()))
            eta = EtaInfo(arrive, rem, secs, delayMin)
            routeFrac = (1.0 - frac).toFloat().coerceIn(0f, 1f)
            pruneLiveAlts(progress)
            checkFaster(r, secs)
            try { checkTraffic(r) } catch (e: Exception) { }
        }

        if (!light) try { routeExtrasTick(r, progress) } catch (e: Exception) { android.util.Log.w("NavEngine", "route extras failed", e) }
        val ins = r.steps
        var k = ins.indexOfFirst { it.off > progress + 4 }
        if (k < 0) k = ins.size - 1
        if (k >= 0) {
            val cur = ins[k]
            val d = max(0.0, cur.off - progress)
            val arriving = cur.maneuver.uppercase().startsWith("ARRIVE")
            val side = if (arriving) arrivalSide(r, cur.maneuver) else ""
            val nxt = ins.getOrNull(k + 1)
            val street = if (arriving) (dest?.name ?: "Destination") + (if (side.isNotEmpty()) " · on the $side" else "") else cur.street.ifBlank { cur.sign.ifBlank { cur.msg.ifBlank { Geo.maneuverText(cur.maneuver, cur.roundExit) } } }
            // several lane sections can touch one junction (the road often widens on the approach): use the one with the most lanes, then the nearest to the junction
            val realSec = if (d < 1000 && !arriving) r.lanes.filter { progress < it.end + 5 && abs(it.end - cur.off) < 200 }.sortedWith(compareByDescending<LaneSec> { it.lanes.size }.thenBy { abs(it.end - cur.off) }).firstOrNull() else null
            val laneSec = realSec
            val laneAdv = laneSec?.let { Geo.laneAdvice(it, cur.maneuver) }
            updateLaneMarks(r, cur, laneSec, d)
            onRoad = ins.getOrNull(k - 1)?.street ?: ""
            refreshRoad()
            val newTurn = TurnInfo(
                d, street, cur.maneuver, nxt?.maneuver,
                if (nxt != null) "Then " + Geo.maneuverText(nxt.maneuver, nxt.roundExit) + (if (nxt.street.isNotBlank()) " onto ${nxt.street}" else "") else "",
                laneSec, Geo.stepTag(cur), laneAdv, cur.roundExit, cur.sign,
            )
            // only publish a new turn card when something a driver can see changed (about 3 m of distance), so the screen is not redrawn four times a second for nothing
            val ot = turn
            if (ot == null || ot.maneuver != newTurn.maneuver || ot.street != newTurn.street || ot.lanes !== newTurn.lanes || ot.thenText != newTurn.thenText || abs(ot.dist - newTurn.dist) >= 3.0 || newTurn.dist < 30.0) turn = newTurn
            val word = Geo.maneuverText(cur.maneuver, cur.roundExit)
            val tail = if (arriving || cur.street.isBlank()) "" else " onto ${cur.street}"
            val lane = if (laneAdv != null) ". $laneAdv" else ""
            if (onRoad.isNotBlank()) tripRoads.add(onRoad)
            // smarter voice: junction numbers, sign destinations and the next move when it follows quickly
            val phrase = if (arriving) word else smartPhrase(cur, nxt, word, tail)
            // on roads you drive a lot the early heads-ups are skipped and the main one comes a little later
            val familiar = prefs.b("smartvoice", true) && onRoad.isNotBlank() && (roadFam[onRoad] ?: 0) >= 6
            val fFrom = if (familiar) 330.0 else 520.0
            // a heads-up well ahead on fast roads, then the main call-out, then the final one at the junction
            if (!familiar && d <= 1700 && d > 1100 && p0Speed() > 18.0 && !arriving && said.add("${k}e"))
                speak("In ${Geo.spoken(d, imperial)}, $phrase")
            if (d <= fFrom && d > 200 && said.add("${k}f"))
                speak(if (arriving) "In ${Geo.spoken(d, imperial)}, you will arrive" + (if (side.isNotEmpty()) ". Your destination is on the $side" else "") else "In ${Geo.spoken(d, imperial)}, $phrase$lane")
            if (d <= 120 && said.add("${k}n"))
                speak(if (arriving) (if (side.isNotEmpty()) "Your destination is on the $side" else "You have arrived") else phrase.replaceFirstChar { it.uppercase() })
        }
        if (rem < 25 && said.add("end")) {
            toast("You have arrived", 5000)
            if (navStartMs > 0) {
                val secsT = (System.currentTimeMillis() - navStartMs) / 1000.0
                val dd = max(0.0, tripDist - navStartDist)
                val sideA = try { arrivalSide(r, r.steps.lastOrNull()?.maneuver ?: "") } catch (e: Exception) { "" }
                val a = ArrivalInfo(dest, dest?.name ?: "Destination", dd, secsT, if (secsT > 0) dd / secsT else 0.0, sideA)
                arrival = a
                navStartMs = 0L
                arrivalMoment(a)
                scope.launch { delay(20_000); if (arrival === a) dismissArrival() }
            }
            arriveFlash = true
            scope.launch { delay(7000); arriveFlash = false }
            val doneRoute = r
            scope.launch { delay(4000); if (route === doneRoute || route == null) endRoute() }
        }
    }

    // ---- live rain radar ----
    private var radarJob: Job? = null
    private var radarOnNow = false

    /** Switches the rain radar layer on or off; while on it picks up the newest radar picture every 10 minutes. */
    fun setRadarOn(on: Boolean) {
        if (on == radarOnNow) return
        radarOnNow = on
        radarJob?.cancel(); radarJob = null
        if (!on) { map.setRadar(null); return }
        radarJob = scope.launch {
            var warned = false
            while (true) {
                val url = withContext(Dispatchers.IO) {
                    try {
                        val c = java.net.URL("https://api.rainviewer.com/public/weather-maps.json").openConnection() as java.net.HttpURLConnection
                        c.connectTimeout = 10_000; c.readTimeout = 15_000
                        val body = c.inputStream.bufferedReader().use { it.readText() }
                        val o = org.json.JSONObject(body)
                        val host = o.optString("host", "https://tilecache.rainviewer.com")
                        val past = o.getJSONObject("radar").getJSONArray("past")
                        val path = past.getJSONObject(past.length() - 1).getString("path")
                        "$host$path/256/{z}/{x}/{y}/2/1_1.png"
                    } catch (e: Exception) { null }
                }
                if (url != null) map.setRadar(url)
                else if (!warned) { warned = true; toast("Rain radar isn't available right now (needs signal)", 3500) }
                delay(if (url != null) 600_000L else 120_000L)
            }
        }
    }

    /**
     * Predictive destinations: where you are probably heading now (a place you often drive to at this time, or work in the
     * morning and home later on), with the live journey time. Checked at most every 5 minutes, and only while idle.
     */
    fun refreshPrediction(force: Boolean = false) {
        if (!prefs.b("predict", true)) { prediction = null; return }
        if (route != null || previewing) return
        val now = System.currentTimeMillis()
        if (!force && now - predictionAt < 300_000L) return
        val here = fix?.pos ?: return
        predictionAt = now
        val cal = java.util.Calendar.getInstance()
        val hm = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
        val dow = cal.get(java.util.Calendar.DAY_OF_WEEK)
        val weekend = dow == java.util.Calendar.SATURDAY || dow == java.util.Calendar.SUNDAY
        val home = places.slot("home"); val work = places.slot("work")
        var cand: Place? = habits.suggest(now)
        if (cand == null && !weekend && work != null && hm in 360..630 && Geo.dist(here, work.pos) > 1500) cand = work
        if (cand == null && home != null && hm >= (if (weekend) 1020 else 930) && Geo.dist(here, home.pos) > 1500) cand = home
        val pl = cand
        if (pl == null || Geo.dist(here, pl.pos) < 800) { prediction = null; return }
        val title = when {
            home != null && Geo.dist(home.pos, pl.pos) < 150 -> "Home"
            work != null && Geo.dist(work.pos, pl.pos) < 150 -> "Work"
            else -> pl.name
        }
        scope.launch {
            var live = false
            val r = kotlinx.coroutines.withTimeoutOrNull(15_000L) {
                withContext(Dispatchers.IO) {
                    try {
                        if (hasKey && online()) { live = true; TomTomRest.routes(apiKey, here, pl.pos, false, 0L, emptyList(), -1.0, true).firstOrNull() }
                        else if (OfflineRouter.installed(ctx)) OfflineRouter.routes(ctx, here, pl.pos).firstOrNull() else null
                    } catch (e: Exception) { null }
                }
            }
            if (route != null) return@launch
            val mins = r?.let { Math.round(it.time / 60.0).toInt() } ?: -1
            val dmin = if (live && r != null) Math.round(r.delay / 60.0).toInt() else 0
            val note = when { r == null || !live -> ""; dmin >= 10 -> "heavy traffic"; dmin >= 3 -> "some traffic"; else -> "light traffic" }
            prediction = Prediction(pl, title, mins, dmin, note)
        }
    }

    /** The hazard radar: everything in the next two miles, nearest first. Only republished when what you would see changes. */
    private fun updateRadar(r: Route, progress: Double, pl: Placed) {
        if (bendsFor !== r) {
            bendsFor = r; bends = emptyList()
            scope.launch { val b = withContext(Dispatchers.Default) { try { routeBends(r) } catch (e: Exception) { emptyList() } }; if (bendsFor === r) bends = b }
        }
        val reach = 3219.0
        val out = ArrayList<RadarItem>()
        fun add(kind: String, off: Double, label: String) { val d = off - progress; if (d in -5.0..reach) out += RadarItem(kind, max(0.0, d), label) }
        if (prefs.b("cameras", true)) for ((_, off) in routeCams) add("camera", off, "Speed camera")
        for ((inc, off, _) in incMatches) add(if (inc.cat.contains("work", true)) "works" else "incident", off, incidentLabel(inc))
        if (prefs.b("avgzones", true)) for (a in pl.avg) add("avg", a.start, "Average speed check")
        val school = RouteExtras.schoolTime(System.currentTimeMillis())
        for (h in pl.hz) when (h.poi.kind) {
            "bump" -> if (prefs.b("bumps", true)) add("bump", h.off, "Speed bump")
            "school" -> if (prefs.b("schools", true)) add("school", h.off, if (school) "School · school run" else "School")
            "crossing" -> add("crossing", h.off, "Crossing")
        }
        for ((o, dir) in bends) add("bend", o, if (dir < 0) "Bend left" else "Bend right")
        out.sortBy { it.dist }
        val shown = out.take(14)
        var sig = shown.size
        for (e in shown) sig = sig * 31 + e.kind.hashCode() + (e.dist / 40.0).toInt()
        if (sig != radarSig) { radarSig = sig; radar = shown }
    }

    private val refRx = Regex("\\b([MAB][0-9]{1,4}(?:\\(M\\))?)\\b")

    /** Road numbers on a sign ("A34", "M3"). */
    private fun signRefs(sign: String): List<String> = refRx.findAll(sign).map { it.groupValues[1] }.distinct().toList()

    /** Place names on a sign, without the road numbers ("Winchester", "Basingstoke"). */
    private fun signDests(sign: String): List<String> =
        sign.split(',', '/', ';', '|').map { refRx.replace(it, "").replace(Regex("[()]"), "").trim() }.filter { it.length >= 3 && it.any { ch -> ch.isLetter() } }.distinct()

    /** "take junction 9 towards Winchester, then keep left for the A34", from the route's step and sign data. */
    private fun smartPhrase(cur: Step, nxt: Step?, word: String, tail: String): String {
        if (!prefs.b("smartvoice", true)) return word + tail
        val m = cur.maneuver.uppercase()
        val exitLike = m.contains("EXIT") || m.contains("KEEP") || m.contains("BEAR") || m.contains("RAMP")
        var main = if (cur.exitNo.isNotBlank() && exitLike) "take junction ${cur.exitNo}" else word
        val dests = signDests(cur.sign)
        val refs = signRefs(cur.sign)
        main += when {
            dests.isNotEmpty() -> (if (refs.isNotEmpty() && cur.exitNo.isNotBlank()) " for the ${refs[0]}" else "") + " towards " + dests.take(2).joinToString(" and ")
            refs.isNotEmpty() && exitLike -> " for the ${refs[0]}"
            else -> tail
        }
        if (nxt != null && nxt.off - cur.off in 1.0..450.0 && !nxt.maneuver.uppercase().startsWith("ARRIVE")) {
            val target = signRefs(nxt.sign).firstOrNull() ?: nxt.street
            val forWhat = when {
                target.isBlank() -> ""
                refRx.matches(target) -> " for the $target"
                else -> " onto $target"
            }
            main += ", then " + Geo.maneuverText(nxt.maneuver, nxt.roundExit) + forWhat
        }
        return main
    }

    /** Counts the roads driven on this trip into the familiar-roads list (kept to the 300 most driven). */
    private fun flushRoads() {
        if (tripRoads.isEmpty()) return
        if (simMode != 0) { tripRoads.clear(); return }   // the demo drive doesn't count
        for (r in tripRoads) roadFam[r] = (roadFam[r] ?: 0) + 1
        tripRoads.clear()
        val top = roadFam.entries.sortedByDescending { it.value }.take(300)
        val o = org.json.JSONObject()
        for ((k, v) in top) o.put(k, v)
        prefs.put("roadfam", o.toString())
    }

    /** The arrival moment: the camera swoops down to the destination, and the nearest car park is looked up. */
    private fun arrivalMoment(a: ArrivalInfo) {
        arrivalParking = null
        val d = a.place?.pos ?: return
        if (prefs.b("arrivalfx", true)) {
            following = false
            recentreToken++
            map.cameraTo(d, fix?.heading ?: map.cameraNow()?.get(2), 58.0, 17.4, 2600, 0.25)
        }
        if (simMode != 0) return
        scope.launch {
            val list = kotlinx.coroutines.withTimeoutOrNull(15_000L) {
                withContext(Dispatchers.IO) {
                    try { if (hasKey && online()) TomTomRest.poiNearby(apiKey, "parking", d, 700) else Overpass.nearby("parking", d, 700) }
                    catch (e: Exception) { try { Overpass.nearby("parking", d, 700) } catch (e2: Exception) { emptyList() } }
                }
            }
            if (arrival === a) arrivalParking = list?.minByOrNull { Geo.dist(d, it.place.pos) }?.let { it.copy(dist = Geo.dist(d, it.place.pos)) }
        }
    }

    /** Closes the arrival card and goes back to following the car. */
    fun dismissArrival() {
        arrival = null; arrivalParking = null
        if (!following && route == null) recenter()
    }

    /** "left" or "right" for the side of the road the destination is on, from the route's own instruction or from where the pin is. */
    private fun arrivalSide(r: Route, maneuver: String): String {
        val m = maneuver.uppercase()
        if (m.endsWith("LEFT")) return "left"
        if (m.endsWith("RIGHT")) return "right"
        val d = dest?.pos ?: return ""
        if (r.pts.size < 2) return ""
        val a = r.pts[r.pts.size - 2]; val b = r.pts.last()
        if (Geo.dist(a, b) < 2.0 || Geo.dist(b, d) < 8.0) return ""
        val kx = cos(Geo.rad(b.lat)) * 111320.0
        val cross = ((b.lon - a.lon) * kx) * ((d.lat - a.lat) * 110574.0) - ((b.lat - a.lat) * 110574.0) * ((d.lon - a.lon) * kx)
        return if (cross > 0) "left" else "right"
    }

    // ---- arrive by ----
    /** Works out when to leave the chosen destination's route to arrive at [arriveMs], and reminds you when it is time. */
    fun planArriveBy(arriveMs: Long) {
        val d = dest ?: return
        val from = fix?.pos ?: map.center() ?: return
        val r = route
        val viaPts = via.map { it.pos }
        scope.launch {
            val leave = withContext(Dispatchers.IO) {
                try { if (hasKey && online()) TomTomRest.departureFor(apiKey, from, d.pos, viaPts, arriveMs) else null } catch (e: Exception) { null }
            } ?: (arriveMs - ((r?.time ?: 1800.0) * 1000).toLong() - 5 * 60_000L)
            val p = PlannedTrip(d, arriveMs, leave)
            planned = p
            savePlanned()
            // back to the map, where the planned card shows the leave time
            if (previewing) endRoute()
            val f = SimpleDateFormat("HH:mm", Locale.UK)
            toast(if (leave <= System.currentTimeMillis()) "Leave now to arrive by ${f.format(Date(arriveMs))}" else "Leave by ${f.format(Date(leave))} to arrive by ${f.format(Date(arriveMs))}. I'll remind you.", 5000)
            watchPlanned()
        }
    }

    fun cancelPlanned() { planned = null; savePlanned(); plannedJob?.cancel() }

    /** Starts the planned trip now. */
    fun startPlanned() { val p = planned ?: return; cancelPlanned(); startRoute(p.dest) }

    private fun savePlanned() {
        val p = planned
        prefs.put("planned", if (p == null) "{}" else org.json.JSONObject().put("n", p.dest.name).put("s", p.dest.sub).put("la", p.dest.pos.lat).put("lo", p.dest.pos.lon).put("a", p.arriveBy).put("l", p.leaveBy).toString())
    }

    /** Checks the planned trip twice a minute: refreshes the leave time with live traffic half an hour before, and gives the reminders. */
    private fun watchPlanned() {
        plannedJob?.cancel()
        plannedJob = scope.launch {
            var warned10 = false; var warned0 = false; var refreshed = false
            while (true) {
                val p = planned ?: break
                val now = System.currentTimeMillis()
                if (now > p.arriveBy) { cancelPlanned(); break }
                if (!refreshed && now > p.leaveBy - 35 * 60_000L && hasKey && online()) {
                    refreshed = true
                    val from = fix?.pos
                    if (from != null) {
                        val l = withContext(Dispatchers.IO) { try { TomTomRest.departureFor(apiKey, from, p.dest.pos, emptyList(), p.arriveBy) } catch (e: Exception) { null } }
                        if (l != null && planned === p) { planned = PlannedTrip(p.dest, p.arriveBy, l); savePlanned() }
                    }
                }
                val cur = planned ?: break
                val busyDriving = route != null && !previewing
                if (!busyDriving && !warned10 && now >= cur.leaveBy - 10 * 60_000L && now < cur.leaveBy) {
                    warned10 = true
                    raiseAlert("plan", "Leave in 10 minutes for ${cur.dest.name}", 7000)
                    speak("Leave in about 10 minutes for ${cur.dest.name}", true)
                }
                if (!busyDriving && !warned0 && now >= cur.leaveBy) {
                    warned0 = true
                    chime(android.media.ToneGenerator.TONE_PROP_PROMPT)
                    raiseAlert("plan", "Time to leave for ${cur.dest.name}", 8000)
                    speak("It's time to leave for ${cur.dest.name}", true)
                }
                delay(30_000)
            }
        }
    }

    // ---- smart fuel stop ----
    /** On a long trip, finds a good place to fill up around the middle of the route: the cheapest (with Fuel Finder) or the quickest detour. */
    private fun suggestFuel(r: Route) {
        if (r.len < 150_000) return
        val a = r.len * 0.35; val b = r.len * 0.75
        val fuel = prefs.s("fueltype", "E10")
        scope.launch {
            val best = withContext(Dispatchers.IO) {
                try {
                    val out = ArrayList<Nearby>()
                    if (FuelFinder.configured(prefs)) {
                        try { FuelFinder.refresh(ctx, prefs) } catch (e: Exception) { }
                        var minLat = 90.0; var maxLat = -90.0; var minLon = 180.0; var maxLon = -180.0
                        for (i in r.pts.indices) if (r.cum[i] in a..b) { val q = r.pts[i]; minLat = min(minLat, q.lat); maxLat = max(maxLat, q.lat); minLon = min(minLon, q.lon); maxLon = max(maxLon, q.lon) }
                        for (s0 in FuelFinder.stations(ctx)) {
                            if (s0.pos.lat < minLat - 0.015 || s0.pos.lat > maxLat + 0.015 || s0.pos.lon < minLon - 0.025 || s0.pos.lon > maxLon + 0.025) continue
                            val pr = RouteExtras.project(r, s0.pos, 1200.0) ?: continue
                            if (pr.first !in a..b) continue
                            val price = FuelFinder.priceOf(ctx, s0.id, fuel) ?: continue
                            out += Nearby(Place(s0.name, s0.brand, s0.pos), pr.first, if (s0.motorway) "Motorway services" else "", price.pence, detour(pr.second), true)
                        }
                    }
                    if (out.isEmpty() && hasKey && online()) {
                        val line = RouteExtras.line(r, a, b, 800.0, 140)
                        for ((n, secs) in TomTomRest.poiAlong(apiKey, "fuel", line, 600)) {
                            val pr = RouteExtras.project(r, n.place.pos, 3000.0) ?: continue
                            out += n.copy(dist = pr.first, detourMin = if (secs >= 0) Math.round(secs / 60.0).toInt() else detour(pr.second), ahead = true)
                        }
                    }
                    // price matters most, but a long detour costs time (each minute counts as a penny a litre)
                    if (out.any { it.price != null }) out.filter { it.detourMin in 0..8 }.minByOrNull { (it.price ?: 999.0) + it.detourMin }
                    else out.filter { it.detourMin >= 0 }.minByOrNull { it.detourMin }
                } catch (e: Exception) { null }
            }
            if (route === r) fuelSuggestion = best
        }
    }

    // ---- wrong way ----
    private fun checkWrongWay(p: Fix) {
        if (simMode != 0 || !prefs.b("wrongway", true) || p.speed < 4.0 || (p.acc > 0 && p.acc > 20.0)) { wrongCount = 0; return }
        if (Overpass.wrongWay(p.pos, p.heading)) wrongCount++ else wrongCount = 0
        val now = System.currentTimeMillis()
        if (wrongCount >= 3 && now - wrongAt > 60_000L) {
            wrongAt = now
            chime(android.media.ToneGenerator.TONE_PROP_BEEP2)
            raiseAlert("wrongway", "Wrong way! This is a one-way road", 7000)
            speak("Warning. You may be going the wrong way on a one-way road.", true)
        }
    }

    // ---- voice commands ----
    /**
     * Understands simple spoken commands. Returns null when it isn't a command (the words are then searched for),
     * "share" when the ETA should be shared, "search:<place>" to search for a place, or "" when it was handled.
     */
    fun handleVoice(raw: String): String? {
        val t = raw.lowercase(Locale.UK).trim().removePrefix("hey horizon").trim(' ', ',', '.')
        fun has(vararg w: String) = w.any { t.contains(it) }
        val f = SimpleDateFormat("HH:mm", Locale.UK)
        fun say(s: String) { toast(s, 3500); speak(s, true) }
        // places you have saved
        if (Regex("^(go|take me|navigate|drive|directions|head)( back)?( to)? ?home$").matches(t) || t == "home") {
            val h = places.slot("home"); if (h != null) { say("Going home"); startRoute(h) } else say("Home isn't set yet"); return ""
        }
        if (Regex("^(go|take me|navigate|drive|directions|head)( to)? ?work$").matches(t) || t == "work") {
            val w = places.slot("work"); if (w != null) { say("Going to work"); startRoute(w) } else say("Work isn't set yet"); return ""
        }
        // reports
        if (t.startsWith("report")) {
            val k = when { has("police", "cop") -> "police"; has("accident", "crash") -> "accident"; has("breakdown", "broken") -> "breakdown"; has("camera") -> "mobilecam"; else -> "hazard" }
            report(k); return ""
        }
        // finding things
        val kind = when {
            has("fuel", "petrol", "diesel", "filling station", "gas station") -> "fuel"
            has("charg") -> "charging"; has("toilet", "loo", "bathroom") -> "toilets"; has("coffee", "cafe", "café") -> "coffee"
            has("food", "eat", "restaurant", "hungry") -> "food"; has("services", "rest stop", "rest area") -> "services"
            has("parking", "car park", "somewhere to park") -> "parking"; else -> null
        }
        if (kind != null && has("find", "nearest", "look for", "search for", "where", "any ", "need", "show", "cheap", "stop for", "add a stop", "add stop", "near")) {
            nearbySort = if (has("cheap")) "cheap" else "near"
            if (has("stop") && route != null) stopMode = true
            loadNearby(kind, has("destination", "when i get there"))
            say("Looking for " + Overpass.kindLabel(kind).lowercase() + if (route != null) " along your route" else " nearby")
            return ""
        }
        // route preferences
        if (has("avoid toll")) { prefs.put("avoid_toll", true); say("Avoiding toll roads"); dest?.let { startRoute(it, departMin, true, startNow = route != null && !previewing) }; return "" }
        if (has("avoid motorway")) { prefs.put("avoid_motorway", true); say("Avoiding motorways"); dest?.let { startRoute(it, departMin, true, startNow = route != null && !previewing) }; return "" }
        if (has("avoid this road", "avoid the road")) { if (route != null) { say("Looking for a way round"); avoidRoadAhead() } else say("There's no route to change"); return "" }
        // trip info
        if (has("eta", "arrive", "how long", "how far", "time left", "when will i")) {
            val e = eta
            if (e == null) say("There's no route at the moment")
            else say("You'll arrive at ${e.arrive}, in ${Geo.fmtDur(e.secs)}. ${Geo.spoken(e.dist, imperial)} to go." + if (e.delayMin >= 1) " ${e.delayMin} minutes of traffic." else "")
            return ""
        }
        if (has("share")) return "share"
        // sound
        if (has("unmute", "sound on", "turn the voice on", "voice on")) { prefs.put("soundmode", 0); say("Voice guidance on"); return "" }
        if (has("alerts only")) { prefs.put("soundmode", 1); say("Alerts only"); return "" }
        if (has("mute", "be quiet", "quiet", "stop talking", "silence", "voice off")) { say("Voice off"); prefs.put("soundmode", 2); return "" }
        // the map
        if (has("stop navigation", "end route", "end navigation", "cancel route", "cancel navigation", "stop the route", "stop route")) { endRoute(); say("Route ended"); return "" }
        if (has("overview", "show the route", "show route", "whole route")) { overview(); return "" }
        if (has("zoom in")) { zoom(1.0); return "" }
        if (has("zoom out")) { zoom(-1.0); return "" }
        if (has("north up")) { if (!northUp) toggleNorthUp(); return "" }
        if (t == "3d" || t == "2d" || has("three d", "two d")) { if ((t.contains("3") || t.contains("three")) != tilt3d) toggleTilt(); return "" }
        if (has("what time")) { say("It's ${f.format(Date())}"); return "" }
        // "take me to …", "navigate to …"
        Regex("^(?:go to|take me to|navigate to|drive to|directions to|head to|find|search for|show me)\\s+(.+)$").find(t)?.let { return "search:" + it.groupValues[1] }
        return null
    }

    /** Once a second while navigating: fetches and places services, bumps, schools and average speed checks, and raises their alerts. */
    private fun routeExtrasTick(r: Route, progress: Double) {
        if (previewing) return
        val now = System.currentTimeMillis()
        barProgress = progress
        val d = dest
        // motorway services: once per destination, for longer trips
        if (d != null && servicesFor !== d && !servicesBusy && r.len > 15_000 && now > servicesRetryAt && online()) {
            servicesBusy = true
            val line = RouteExtras.line(r, progress, progress + 400_000.0, 2000.0, 220)
            scope.launch {
                try { rawServices = withContext(Dispatchers.IO) { RouteExtras.services(line) }; servicesFor = d }
                catch (e: Exception) { servicesRetryAt = System.currentTimeMillis() + 120_000L }
                finally { servicesBusy = false }
            }
        }
        // speed bumps, schools and average speed checks: a window of the next 20 km, fetched again before you reach its end
        val wantHz = prefs.b("bumps", true) || prefs.b("schools", true) || prefs.b("avgzones", true)
        // (a new route after a reroute is looked up again, but not more than once every 45 seconds)
        if (wantHz && !hzBusy && (progress + 6000.0 > hzWinEnd || (hzWinRoute !== r && now - hzLastAt > 45_000L)) && now > hzRetryAt && online()) {
            hzBusy = true; hzLastAt = now
            val to = progress + 20_000.0
            val line = RouteExtras.line(r, progress - 300.0, to, 250.0, 90)
            scope.launch {
                try {
                    val (p, a) = withContext(Dispatchers.IO) { RouteExtras.hazards(line) }
                    rawHz = (rawHz + p).distinctBy { "${it.kind}${Math.round(it.pos.lat * 1e5)},${Math.round(it.pos.lon * 1e5)}" }.takeLast(1500)
                    rawAvg = (rawAvg + a).distinctBy { it.id }.takeLast(60)
                    hzWinRoute = r; hzWinEnd = to
                } catch (e: Exception) { hzRetryAt = System.currentTimeMillis() + 60_000L }
                finally { hzBusy = false }
            }
        }
        // place everything on this route (in the background) whenever the route or what was found changes
        val sig = ((System.identityHashCode(r) * 31 + rawServices.size) * 31 + rawHz.size) * 31 + rawAvg.size * 7 + via.size * 13 + zonesVersion * 17
        if (sig != placedSig && !placing) {
            placing = true
            val sv = rawServices; val hz = rawHz; val av = rawAvg; val vs = via
            val zoneWarn = prefs.b("zonewarn", true)
            val fuelOn = FuelFinder.configured(prefs)
            val fuel = prefs.s("fueltype", "E10")
            scope.launch {
                try {
                    val pl = withContext(Dispatchers.Default) {
                        val svc = sv.mapNotNull { poi -> RouteExtras.project(r, poi.pos, 400.0)?.let { (o, side) -> PoiOnRoute(poi, o, side) } }.sortedBy { it.off }
                        val fuelText = HashMap<RoutePoi, String>()
                        if (fuelOn) {
                            val st = FuelFinder.stations(ctx)
                            for (s in svc) {
                                val near = st.filter { Geo.dist(it.pos, s.poi.pos) < 700.0 }.minByOrNull { Geo.dist(it.pos, s.poi.pos) } ?: continue
                                FuelFinder.priceOf(ctx, near.id, fuel)?.let { fuelText[s.poi] = String.format(java.util.Locale.UK, "%s %.1fp", if (fuel == "B7") "Diesel" else fuel, it.pence) }
                            }
                        }
                        val hzOn = hz.mapNotNull { poi -> RouteExtras.project(r, poi.pos, if (poi.kind == "school") 90.0 else if (poi.kind == "crossing") 12.0 else 15.0)?.let { (o, side) -> PoiOnRoute(poi, o, side) } }
                        val avg = av.mapNotNull { RouteExtras.placeAvg(r, it) }.sortedBy { it.start }
                        val stops = vs.mapNotNull { RouteExtras.project(r, it.pos, 300.0)?.first }
                        val zs = if (zoneWarn) Zones.entries(r, Zones.all(ctx)).map { it.first.name to it.second } else emptyList()
                        Placed(r, svc, fuelText, hzOn, avg, stops, zs)
                    }
                    placed = pl; placedSig = sig
                } catch (e: Exception) { placedSig = sig } finally { placing = false }
            }
        }
        val pl = placed?.takeIf { it.route === r }
        if (pl == null) { if (avgInfo != null) avgInfo = null; return }
        val sp = fix?.speed ?: 0.0

        // average speed check
        if (prefs.b("avgzones", true)) {
            val cur = pl.avg.firstOrNull { progress >= it.start && progress < it.end }
            if (cur != null) {
                if (avgIn !== cur) {
                    avgIn = cur; avgEnterAt = now; avgEnterProg = progress; avgOverWarned = false
                    if (avgAlerted.add(cur.def.id)) {
                        chime(android.media.ToneGenerator.TONE_PROP_PROMPT)
                        raiseAlert("avg", "Average speed check for ${Geo.fmtDist(cur.end - progress, imperial)}", 6000)
                        speak("Average speed check for ${Geo.spoken(cur.end - progress, imperial)}", true)
                    }
                }
                val secs = (now - avgEnterAt) / 1000.0
                val avg = if (secs > 4.0) (progress - avgEnterProg) / secs else sp
                val lim = cur.def.limit ?: speedLimit
                val over = lim != null && secs > 15.0 && avg > lim + 0.45
                if (over && !avgOverWarned) {
                    avgOverWarned = true
                    chime(android.media.ToneGenerator.TONE_PROP_BEEP2)
                    speak("Your average speed is over the limit", true)
                } else if (!over && lim != null && avg < lim - 0.5) avgOverWarned = false
                avgInfo = AvgInfo(avg, lim, cur.end - progress, over, false, 0.0)
            } else {
                if (avgIn != null) { avgIn = null; toast("End of average speed check", 2500) }
                val next = pl.avg.filter { it.start > progress && it.start - progress < 1200.0 }.minByOrNull { it.start }
                avgInfo = next?.let { AvgInfo(0.0, it.def.limit ?: speedLimit, it.end - it.start, false, true, it.start - progress) }
                if (next != null && next.start - progress < 500.0 && avgAlerted.add(next.def.id)) {
                    chime(android.media.ToneGenerator.TONE_PROP_PROMPT)
                    raiseAlert("avg", "Average speed check ahead, ${Geo.fmtDist(next.end - next.start, imperial)} long", 6000)
                    speak("Average speed check ahead", true)
                }
            }
        } else if (avgInfo != null) avgInfo = null

        if (prefs.b("hazardradar", false)) updateRadar(r, progress, pl)

        // speed bumps and schools just ahead
        for (h in pl.hz) {
            val ahead = h.off - progress
            if (ahead < 0.0 || ahead > 320.0 || h.poi.kind == "crossing") continue
            val key = "${h.poi.kind}${Math.round(h.poi.pos.lat * 1e5)},${Math.round(h.poi.pos.lon * 1e5)}"
            if (h.poi.kind == "bump") {
                if (prefs.b("bumps", true) && sp > 6.7 && ahead < max(70.0, sp * 6.0) && now - lastBumpAt > 25_000L && hzAlerted.add(key)) {
                    lastBumpAt = now
                    chime(android.media.ToneGenerator.TONE_PROP_ACK)
                    raiseAlert("bump", "Speed bump ahead", 3500)
                }
            } else if (prefs.b("schools", true) && ahead < 300.0 && RouteExtras.schoolTime(now) && hzAlerted.add(key)) {
                raiseAlert("school", "School ahead: ${h.poi.name}", 5000)
                speak("School ahead", true)
            }
        }

        // clean air / low emission zones
        if (prefs.b("zonewarn", true)) for ((name, off) in pl.zones) {
            val ahead = off - progress
            if (ahead in -50.0..1500.0 && zoneAlerted.add(name)) {
                raiseAlert("zone", if (ahead <= 0) "You are in $name" else "Entering $name in ${Geo.fmtDist(ahead, imperial)}", 7000)
                speak(if (ahead <= 0) "You are in $name. A charge may apply." else "You are about to enter $name. A charge may apply.", true)
            }
        }

        // next services (only republished when what a driver would see changes)
        val nextSvc = pl.services.filter { it.off > progress + 150.0 && it.off - progress < 130_000.0 && it.side < 400.0 }.take(2)
        var ss = nextSvc.size
        for (s in nextSvc) ss = ss * 31 + s.poi.name.hashCode() + ((s.off - progress) / 160.0).toInt()
        if (ss != servicesSig) {
            servicesSig = ss
            servicesAhead = nextSvc.map { ServiceAhead(it.poi.name, it.off - progress, pl.serviceFuel[it.poi].orEmpty()) }
        }

        // route bar markers
        if (prefs.b("routebar", true)) {
            val span = r.len
            val ev = ArrayList<BarEvent>()
            if (prefs.b("cameras", true)) for ((_, off) in routeCams) ev += BarEvent(off, "camera")
            for ((inc, off, _) in incMatches) ev += BarEvent(off, if (inc.cat.contains("work", true)) "works" else "incident")
            for (s in pl.services) if (s.side < 400.0) ev += BarEvent(s.off, "services")
            for (a in pl.avg) ev += BarEvent(a.start, "avg")
            for (o in pl.stops) ev += BarEvent(o, "stop")
            for ((_, o) in pl.zones) ev += BarEvent(o, "zone")
            val shown = ev.filter { it.off >= progress - 30.0 && it.off <= span }
            var bs = shown.size
            for (e in shown) bs = bs * 31 + e.off.toInt() / 50 + e.kind.hashCode()
            if (bs != barSig) { barSig = bs; barEvents = shown }
        }
    }

    fun speakForce(text: String) {
        if (!ttsReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "read")
    }

    /** Turn-by-turn guidance is spoken only in "all" mode; alerts are also spoken in "alerts only". */
    fun speak(text: String, alert: Boolean = false) {
        val m = soundMode
        if (m == 2 || (m == 1 && !alert) || !ttsReady) return
        duck()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nav")
    }

    // ---- demo drive ----
    fun cycleSim() {
        val r = route
        if (r == null) { toast("Pick a destination first, then start the demo drive"); return }
        when (simMode) {
            0 -> { simMode = 1; startSim(r) }
            1 -> simMode = 4
            else -> stopSim()
        }
    }

    private fun startSim(r: Route) {
        simJob?.cancel()
        simDist = fix?.let { snap(r, it.pos).progress } ?: 0.0
        following = true
        simJob = scope.launch {
            while (true) {
                val cur = route ?: break
                // the position moves by exactly the speed it reports, so the arrow glide never sees a gap it has to jump to close
                // (the old demo moved 16 m a second while claiming 7 m/s near a turn, which the glide "corrected" with a jump halfway round the roundabout)
                val td = turn?.dist ?: 1000.0
                val demoSpeed = (if (td < 150) 7.0 else if (td < 400) 13.0 else if (td < 1200) 20.0 else 27.0) * simMode
                simDist = min(cur.len, simDist + demoSpeed)
                val (pt, hd) = pointAt(cur, simDist)
                onPosition(Fix(pt, hd, demoSpeed, 0.0), false)
                if (simDist >= cur.len) break
                delay(1000)
            }
            simMode = 0
        }
    }

    fun stopSim() { simJob?.cancel(); simJob = null; simMode = 0 }

    var onRoad by mutableStateOf("")
    private var limitRoad = ""
    private var roadShown = ""

    /** Name of the road you are on: from the route while navigating, otherwise from the map data around you. */
    private fun refreshRoad() {
        val n = Geo.shortRoad(if (route != null && !previewing && onRoad.isNotBlank()) onRoad else limitRoad)
        if (n != roadShown) { roadShown = n; map.setRoadName(n) }
        if (roadNow != n) roadNow = n
    }
    private var laneKey: Pair<Double, LaneSec>? = null

    private fun laneHit(dir: String, maneuver: String): Boolean {
        val m = maneuver.uppercase()
        return when {
            m.contains("U_TURN") -> dir.endsWith("U_TURN")
            m.contains("LEFT") -> dir.contains("LEFT")
            m.contains("RIGHT") -> dir.contains("RIGHT")
            else -> dir == "STRAIGHT"
        }
    }

    /** Paints the lane arrows on the road ahead of the junction (approximate: placed across the route line). */
    private fun updateLaneMarks(r: Route, cur: Step, sec: LaneSec?, d: Double) {
        val key = if (sec != null && d < 400.0 && prefs.b("lanemap", true)) Pair(cur.off, sec) else null
        if (key == laneKey) return
        laneKey = key
        if (key == null || sec == null) { map.setLanes(emptyList()); return }
        val n = sec.lanes.size
        val anyFollow = sec.lanes.any { it.follow != null }
        val laneW = 3.6
        val activeIdx = sec.lanes.indices.filter { i -> val ln = sec.lanes[i]; if (anyFollow) ln.follow != null else ln.dirs.any { laneHit(it, cur.maneuver) } }
        // the route runs along the lane you need, so the lane strips are laid out with that lane under the route line
        val centre = if (activeIdx.isEmpty()) (n - 1) / 2.0 else activeIdx.average()
        fun latOf(i: Int) = (i - centre) * laneW
        fun shifted(p: LL, brg: Double, lateral: Double): LL {
            val rad = Math.toRadians(brg + 90.0)
            return LL(p.lat + lateral * Math.cos(rad) / 111320.0, p.lon + lateral * Math.sin(rad) / (111320.0 * Math.cos(Math.toRadians(p.lat))))
        }
        val marks = ArrayList<MapBinding.LaneMark>()
        for (back in listOf(28.0, 65.0)) {
            val off = cur.off - back
            if (off < 0) continue
            val (p, brg) = pointAt(r, off)
            sec.lanes.forEachIndexed { i, lane ->
                val at = shifted(p, brg, latOf(i))
                val active = i in activeIdx
                lane.dirs.forEach { dir ->
                    val hit = active && (if (anyFollow) dir == lane.follow else laneHit(dir, cur.maneuver))
                    marks += MapBinding.LaneMark(at, brg, dir, hit)
                }
            }
        }
        // lane strips from up to 130 m before the junction to just short of it
        // TomTom's lane section can be short, but the lanes carry on back along the approach, so the strips do not stop where the section starts
        val from = max(0.0, cur.off - 110.0)
        val to = cur.off - 6.0
        val bands = ArrayList<MapBinding.LaneBand>()
        val divs = ArrayList<MapBinding.LaneEdge>()
        if (to - from > 20.0) {
            val samples = ArrayList<Pair<LL, Double>>()
            var o = from
            while (o < to) { samples += pointAt(r, o); o += 10.0 }
            samples += pointAt(r, to)
            val last = samples.size - 1
            for (i in 0 until n) {
                // cut into short pieces so the ribbon can fade in softly at its start
                for (k in 0 until last) {
                    val l = ArrayList<LL>(); val rt = ArrayList<LL>()
                    for (m in k..k + 1) { val (p, brg) = samples[m]; l += shifted(p, brg, latOf(i) - laneW / 2); rt += shifted(p, brg, latOf(i) + laneW / 2) }
                    val a = 0.5 + 0.5 * min(1.0, k / 3.0)
                    bands += MapBinding.LaneBand(l + rt.reversed(), i in activeIdx, a)
                }
                val edge = ArrayList<LL>(); for ((p, brg) in samples) edge += shifted(p, brg, latOf(i) + laneW / 2)
                divs += MapBinding.LaneEdge(edge, i == n - 1)
            }
            val outer = ArrayList<LL>(); for ((p, brg) in samples) outer += shifted(p, brg, latOf(0) - laneW / 2)
            divs += MapBinding.LaneEdge(outer, true)
        }
        map.setLaneBands(bands, divs)
        map.setLanes(marks)
    }

    /** Index of the last route point at or before [d] metres along the route. */
    private fun idxAt(r: Route, d: Double): Int {
        val c = r.cum
        var lo = 0; var hi = c.size - 1
        while (lo < hi) { val m = (lo + hi + 1) ushr 1; if (c[m] <= d) lo = m else hi = m - 1 }
        return lo
    }

    private var gDoneAt = 0L
    private var doneShown = false

    private fun updateDone(r: Route, prog: Double) {
        val start = max(0.0, prog - 800.0)
        if (prog - start < 2.0) { if (doneShown) { map.setDone(emptyList()); doneShown = false }; return }
        val pts = ArrayList<LL>()
        pts += pointAt(r, start).first
        var i = idxAt(r, start) + 1
        while (i < r.pts.size && r.cum[i] < prog) { pts += r.pts[i]; i++ }
        pts += pointAt(r, prog).first
        map.setDone(pts); doneShown = true
    }

    private fun pointAt(r: Route, d: Double): Pair<LL, Double> {
        val c = r.cum
        var lo = 0; var hi = c.size - 1
        while (lo < hi - 1) { val m = (lo + hi) ushr 1; if (c[m] <= d) lo = m else hi = m }
        val seg = (c[hi] - c[lo]).takeIf { it > 0 } ?: 1.0
        val t = ((d - c[lo]) / seg).coerceIn(0.0, 1.0)
        val a = r.pts[lo]; val b = r.pts[hi]
        return Pair(LL(a.lat + (b.lat - a.lat) * t, a.lon + (b.lon - a.lon) * t), Geo.bearing(a, b))
    }
}
