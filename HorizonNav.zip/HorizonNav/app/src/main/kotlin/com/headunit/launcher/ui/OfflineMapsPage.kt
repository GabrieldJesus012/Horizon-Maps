package com.headunit.launcher.ui

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.headunit.launcher.NavEngine
import com.headunit.launcher.OfflineRouter
import com.headunit.launcher.Prefs
import java.io.File

private fun fmtSize(b: Long): String = if (b >= 1_000_000_000L) "%.1f GB".format(b / 1e9) else "%.0f MB".format(b / 1e6)

/** The downloaded offline pack: what is on the unit, download / update, which map to draw, and delete. */
@Composable
internal fun OfflineMapsContent(prefs: Prefs, engine: NavEngine) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    @Suppress("UNUSED_VARIABLE") val rev = engine.packRev // re-read the files when a download or delete finishes
    val region = prefs.s("packregion", "ew")
    val packUrl = if (region == "gb") OfflineRouter.DEFAULT_PACK_GB else OfflineRouter.DEFAULT_PACK
    var confirmDelete by remember { mutableStateOf(false) }

    val dir = OfflineRouter.dir(ctx)
    val routing = File(dir, "tiles.tar")
    val installed = OfflineRouter.installed(ctx)
    val total = OfflineRouter.sizeOf(dir)
    val free = try { android.os.StatFs(dir.path).availableBytes } catch (e: Exception) { -1L }
    val built = if (routing.exists()) java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.UK).format(java.util.Date(routing.lastModified())) else ""

    SGroup("Offline pack", footer = "Download once on Wi-Fi and the map, search and routes all work with no signal. The pack is a snapshot of the roads on the day it was built: update it now and then.") {
        SChoice("Area", listOf("ew" to "England & Wales", "gb" to "Great Britain"), region,
            if (region == "gb") "Includes Scotland. The pack-gb release has to be built once first with the region pack workflow" else null) { prefs.put("packregion", it) }
        SItem(
            if (installed) "Installed" + (if (built.isNotEmpty()) " · built $built" else "") else "Not downloaded",
            fmtSize(total) + (if (free >= 0) " used · ${fmtSize(free)} free" else " used"),
        ) {
            SButton(if (engine.packBusy) "Downloading…" else if (installed) "Update" else "Download", primary = true) { engine.downloadPack(packUrl) }
        }
        val age = engine.packAgeDays()
        if (age != null && age >= 120 && !engine.packBusy) SNote("This pack is about ${age / 30} months old. Update it on Wi-Fi to pick up new roads and junction changes.")
        if (engine.packBusy) LinearProgressIndicator(color = c.accent, trackColor = c.tile, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
        if (engine.packStatus.isNotBlank()) SNote(engine.packStatus + if (engine.packBusy) " · you can leave this page" else "")
    }
    SGroup("Without signal") {
        SChoice("Which map to draw", listOf("auto" to "Auto", "always" to "Downloaded", "never" to "Online"), prefs.s("offmap", "auto"),
            "Auto switches to the downloaded map when signal drops, and back again") { prefs.put("offmap", it); engine.restyle() }
    }
    if (installed || total > 0) SGroup("Storage") {
        SItem("Delete the pack", "Frees ${fmtSize(total)}") {
            if (!confirmDelete) SButton("Delete", danger = true) { confirmDelete = true }
            else {
                SButton("Yes, delete", danger = true) { confirmDelete = false; engine.deletePack() }
                SButton("Keep") { confirmDelete = false }
            }
        }
    }
}
