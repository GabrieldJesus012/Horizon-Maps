package com.headunit.launcher.ui

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.headunit.launcher.NavEngine
import com.headunit.launcher.OfflineRouter
import com.headunit.launcher.PackRegions
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.headunit.launcher.Prefs
import java.io.File

/**
 * The Mapbox map with no signal: a circle round Home, the current route's strip, and (optionally) every route's strip as it starts.
 * Mapbox keeps these on the device itself; the map uses them automatically when there's no signal.
 */
@Composable
private fun MapboxOfflineGroup(prefs: Prefs, engine: NavEngine) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { com.headunit.launcher.MapboxOffline.refresh(ctx) }
    val off = com.headunit.launcher.MapboxOffline
    var confirm by remember { mutableStateOf<String?>(null) }
    SGroup("Mapa Mapbox sem sinal", footer = "A Mapbox deixa cada aparelho guardar só áreas offline limitadas: cabe um raio ao redor de casa e várias rotas, mas não um país inteiro. As áreas por onde você dirigiu recentemente também ficam guardadas automaticamente.") {
        if (!engine.hasMapbox) SNote("Adicione primeiro o seu token da Mapbox em Busca e chaves.")
        val km = prefs.s("mbhomekm", "30").toIntOrNull() ?: 30
        val home = engine.places.slot("home")
        SItem("Arredores de casa", if (home == null) "Defina Casa primeiro (busque e salve um local como Casa)" else "O mapa 3D num raio de $km km de Casa · cerca de ${off.homeMb(km)} MB") {
            Segmented(listOf("15" to "15 km", "30" to "30 km", "50" to "50 km"), km.toString()) { prefs.put("mbhomekm", it) }
            if (home != null && engine.hasMapbox) SButton(if (off.busy?.startsWith("Arredores de casa") == true) "Salvando…" else "Salvar", primary = true) { off.saveHome(ctx, home.pos, km) }
        }
        val r = engine.route
        SItem("Salvar o mapa desta rota", if (r == null) "Planeje uma rota primeiro" else engine.offlineRouteName() + " · uma faixa ao longo da rota · cerca de ${off.routeMb(r.len)} MB") {
            if (r != null && engine.hasMapbox) SButton("Salvar", primary = true) { off.saveRoute(ctx, engine.offlineRouteName(), r.pts) }
        }
        SToggle(prefs, "Salvar o mapa de toda rota", "mbautoroute", false, "Quando uma rota começa, a faixa dela é salva em segundo plano")
        if (prefs.b("mbautoroute", false)) SChoice("Salvar rotas", listOf("wifi" to "Só no Wi-Fi", "always" to "Sempre (usa dados móveis)"), prefs.s("mbautonet", "wifi")) { prefs.put("mbautonet", it) }
        if (off.saved.isNotEmpty() || off.busy != null) {
            SItem("Salvos", null)
            for (a in off.saved) {
                SItem(a.name, "%.0f MB".format(a.mb) + if (a.complete) " · salvo" else " · salvo em parte") {
                    if (confirm == a.id) {
                        SButton("Sim, apagar", danger = true) { confirm = null; off.delete(ctx, a.id) }
                        SButton("Manter") { confirm = null }
                    } else SButton("Apagar", danger = true) { confirm = a.id }
                }
            }
        }
        if (off.busy != null) {
            SItem(off.busy ?: "", off.status) { SButton("Parar") { off.stop() } }
            LinearProgressIndicator(progress = { off.progress }, color = LocalVw.current.accent, trackColor = LocalVw.current.tile, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
        } else if (off.status.isNotBlank()) SNote(off.status)
    }
}

private fun fmtSize(b: Long): String = if (b >= 1_000_000_000L) "%.1f GB".format(b / 1e9) else "%.0f MB".format(b / 1e6)

/** The downloaded areas: what's on the unit, which is in use, add another, update and delete. */
@Composable
internal fun OfflineMapsContent(prefs: Prefs, engine: NavEngine) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    @Suppress("UNUSED_VARIABLE") val rev = engine.packRev // re-read the files when a download, switch or delete finishes
    @Suppress("UNUSED_VARIABLE") val pick = prefs.s("packregion", "")   // redraw when the area to add changes
    val region = engine.chosenPack()
    val have = engine.installedPacks()
    val activeId = engine.installedPackId()
    var confirmDelete by remember { mutableStateOf<String?>(null) }
    var picking by remember { mutableStateOf(false) }
    // has the area to add been built yet? (checked when it changes)
    var avail by remember(region.id) { mutableStateOf<Boolean?>(null) }
    LaunchedEffect(region.id, have.size) { if (region.id !in have) avail = withContext(Dispatchers.IO) { PackRegions.available(region) } }
    // sizes and free space are worked out in the background (a pack's font folder holds thousands of small files)
    val sizes by androidx.compose.runtime.produceState(emptyMap<String, Long>(), have, rev) {
        value = withContext(Dispatchers.IO) { have.associateWith { OfflineRouter.sizeOf(OfflineRouter.packDir(ctx, it)) } }
    }
    // areas downloaded before the speed limit and camera files existed: has the file been published for them since?
    val extrasReady by androidx.compose.runtime.produceState(emptySet<String>(), have, rev) {
        value = withContext(Dispatchers.IO) {
            have.filter { !File(OfflineRouter.packDir(ctx, it), "limits.bin").exists() && PackRegions.hasExtras(PackRegions.byId(it)) == true }.toSet()
        }
    }
    val free by androidx.compose.runtime.produceState(-1L, rev) {
        value = withContext(Dispatchers.IO) { try { android.os.StatFs(OfflineRouter.packsRoot(ctx).path).availableBytes } catch (e: Exception) { -1L } }
    }

    MapboxOfflineGroup(prefs, engine)
    SGroup("Regiões baixadas", footer = "Guarde quantas regiões quiser: a região onde você está é usada automaticamente (as rotas funcionam offline dentro de uma região). Cada uma é um retrato das vias no dia em que foi gerada, então atualize de vez em quando." + if (free >= 0) " ${fmtSize(free)} free." else "") {
        if (have.isEmpty()) SNote("Nada baixado ainda. Escolha uma região abaixo e baixe no Wi-Fi.")
        for (id in have) {
            val r = PackRegions.byId(id)
            val d = OfflineRouter.packDir(ctx, id)
            val tiles = File(d, "tiles.tar")
            val built = if (tiles.exists()) java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale("pt", "BR")).format(java.util.Date(tiles.lastModified())) else ""
            val inUse = id == activeId
            val hasLimits = File(d, "limits.bin").exists()
            SItem(r.name + if (inUse) " · em uso" else "", (sizes[id]?.let { fmtSize(it) } ?: "…") + (if (built.isNotEmpty()) " · gerado em $built" else "") +
                (if (hasLimits) " · limites de velocidade e radares offline" else "")) {
                if (confirmDelete == id) {
                    SButton("Sim, apagar", danger = true) { confirmDelete = null; engine.deletePack(id) }
                    SButton("Manter") { confirmDelete = null }
                } else {
                    if (!inUse && have.size > 1) SButton("Usar") { engine.useArea(id) }
                    SButton(if (engine.packDownloading == id) "Atualizando…" else "Atualizar") { engine.downloadRegion(r) }
                    SButton("Apagar", danger = true) { confirmDelete = id }
                }
            }
        }
        for (id in extrasReady) if (engine.packDownloading != id)
            SNote("Limites de velocidade e radares offline já estão prontos para ${PackRegions.byId(id).name}: toque em Atualizar (só os arquivos novos são baixados, normalmente menos de 100 MB).")
        val age = engine.packAgeDays()
        if (age != null && age >= 120 && !engine.packBusy) SNote("A região em uso tem cerca de ${age / 30} meses. Atualize no Wi-Fi para receber vias novas e mudanças em cruzamentos.")
    }
    SGroup("Adicionar região") {
        SItem("Região", region.name + " · " + region.group) { SButton("Mudar") { picking = true } }
        if (region.id !in have && avail == false) SNote("O pacote ${region.name} ainda não foi gerado, então não pode ser baixado agora.")
        SItem(if (region.id in have) "${region.name} já está baixado" else "Baixar ${region.name}", "Melhor no Wi-Fi: um país costuma ter de 1 a 4 GB") {
            SButton(if (engine.packBusy) "Baixando…" else if (region.id in have) "Atualizar" else "Baixar", primary = true) { engine.downloadRegion(region) }
        }
        if (engine.packBusy) LinearProgressIndicator(color = c.accent, trackColor = c.tile, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
        if (engine.packStatus.isNotBlank()) SNote((engine.packDownloading?.let { PackRegions.byId(it).name + ": " } ?: "") + engine.packStatus + if (engine.packBusy) " · você pode sair desta página" else "")
    }
    SGroup("Sem sinal") {
        SChoice("Qual mapa desenhar", listOf("auto" to "Automático", "always" to "Baixado", "never" to "Online"), prefs.s("offmap", "auto"),
            "Automático: sem sinal, o mapa da Mapbox continua com as áreas que tem guardadas (onde você esteve recentemente e as áreas salvas da Mapbox); o mapa do pacote baixado só assume onde a Mapbox não tem nada, e o mapa online volta quando o sinal volta") { prefs.put("offmap", it); engine.restyle() }
    }
    if (picking) PackPickerDialog(region, { prefs.put("packregion", it.id) }) { picking = false }
}
