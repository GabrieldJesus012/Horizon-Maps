package com.headunit.launcher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Construction
import androidx.compose.material.icons.rounded.Eco
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.GpsOff
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.LocalCafe
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material.icons.rounded.PriorityHigh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.headunit.launcher.Geo
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Place
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.min

/** True while a route is being followed (not just previewed). */
private val NavEngine.guiding: Boolean get() = route != null && !previewing

/** The route bar is shown on the right while navigating (it can be switched off in Settings). */
val NavEngine.showRouteBar: Boolean get() = guiding && prefs.b("routebar", true)

/** Driving with no route: just the road, your speed and the alerts. */
val NavEngine.cruising: Boolean get() = route == null && !previewing && (fix?.speed ?: 0.0) > 4.0

private fun barIcon(kind: String): ImageVector = when (kind) {
    "camera" -> Icons.Rounded.CameraAlt
    "works" -> Icons.Rounded.Construction
    "incident" -> Icons.Rounded.PriorityHigh
    "services" -> Icons.Rounded.LocalCafe
    "avg" -> Icons.Rounded.Speed
    "stop" -> Icons.Rounded.Place
    "zone" -> Icons.Rounded.Eco
    else -> Icons.Rounded.Flag
}

private fun barColor(kind: String): Color = when (kind) {
    "camera", "avg" -> Bad
    "works", "incident" -> Warn
    "services" -> Color(0xFF4C8DFF)
    "zone" -> Good
    else -> Color(0xFF8E5CF0)
}

/**
 * The whole route as a strip above the trip card: traffic in amber and red, markers for cameras, incidents, services,
 * average speed checks, stops and zones, and an arrow that moves along it as you drive (start on the left, destination on the right).
 */
@Composable
fun RouteBar(engine: NavEngine, modifier: Modifier = Modifier) {
    val r = engine.route ?: return
    val c = LocalVw.current
    val len = max(1.0, r.len)
    val target = (engine.barProgress / len).coerceIn(0.0, 1.0).toFloat()
    // progress arrives about once a second; the arrow glides between updates (only the drawing is redone, nothing is recomposed)
    val frac by androidx.compose.animation.core.animateFloatAsState(target, androidx.compose.animation.core.tween(1000, easing = androidx.compose.animation.core.LinearEasing), label = "barArrow")
    val bins = 120
    val levels = remember(r, r.sev.size, engine.barEvents) {
        val out = IntArray(bins)
        for (i in r.sev.indices) {
            if (i + 1 >= r.cum.size) break
            val b = ((r.cum[i] / len) * bins).toInt().coerceIn(0, bins - 1)
            if (r.sev[i] > out[b]) out[b] = r.sev[i]
        }
        out
    }
    val accent = c.accent
    BoxWithConstraints(modifier.height(48.dp)) {
        val w = maxWidth
        // the track, with the part already driven greyed out, and the arrow
        Canvas(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(26.dp)) {
            val th = 8.dp.toPx()
            val y0 = (size.height - th) / 2f
            val bw = size.width / bins
            drawRoundRect(Color.Black.copy(alpha = 0.45f), Offset(0f, y0 - 1.5f), Size(size.width, th + 3f), CornerRadius(th))
            for (b in 0 until bins) {
                val done = (b + 1f) / bins <= frac
                val col = when (levels[b]) { 2 -> Bad; 1 -> Warn; else -> accent }
                drawRect(if (done) Color(0xFF8A8F99) else col, Offset(b * bw, y0), Size(bw + 0.6f, th))
            }
            // the arrow: a chunky white chevron pointing the way you are going, like the locator on the map
            val ax = (frac * size.width).coerceIn(9.dp.toPx(), size.width - 9.dp.toPx())
            val cy = size.height / 2f
            val hl = 13.dp.toPx(); val hw = 12.dp.toPx()
            val arrow = androidx.compose.ui.graphics.Path().apply {
                moveTo(ax + hl * 0.55f, cy)
                lineTo(ax - hl * 0.55f, cy - hw)
                lineTo(ax - hl * 0.15f, cy)
                lineTo(ax - hl * 0.55f, cy + hw)
                close()
            }
            drawPath(arrow, Color.Black.copy(alpha = 0.35f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 5.dp.toPx(), join = androidx.compose.ui.graphics.StrokeJoin.Round))
            drawPath(arrow, Color.White)
            drawPath(arrow, accent, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.6.dp.toPx(), join = androidx.compose.ui.graphics.StrokeJoin.Round))
        }
        // markers above the track (ones that would sit on top of each other are left out)
        var lastX = -100f
        for (e in engine.barEvents.sortedBy { it.off }) {
            val f = (e.off / len).coerceIn(0.0, 1.0).toFloat()
            val x = w.value * f
            if (x - lastX < 22f) continue
            lastX = x
            Box(
                Modifier.offset(x = (w * f - 10.dp).coerceIn(0.dp, w - 20.dp), y = 0.dp).size(20.dp).shadow(3.dp, CircleShape).clip(CircleShape).background(Color.White),
                contentAlignment = Alignment.Center,
            ) { Icon(barIcon(e.kind), null, tint = barColor(e.kind), modifier = Modifier.size(13.dp)) }
        }
        Box(
            Modifier.offset(x = w - 20.dp, y = 0.dp).size(20.dp).shadow(3.dp, CircleShape).clip(CircleShape).background(Color.White),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Flag, null, tint = Color(0xFFEA4335), modifier = Modifier.size(13.dp)) }
    }
}

/** Card for an average speed check: your average so far against the limit, and how much is left. */
@Composable
fun AvgSpeedCard(engine: NavEngine, modifier: Modifier = Modifier) {
    val a = engine.avgInfo ?: return
    val c = LocalVw.current
    val k = if (engine.imperial) 2.23694 else 3.6
    val unit = if (engine.imperial) "mph" else "km/h"
    val shape = RoundedCornerShape(22.dp)
    Row(
        modifier.fillMaxWidth().shadow(8.dp, shape).clip(shape).background(c.surface).border(2.dp, if (a.over) Bad else Color.Transparent, shape).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        val lim = a.limitMs?.let { (Math.round(it * k / 5.0) * 5).toInt() }
        Box(Modifier.size(46.dp).clip(CircleShape).background(Color.White).border(5.dp, Bad, CircleShape), contentAlignment = Alignment.Center) {
            Text(lim?.toString() ?: "?", color = Color.Black, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f)) {
            Text(if (a.ahead) "AVERAGE SPEED CHECK AHEAD" else "AVERAGE SPEED CHECK", color = Bad, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            if (a.ahead) Text("Starts in ${Geo.fmtDist(a.toStartM, engine.imperial)} · ${Geo.fmtDist(a.leftM, engine.imperial)} long", color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            else Text("${Geo.fmtDist(a.leftM, engine.imperial)} left", color = c.sub, fontSize = 13.sp)
        }
        if (!a.ahead) Column(horizontalAlignment = Alignment.End) {
            Text("${Math.round(a.avgMs * k)}", color = if (a.over) Bad else Good, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("avg $unit", color = c.sub, fontSize = 11.sp)
        }
    }
}

/** The next motorway services on the route, with the fuel price there when Fuel Finder is set up. */
@Composable
fun ServicesCard(engine: NavEngine, modifier: Modifier = Modifier) {
    val list = engine.servicesAhead
    if (list.isEmpty() || engine.avgInfo != null || !engine.prefs.b("servicescard", true)) return
    val c = LocalVw.current
    val shape = RoundedCornerShape(20.dp)
    Column(modifier.fillMaxWidth().shadow(6.dp, shape).clip(shape).background(c.surface).padding(horizontal = 14.dp, vertical = 8.dp)) {
        list.take(2).forEachIndexed { i, s ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(26.dp).clip(RoundedCornerShape(7.dp)).background(Color(0xFF4C8DFF)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.LocalCafe, null, tint = Color.White, modifier = Modifier.size(16.dp))
                }
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text(s.name, color = c.text, fontSize = if (i == 0) 15.sp else 13.sp, fontWeight = if (i == 0) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (s.fuel.isNotBlank()) Text(s.fuel, color = c.sub, fontSize = 11.sp)
                }
                Text(Geo.fmtDist(s.dist, engine.imperial), color = c.text, fontSize = if (i == 0) 15.sp else 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** Shown while the GPS has dropped out (a tunnel): the arrow is being kept moving along the route. */
@Composable
fun DeadReckoningChip(modifier: Modifier = Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(50)).background(Color(0xE6121922)).padding(horizontal = 14.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.GpsOff, null, tint = Warn, modifier = Modifier.size(18.dp))
        Text("No GPS · estimating your position", color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp))
    }
}

/** Driving with no route: the road you are on and which way you are heading. */
@Composable
fun CruisePill(engine: NavEngine, modifier: Modifier = Modifier) {
    val road = engine.roadNow
    val dir = com.headunit.launcher.RouteExtras.compass(engine.fix?.heading ?: 0.0)
    Row(
        modifier.shadow(6.dp, RoundedCornerShape(50)).clip(RoundedCornerShape(50)).background(Color(0xE6121922)).padding(horizontal = 18.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Navigation, null, tint = Color.White, modifier = Modifier.size(18.dp))
        Text((if (road.isNotBlank()) "$road · " else "") + "Heading $dir", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 8.dp))
    }
}

/** Edit the stops on the way: add by searching, move them up or down, or remove them. */
@Composable
fun StopsDialog(engine: NavEngine, onClose: () -> Unit) {
    val c = LocalVw.current
    var stops by remember { mutableStateOf(engine.via) }
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Place>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(q) {
        if (q.trim().length < 3) { results = emptyList(); return@LaunchedEffect }
        delay(500)
        busy = true
        results = try { engine.findPlaces(q) } catch (e: Exception) { emptyList() }
        busy = false
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.width(620.dp).heightIn(max = 560.dp).clip(RoundedCornerShape(26.dp)).background(c.surface).padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Stops on the way", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Icon(Icons.Rounded.Close, "Close", tint = c.sub, modifier = Modifier.size(28.dp).clickable { onClose() })
            }
            TextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                placeholder = { Text("Search for a stop to add") },
                leadingIcon = { Icon(Icons.Rounded.Search, null, tint = c.sub) },
                trailingIcon = { if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = c.accent, strokeWidth = 2.dp) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { }),
                shape = RoundedCornerShape(50),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = c.tile, unfocusedContainerColor = c.tile, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = c.text, unfocusedTextColor = c.text, cursorColor = c.accent,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            if (results.isNotEmpty()) LazyColumn(Modifier.heightIn(max = 200.dp).clip(RoundedCornerShape(16.dp)).background(c.tile)) {
                itemsIndexed(results) { _, p ->
                    Row(Modifier.fillMaxWidth().clickable { stops = (stops + p).take(8); q = ""; results = emptyList() }.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Add, null, tint = c.accent, modifier = Modifier.size(22.dp))
                        Column(Modifier.padding(start = 10.dp)) {
                            Text(p.name, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (p.sub.isNotBlank()) Text(p.sub, color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 260.dp)) {
                itemsIndexed(stops) { i, p ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(30.dp).clip(CircleShape).background(c.accent), contentAlignment = Alignment.Center) {
                            Text("${i + 1}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(p.name, color = c.text, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(start = 12.dp))
                        Icon(Icons.Rounded.KeyboardArrowUp, "Earlier", tint = if (i > 0) c.text else c.sub.copy(alpha = 0.3f),
                            modifier = Modifier.size(36.dp).clickable(enabled = i > 0) { stops = stops.toMutableList().also { l -> val t = l[i]; l[i] = l[i - 1]; l[i - 1] = t } })
                        Icon(Icons.Rounded.KeyboardArrowDown, "Later", tint = if (i < stops.size - 1) c.text else c.sub.copy(alpha = 0.3f),
                            modifier = Modifier.size(36.dp).clickable(enabled = i < stops.size - 1) { stops = stops.toMutableList().also { l -> val t = l[i]; l[i] = l[i + 1]; l[i + 1] = t } })
                        Icon(Icons.Rounded.Close, "Remove", tint = Bad, modifier = Modifier.padding(start = 6.dp).size(30.dp).clickable { stops = stops.filterIndexed { n, _ -> n != i } })
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(30.dp).clip(CircleShape).background(Color(0xFFEA4335)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Flag, null, tint = Color.White, modifier = Modifier.size(18.dp))
                }
                Text(engine.dest?.name ?: "Destination", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(start = 12.dp))
            }
            if (stops.isEmpty()) Text("No stops yet. Search above to add one; the route goes through them in this order.", color = c.sub, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 4.dp)) {
                Pill("Update route", true, { engine.setStops(stops); onClose() })
                Pill("Cancel", false, onClose)
            }
        }
    }
}

/** Route options row: the clean air / low emission zones this route goes into. */
@Composable
fun ZonesRow(engine: NavEngine) {
    val z = engine.routeZones
    if (z.isEmpty()) return
    val c = LocalVw.current
    Row(
        Modifier.floating(50.dp).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Icon(Icons.Rounded.Eco, null, tint = Warn, modifier = Modifier.size(20.dp))
        Text("Goes into " + z.joinToString(", ") + ". A charge may apply.", color = c.text, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
        if (!engine.prefs.b("avoidzones", false)) Pill("Avoid zones", false, { engine.prefs.put("avoidzones", true); engine.dest?.let { engine.startRoute(it, engine.departMin, true) } })
    }
}
