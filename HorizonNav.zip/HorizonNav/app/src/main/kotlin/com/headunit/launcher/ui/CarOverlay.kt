package com.headunit.launcher.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Work
import androidx.compose.foundation.layout.size
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.Geo
import com.headunit.launcher.NavEngine

/**
 * The app's own screens on the Android Auto display, drawn over the car's map with the app's designs: alerts across the top, the
 * turn card (top left), hazard badges, speed and the trip card (bottom left), the route choice before setting off, and the arrival
 * summary. [scale] makes them the same size on the car screen as in the app (car screens have few pixels per inch for their size).
 * Nothing here can be tapped (Android Auto only lets its own buttons take touches), so the matching buttons are Android Auto's.
 */
@Composable
fun CarOverlay(engine: NavEngine, area: State<android.graphics.Rect?>, dark: State<Boolean>, scale: Float, actions: CarActions) {
    val base = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(base.density * scale, base.fontScale)) {
        VwTheme(dark.value) { CarScreen(engine, area.value, actions) }
    }
}

/** What taps on the app's cards do that needs Android Auto's own screens (search, the places list). */
interface CarActions {
    fun search()
    fun places()
}

/**
 * Taps on the car screen: Android Auto passes a tap's position (on newer cars), and it's matched against where the app's cards and
 * buttons are drawn, so the search bar, chips, route cards and Start work by touch as in the app.
 */
object CarTaps {
    private val regions = java.util.LinkedHashMap<String, Pair<androidx.compose.ui.geometry.Rect, () -> Unit>>()
    fun set(id: String, r: androidx.compose.ui.geometry.Rect, a: () -> Unit) { synchronized(regions) { regions.remove(id); regions[id] = r to a } }
    fun remove(id: String) { synchronized(regions) { regions.remove(id) } }
    /** Runs what's under (x, y); true when something was there. */
    fun hit(x: Float, y: Float): Boolean {
        val a = synchronized(regions) { regions.values.toList().asReversed().firstOrNull { it.first.contains(androidx.compose.ui.geometry.Offset(x, y)) }?.second } ?: return false
        a(); return true
    }
}

/** Makes this card or button react to taps on the car screen. */
@Composable
internal fun Modifier.carTap(id: String, action: () -> Unit): Modifier {
    val act = androidx.compose.runtime.rememberUpdatedState(action)
    androidx.compose.runtime.DisposableEffect(id) { onDispose { CarTaps.remove(id) } }
    return this.then(Modifier.onGloballyPositioned { CarTaps.set(id, it.boundsInRoot()) { act.value() } })
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun CarScreen(engine: NavEngine, a: android.graphics.Rect?, actions: CarActions) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val dens = LocalDensity.current
        val hPx = with(dens) { maxHeight.toPx() }
        val wPx = with(dens) { maxWidth.toPx() }
        // well in from the edges: car screens have rounded corners, and Android Auto's own buttons sit along the top and right
        val left = with(dens) { (a?.left ?: 0).toDp() } + 28.dp
        val top = with(dens) { (a?.top ?: 0).toDp() } + 26.dp
        val right = with(dens) { (wPx - (a?.right ?: wPx.toInt())).coerceAtLeast(0f).toDp() } + 96.dp
        val bottom = with(dens) { (hPx - (a?.bottom ?: hPx.toInt())).coerceAtLeast(0f).toDp() } + 26.dp
        val previewing = engine.previewing
        val guiding = engine.route != null && !previewing
        val c = LocalVw.current

        // the turn card, top left (as in the app)
        val t = engine.turn
        if (guiding && t != null && engine.arrival == null) Box(Modifier.padding(start = left, top = top).width(minOf(420.dp, maxWidth * 0.36f))) { ImmTurnCard(engine, t) }

        // not navigating: the app's search bar and quick chips, top left (tap them as in the app)
        if (engine.route == null && engine.arrival == null) Column(Modifier.padding(start = left, top = top).width(minOf(460.dp, maxWidth * 0.40f)), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth().height(60.dp).panel(10.dp, RoundedCornerShape(30.dp), c.surface).carTap("search") { actions.search() }.padding(start = 18.dp, end = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Rounded.Search, null, tint = c.sub)
                Text("Where to?", color = c.sub, fontSize = 18.sp, modifier = Modifier.padding(start = 12.dp).weight(1f))
                Box(Modifier.size(44.dp).clip(androidx.compose.foundation.shape.CircleShape).background(c.accent), contentAlignment = Alignment.Center) {
                    androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Rounded.Mic, null, tint = Color.White, modifier = Modifier.size(23.dp))
                }
            }
            val home = engine.places.slot("home"); val work = engine.places.slot("work")
            val mine = engine.places.customs()
            // two rows of chips (no sideways scrolling on a car screen)
            androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.carTap("home") { if (home != null) engine.startRoute(home) else actions.search() }) {
                    ImmChip(androidx.compose.material.icons.Icons.Rounded.Home, Color(0xFF4C8DFF), if (home != null) "Home" else "Set home") {}
                }
                Box(Modifier.carTap("work") { if (work != null) engine.startRoute(work) else actions.search() }) {
                    ImmChip(androidx.compose.material.icons.Icons.Rounded.Work, Color(0xFFF29900), if (work != null) "Work" else "Set work") {}
                }
                for (lp in mine.take(4)) Box(Modifier.carTap("place-" + lp.label) { engine.startRoute(lp.place) }) {
                    ImmChip(androidx.compose.material.icons.Icons.Rounded.Star, Color(0xFF12A4B4), lp.label) {}
                }
                Box(Modifier.carTap("saved") { actions.places() }) {
                    ImmChip(androidx.compose.material.icons.Icons.Rounded.History, Color(0xFF9CA4BF), "Saved & recent") {}
                }
            }
        }

        // alerts (cameras, limits, hazards...) across the top, clear of the turn card
        val alert = engine.alert
        AnimatedVisibility(alert != null, modifier = Modifier.align(Alignment.TopCenter).padding(top = top, start = if (guiding) maxWidth * 0.42f else left, end = right),
            enter = fadeIn(), exit = fadeOut()) { alert?.let { AlertBanner(it) } }

        if (!previewing && engine.arrival == null) Column(
            Modifier.align(Alignment.BottomStart).padding(start = left, bottom = bottom), verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // hazards just ahead, as in the app
            val inc = engine.incidentAhead; val cam = engine.cameraDist
            if ((inc != null && alert?.kind != "incident") || (cam != null && alert?.kind != "camera")) Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (inc != null && alert?.kind != "incident") HazardBadge("incident", inc.label, Geo.fmtDist(inc.dist, engine.imperial))
                if (cam != null && alert?.kind != "camera") HazardBadge("camera", "Speed camera", Geo.fmtDist(cam.toDouble(), engine.imperial))
            }
            val e = engine.eta
            if (guiding && e != null) {
                val dc = if (e.delayMin >= 10) Bad else if (e.delayMin >= 1) Warn else Good
                Column(Modifier.panel(10.dp, RoundedCornerShape(22.dp), c.surface)) {
                    if (engine.showRouteBar) {
                        RouteBar(engine, Modifier.width(380.dp).padding(start = 18.dp, end = 18.dp, top = 9.dp, bottom = 4.dp))
                        Box(Modifier.width(380.dp).padding(horizontal = 18.dp).height(1.dp).background(c.line))
                    }
                    Row(Modifier.widthIn(min = 380.dp).padding(start = 18.dp, end = 12.dp, top = 9.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                        ImmStat(Geo.fmtDur(e.secs), if (e.delayMin >= 1) "+${e.delayMin} min traffic" else "time left", dc)
                        ImmStat(e.arrive, "arrival", c.text)
                        ImmStat(Geo.fmtDist(e.dist, engine.imperial), "to go", c.text)
                        // end the route, as in the app
                        Box(Modifier.size(40.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Bad).carTap("end") { engine.endRoute() }, contentAlignment = Alignment.Center) {
                            androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Rounded.Close, null, tint = Color.White, modifier = Modifier.size(21.dp))
                        }
                    }
                }
            }
        }

        // your speed and the limit, bottom right as in the app (clear of Android Auto's zoom buttons; the limit sign sticks out
        // above and to the left of the ring, so there's room left for it)
        if (!previewing && engine.arrival == null) Box(Modifier.align(Alignment.BottomEnd).padding(end = right, bottom = bottom, start = 34.dp, top = 20.dp)) { ImmSpeed(engine) }

        // before setting off: the destination, the route choices and the Start bar that starts by itself after 10 s
        if (previewing) Box(Modifier.align(Alignment.BottomCenter).padding(start = left, end = right, bottom = bottom)) { CarRoutePreview(engine) }

        // the arrival summary
        val arr = engine.arrival
        if (arr != null) Box(Modifier.align(Alignment.BottomCenter).padding(bottom = bottom)) { ArrivalCard(engine, arr) }
    }
}

/** The app's route choice, as on its own screen: pick with the car's Next route button, start with Start (or wait 10 s). */
@Composable
private fun CarRoutePreview(engine: NavEngine) {
    val c = LocalVw.current
    val rs = engine.routes.take(3)
    if (rs.isEmpty()) return
    val fastest = rs.indices.minByOrNull { rs[it].time } ?: 0
    val shortest = rs.indices.minByOrNull { rs[it].len } ?: 0
    val progress = remember { Animatable(0f) }
    LaunchedEffect(engine.active, engine.routes) {
        progress.snapTo(0f)
        progress.animateTo(1f, tween(10000, easing = LinearEasing))
        if (engine.previewing) engine.beginNavigation()
    }
    val fmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
    val baseMs = if (engine.departAtMs > 0) engine.departAtMs else System.currentTimeMillis()
    Row(
        Modifier.fillMaxWidth().floating(28.dp).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Column(Modifier.width(170.dp)) {
            Text("Destination", color = c.sub, fontSize = 12.sp)
            Text(engine.dest?.name ?: "", color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        rs.forEachIndexed { i, r ->
            val sel = i == engine.active
            val label = if (i == fastest) "Fastest" else if (i == shortest) "Shortest" else "Alternative"
            Column(Modifier.weight(1f).inset(18.dp, if (sel) c.accent else null).carTap("route-$i") { engine.selectRoute(i) }.padding(horizontal = 14.dp, vertical = 9.dp)) {
                Text(label.uppercase(), color = if (sel) c.accent else c.sub, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(Geo.fmtDur(r.time), color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("${Geo.fmtDist(r.len, engine.imperial)} · arrive ${fmt.format(java.util.Date(baseMs + (r.time * 1000).toLong()))}", color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val via = viaOf(r)
                val delayMin = Math.round(r.delay / 60.0).toInt()
                Text(if (delayMin >= 1) "+$delayMin min traffic" else if (via.isNotEmpty()) "via $via" else "No delays",
                    color = if (delayMin >= 10) Bad else if (delayMin >= 1) Warn else c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Box(Modifier.width(220.dp).height(72.dp).clip(RoundedCornerShape(36.dp)).background(c.accent.copy(alpha = 0.30f)).carTap("start") { engine.beginNavigation() }, contentAlignment = Alignment.Center) {
            Box(Modifier.align(Alignment.CenterStart).fillMaxHeight().fillMaxWidth(progress.value).background(c.accent))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Start navigation", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Starting in ${kotlin.math.ceil((1f - progress.value) * 10f).toInt()} s", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            }
        }
        Box(Modifier.size(46.dp).clip(androidx.compose.foundation.shape.CircleShape).background(c.tile).carTap("cancel") { engine.endRoute() }, contentAlignment = Alignment.Center) {
            androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Rounded.Close, null, tint = c.text, modifier = Modifier.size(22.dp))
        }
    }
}
