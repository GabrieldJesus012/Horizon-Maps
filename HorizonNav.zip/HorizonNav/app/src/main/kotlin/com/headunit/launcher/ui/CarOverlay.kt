package com.headunit.launcher.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.headunit.launcher.Geo
import com.headunit.launcher.NavEngine

/**
 * The app's own cards on the Android Auto screen, drawn over the car's map exactly as in the app: the turn card (top left), and
 * your speed with the limit sign and the trip figures (bottom left). They keep clear of Android Auto's own buttons ([area] is the
 * part of the screen it leaves free). Nothing here can be tapped: Android Auto only lets its own buttons take touches.
 */
@Composable
fun CarOverlay(engine: NavEngine, area: State<android.graphics.Rect?>, dark: State<Boolean>) {
    VwTheme(dark.value) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val dens = LocalDensity.current
            val a = area.value
            val hPx = with(dens) { maxHeight.toPx() }
            val left = with(dens) { (a?.left ?: 0).toDp() } + 14.dp
            val top = with(dens) { (a?.top ?: 0).toDp() } + 14.dp
            val bottom = with(dens) { (hPx - (a?.bottom ?: hPx.toInt())).coerceAtLeast(0f).toDp() } + 14.dp
            val guiding = engine.route != null && !engine.previewing
            val t = engine.turn
            if (guiding && t != null) Box(Modifier.padding(start = left, top = top).width(minOf(400.dp, maxWidth * 0.36f))) { ImmTurnCard(engine, t) }
            Column(Modifier.align(Alignment.BottomStart).padding(start = left, bottom = bottom), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ImmSpeed(engine)
                val e = engine.eta
                if (guiding && e != null) {
                    val c = LocalVw.current
                    val dc = if (e.delayMin >= 10) Bad else if (e.delayMin >= 1) Warn else Good
                    Row(Modifier.panel(10.dp, RoundedCornerShape(22.dp), c.surface).padding(horizontal = 18.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                        ImmStat(Geo.fmtDur(e.secs), if (e.delayMin >= 1) "+${e.delayMin} min traffic" else "time left", dc)
                        ImmStat(e.arrive, "arrival", c.text)
                        ImmStat(Geo.fmtDist(e.dist, engine.imperial), "to go", c.text)
                    }
                }
            }
        }
    }
}
