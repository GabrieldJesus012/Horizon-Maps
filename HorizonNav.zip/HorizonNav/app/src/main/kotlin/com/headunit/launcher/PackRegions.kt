package com.headunit.launcher

import java.net.HttpURLConnection
import java.net.URL

/**
 * The areas an offline pack can be downloaded for. Each pack is built (once, on GitHub) from the matching Geofabrik extract of
 * OpenStreetMap and published as a release called "pack-<id>". England & Wales and Great Britain keep their original releases.
 *
 * The id comes from the Geofabrik path with the continent dropped: europe/france → "france", north-america/us/georgia → "us-georgia".
 * The "Build country packs" workflow uses exactly the same rule, so the app always knows where a pack will be.
 */
data class PackRegion(val id: String, val name: String, val group: String, val path: String, val country: String) {
    val url: String get() = "$RELEASES/pack-$id"
}

const val RELEASES = "https://github.com/benbishop028-arch/HeadUnitOrbis/releases/download"

object PackRegions {
    fun idOf(path: String): String {
        val parts = path.trim().trim('/').split('/')
        return (if (parts.size > 1) parts.drop(1) else parts).joinToString("-")
    }

    private fun r(group: String, path: String, name: String, cc: String) = PackRegion(idOf(path), name, group, path, cc)

    val groups = listOf("UK & Ireland", "Europe", "United States", "Canada", "Mexico & Central America", "South America")

    val all: List<PackRegion> = buildList {
        // the original UK packs (built by the "Build offline region pack" workflow)
        add(PackRegion("ew", "England & Wales", "UK & Ireland", "europe/great-britain", "GB"))
        add(PackRegion("gb", "Great Britain", "UK & Ireland", "europe/great-britain", "GB"))
        add(r("UK & Ireland", "europe/ireland-and-northern-ireland", "Ireland & Northern Ireland", "IE"))
        add(r("UK & Ireland", "europe/isle-of-man", "Isle of Man", "IM"))
        add(r("UK & Ireland", "europe/guernsey-jersey", "Guernsey & Jersey", "GG"))
        val eu = listOf(
            "albania" to ("Albania" to "AL"), "andorra" to ("Andorra" to "AD"), "austria" to ("Austria" to "AT"), "belarus" to ("Belarus" to "BY"),
            "belgium" to ("Belgium" to "BE"), "bosnia-herzegovina" to ("Bosnia & Herzegovina" to "BA"), "bulgaria" to ("Bulgaria" to "BG"),
            "croatia" to ("Croatia" to "HR"), "cyprus" to ("Cyprus" to "CY"), "czech-republic" to ("Czechia" to "CZ"), "denmark" to ("Denmark" to "DK"),
            "estonia" to ("Estonia" to "EE"), "faroe-islands" to ("Faroe Islands" to "FO"), "finland" to ("Finland" to "FI"), "france" to ("France" to "FR"),
            "georgia" to ("Georgia" to "GE"), "germany" to ("Germany" to "DE"), "greece" to ("Greece" to "GR"), "hungary" to ("Hungary" to "HU"),
            "iceland" to ("Iceland" to "IS"), "italy" to ("Italy" to "IT"), "kosovo" to ("Kosovo" to "XK"), "latvia" to ("Latvia" to "LV"),
            "liechtenstein" to ("Liechtenstein" to "LI"), "lithuania" to ("Lithuania" to "LT"), "luxembourg" to ("Luxembourg" to "LU"),
            "macedonia" to ("North Macedonia" to "MK"), "malta" to ("Malta" to "MT"), "moldova" to ("Moldova" to "MD"), "monaco" to ("Monaco" to "MC"),
            "montenegro" to ("Montenegro" to "ME"), "netherlands" to ("Netherlands" to "NL"), "norway" to ("Norway" to "NO"), "poland" to ("Poland" to "PL"),
            "portugal" to ("Portugal" to "PT"), "romania" to ("Romania" to "RO"), "serbia" to ("Serbia" to "RS"), "slovakia" to ("Slovakia" to "SK"),
            "slovenia" to ("Slovenia" to "SI"), "spain" to ("Spain" to "ES"), "sweden" to ("Sweden" to "SE"), "switzerland" to ("Switzerland" to "CH"),
            "turkey" to ("Turkey" to "TR"), "ukraine" to ("Ukraine" to "UA"),
        )
        for ((p, nc) in eu) add(r("Europe", "europe/$p", nc.first, nc.second))
        val states = listOf(
            "alabama", "alaska", "arizona", "arkansas", "california", "colorado", "connecticut", "delaware", "district-of-columbia", "florida",
            "georgia", "hawaii", "idaho", "illinois", "indiana", "iowa", "kansas", "kentucky", "louisiana", "maine", "maryland", "massachusetts",
            "michigan", "minnesota", "mississippi", "missouri", "montana", "nebraska", "nevada", "new-hampshire", "new-jersey", "new-mexico",
            "new-york", "north-carolina", "north-dakota", "ohio", "oklahoma", "oregon", "pennsylvania", "puerto-rico", "rhode-island",
            "south-carolina", "south-dakota", "tennessee", "texas", "utah", "vermont", "virginia", "washington", "west-virginia", "wisconsin", "wyoming",
        )
        for (s in states) add(r("United States", "north-america/us/$s", title(s), "US"))
        val provinces = listOf(
            "alberta", "british-columbia", "manitoba", "new-brunswick", "newfoundland-and-labrador", "northwest-territories", "nova-scotia",
            "nunavut", "ontario", "prince-edward-island", "quebec", "saskatchewan", "yukon",
        )
        for (s in provinces) add(r("Canada", "north-america/canada/$s", title(s), "CA"))
        add(r("Mexico & Central America", "north-america/mexico", "Mexico", "MX"))
        add(r("Mexico & Central America", "central-america", "Central America", ""))
        val sa = listOf(
            "argentina" to ("Argentina" to "AR"), "bolivia" to ("Bolivia" to "BO"), "brazil" to ("Brazil" to "BR"), "chile" to ("Chile" to "CL"),
            "colombia" to ("Colombia" to "CO"), "ecuador" to ("Ecuador" to "EC"), "paraguay" to ("Paraguay" to "PY"), "peru" to ("Peru" to "PE"),
            "suriname" to ("Suriname" to "SR"), "uruguay" to ("Uruguay" to "UY"), "venezuela" to ("Venezuela" to "VE"),
        )
        for ((p, nc) in sa) add(r("South America", "south-america/$p", nc.first, nc.second))
    }

    private fun title(s: String) = s.split('-').joinToString(" ") { w -> if (w == "of" || w == "and") w else w.replaceFirstChar { it.uppercase() } }

    fun byId(id: String): PackRegion = all.firstOrNull { it.id == id } ?: all.first()

    /** The best guess at a pack for the country you're in (GB → England & Wales). */
    fun suggestFor(cc: String): PackRegion? = when (cc.uppercase()) {
        "", "US", "CA" -> null          // these are split by state / province: let the person pick
        "GB" -> byId("ew")
        else -> all.firstOrNull { it.country.equals(cc, true) }
    }

    /**
     * Whether the pack for [r] has been built and published yet: its routing, map and search files are all there (they are built
     * side by side, so one can arrive before the others). Returns null when it couldn't be checked (no signal).
     */
    fun available(r: PackRegion): Boolean? = try {
        fun has(name: String): Boolean {
            val c = URL("${r.url}/$name").openConnection() as HttpURLConnection
            c.requestMethod = "HEAD"; c.connectTimeout = 10000; c.readTimeout = 10000; c.instanceFollowRedirects = true
            val ok = c.responseCode in 200..299
            c.disconnect()
            return ok
        }
        // the original UK packs came from the older workflow, where the map was optional: the routing files are enough there
        if (r.id == "ew" || r.id == "gb") has("valhalla.json")
        else has("valhalla.json") && (has("map.pmtiles") || has("map.pmtiles.part00")) && (has("places.tsv") || has("places.tsv.part00"))
    } catch (e: Exception) { null }
}
