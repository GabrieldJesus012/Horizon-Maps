package com.headunit.launcher

import java.net.HttpURLConnection
import java.net.URL

/**
 * The areas an offline pack can be downloaded for. Each pack is built (once, on GitHub) from the matching Geofabrik extract of
 * OpenStreetMap and published as a release called "pack-<id>". England & Wales and Great Britain keep their original releases.
 *
 * The id comes from the Geofabrik path with the continent dropped: europe/france → "france", north-america/us/georgia → "us-georgia".
 * The "Build country packs" workflow uses exactly the same rule, so the app always knows where a pack will be.
 */
data class PackRegion(val id: String, val name: String, val group: String, val path: String, val country: String) {
    // the original UK packs live in the HeadUnitOrbis repo; every other area is built in the Horizon-Maps repo
    val url: String get() = if (id == "ew" || id == "gb") "$RELEASES/pack-$id" else "$COUNTRY_RELEASES/pack-$id"
    /** Where the speed limit and camera files are: the same release, except the UK packs, whose extras are built in Horizon-Maps. */
    val extrasUrl: String get() = "$COUNTRY_RELEASES/pack-$id"
}

const val RELEASES = "https://github.com/benbishop028-arch/HeadUnitOrbis/releases/download"
const val COUNTRY_RELEASES = "https://github.com/benbishop028-arch/Horizon-Maps/releases/download"

object PackRegions {
    fun idOf(path: String): String {
        val parts = path.trim().trim('/').split('/')
        return (if (parts.size > 1) parts.drop(1) else parts).joinToString("-")
    }

    private fun r(group: String, path: String, name: String, cc: String) = PackRegion(idOf(path), name, group, path, cc)

    val groups = listOf("Reino Unido e Irlanda", "Europa", "Estados Unidos", "Canadá", "México e América Central", "América do Sul", "Ásia", "África", "Oceania")

    val all: List<PackRegion> = buildList {
        // the original UK packs (built by the "Build offline region pack" workflow)
        add(PackRegion("ew", "Inglaterra e País de Gales", "Reino Unido e Irlanda", "europe/great-britain", "GB"))
        // the rest of the UK is built like every other area (in Horizon-Maps), straight from Geofabrik's UK extracts
        add(r("Reino Unido e Irlanda", "europe/great-britain", "Grã-Bretanha (Inglaterra, Escócia e País de Gales)", "GB"))
        add(r("Reino Unido e Irlanda", "europe/united-kingdom/england", "Inglaterra", "GB"))
        add(r("Reino Unido e Irlanda", "europe/united-kingdom/scotland", "Escócia", "GB"))
        add(r("Reino Unido e Irlanda", "europe/united-kingdom/wales", "País de Gales", "GB"))
        add(r("Reino Unido e Irlanda", "europe/ireland-and-northern-ireland", "Irlanda e Irlanda do Norte", "IE"))
        add(r("Reino Unido e Irlanda", "europe/isle-of-man", "Ilha de Man", "IM"))
        add(r("Reino Unido e Irlanda", "europe/guernsey-jersey", "Guernsey e Jersey", "GG"))
        val eu = listOf(
            "albania" to ("Albânia" to "AL"), "andorra" to ("Andorra" to "AD"), "austria" to ("Áustria" to "AT"), "belarus" to ("Bielorrússia" to "BY"),
            "belgium" to ("Bélgica" to "BE"), "bosnia-herzegovina" to ("Bósnia e Herzegovina" to "BA"), "bulgaria" to ("Bulgária" to "BG"),
            "croatia" to ("Croácia" to "HR"), "cyprus" to ("Chipre" to "CY"), "czech-republic" to ("Tchéquia" to "CZ"), "denmark" to ("Dinamarca" to "DK"),
            "estonia" to ("Estônia" to "EE"), "faroe-islands" to ("Ilhas Faroé" to "FO"), "finland" to ("Finlândia" to "FI"), "france" to ("França" to "FR"),
            "georgia" to ("Geórgia" to "GE"), "germany" to ("Alemanha" to "DE"), "greece" to ("Grécia" to "GR"), "hungary" to ("Hungria" to "HU"),
            "iceland" to ("Islândia" to "IS"), "italy" to ("Itália" to "IT"), "kosovo" to ("Kosovo" to "XK"), "latvia" to ("Letônia" to "LV"),
            "liechtenstein" to ("Liechtenstein" to "LI"), "lithuania" to ("Lituânia" to "LT"), "luxembourg" to ("Luxemburgo" to "LU"),
            "macedonia" to ("Macedônia do Norte" to "MK"), "malta" to ("Malta" to "MT"), "moldova" to ("Moldávia" to "MD"), "monaco" to ("Mônaco" to "MC"),
            "montenegro" to ("Montenegro" to "ME"), "netherlands" to ("Países Baixos" to "NL"), "norway" to ("Noruega" to "NO"), "poland" to ("Polônia" to "PL"),
            "portugal" to ("Portugal" to "PT"), "romania" to ("Romênia" to "RO"), "serbia" to ("Sérvia" to "RS"), "slovakia" to ("Eslováquia" to "SK"),
            "slovenia" to ("Eslovênia" to "SI"), "spain" to ("Espanha" to "ES"), "sweden" to ("Suécia" to "SE"), "switzerland" to ("Suíça" to "CH"),
            "turkey" to ("Turquia" to "TR"), "ukraine" to ("Ucrânia" to "UA"),
        )
        for ((p, nc) in eu) add(r("Europa", "europe/$p", nc.first, nc.second))
        add(r("Europa", "europe/azores", "Açores", "PT"))
        add(r("Europa", "russia", "Rússia", "RU"))
        val states = listOf(
            "alabama", "alaska", "arizona", "arkansas", "california", "colorado", "connecticut", "delaware", "district-of-columbia", "florida",
            "georgia", "hawaii", "idaho", "illinois", "indiana", "iowa", "kansas", "kentucky", "louisiana", "maine", "maryland", "massachusetts",
            "michigan", "minnesota", "mississippi", "missouri", "montana", "nebraska", "nevada", "new-hampshire", "new-jersey", "new-mexico",
            "new-york", "north-carolina", "north-dakota", "ohio", "oklahoma", "oregon", "pennsylvania", "puerto-rico", "rhode-island",
            "south-carolina", "south-dakota", "tennessee", "texas", "utah", "vermont", "virginia", "washington", "west-virginia", "wisconsin", "wyoming",
        )
        for (s in states) add(r("Estados Unidos", "north-america/us/$s", title(s), "US"))
        val provinces = listOf(
            "alberta", "british-columbia", "manitoba", "new-brunswick", "newfoundland-and-labrador", "northwest-territories", "nova-scotia",
            "nunavut", "ontario", "prince-edward-island", "quebec", "saskatchewan", "yukon",
        )
        for (s in provinces) add(r("Canadá", "north-america/canada/$s", title(s), "CA"))
        add(r("México e América Central", "north-america/mexico", "México", "MX"))
        add(r("México e América Central", "central-america", "Central America (all)", ""))
        val ca = listOf(
            "bahamas" to ("Bahamas" to "BS"), "belize" to ("Belize" to "BZ"), "costa-rica" to ("Costa Rica" to "CR"), "cuba" to ("Cuba" to "CU"),
            "el-salvador" to ("El Salvador" to "SV"), "guatemala" to ("Guatemala" to "GT"), "haiti-and-domrep" to ("Haiti e República Dominicana" to "DO"),
            "honduras" to ("Honduras" to "HN"), "jamaica" to ("Jamaica" to "JM"), "nicaragua" to ("Nicarágua" to "NI"), "panama" to ("Panamá" to "PA"),
        )
        for ((p, nc) in ca) add(r("México e América Central", "central-america/$p", nc.first, nc.second))
        val sa = listOf(
            "argentina" to ("Argentina" to "AR"), "bolivia" to ("Bolívia" to "BO"), "brazil" to ("Brasil" to "BR"), "chile" to ("Chile" to "CL"),
            "colombia" to ("Colômbia" to "CO"), "ecuador" to ("Equador" to "EC"), "paraguay" to ("Paraguai" to "PY"), "peru" to ("Peru" to "PE"),
            "suriname" to ("Suriname" to "SR"), "guyana" to ("Guiana" to "GY"), "uruguay" to ("Uruguai" to "UY"), "venezuela" to ("Venezuela" to "VE"),
        )
        for ((p, nc) in sa) add(r("América do Sul", "south-america/$p", nc.first, nc.second))
        val asia = listOf(
            "afghanistan" to ("Afeganistão" to "AF"), "armenia" to ("Armênia" to "AM"), "azerbaijan" to ("Azerbaijão" to "AZ"), "bangladesh" to ("Bangladesh" to "BD"),
            "bhutan" to ("Butão" to "BT"), "cambodia" to ("Camboja" to "KH"), "china" to ("China" to "CN"), "east-timor" to ("Timor-Leste" to "TL"),
            "gcc-states" to ("Países do Golfo (Emirados, Arábia Saudita, Catar…)" to "AE"), "india" to ("Índia" to "IN"), "indonesia" to ("Indonésia" to "ID"),
            "iran" to ("Irã" to "IR"), "iraq" to ("Iraque" to "IQ"), "israel-and-palestine" to ("Israel e Palestina" to "IL"), "japan" to ("Japão" to "JP"),
            "jordan" to ("Jordânia" to "JO"), "kazakhstan" to ("Cazaquistão" to "KZ"), "kyrgyzstan" to ("Quirguistão" to "KG"), "laos" to ("Laos" to "LA"),
            "lebanon" to ("Líbano" to "LB"), "malaysia-singapore-brunei" to ("Malásia, Singapura e Brunei" to "MY"), "maldives" to ("Maldivas" to "MV"),
            "mongolia" to ("Mongólia" to "MN"), "myanmar" to ("Mianmar" to "MM"), "nepal" to ("Nepal" to "NP"), "north-korea" to ("Coreia do Norte" to "KP"),
            "pakistan" to ("Paquistão" to "PK"), "philippines" to ("Filipinas" to "PH"), "south-korea" to ("Coreia do Sul" to "KR"), "sri-lanka" to ("Sri Lanka" to "LK"),
            "syria" to ("Síria" to "SY"), "taiwan" to ("Taiwan" to "TW"), "tajikistan" to ("Tadjiquistão" to "TJ"), "thailand" to ("Tailândia" to "TH"),
            "turkmenistan" to ("Turcomenistão" to "TM"), "uzbekistan" to ("Uzbequistão" to "UZ"), "vietnam" to ("Vietnã" to "VN"), "yemen" to ("Iêmen" to "YE"),
        )
        for ((p, nc) in asia) add(r("Ásia", "asia/$p", nc.first, nc.second))
        val africa = listOf(
            "algeria" to ("Argélia" to "DZ"), "angola" to ("Angola" to "AO"), "benin" to ("Benin" to "BJ"), "botswana" to ("Botsuana" to "BW"),
            "burkina-faso" to ("Burquina Faso" to "BF"), "burundi" to ("Burundi" to "BI"), "cameroon" to ("Camarões" to "CM"), "canary-islands" to ("Ilhas Canárias" to "ES"),
            "cape-verde" to ("Cabo Verde" to "CV"), "central-african-republic" to ("República Centro-Africana" to "CF"), "chad" to ("Chade" to "TD"),
            "comores" to ("Comores" to "KM"), "congo-brazzaville" to ("Congo (Brazzaville)" to "CG"), "congo-democratic-republic" to ("Congo (Kinshasa)" to "CD"),
            "djibouti" to ("Djibuti" to "DJ"), "egypt" to ("Egito" to "EG"), "equatorial-guinea" to ("Guiné Equatorial" to "GQ"), "eritrea" to ("Eritreia" to "ER"),
            "ethiopia" to ("Etiópia" to "ET"), "gabon" to ("Gabão" to "GA"), "ghana" to ("Gana" to "GH"), "guinea" to ("Guiné" to "GN"),
            "guinea-bissau" to ("Guiné-Bissau" to "GW"), "ivory-coast" to ("Costa do Marfim" to "CI"), "kenya" to ("Quênia" to "KE"), "lesotho" to ("Lesoto" to "LS"),
            "liberia" to ("Libéria" to "LR"), "libya" to ("Líbia" to "LY"), "madagascar" to ("Madagascar" to "MG"), "malawi" to ("Malaui" to "MW"),
            "mali" to ("Mali" to "ML"), "mauritania" to ("Mauritânia" to "MR"), "mauritius" to ("Maurício" to "MU"), "morocco" to ("Marrocos" to "MA"),
            "mozambique" to ("Moçambique" to "MZ"), "namibia" to ("Namíbia" to "NA"), "niger" to ("Níger" to "NE"), "nigeria" to ("Nigéria" to "NG"),
            "rwanda" to ("Ruanda" to "RW"), "saint-helena-ascension-and-tristan-da-cunha" to ("Santa Helena, Ascensão e Tristão da Cunha" to "SH"),
            "sao-tome-and-principe" to ("São Tomé e Príncipe" to "ST"), "senegal-and-gambia" to ("Senegal e Gâmbia" to "SN"), "seychelles" to ("Seicheles" to "SC"),
            "sierra-leone" to ("Serra Leoa" to "SL"), "somalia" to ("Somália" to "SO"), "south-africa" to ("África do Sul" to "ZA"), "south-sudan" to ("Sudão do Sul" to "SS"),
            "sudan" to ("Sudão" to "SD"), "swaziland" to ("Essuatíni" to "SZ"), "tanzania" to ("Tanzânia" to "TZ"), "togo" to ("Togo" to "TG"),
            "tunisia" to ("Tunísia" to "TN"), "uganda" to ("Uganda" to "UG"), "zambia" to ("Zâmbia" to "ZM"), "zimbabwe" to ("Zimbábue" to "ZW"),
        )
        for ((p, nc) in africa) add(r("África", "africa/$p", nc.first, nc.second))
        val oceania = listOf(
            "australia" to ("Austrália" to "AU"), "new-zealand" to ("Nova Zelândia" to "NZ"), "american-oceania" to ("Oceania americana (Guam, Samoa…)" to "GU"),
            "cook-islands" to ("Ilhas Cook" to "CK"), "fiji" to ("Fiji" to "FJ"), "kiribati" to ("Quiribati" to "KI"), "marshall-islands" to ("Ilhas Marshall" to "MH"),
            "micronesia" to ("Micronésia" to "FM"), "nauru" to ("Nauru" to "NR"), "new-caledonia" to ("Nova Caledônia" to "NC"), "niue" to ("Niue" to "NU"),
            "palau" to ("Palau" to "PW"), "papua-new-guinea" to ("Papua-Nova Guiné" to "PG"), "polynesie-francaise" to ("Polinésia Francesa" to "PF"),
            "samoa" to ("Samoa" to "WS"), "solomon-islands" to ("Ilhas Salomão" to "SB"), "tonga" to ("Tonga" to "TO"), "tuvalu" to ("Tuvalu" to "TV"),
            "vanuatu" to ("Vanuatu" to "VU"), "wallis-et-futuna" to ("Wallis e Futuna" to "WF"),
        )
        for ((p, nc) in oceania) add(r("Oceania", "australia-oceania/$p", nc.first, nc.second))
    }

    private fun title(s: String) = s.split('-').joinToString(" ") { w -> if (w == "of" || w == "and") w else w.replaceFirstChar { it.uppercase() } }

    /** The area with this id; one that isn't in the list (built by hand) gets its id as its name. */
    fun byId(id0: String): PackRegion = (if (id0 == "gb") "great-britain" else id0).let { id -> all.firstOrNull { it.id == id }
        ?: PackRegion(id, id.replace('_', ' ').replace('-', ' ').replaceFirstChar { it.uppercase() }, "Outras", "", "") }

    /** The best guess at a pack for the country you're in (GB → England & Wales). */
    fun suggestFor(cc: String): PackRegion? = when (cc.uppercase()) {
        "", "US", "CA" -> null          // these are split by state / province: let the person pick
        "GB" -> byId("ew")
        else -> all.firstOrNull { it.country.equals(cc, true) }
    }

    /**
     * Whether the pack for [r] has been built and published yet: its routing, map and search files are all there (they are built
     * side by side, so one can arrive before the others). Returns null when it couldn't be checked (no signal).
     */
    /** Whether the speed limit file has been published for [r] (so an older download can pick it up with Update). Null: couldn't check. */
    fun hasExtras(r: PackRegion): Boolean? = try {
        val c = URL("${r.extrasUrl}/limits.bin").openConnection() as HttpURLConnection
        c.requestMethod = "HEAD"; c.connectTimeout = 10000; c.readTimeout = 10000; c.instanceFollowRedirects = true
        val ok = c.responseCode in 200..299
        c.disconnect()
        ok
    } catch (e: Exception) { null }

    /**
     * Whether newer map data has been published for [r] than what's in [d] (the downloaded area's folder): a rebuilt pack, or speed
     * limit / camera files that are new or have been redone since. Null when it couldn't be checked (no signal).
     */
    fun newerOnline(r: PackRegion, d: java.io.File): Boolean? = try {
        fun head(u: String): Long? {
            val c = URL(u).openConnection() as HttpURLConnection
            c.requestMethod = "HEAD"; c.connectTimeout = 10000; c.readTimeout = 10000; c.instanceFollowRedirects = true
            val ok = c.responseCode in 200..299
            val lm = c.lastModified
            c.disconnect()
            return if (ok) lm else null
        }
        var newer = false
        // the routing data (rebuilt with the rest of the pack): published well after this copy was downloaded
        val tiles = java.io.File(d, "tiles.tar")
        val t = head("${r.url}/tiles.tar") ?: head("${r.url}/tiles.tar.part00")
        if (t != null && t > 0L && tiles.exists() && t > tiles.lastModified() + 3_600_000L) newer = true
        // speed limits and cameras: new for this area, or redone since they were downloaded
        if (!newer) for (name in listOf("limits.bin", "cameras.tsv")) {
            val h = head("${r.extrasUrl}/$name") ?: continue
            val f = java.io.File(d, name)
            if (!f.exists() || (h > 0L && h > f.lastModified() + 600_000L)) { newer = true; break }
        }
        newer
    } catch (e: Exception) { null }

    fun available(r: PackRegion): Boolean? = try {
        fun has(name: String): Boolean {
            val c = URL("${r.url}/$name").openConnection() as HttpURLConnection
            c.requestMethod = "HEAD"; c.connectTimeout = 10000; c.readTimeout = 10000; c.instanceFollowRedirects = true
            val ok = c.responseCode in 200..299
            c.disconnect()
            return ok
        }
        // the original UK packs came from the older workflow, where the map was optional: the routing files are enough there
        if (r.id == "ew" || r.id == "gb") has("valhalla.json")
        else has("valhalla.json") && (has("map.pmtiles") || has("map.pmtiles.part00")) && (has("places.tsv") || has("places.tsv.part00"))
    } catch (e: Exception) { null }
}
