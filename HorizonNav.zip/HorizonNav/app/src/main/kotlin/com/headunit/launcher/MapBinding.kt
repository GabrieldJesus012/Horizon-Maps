package com.headunit.launcher

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import android.content.Context
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapLibreMapOptions
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.Layer
import org.maplibre.android.style.layers.FillLayer
import org.maplibre.android.style.layers.BackgroundLayer
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.layers.FillExtrusionLayer
import org.maplibre.android.style.layers.RasterLayer
import org.maplibre.android.style.sources.RasterSource
import org.maplibre.android.style.sources.TileSet
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.MultiLineString
import org.maplibre.geojson.Point

/** Owns the single native MapView so it can move between the Home preview and the full Navigation page. */
class MapBinding(private val ctx: Context, fast: Boolean = false, res: Float = 1f) : DefaultLifecycleObserver {
    val mapView: MapView
    var map: MapLibreMap? = null
        private set
    private var style: Style? = null
    private var wantedStyle: String? = null
    private var loadedStyle: String? = null

    private var main: List<LL> = emptyList()
    private var alts: List<List<LL>> = emptyList()
    private var dest: LL? = null
    private var me: LL? = null
    private var meHeading = 0.0

    var onLongPress: ((LL) -> Unit)? = null
    var onUserGesture: (() -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    private var satellite = false
    private var buildings3d = true
    private var lite = false
    private var hideTraffic = false
    private var routing = false
    private var roadLayerIds: Array<String>? = null
    private val origVisible = HashMap<String, Boolean>()
    var tiltNow = 0.0
        private set

    init {
        MapLibre.getInstance(ctx)
        val opts = MapLibreMapOptions.createFromAttributes(ctx)
            .textureMode(!fast)
            .attributionEnabled(true)
            // labels from different map sources no longer have to be checked against each other every frame (a big CPU saving on slow units)
            .crossSourceCollisions(false)
            .logoEnabled(false)
            .camera(CameraPosition.Builder().target(LatLng(51.5072, -0.1276)).zoom(14.0).tilt(55.0).build())
        // a lower render resolution is the biggest single saving on a slow GPU
        if (res < 1f) opts.pixelRatio(Math.max(0.6f, ctx.resources.displayMetrics.density * res))
        mapView = MapView(ctx, opts)
        mapView.onCreate(null)
        mapView.addOnWillStartRenderingFrameListener { if (PerfStats.on) PerfStats.renders++ }
        mapView.addOnDidFailLoadingMapListener { msg -> onError?.invoke(msg ?: "Map failed to load") }
        mapView.getMapAsync { m ->
            map = m
            m.setMaxPitchPreference(75.0)
            m.uiSettings.isCompassEnabled = false
            m.uiSettings.attributionGravity = android.view.Gravity.TOP or android.view.Gravity.END
            m.uiSettings.setAttributionMargins(0, 150, 26, 0)
            m.uiSettings.isRotateGesturesEnabled = true
            m.uiSettings.isTiltGesturesEnabled = true
            m.addOnMapLongClickListener { p ->
                onLongPress?.invoke(LL(p.latitude, p.longitude)); true
            }
            m.addOnCameraMoveStartedListener { reason ->
                if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) onUserGesture?.invoke()
            }
            m.addOnCameraMoveListener { refreshLamps(); refreshSignals() }
            m.addOnCameraIdleListener { refreshLamps(); refreshSignals() }
            wantedStyle?.let { loadStyle(it) }
        }
    }

    // ---- lifecycle ----
    override fun onStart(owner: LifecycleOwner) = mapView.onStart()
    override fun onResume(owner: LifecycleOwner) = mapView.onResume()
    override fun onPause(owner: LifecycleOwner) = mapView.onPause()
    override fun onStop(owner: LifecycleOwner) = mapView.onStop()
    override fun onDestroy(owner: LifecycleOwner) = mapView.onDestroy()

    // ---- style ----
    fun setStyleUrl(url: String) {
        wantedStyle = url
        if (map != null && url != loadedStyle) loadStyle(url)
    }

    /** "classic" or "immersive": changes the map colours, route, arrow and destination pin. Reloads the style when it changes. */
    var theme = "immersive"
        private set

    fun setTheme(t: String) {
        if (t == theme) return
        theme = t
        val w = wantedStyle
        if (map != null && w != null) { loadedStyle = null; loadStyle(w) }
    }

    private fun srcLayerOf(l: Layer): String = try {
        when (l) {
            is FillLayer -> l.sourceLayer
            is LineLayer -> l.sourceLayer
            is FillExtrusionLayer -> l.sourceLayer
            is SymbolLayer -> l.sourceLayer
            else -> ""
        } ?: ""
    } catch (e: Exception) { "" }

    /** Fill colour that is a slight green for grass, woods and parks and plain land colour for everything else, chosen per shape from its class. */
    private fun greenByClass(park: String, land: String): Expression {
        val kinds = arrayOf(
            "grass", "wood", "forest", "park", "garden", "meadow", "scrub", "heath", "farmland", "farm", "orchard", "vineyard", "recreation_ground", "recreation",
            "pitch", "golf_course", "golf", "cemetery", "nature_reserve", "village_green", "allotments", "common", "grassland", "tree", "trees", "wetland", "playground", "sports_centre", "green",
        )
        return Expression.match(
            Expression.downcase(Expression.toString(Expression.coalesce(Expression.get("class"), Expression.get("subclass"), Expression.get("kind"), Expression.get("type"), Expression.literal("")))),
            Expression.literal(kinds), Expression.color(android.graphics.Color.parseColor(park)),
            Expression.color(android.graphics.Color.parseColor(land)),
        )
    }

    /** Paints the base map in soft, light tones (or a deep blue-grey at night) by matching layer names to land, water, parks, roads and buildings. */
    private fun recolour(st: Style) {
        val dark = (wantedStyle ?: "").contains("dark", true)
        // gentle, even lighting on buildings: low contrast between wall faces, so they read as soft blocks rather than hard shapes
        try {
            val li = st.light
            li?.setIntensity(if (dark) 0.36f else 0.45f)
            li?.setPosition(org.maplibre.android.style.light.Position(1.25f, 215f, 48f))
        } catch (e: Exception) { }
        val land = if (dark) "#2D3358" else "#E0E4EF"
        val water = if (dark) "#2A6682" else "#ABD3E4"
        val park = if (dark) "#2E5C5E" else "#D0E2D6"
        val bld = if (dark) "#454C78" else "#CDD3E6"
        val ext = if (dark) "#59618E" else "#CED4E8"
        val roadFill = if (dark) "#464E7C" else "#F5F6FB"
        val roadCase = if (dark) "#262B4B" else "#C5CBDB"
        val hwyFill = if (dark) "#5E67A0" else "#F8F9FD"
        val hwyCase = if (dark) "#2B3052" else "#B3BCD3"
        val rail = if (dark) "#454C70" else "#C0C6D8"
        val text = if (dark) "#C9CEE8" else "#474D66"
        val halo = if (dark) "#2D3358" else "#EEF0F7"
        val parkWords = listOf("park", "green", "forest", "wood", "grass", "vegetation", "nature", "garden", "golf", "cemetery", "recreation", "pitch", "meadow", "scrub", "farm")
        val roadWords = listOf("road", "street", "motorway", "trunk", "highway", "primary", "secondary", "tertiary", "residential", "service", "link", "ramp", "track", "bridge", "tunnel", "path", "pedestrian", "transportation")
        val hwyWords = listOf("motorway", "trunk", "highway", "freeway", "expressway")
        // the wide blurred glow under the route is one of the most expensive things to draw; the light map leaves it out
        try { st.getLayer("dl-route-glow")?.setProperties(PropertyFactory.visibility(if (lite) Property.NONE else Property.VISIBLE)) } catch (e: Exception) { }
        for (l in st.layers) {
            val id = l.id
            if (id.startsWith("dl-")) continue
            val key = (id + " " + srcLayerOf(l)).lowercase()
            if (key.contains("traffic") || key.contains("flow") || key.contains("incident")) continue
            try {
                when (l) {
                    is BackgroundLayer -> l.setProperties(PropertyFactory.backgroundColor(land))
                    is FillLayer -> when {
                        key.contains("water") -> l.setProperties(PropertyFactory.fillColor(water))
                        parkWords.any { key.contains(it) } -> l.setProperties(PropertyFactory.fillColor(park))
                        key.contains("building") -> l.setProperties(PropertyFactory.fillColor(bld))
                        // generic land-cover / land-use layers hold grass, woods and parks together with plain ground: tint by each shape's class
                        listOf("landcover", "land cover", "landuse", "land use", "vegetation", "natural", "leisure", "green").any { key.contains(it) } ->
                            l.setProperties(PropertyFactory.fillColor(greenByClass(park, land)))
                        listOf("land", "background", "landuse", "urban", "residential", "commercial", "industrial").any { key.contains(it) } -> l.setProperties(PropertyFactory.fillColor(land))
                    }
                    is FillExtrusionLayer -> {
                        // taller buildings are a little deeper in tone, walls shade towards the ground and the light comes from one side, so blocks read as solid shapes
                        val h = Expression.switchCase(
                            Expression.has("render_height"), Expression.toNumber(Expression.get("render_height")),
                            Expression.has("height"), Expression.toNumber(Expression.get("height")),
                            Expression.literal(10),
                        )
                        val cols = if (dark) intArrayOf(0xFF3C4370.toInt(), 0xFF454C7E.toInt(), 0xFF51598F.toInt(), 0xFF5F68A0.toInt())
                                   else intArrayOf(0xFFDADEEB.toInt(), 0xFFCDD3E6.toInt(), 0xFFBFC6DE.toInt(), 0xFFB1BAD7.toInt())
                        l.setProperties(
                            PropertyFactory.fillExtrusionColor(Expression.interpolate(Expression.linear(), h,
                                Expression.stop(0, Expression.color(cols[0])), Expression.stop(20, Expression.color(cols[1])),
                                Expression.stop(60, Expression.color(cols[2])), Expression.stop(150, Expression.color(cols[3])))),
                            PropertyFactory.fillExtrusionOpacity(if (dark) 0.9f else 0.92f), PropertyFactory.fillExtrusionVerticalGradient(true))
                    }
                    is LineLayer -> {
                        val casing = key.contains("casing") || key.contains("case") || key.contains("outline") || key.contains("stroke")
                        val hwy = hwyWords.any { key.contains(it) }
                        when {
                            key.contains("water") || key.contains("river") || key.contains("stream") || key.contains("canal") -> l.setProperties(PropertyFactory.lineColor(water))
                            key.contains("rail") || key.contains("subway") || key.contains("transit") -> l.setProperties(PropertyFactory.lineColor(rail))
                            roadWords.any { key.contains(it) } -> l.setProperties(PropertyFactory.lineColor(if (casing) (if (hwy) hwyCase else roadCase) else (if (hwy) hwyFill else roadFill)))
                        }
                    }
                    is SymbolLayer -> l.setProperties(PropertyFactory.textColor(text), PropertyFactory.textHaloColor(halo), PropertyFactory.textHaloWidth(1.4f))
                    else -> {}
                }
            } catch (e: Exception) { }
        }
    }

    /** Google-style destination pin: red teardrop with a white centre. */
    private fun pinBitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(96, 128, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val path = Path().apply {
            addCircle(48f, 44f, 34f, Path.Direction.CW)
            moveTo(22f, 66f); lineTo(48f, 120f); lineTo(74f, 66f); close()
        }
        c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF000000.toInt(); setShadowLayer(8f, 0f, 4f, 0x66000000) })
        c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFEA4335.toInt(); style = Paint.Style.FILL })
        c.drawCircle(48f, 44f, 13f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8C1D18.toInt() })
        c.drawCircle(48f, 44f, 11f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() })
        return bmp
    }

    private var locatorCache: Pair<String, Bitmap>? = null

    /** The same locator picture the map uses (for the current map colours), for drawing it small elsewhere. Points up. */
    fun locatorBitmap(): Bitmap {
        locatorCache?.let { if (it.first == theme) return it.second }
        val b = if (theme == "immersive") arrowBitmapImmersive() else arrowBitmap()
        locatorCache = theme to b
        return b
    }

    /** Google Maps locator: a chunky white chevron with a visible edge, lying flat on the map. Points up; the badge is rotated by heading. */
    private fun arrowBitmapImmersive(): Bitmap {
        // the whole locator in one picture (translucent ring plus a soft 3D slab arrow), laid flat on the map, so the ring and the arrow always keep the
        // same proportions and squash together as the view tilts. Drawn 4x larger than it is shown (the layer's icon size scales it back down).
        val n = 384
        val cx = 192f; val cy = 192f
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val ringR = 160f
        c.drawCircle(cx, cy, ringR - 3f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB02F78AE.toInt() })
        c.drawCircle(cx, cy, ringR - 3f, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 7f; color = 0xB39ED0E2.toInt() })
        val top = Path().apply {
            moveTo(cx, cy - 125f)
            lineTo(cx + 91f, cy + 33f)
            lineTo(cx, cy + 11f)
            lineTo(cx - 91f, cy + 33f)
            close()
        }
        val round = android.graphics.CornerPathEffect(26f)
        val h = 34
        c.drawPath(Path(top).apply { offset(0f, h + 22f) }, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66102040; pathEffect = round; maskFilter = android.graphics.BlurMaskFilter(18f, android.graphics.BlurMaskFilter.Blur.NORMAL) })
        // the slab's wall: lighter at the top edge, darker towards the ground, so it reads as a solid block
        for (d in h downTo 1) {
            val t = d / h.toFloat()
            val col = android.graphics.Color.rgb((0xA4 - 0x3A * t).toInt(), (0xA5 - 0x3A * t).toInt(), (0xC8 - 0x38 * t).toInt())
            c.drawPath(Path(top).apply { offset(0f, d.toFloat()) }, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col; pathEffect = round })
        }
        c.drawPath(top, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            pathEffect = round
            shader = android.graphics.LinearGradient(0f, cy - 125f, 0f, cy + 33f, 0xFFF2F2F6.toInt(), 0xFFC4C5D0.toInt(), android.graphics.Shader.TileMode.CLAMP)
        })
        // a thin bright edge round the top face
        c.drawPath(top, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = 0x99FFFFFF.toInt(); pathEffect = round })
        return bmp
    }

    private fun loadStyle(url: String) {
        val m = map ?: return
        loadedStyle = url
        style = null
        m.setStyle(if (url.startsWith("{")) Style.Builder().fromJson(url) else Style.Builder().fromUri(url)) { st ->
            style = st
            install(st)
            try { tuneRoads(st) } catch (e: Throwable) { }
        }
    }

    /** A small street lamp standing upright: slim pole, curved arm, bright head, with its foot at the bottom of the image. */
    private fun lampBitmap(): Bitmap {
        val w = 96; val h = 192
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val foot = h - 6f
        val pole = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8C93A3.toInt(); style = Paint.Style.STROKE; strokeWidth = 7f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        val path = Path().apply { moveTo(34f, foot); lineTo(34f, 52f); quadTo(34f, 28f, 62f, 28f) }
        c.drawPath(path, Paint(pole).apply { color = 0x66000000; strokeWidth = 11f })
        c.drawPath(path, pole)
        c.drawCircle(62f, 30f, 26f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = android.graphics.RadialGradient(62f, 30f, 26f, intArrayOf(0xCCFFE2A0.toInt(), 0x55FFC860, 0x00FFC060), floatArrayOf(0f, 0.45f, 1f), android.graphics.Shader.TileMode.CLAMP)
        })
        c.drawRoundRect(android.graphics.RectF(50f, 24f, 74f, 33f), 4f, 4f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFF4D2.toInt() })
        return bmp
    }

    private fun lampAngle(q: DoubleArray): Double =
        if (q.size > 2) q[2] else (Math.abs(Math.round(q[0] * 1e5) * 31 + Math.round(q[1] * 1e5) * 17) % 4) * Math.PI / 2

    /** Where the lamp head hangs: about 1.8 m out along the arm. */
    private fun lampHead(q: DoubleArray): DoubleArray {
        val a = lampAngle(q)
        val dLat = 1.0 / 111320.0
        return doubleArrayOf(q[0] + Math.sin(a) * 2.0 * dLat, q[1] + Math.cos(a) * 2.0 * dLat / Math.cos(Math.toRadians(q[0])))
    }

    /** A 3D street lamp: round stepped pole on a flared base, a curved arm and a cobra-head lantern with a bright lens and a faint glow around it. Drawn a little bigger than life. */
    /** A round light sprite that fades out smoothly (Gaussian-like), warm white. */
    private fun glowBitmap(): Bitmap {
        val n = 256
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val steps = 16
        val cols = IntArray(steps + 1); val pos = FloatArray(steps + 1)
        for (k in 0..steps) {
            val r = k / steps.toFloat()
            val a = Math.exp(-Math.pow(r / 0.42, 2.0)).toFloat() * (1f - r * r * r * r)
            cols[k] = (Math.round(a.coerceIn(0f, 1f) * 255f) shl 24) or 0xFFF2DD
            pos[k] = r
        }
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = android.graphics.RadialGradient(n / 2f, n / 2f, n / 2f, cols, pos, android.graphics.Shader.TileMode.CLAMP)
        Canvas(bmp).drawRect(0f, 0f, n.toFloat(), n.toFloat(), p)
        return bmp
    }

    private fun lampSolids(lat: Double, lon: Double, ang: Double): Pair<List<Feature>, List<Feature>> {
        val dLat = 1.0 / 111320.0
        val dLon = dLat / Math.cos(Math.toRadians(lat))
        val ca = Math.cos(ang); val sa = Math.sin(ang)
        fun fin(ring: List<Pair<Double, Double>>, base: Double, top: Double, col: String): Feature {
            val pts = (ring + ring[0]).map { org.maplibre.geojson.Point.fromLngLat(lon + (it.first * ca - it.second * sa) * dLon, lat + (it.first * sa + it.second * ca) * dLat) }
            val f = Feature.fromGeometry(org.maplibre.geojson.Polygon.fromLngLats(listOf(pts)))
            f.addStringProperty("c", col); f.addNumberProperty("b", base); f.addNumberProperty("h", top)
            return f
        }
        fun box(x0: Double, x1: Double, y0: Double, y1: Double, base: Double, top: Double, col: String) =
            fin(listOf(x0 to y0, x1 to y0, x1 to y1, x0 to y1), base, top, col)
        fun round(r: Double, base: Double, top: Double, col: String) =
            fin((0 until 16).map { k -> val t = k * 2 * Math.PI / 16; r * Math.cos(t) to r * Math.sin(t) }, base, top, col)
        fun ell(cx: Double, rx: Double, ry: Double, base: Double, top: Double, col: String) =
            fin((0 until 14).map { k -> val t = k * 2 * Math.PI / 14; (cx + rx * Math.cos(t)) to ry * Math.sin(t) }, base, top, col)
        // height of the arm's centre line: it rises out of the pole in a smooth curve, then levels off and dips slightly toward the lantern
        fun armZ(x: Double) = if (x < 1.1) 6.3 + 0.72 * Math.sin(x / 1.1 * Math.PI / 2) else 7.02 - 0.14 * (x - 1.1) / 0.9
        val solid = ArrayList<Feature>()
        solid += round(0.40, 0.0, 0.14, "#3A404B")             // flared foot
        solid += round(0.29, 0.14, 0.42, "#454C59")
        solid += round(0.23, 0.42, 0.58, "#5E6675")            // collar
        // pole tapers upward in small steps so it reads as one smooth tube
        for (k in 0 until 6) {
            val r = 0.19 - 0.065 * k / 5.0
            val z0 = 0.58 + k * 0.97
            solid += round(r, z0, z0 + 0.99, if (k < 3) "#7F8798" else "#929AAB")
        }
        // curved arm made of short overlapping pieces that follow the curve
        for (k in 0 until 11) {
            val x0 = k * 0.17; val x1 = x0 + 0.2
            val zc = armZ((x0 + x1) / 2)
            solid += box(x0 - 0.05, x1, -0.065, 0.065, zc - 0.08, zc + 0.08, "#A3ABBA")
        }
        // cobra-head lantern: rounded, tapering shell with a bright lens underneath
        solid += ell(2.45, 0.66, 0.33, 6.62, 6.80, "#4A515D")
        solid += ell(2.45, 0.54, 0.27, 6.80, 6.92, "#5B6270")
        solid += ell(2.5, 0.58, 0.29, 6.54, 6.62, "#2F343E")
        solid += ell(2.55, 0.5, 0.25, 6.47, 6.54, "#FFFEF6")      // lit lens
        val halo = listOf(
            ell(2.55, 0.85, 0.5, 6.1, 6.47, "#FFF4DC"),
            ell(2.55, 1.15, 0.7, 5.7, 6.1, "#FFF4DC"),
        )
        return Pair(solid, halo)
    }

    private var lampLat = 999.0
    private var lampLon = 0.0
    private var lampZ = 0
    private var lampAt = 0L
    private var lampBusy = false
    private var lampRetry = false

    /** Loads the real street lamps around the screen into the night map (only when the pack has lamps.tsv). */
    /** Set when the last run never finished (the app froze or crashed inside the lamp code): lamps then switch themselves off. */
    var lampsOn = true
    var lampTripped = false
    private val guard by lazy { ctx.getSharedPreferences("lampguard", Context.MODE_PRIVATE) }
    fun initLampGuard() {
        if (guard.getBoolean("busy", false)) { lampsOn = false; lampTripped = true; guard.edit().putBoolean("busy", false).apply() }
    }
    fun lampsEnabled(on: Boolean) {
        lampsOn = on
        if (!on) { try { (style?.getSource("dl-lamp-src") as? GeoJsonSource)?.setGeoJson(empty()); (style?.getSource("dl-lamp-3d") as? GeoJsonSource)?.setGeoJson(empty()); (style?.getSource("dl-lamp-halo") as? GeoJsonSource)?.setGeoJson(empty()) } catch (e: Throwable) { } }
        else { lampLat = 999.0; lampAt = 0L }
    }

    // ---- traffic lights (OpenStreetMap), fetched one map tile at a time and kept ----
    var signalsOn = true
    private val signalTiles = object : LinkedHashMap<Long, List<LL>>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, List<LL>>?) = size > 40
    }
    private val signalFailed = HashMap<Long, Long>()
    private var signalBusy = false
    private var signalAt = 0L
    private var signalPts: List<LL> = emptyList()
    private var signalErr = ""
    private var signalToken = 0
    private var signalStage = "not started"

    /** One line for the settings page: how many lights are known and whether the last fetch worked. */
    fun signalInfo(): String {
        if (!signalsOn) return "off"
        if (main.size < 2) return "no route (lights only show on your route)"
        val onR = try { signalFeatures().features()?.size ?: 0 } catch (e: Throwable) { 0 }
        return "$onR on route, ${signalPts.size} nearby, ${signalTiles.size} area(s) loaded" + (if (signalErr.isNotEmpty()) ", last error: $signalErr" else "") + ", status: $signalStage"
    }

    fun signalsEnabled(on: Boolean) {
        signalsOn = on
        if (on) { signalAt = 0L; refreshSignals() } else { signalPts = emptyList(); pushSignals() }
    }

    private fun signalBitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(48, 96, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xF21B2029.toInt() }
        c.drawRoundRect(RectF(4f, 4f, 44f, 92f), 14f, 14f, body)
        val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = 0x55FFFFFF }
        c.drawRoundRect(RectF(4f, 4f, 44f, 92f), 14f, 14f, edge)
        val dot = Paint(Paint.ANTI_ALIAS_FLAG)
        dot.color = 0xFFFF5A52.toInt(); c.drawCircle(24f, 22f, 10f, dot)
        dot.color = 0xFFFFC043.toInt(); c.drawCircle(24f, 48f, 10f, dot)
        dot.color = 0xFF3DDC84.toInt(); c.drawCircle(24f, 74f, 10f, dot)
        return bmp
    }

    // only the lights on the road you are following are drawn: the route is turned into a set of small grid cells, and a light counts if it sits in or next to one
    private var cellsFor: List<LL>? = null
    private val routeCells = HashSet<Long>()
    private fun cellKey(lat: Double, lon: Double) = Math.floor(lat / 0.0002).toLong() * 1000003L + Math.floor(lon / 0.0003).toLong()

    private fun rebuildCells(r: List<LL>) {
        routeCells.clear()
        for (i in r.indices) {
            val a = r[i]
            routeCells.add(cellKey(a.lat, a.lon))
            if (i + 1 < r.size) {
                val b = r[i + 1]
                val steps = (Geo.dist(a, b) / 15.0).toInt()
                for (k in 1..steps) { val t = k / (steps + 1.0); routeCells.add(cellKey(a.lat + (b.lat - a.lat) * t, a.lon + (b.lon - a.lon) * t)) }
            }
        }
        cellsFor = r
    }

    private fun onRoute(p: LL): Boolean {
        val k = Math.floor(p.lat / 0.0002).toLong() * 1000003L + Math.floor(p.lon / 0.0003).toLong()
        for (dy in -1..1) for (dx in -1..1) if (routeCells.contains(k + dy * 1000003L + dx)) return true
        return false
    }

    private fun signalFeatures(): FeatureCollection {
        val r = main
        if (r.size < 2) return empty()
        if (cellsFor !== r) rebuildCells(r)
        return FeatureCollection.fromFeatures(ArrayList(signalPts.filter { onRoute(it) }.take(150).map { Feature.fromGeometry(Point.fromLngLat(it.lon, it.lat)) }))
    }

    private fun pushSignals() {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try { (style?.getSource("dl-signals") as? GeoJsonSource)?.setGeoJson(signalFeatures()) } catch (e: Throwable) { }
        }
    }

    private fun refreshSignals() {
        if (!signalsOn || main.size < 2) return
        try {
            val m = map ?: return
            if (style == null) { signalStage = "waiting for the map style"; return }
            if (signalBusy) { signalStage = "loading lights…"; return }
            if (!mapView.isAttachedToWindow || !mapView.isShown || mapView.width < 50 || mapView.height < 50) return
            val cam = m.cameraPosition
            if (cam.zoom < 13.5) { signalStage = "zoomed out too far (zoom ${cam.zoom.toInt()})"; return }
            val c = cam.target ?: return
            val now = android.os.SystemClock.uptimeMillis()
            if (now - signalAt < 1200) return
            // tiles are about 1.5 km on a side
            val tx = Math.floor((c.longitude + 180.0) / 360.0 * 16384.0).toLong()
            val ty = Math.floor((1.0 - Math.log(Math.tan(Math.toRadians(c.latitude)) + 1.0 / Math.cos(Math.toRadians(c.latitude))) / Math.PI) / 2.0 * 16384.0).toLong()
            val centreKey = tx * 100000L + ty
            // the tile under the camera plus its neighbours, whichever are already known
            val have = ArrayList<LL>()
            for (dx in -1..1) for (dy in -1..1) signalTiles[(tx + dx) * 100000L + (ty + dy)]?.let { have.addAll(it) }
            val merged = have.distinctBy { Math.round(it.lat * 1e6) * 1000003L + Math.round(it.lon * 1e6) }
                .sortedBy { Math.abs(it.lat - c.latitude) + Math.abs(it.lon - c.longitude) }.take(400)
            if (merged.size != signalPts.size) { signalPts = merged; pushSignals() }
            if (signalTiles.containsKey(centreKey)) return
            val failedAt = signalFailed[centreKey]
            if (failedAt != null && now - failedAt < 20_000L) return
            signalBusy = true; signalAt = now; signalStage = "loading lights…"
            val token = ++signalToken
            // if the request has not come back after 30 s, give up on it so the next attempt can start
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                if (signalBusy && token == signalToken) { signalBusy = false; signalFailed[centreKey] = android.os.SystemClock.uptimeMillis(); signalErr = "timed out (" + Overpass.lastNote.take(80) + ")" }
            }, 30_000L)
            fun lonOf(x: Double) = x / 16384.0 * 360.0 - 180.0
            fun latOf(y: Double) = Math.toDegrees(Math.atan(Math.sinh(Math.PI * (1.0 - 2.0 * y / 16384.0))))
            val minLon = lonOf(tx - 0.4); val maxLon = lonOf(tx + 1.4)
            val maxLat = latOf(ty - 0.4); val minLat = latOf(ty + 1.4)
            Thread {
                try {
                    val offline = OfflineRouter.hasSignals(ctx)
                    val pts = if (offline) OfflineRouter.lamps(ctx, minLat, minLon, maxLat, maxLon, "signals.tsv").map { LL(it[0], it[1]) } else Overpass.signals(minLat, minLon, maxLat, maxLon)
                    if (offline) Overpass.lastNote = "offline pack"
                    android.os.Handler(android.os.Looper.getMainLooper()).post { signalTiles[centreKey] = pts; if (token == signalToken) signalBusy = false; signalErr = ""; signalStage = "loaded ${pts.size} lights (${Overpass.lastNote})"; signalAt = 0L; refreshSignals() }
                } catch (e: Throwable) {
                    val msg = (e.message ?: e.javaClass.simpleName).take(80)
                    android.os.Handler(android.os.Looper.getMainLooper()).post { signalFailed[centreKey] = android.os.SystemClock.uptimeMillis(); if (token == signalToken) signalBusy = false; signalErr = msg }
                }
            }.start()
        } catch (e: Throwable) { signalBusy = false; signalErr = "internal: " + (e.message ?: e.javaClass.simpleName).take(60) }
    }

    private fun refreshLamps() {
        if (!lampsOn) return
        try { refreshLampsInner() } catch (e: Throwable) { lampBusy = false; guard.edit().putBoolean("busy", false).apply() }
    }

    private fun refreshLampsInner() {
        val m = map ?: return
        val st = style ?: return
        if (!nightStyle || lampBusy || st.getSource("dl-lamp-src") == null) return
        // the map view is taken off screen while a settings page is open; asking a detached map about its features can block forever
        if (!mapView.isAttachedToWindow || !mapView.isShown || mapView.width < 50 || mapView.height < 50 || mapView.windowVisibility != android.view.View.VISIBLE) return
        val cam = m.cameraPosition
        val z = cam.zoom
        if (z < 15.0) return
        val now = android.os.SystemClock.uptimeMillis()
        val c = cam.target ?: return
        val moved = Math.hypot((c.latitude - lampLat) * 111000.0, (c.longitude - lampLon) * 111000.0 * Math.cos(Math.toRadians(c.latitude)))
        if (moved < (if (OfflineRouter.hasLamps(ctx)) 150.0 else 30.0) && (z * 2).toInt() == lampZ && lampLat != 999.0) return
        if (now - lampAt < 2500) {
            // too soon: try again once the pause is over, so lamps never wait for the next camera move
            if (!lampRetry) { lampRetry = true; android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ lampRetry = false; refreshLamps() }, 2600L - (now - lampAt)) }
            return
        }
        val b = try { m.projection.visibleRegion.latLngBounds } catch (e: Throwable) { return }
        val padLat = (b.latitudeNorth - b.latitudeSouth) * 0.4
        val padLon = (b.longitudeEast - b.longitudeWest) * 0.4
        lampBusy = true; lampAt = now; lampLat = c.latitude; lampLon = c.longitude; lampZ = (z * 2).toInt()
        // the "busy" mark is only held while the map itself is being asked or told something, so an unrelated crash elsewhere is not blamed on the lamps
        guard.edit().putBoolean("busy", true).commit()
        val roadFeats = try { if (OfflineRouter.hasLamps(ctx)) null else queryLampRoads(m) } finally { guard.edit().putBoolean("busy", false).commit() }
        val cLat = c.latitude; val cLon = c.longitude
        Thread {
          try {
            val pts = if (roadFeats != null) keepNearby(guessLamps(roadFeats), cLat, cLon) else thin(OfflineRouter.lamps(ctx, b.latitudeSouth - padLat, b.longitudeWest - padLon, b.latitudeNorth + padLat, b.longitudeEast + padLon))
            val solids = ArrayList<Feature>()
            val halos = ArrayList<Feature>()
            if (z >= 16.5) for (q in pts.sortedBy { Math.abs(it[0] - cLat) + Math.abs(it[1] - cLon) }.take(36)) { val pr = lampSolids(q[0], q[1], lampAngle(q)); solids.addAll(pr.first); halos.addAll(pr.second) }
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                lampBusy = false
                guard.edit().putBoolean("busy", true).commit()
                try {
                    val fc = FeatureCollection.fromFeatures(ArrayList(pts.take(250).map { q -> val h = lampHead(q); Feature.fromGeometry(org.maplibre.geojson.Point.fromLngLat(h[1], h[0])) }))
                    (style?.getSource("dl-lamp-src") as? GeoJsonSource)?.setGeoJson(fc)
                    (style?.getSource("dl-lamp-3d") as? GeoJsonSource)?.setGeoJson(FeatureCollection.fromFeatures(solids))
                    (style?.getSource("dl-lamp-halo") as? GeoJsonSource)?.setGeoJson(FeatureCollection.fromFeatures(halos))
                } catch (e: Throwable) { }
                guard.edit().putBoolean("busy", false).commit()
            }
          } catch (e: Throwable) {
            android.os.Handler(android.os.Looper.getMainLooper()).post { lampBusy = false; guard.edit().putBoolean("busy", false).apply() }
          }
        }.start()
    }

    /** Set by the engine: true when the night style is showing. */
    var nightStyle = true

    /** Day: nudge road fills a little darker so they separate from the land. Night: faint lamp glows along the roads (drawn from the road geometry, not surveyed lamp positions). */
    private fun tuneRoads(st: Style) {
        val roads = st.layers.filter { it is LineLayer && !it.id.startsWith("dl-") && roadLike(it.id) }.map { it as LineLayer }
        if (!nightStyle) {
            for (l in roads) {
                val id = l.id.lowercase()
                if (id.contains("casing") || id.contains("outline")) continue
                try {
                    val c = l.lineColorAsInt
                    val f = 0.80f
                    val r = ((c shr 16 and 255) * f).toInt(); val g = ((c shr 8 and 255) * f).toInt(); val b = ((c and 255) * f).toInt()
                    l.setProperties(PropertyFactory.lineColor(0xFF000000.toInt() or (r shl 16) or (g shl 8) or b))
                } catch (e: Throwable) { }
            }
            return
        }
        st.addSource(GeoJsonSource("dl-lamp-src", empty()))
        // light: a soft, smoothly fading sprite (not stacked rings), laid on the ground as a pool, plus a small glow around the lamp head
        st.addImage("dl-lamp-glow-img", glowBitmap())
        fun glowLayer(id: String, ground: Boolean, z16: Float, z19: Float, op: Float) {
            st.addLayerBelow(SymbolLayer(id, "dl-lamp-src").withProperties(
                PropertyFactory.iconImage("dl-lamp-glow-img"),
                PropertyFactory.iconAllowOverlap(true), PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconPitchAlignment(if (ground) Property.ICON_PITCH_ALIGNMENT_MAP else Property.ICON_PITCH_ALIGNMENT_VIEWPORT),
                PropertyFactory.iconRotationAlignment(if (ground) Property.ICON_ROTATION_ALIGNMENT_MAP else Property.ICON_ROTATION_ALIGNMENT_VIEWPORT),
                PropertyFactory.iconOpacity(op),
                PropertyFactory.iconSize(Expression.interpolate(Expression.exponential(2), Expression.zoom(), Expression.stop(16, z16), Expression.stop(19, z19))),
            ).also { it.minZoom = 16f }, "dl-alts-line")
        }
        glowLayer("dl-lamp-pool", true, 0.07f, 0.62f, 0.5f)
        glowLayer("dl-lamp-halo2", false, 0.04f, 0.34f, 0.4f)
        glowLayer("dl-lamp-bulb", false, 0.012f, 0.1f, 0.95f)
        st.addSource(GeoJsonSource("dl-lamp-3d", empty()))
        st.addLayerBelow(org.maplibre.android.style.layers.FillExtrusionLayer("dl-lamp-core", "dl-lamp-3d").withProperties(
            PropertyFactory.fillExtrusionColor(Expression.toColor(Expression.get("c"))),
            PropertyFactory.fillExtrusionHeight(Expression.get("h")),
            PropertyFactory.fillExtrusionBase(Expression.get("b")),
            PropertyFactory.fillExtrusionOpacity(1f),
            PropertyFactory.fillExtrusionVerticalGradient(false),
        ).also { it.minZoom = 16.5f }, "dl-alts-line")
        st.addSource(GeoJsonSource("dl-lamp-halo", empty()))
        st.addLayerBelow(org.maplibre.android.style.layers.FillExtrusionLayer("dl-lamp-halo-l", "dl-lamp-halo").withProperties(
            PropertyFactory.fillExtrusionColor(0xFFFFF4DC.toInt()),
            PropertyFactory.fillExtrusionHeight(Expression.get("h")),
            PropertyFactory.fillExtrusionBase(Expression.get("b")),
            PropertyFactory.fillExtrusionOpacity(0.2f),
            PropertyFactory.fillExtrusionVerticalGradient(false),
        ).also { it.minZoom = 16.5f }, "dl-alts-line")
        lampIds = roads.filter { l -> val id = l.id.lowercase(); !(id.contains("casing") || id.contains("outline") || id.contains("tunnel") || id.contains("motorway") || id.contains("trunk")) }.map { it.id }.toTypedArray()
        lampLat = 999.0
    }

    private var lampCache: List<DoubleArray> = emptyList()

    /** Lamps stay where they were first put: new road pieces from the map only fill gaps, so zooming out and in (when the map redraws the roads from different tiles) never moves them. */
    private fun keepNearby(fresh: List<DoubleArray>, cLat: Double, cLon: Double): List<DoubleArray> {
        val cell = Math.max(6.0, lampGap * 0.6)
        val grid = HashMap<Long, ArrayList<DoubleArray>>()
        val out = ArrayList<DoubleArray>()
        val kx = 111320.0 * Math.cos(Math.toRadians(cLat))
        fun cellOf(q: DoubleArray) = longArrayOf(Math.floor(q[0] * 111320.0 / cell).toLong(), Math.floor(q[1] * kx / cell).toLong())
        fun near(q: DoubleArray): Boolean {
            val c = cellOf(q)
            for (dy in -1L..1L) for (dx in -1L..1L) {
                val l = grid[(c[0] + dy) * 1000003L + (c[1] + dx)] ?: continue
                for (o in l) if (Math.hypot((o[0] - q[0]) * 111320.0, (o[1] - q[1]) * kx) < cell) return true
            }
            return false
        }
        fun add(q: DoubleArray) {
            val c = cellOf(q)
            grid.getOrPut(c[0] * 1000003L + c[1]) { ArrayList() }.add(q); out.add(q)
        }
        lampCache.forEach { add(it) }
        for (q in fresh) if (!near(q)) add(q)
        val res = if (out.size > 3000) out.sortedBy { Math.abs(it[0] - cLat) + Math.abs(it[1] - cLon) }.take(3000) else out
        lampCache = res
        return res
    }

    private var lampIds: Array<String> = emptyArray()

    /** How far apart lamps are placed, in metres (the user's setting). */
    var lampGap = 40.0
    fun applyLampGap(m: Double) {
        if (m == lampGap) return
        lampGap = m; lampLat = 999.0; lampAt = 0L; lampCache = emptyList()
    }

    /** Lamps at guessed positions: walks along the roads drawn on screen and puts one on alternate sides every [lampGap] metres. */
    private fun queryLampRoads(m: MapLibreMap): List<Feature> {
        if (lampIds.isEmpty()) return emptyList()
        val w = mapView.width.toFloat(); val h = mapView.height.toFloat()
        val rect = android.graphics.RectF(0f, 0f, w, h)
        return try { m.queryRenderedFeatures(rect, *lampIds.take(6).toTypedArray()).take(120) } catch (e: Throwable) { emptyList() }
    }

    private fun guessLamps(feats: List<Feature>): List<DoubleArray> {
        val out = ArrayList<DoubleArray>()
        val seen = HashSet<Long>()
        var side = 1.0
        fun walk(pts: List<org.maplibre.geojson.Point>) {
            var carry = lampGap / 2
            for (i in 0 until pts.size - 1) {
                val la0 = pts[i].latitude(); val lo0 = pts[i].longitude()
                val k = Math.cos(Math.toRadians(la0)) * 111320.0
                val dx = (pts[i + 1].longitude() - lo0) * k; val dy = (pts[i + 1].latitude() - la0) * 111320.0
                val len = Math.hypot(dx, dy)
                if (len < 0.5) continue
                var d = carry
                while (d < len) {
                    val t = d / len
                    val nx = -dy / len; val ny = dx / len
                    val sd = side; val off = 5.0 * sd; side = -sd
                    val ang = Math.atan2(-ny * sd, -nx * sd)
                    val la = la0 + (dy * t + ny * off) / 111320.0
                    val lo = lo0 + (dx * t + nx * off) / k
                    val key = Math.round(la * 30000.0) * 1000003L + Math.round(lo * 30000.0)
                    if (seen.add(key)) out.add(doubleArrayOf(la, lo, ang))
                    d += lampGap
                }
                carry = d - len
            }
        }
        for (f in feats) {
            when (val g = f.geometry()) {
                is org.maplibre.geojson.LineString -> walk(g.coordinates())
                is org.maplibre.geojson.MultiLineString -> for (ln in g.coordinates()) walk(ln)
                else -> { }
            }
            if (out.size > 500) break
        }
        return out
    }

    /** Keeps at most one real lamp per [lampGap] metres square. */
    private fun thin(pts: List<DoubleArray>): List<DoubleArray> {
        if (lampGap <= 12) return pts
        val seen = HashSet<Long>()
        val out = ArrayList<DoubleArray>()
        for (q in pts) {
            val gx = Math.floor(q[1] * 111320.0 * Math.cos(Math.toRadians(q[0])) / lampGap).toLong()
            val gy = Math.floor(q[0] * 111320.0 / lampGap).toLong()
            if (seen.add(gy * 1000003L + gx)) out.add(q)
        }
        return out
    }

    /** Waze-style arrow: fat rounded chevron, blue fill, thick white outline and a soft shadow. Points up; rotated by heading. */
    private fun arrowBitmap(): Bitmap {
        val n = 128
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val path = Path().apply {
            moveTo(64f, 14f)
            quadTo(70f, 14f, 74f, 22f)
            lineTo(100f, 92f)
            quadTo(104f, 104f, 92f, 100f)
            lineTo(64f, 84f)
            lineTo(36f, 100f)
            quadTo(24f, 104f, 28f, 92f)
            lineTo(54f, 22f)
            quadTo(58f, 14f, 64f, 14f)
            close()
        }
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x00000000; style = Paint.Style.FILL; setShadowLayer(10f, 0f, 5f, 0x80000000.toInt())
        }
        c.drawPath(path, shadow)
        val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 12f; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
        }
        c.drawPath(path, edge)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = android.graphics.LinearGradient(0f, 14f, 0f, 104f, 0xFF3AA0FF.toInt(), 0xFF1263E0.toInt(), android.graphics.Shader.TileMode.CLAMP)
        }
        c.drawPath(path, fill)
        return bmp
    }

    private fun empty() = FeatureCollection.fromFeatures(ArrayList<Feature>())

    private fun install(st: Style) {
        val im = theme == "immersive"
        if (im && !(wantedStyle ?: "").startsWith("{")) recolour(st)
        st.addSource(GeoJsonSource("dl-alts", empty()))
        st.addSource(GeoJsonSource("dl-route", empty()))
        st.addSource(GeoJsonSource("dl-done", empty()))
        st.addSource(GeoJsonSource("dl-dest", empty()))
        st.addSource(GeoJsonSource("dl-hazards", empty()))
        st.addSource(GeoJsonSource("dl-me", empty()))
        st.addSource(GeoJsonSource("dl-lanes", empty()))
        laneImgs.clear()
        // lane bands: each lane drawn as a strip along the road before a junction, the lane(s) you need lit, the others dimmed, with dashed dividers
        st.addSource(GeoJsonSource("dl-lane-bands", empty()))
        st.addSource(GeoJsonSource("dl-lane-divs", empty()))
        st.addLayer(
            LineLayer("dl-alts-line", "dl-alts").withProperties(
                PropertyFactory.lineColor(if (im) "#9AA7B8" else "#8fa3bd"), PropertyFactory.lineWidth(if (im) 8f else 7f), PropertyFactory.lineOpacity(0.85f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            LineLayer("dl-route-glow", "dl-route").withProperties(
                PropertyFactory.lineColor(sevColor(im)), PropertyFactory.lineWidth(routeW(if (im) 2.3f else 1.7f)), PropertyFactory.lineBlur(12f),
                PropertyFactory.lineOpacity(if (im) 0.62f else 0.4f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            LineLayer("dl-route-casing", "dl-route").withProperties(
                PropertyFactory.lineColor(if (im) "#D4F4FF" else "#eaf2ff"), PropertyFactory.lineWidth(routeW(if (im) 1.5f else 1.25f)), PropertyFactory.lineOpacity(if (im) 0.95f else 0.92f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            LineLayer("dl-route-line", "dl-route").withProperties(
                PropertyFactory.lineColor(sevColor(im)), PropertyFactory.lineWidth(routeW(if (im) 1.0f else 0.85f)),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        // the part of the route you have already driven turns grey, drawn over the blue
        st.addLayer(
            LineLayer("dl-done-casing", "dl-done").withProperties(
                PropertyFactory.lineColor(if (im) "#B4B9CE" else "#C3C8D8"), PropertyFactory.lineWidth(routeW(if (im) 1.5f else 1.25f)), PropertyFactory.lineOpacity(0.9f),
                PropertyFactory.lineCap(Property.LINE_CAP_BUTT), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            LineLayer("dl-done-line", "dl-done").withProperties(
                PropertyFactory.lineColor(if (im) "#7E849F" else "#8C92AC"), PropertyFactory.lineWidth(routeW(if (im) 1.0f else 0.85f)),
                PropertyFactory.lineCap(Property.LINE_CAP_BUTT), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        // lane ribbons: the lane you need is a solid teal ribbon that fades away into the distance, the others are quiet road-coloured strips
        val onCol = if (nightStyle) "#2FC9B8" else "#1FB5A8"
        val offCol = if (nightStyle) "#4A5062" else "#FBFAF7"
        st.addLayer(FillLayer("dl-lane-fill", "dl-lane-bands").withProperties(
            PropertyFactory.fillColor(Expression.switchCase(Expression.eq(Expression.get("on"), Expression.literal(1)), Expression.color(android.graphics.Color.parseColor(onCol)), Expression.color(android.graphics.Color.parseColor(offCol)))),
            PropertyFactory.fillOpacity(Expression.product(Expression.get("a"), Expression.switchCase(Expression.eq(Expression.get("on"), Expression.literal(1)), Expression.literal(0.95), Expression.literal(if (nightStyle) 0.75 else 0.85)))),
        ).also { it.minZoom = 15.5f })
        val lineCol = if (nightStyle) "#FFFFFF" else "#6A7080"
        st.addLayer(LineLayer("dl-lane-edge", "dl-lane-divs").withFilter(Expression.eq(Expression.get("s"), Expression.literal(1))).withProperties(
            PropertyFactory.lineColor(lineCol), PropertyFactory.lineOpacity(0.7f),
            PropertyFactory.lineWidth(Expression.interpolate(Expression.exponential(2), Expression.zoom(), Expression.stop(15, 0.15f), Expression.stop(20, 2.5f))),
        ).also { it.minZoom = 15.5f })
        st.addLayer(LineLayer("dl-lane-div", "dl-lane-divs").withFilter(Expression.eq(Expression.get("s"), Expression.literal(0))).withProperties(
            PropertyFactory.lineColor(lineCol), PropertyFactory.lineOpacity(0.75f),
            PropertyFactory.lineDasharray(arrayOf(3f, 4f)),
            PropertyFactory.lineWidth(Expression.interpolate(Expression.exponential(2), Expression.zoom(), Expression.stop(15, 0.15f), Expression.stop(20, 2f))),
        ).also { it.minZoom = 15.5f })
        for ((id, on) in listOf("dl-lanes-off" to 0, "dl-lanes-on" to 1)) {
            st.addLayer(
                SymbolLayer(id, "dl-lanes").withFilter(Expression.eq(Expression.get("on"), Expression.literal(on))).withProperties(
                    PropertyFactory.iconImage(Expression.get("img")),
                    PropertyFactory.iconRotate(Expression.get("rot")),
                    PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
                    PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP),
                    PropertyFactory.iconAllowOverlap(true),
                    PropertyFactory.iconIgnorePlacement(true),
                    PropertyFactory.iconSize(Expression.interpolate(Expression.exponential(2), Expression.zoom(), Expression.stop(15, 0.1f), Expression.stop(20, 2.6f))),
                )
            )
        }
        if (im) {
            st.addImage("dl-pin", pinBitmap())
            st.addLayer(
                SymbolLayer("dl-dest-dot", "dl-dest").withProperties(
                    PropertyFactory.iconImage("dl-pin"), PropertyFactory.iconAnchor(Property.ICON_ANCHOR_BOTTOM),
                    PropertyFactory.iconAllowOverlap(true), PropertyFactory.iconIgnorePlacement(true), PropertyFactory.iconSize(0.6f),
                )
            )
        } else st.addLayer(
            CircleLayer("dl-dest-dot", "dl-dest").withProperties(
                PropertyFactory.circleRadius(10f), PropertyFactory.circleColor("#ff3b30"),
                PropertyFactory.circleStrokeColor("#ffffff"), PropertyFactory.circleStrokeWidth(3f),
            )
        )
        if (!im) {
        st.addLayer(
            CircleLayer("dl-me-halo", "dl-me").withProperties(
                PropertyFactory.circleRadius(15f * 0.625f * arrowScale), PropertyFactory.circleColor(if (im) "#3C8BC9" else "#2e8bff"), PropertyFactory.circleOpacity(if (im) 0.36f else 0.25f),
                PropertyFactory.circleStrokeColor("#9ED0E2"), PropertyFactory.circleStrokeWidth(if (im) 2.5f else 0f), PropertyFactory.circleStrokeOpacity(if (im) 0.6f else 0f),
                PropertyFactory.circleBlur(if (im) 0.2f else 0f),
                PropertyFactory.circlePitchAlignment(Property.CIRCLE_PITCH_ALIGNMENT_MAP), PropertyFactory.circlePitchScale(Property.CIRCLE_PITCH_SCALE_MAP),
            )
        )
        // Immersive: a second, tighter translucent disc so the base reads as a soft glow that flattens as the view tilts
        if (im) st.addLayer(
            CircleLayer("dl-me-disc", "dl-me").withProperties(
                PropertyFactory.circleRadius(36f * arrowScale), PropertyFactory.circleColor("#2F78AE"), PropertyFactory.circleOpacity(0.66f),
                PropertyFactory.circlePitchAlignment(Property.CIRCLE_PITCH_ALIGNMENT_MAP), PropertyFactory.circlePitchScale(Property.CIRCLE_PITCH_SCALE_MAP),
            )
        )
        }
        // traffic lights
        st.addImage("dl-signal", signalBitmap())
        st.addSource(GeoJsonSource("dl-signals", signalFeatures()))
        st.addLayer(
            SymbolLayer("dl-signals", "dl-signals").withProperties(
                PropertyFactory.iconImage("dl-signal"),
                PropertyFactory.iconAllowOverlap(true), PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_VIEWPORT),
                PropertyFactory.iconSize(Expression.interpolate(Expression.linear(), Expression.zoom(), Expression.stop(15, 0.24f), Expression.stop(18, 0.5f), Expression.stop(20, 0.7f))),
            ).also { it.minZoom = 15f }
        )
        // speed cameras, roadworks and closures on the route
        for ((kind, nm) in hazardNames.withIndex()) st.addImage(nm, hazardBitmap(kind))
        st.addLayer(
            SymbolLayer("dl-hazards", "dl-hazards").withProperties(
                PropertyFactory.iconImage(Expression.get("img")),
                PropertyFactory.iconAllowOverlap(true), PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconSize(Expression.interpolate(Expression.linear(), Expression.zoom(), Expression.stop(11, 0.3f), Expression.stop(15, 0.5f), Expression.stop(18, 0.7f))),
            )
        )
        st.addImage("dl-arrow", if (im) arrowBitmapImmersive() else arrowBitmap())
        st.addLayer(
            SymbolLayer("dl-me-arrow", "dl-me").withProperties(
                PropertyFactory.iconImage("dl-arrow"),
                PropertyFactory.iconRotate(Expression.get("h")),
                PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
                PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP),
                PropertyFactory.iconAllowOverlap(true),
                PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconSize((if (im) 0.25f else 0.625f) * arrowScale),
            )
        )
        // road-name pill under the locator
        st.addImage("dl-road", roadBitmap(roadName))
        st.addLayer(
            SymbolLayer("dl-me-road", "dl-me").withProperties(
                PropertyFactory.iconImage("dl-road"),
                PropertyFactory.iconAnchor(Property.ICON_ANCHOR_TOP),
                PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_VIEWPORT),
                PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_VIEWPORT),
                PropertyFactory.iconAllowOverlap(true),
                PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconOffset(arrayOf(0f, roadOffset())),
                PropertyFactory.visibility(if (roadName.isBlank()) Property.NONE else Property.VISIBLE),
            )
        )
        // remember which style layers were visible originally, so toggles never reveal hidden ones
        origVisible.clear()
        roadLayerIds = null
        for (l in st.layers) origVisible[l.id] = l.visibility.value != Property.NONE
        applyView()
        pushAll()
    }

    fun setView(sat: Boolean, b3d: Boolean) {
        satellite = sat
        buildings3d = b3d
        applyView()
    }

    /** While a route is on the map, traffic colours on every other road can be hidden so the route line stands out (the route itself shows its own traffic). */
    fun setHideOtherTraffic(b: Boolean) {
        if (hideTraffic == b) return
        hideTraffic = b
        applyView()
    }

    /** Light map: no points of interest and no route glow, so there is less to draw and place every frame. 3D buildings have their own switch in the map layers. */
    fun setLite(b: Boolean) {
        if (lite == b) return
        lite = b
        applyView()
    }

    private fun isPoiLayer(id: String): Boolean {
        val s = id.lowercase()
        return s.contains("poi") || s.contains("landmark") || s.contains("transit") || s.contains("airport") || s.contains("building")
    }

    /** Satellite imagery under the labels, and 3D building on/off. Safe to call repeatedly. */
    private fun applyView() {
        val st = style ?: return
        val has = st.getLayer("dl-sat") != null
        if (satellite && !has) {
            val ts = TileSet("2.2.0", "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}")
            ts.maxZoom = 19f
            ts.attribution = "Imagery © Esri"
            st.addSource(RasterSource("dl-sat-src", ts, 256))
            st.addLayerAt(RasterLayer("dl-sat", "dl-sat-src"), 0)
        } else if (!satellite && has) {
            st.removeLayer("dl-sat")
            st.removeSource("dl-sat-src")
        }
        for (l in st.layers) {
            val id = l.id
            if (id.startsWith("dl-")) continue
            val orig = origVisible[id] ?: true
            val keep = l is SymbolLayer || id.contains("traffic", true) || id.contains("flow", true)
            val isTraffic = id.contains("traffic", true) || id.contains("flow", true)
            if (routing && hideTraffic && isTraffic) { l.setProperties(PropertyFactory.visibility(Property.NONE)); continue }
            val show = if (l is FillExtrusionLayer) orig && !satellite && buildings3d else if (lite && l is SymbolLayer && isPoiLayer(id)) false else orig && (!satellite || keep)
            l.setProperties(PropertyFactory.visibility(if (show) Property.VISIBLE else Property.NONE))
        }
    }

    /** Line width that grows with zoom the way road widths do: clearly wider than the road under it, but always well under the locator arrow's width. */
    private fun routeW(scale: Float): Expression = Expression.interpolate(
        Expression.exponential(1.7f), Expression.zoom(),
        Expression.stop(10, 3f * scale), Expression.stop(13, 6.5f * scale), Expression.stop(15, 10f * scale), Expression.stop(17, 16f * scale), Expression.stop(19, 24f * scale),
    )

    private fun line(p: List<LL>): Feature =
        Feature.fromGeometry(LineString.fromLngLats(p.map { Point.fromLngLat(it.lon, it.lat) }))

    private fun lineSev(p: List<LL>, level: Int): Feature {
        val f = line(p)
        f.addNumberProperty("sev", level)
        return f
    }

    private var mainSev: IntArray? = null
    private var mainOff = 0

    /** Route colour: blue normally, amber where traffic is slow, red where it is heavy. */
    private fun sevColor(im: Boolean = false): Expression = Expression.switchCase(
        Expression.eq(Expression.get("sev"), Expression.literal(2)), Expression.color(android.graphics.Color.parseColor(if (im) "#D93025" else "#FF4D4D")),
        Expression.eq(Expression.get("sev"), Expression.literal(1)), Expression.color(android.graphics.Color.parseColor(if (im) "#F9AB00" else "#FFB020")),
        Expression.color(android.graphics.Color.parseColor(if (im) "#2FC4F5" else "#4CC9FF")),
    )

    private fun pushAll() {
        pushRoute(); pushDest(); pushMe(); pushHazards()
    }

    private fun src(id: String): GeoJsonSource? = style?.getSourceAs<GeoJsonSource>(id)

    private fun setLine(pts: List<LL>) {
        val s = src("dl-route") ?: return
        if (pts.size < 2) { s.setGeoJson(empty()); return }
        val sev = mainSev
        if (sev == null || sev.isEmpty()) { s.setGeoJson(FeatureCollection.fromFeatures(arrayListOf(lineSev(pts, 0)))); return }
        fun level(j: Int) = if (mainOff + j in sev.indices) sev[mainOff + j] else 0
        val feats = ArrayList<Feature>()
        var start = 0
        var cur = level(0)
        for (j in 1 until pts.size - 1) {
            val l = level(j)
            if (l != cur) { feats += lineSev(pts.subList(start, j + 1), cur); start = j; cur = l }
        }
        feats += lineSev(pts.subList(start, pts.size), cur)
        s.setGeoJson(FeatureCollection.fromFeatures(feats))
    }

    private fun pushRoute() {
        setLine(main)
        src("dl-alts")?.setGeoJson(FeatureCollection.fromFeatures(ArrayList(alts.filter { it.size >= 2 }.map { line(it) })))
    }

    private var hazards: List<Pair<LL, Int>> = emptyList()
    /** Map icons by kind: camera, roadworks, closure, police, accident, hazard, breakdown, mobile camera. */
    private val hazardNames = arrayOf("dl-hz-cam", "dl-hz-work", "dl-hz-closed", "dl-hz-police", "dl-hz-accident", "dl-hz-hazard", "dl-hz-breakdown", "dl-hz-mobilecam")

    /** Icons for speed cameras (0), roadworks (1) and closures (2) along the route. */
    fun setHazards(list: List<Pair<LL, Int>>) { hazards = list; pushHazards() }

    private fun pushHazards() {
        val s = src("dl-hazards") ?: return
        val fs = hazards.map { (p, k) ->
            Feature.fromGeometry(Point.fromLngLat(p.lon, p.lat)).also { it.addStringProperty("img", hazardNames[k.coerceIn(0, hazardNames.size - 1)]) }
        }
        s.setGeoJson(FeatureCollection.fromFeatures(fs))
    }

    /** Round badge with a simple glyph: camera on white with a red ring, amber warning triangle, red no-entry. */
    private fun hazardBitmap(kind: Int): Bitmap {
        val n = 96
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val cx = n / 2f
        fun p(col: Int, st: Paint.Style = Paint.Style.FILL, w: Float = 0f) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col; style = st; strokeWidth = w }
        // a round badge with a bold mark in the middle, for reports
        fun badge(ring: Int, fill: Int, mark: String) {
            c.drawCircle(cx, cx + 2f, 38f, p(0x55000000))
            c.drawCircle(cx, cx, 38f, p(0xFFFFFFFF.toInt()))
            c.drawCircle(cx, cx, 31f, p(fill))
            c.drawCircle(cx, cx, 38f, p(ring, Paint.Style.STROKE, 6f))
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); textSize = 46f; isFakeBoldText = true; textAlign = Paint.Align.CENTER }
            c.drawText(mark, cx, cx + 16f, tp)
        }
        when (kind) {
            4 -> badge(0xFFB71C1C.toInt(), 0xFFE53935.toInt(), "!")
            5 -> badge(0xFFE65100.toInt(), 0xFFF9A825.toInt(), "!")
            6 -> {
                badge(0xFFE65100.toInt(), 0xFFFB8C00.toInt(), "")
                // a small car
                c.drawRoundRect(android.graphics.RectF(cx - 18f, cx - 4f, cx + 18f, cx + 9f), 5f, 5f, p(0xFFFFFFFF.toInt()))
                c.drawRoundRect(android.graphics.RectF(cx - 11f, cx - 13f, cx + 11f, cx - 2f), 5f, 5f, p(0xFFFFFFFF.toInt()))
                c.drawCircle(cx - 10f, cx + 11f, 4.5f, p(0xFF37474F.toInt()))
                c.drawCircle(cx + 10f, cx + 11f, 4.5f, p(0xFF37474F.toInt()))
            }
            7 -> {
                c.drawCircle(cx, cx + 2f, 38f, p(0x55000000))
                c.drawCircle(cx, cx, 38f, p(0xFFFFFFFF.toInt()))
                c.drawCircle(cx, cx, 38f, p(0xFF1E66F5.toInt(), Paint.Style.STROKE, 7f))
                c.drawRoundRect(android.graphics.RectF(cx - 19f, cx - 9f, cx + 19f, cx + 15f), 5f, 5f, p(0xFF37474F.toInt()))
                c.drawRoundRect(android.graphics.RectF(cx - 8f, cx - 16f, cx + 8f, cx - 8f), 3f, 3f, p(0xFF37474F.toInt()))
                c.drawCircle(cx, cx + 3f, 8f, p(0xFFFFFFFF.toInt()))
                c.drawCircle(cx, cx + 3f, 4.5f, p(0xFF37474F.toInt()))
            }
            1 -> {
                val tri = Path().apply { moveTo(cx, 10f); lineTo(n - 8f, n - 14f); lineTo(8f, n - 14f); close() }
                val rounded = android.graphics.CornerPathEffect(10f)
                c.save(); c.translate(0f, 3f)
                c.drawPath(tri, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55000000; pathEffect = rounded })
                c.restore()
                c.drawPath(tri, p(0xFFFFFFFF.toInt()).apply { pathEffect = rounded })
                val inner = Path().apply { moveTo(cx, 22f); lineTo(n - 22f, n - 23f); lineTo(22f, n - 23f); close() }
                c.drawPath(inner, p(0xFFF9A825.toInt()).apply { pathEffect = android.graphics.CornerPathEffect(6f) })
                c.drawRoundRect(android.graphics.RectF(cx - 3.5f, 42f, cx + 3.5f, 62f), 3f, 3f, p(0xFF2B2B2B.toInt()))
                c.drawCircle(cx, 70f, 4.2f, p(0xFF2B2B2B.toInt()))
            }
            2 -> {
                c.drawCircle(cx, cx + 2f, 38f, p(0x55000000))
                c.drawCircle(cx, cx, 38f, p(0xFFFFFFFF.toInt()))
                c.drawCircle(cx, cx, 30f, p(0xFFE53935.toInt()))
                c.drawRoundRect(android.graphics.RectF(cx - 18f, cx - 5f, cx + 18f, cx + 5f), 4f, 4f, p(0xFFFFFFFF.toInt()))
            }
            3 -> {
                c.drawCircle(cx, cx + 2f, 38f, p(0x55000000))
                c.drawCircle(cx, cx, 38f, p(0xFFFFFFFF.toInt()))
                c.drawCircle(cx, cx, 38f, p(0xFF1E66F5.toInt(), Paint.Style.STROKE, 7f))
                // shield
                val sh = Path().apply {
                    moveTo(cx - 14f, cx - 15f); lineTo(cx + 14f, cx - 15f); lineTo(cx + 14f, cx + 2f)
                    quadTo(cx + 14f, cx + 14f, cx, cx + 20f); quadTo(cx - 14f, cx + 14f, cx - 14f, cx + 2f); close()
                }
                c.drawPath(sh, p(0xFF1E66F5.toInt()))
                c.drawCircle(cx, cx - 1f, 5f, p(0xFFFFFFFF.toInt()))
            }
            else -> {
                c.drawCircle(cx, cx + 2f, 38f, p(0x55000000))
                c.drawCircle(cx, cx, 38f, p(0xFFFFFFFF.toInt()))
                c.drawCircle(cx, cx, 38f, p(0xFFE53935.toInt(), Paint.Style.STROKE, 7f))
                // camera glyph: body, viewfinder bump and lens
                c.drawRoundRect(android.graphics.RectF(cx - 19f, cx - 9f, cx + 19f, cx + 15f), 5f, 5f, p(0xFF37474F.toInt()))
                c.drawRoundRect(android.graphics.RectF(cx - 8f, cx - 16f, cx + 8f, cx - 8f), 3f, 3f, p(0xFF37474F.toInt()))
                c.drawCircle(cx, cx + 3f, 8f, p(0xFFFFFFFF.toInt()))
                c.drawCircle(cx, cx + 3f, 4.5f, p(0xFF37474F.toInt()))
            }
        }
        return bmp
    }

    private fun pushDest() {
        val s = src("dl-dest") ?: return
        val d = dest
        if (d != null) s.setGeoJson(Feature.fromGeometry(Point.fromLngLat(d.lon, d.lat))) else s.setGeoJson(empty())
    }

    private fun pushMe() {
        val s = src("dl-me") ?: return
        val p = me
        if (p != null) {
            val f = Feature.fromGeometry(Point.fromLngLat(p.lon, p.lat))
            f.addNumberProperty("h", meHeading)
            s.setGeoJson(f)
        } else s.setGeoJson(empty())
    }

    // ---- lane arrows painted on the road ----
    class LaneMark(val pt: LL, val bearing: Double, val dir: String, val on: Boolean)
    private val laneImgs = HashSet<String>()
    private var lanePulse: android.animation.ValueAnimator? = null

    private fun laneBitmap(dir: String, on: Boolean): Bitmap {
        val bmp = Bitmap.createBitmap(64, 80, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val ang = when (dir) {
            "SLIGHT_LEFT" -> -45f; "LEFT" -> -90f; "SHARP_LEFT" -> -135f; "LEFT_U_TURN" -> -180f
            "SLIGHT_RIGHT" -> 45f; "RIGHT" -> 90f; "SHARP_RIGHT" -> 135f; "RIGHT_U_TURN" -> 180f
            else -> 0f
        }
        fun draw(p: Paint) {
            c.drawLine(32f, 74f, 32f, 44f, p)
            c.save(); c.rotate(ang, 32f, 44f)
            c.drawLine(32f, 44f, 32f, 18f, p)
            c.drawLine(32f, 18f, 22f, 28f, p)
            c.drawLine(32f, 18f, 42f, 28f, p)
            c.restore()
        }
        val out = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = 12f; color = 0x66000000.toInt() }
        draw(out)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = 8f
            color = if (on) 0xFFFFFFFF.toInt() else 0x99FFFFFF.toInt()
        }
        draw(fill)
        return bmp
    }

    class LaneBand(val ring: List<LL>, val on: Boolean, val a: Double = 1.0)
    class LaneEdge(val pts: List<LL>, val solid: Boolean)

    /** Draws the lane strips and dividers (empty lists clear them). */
    fun setLaneBands(bands: List<LaneBand>, divs: List<LaneEdge>) {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            val st = style ?: return@post
            try {
                val bf = ArrayList<Feature>()
                for (b in bands) {
                    if (b.ring.size < 4) continue
                    val pts = (b.ring + b.ring[0]).map { Point.fromLngLat(it.lon, it.lat) }
                    val f = Feature.fromGeometry(org.maplibre.geojson.Polygon.fromLngLats(listOf(pts)))
                    f.addNumberProperty("on", if (b.on) 1 else 0)
                    f.addNumberProperty("a", b.a)
                    bf.add(f)
                }
                st.getSourceAs<GeoJsonSource>("dl-lane-bands")?.setGeoJson(FeatureCollection.fromFeatures(bf))
                val df = ArrayList<Feature>()
                for (d in divs) if (d.pts.size >= 2) df.add(Feature.fromGeometry(LineString.fromLngLats(d.pts.map { Point.fromLngLat(it.lon, it.lat) })).also { it.addNumberProperty("s", if (d.solid) 1 else 0) })
                st.getSourceAs<GeoJsonSource>("dl-lane-divs")?.setGeoJson(FeatureCollection.fromFeatures(df))
            } catch (e: Throwable) { }
        }
    }

    fun setLanes(marks: List<LaneMark>) {
        if (marks.isEmpty()) setLaneBands(emptyList(), emptyList())
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            val st = style ?: return@post
            val feats = ArrayList<Feature>()
            for (m in marks) {
                val name = "ln-${m.dir}-${if (m.on) 1 else 0}"
                if (laneImgs.add(name)) st.addImage(name, laneBitmap(m.dir, m.on))
                val f = Feature.fromGeometry(Point.fromLngLat(m.pt.lon, m.pt.lat))
                f.addStringProperty("img", name)
                f.addNumberProperty("rot", m.bearing)
                f.addNumberProperty("on", if (m.on) 1 else 0)
                feats.add(f)
            }
            st.getSourceAs<GeoJsonSource>("dl-lanes")?.setGeoJson(FeatureCollection.fromFeatures(feats))
            val layer = st.getLayerAs<SymbolLayer>("dl-lanes-on")
            lanePulse?.cancel(); lanePulse = null
            if (feats.isEmpty()) { layer?.setProperties(PropertyFactory.iconOpacity(1f)); return@post }
            lanePulse = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 600; repeatMode = android.animation.ValueAnimator.REVERSE; repeatCount = android.animation.ValueAnimator.INFINITE
                // only four brightness steps, so the map is not asked to redraw on every screen refresh just for a blink
                var lastStep = -1
                addUpdateListener {
                    val step = Math.round((it.animatedValue as Float) * 3f)
                    if (step != lastStep) { lastStep = step; layer?.setProperties(PropertyFactory.iconOpacity(0.7f + 0.3f * step / 3f)) }
                }
                start()
            }
        }
    }

    // ---- data from the engine ----
    fun setRoute(mainPts: List<LL>, altPts: List<List<LL>>, sev: IntArray? = null) {
        main = mainPts; alts = altPts; mainSev = sev; mainOff = 0; pushRoute(); pushSignals(); android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ refreshSignals() }, 1500L)
        val on = mainPts.isNotEmpty()
        if (on != routing) { routing = on; applyView() }
    }
    private var pulseAnim: android.animation.ValueAnimator? = null

    /** Pulses the glow under the route line (used when a turn is close). */
    fun setTurnPulse(on: Boolean) {
        if (theme == "immersive") return      // the route glow stays steady for the whole route
        if (on == (pulseAnim != null)) return
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            pulseAnim?.cancel(); pulseAnim = null
            val layer = style?.getLayerAs<LineLayer>("dl-route-glow")
            if (!on) {
                layer?.setProperties(PropertyFactory.lineOpacity(0.4f), PropertyFactory.lineWidth(routeW(1.7f)))
            } else {
                pulseAnim = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 650; repeatMode = android.animation.ValueAnimator.REVERSE; repeatCount = android.animation.ValueAnimator.INFINITE
                    addUpdateListener {
                        val v = it.animatedValue as Float
                        layer?.setProperties(PropertyFactory.lineOpacity(0.35f + 0.55f * v), PropertyFactory.lineWidth(18f + 16f * v))
                    }
                    start()
                }
            }
        }
    }

    /** Size of the locator arrow (and its glow) relative to normal: 1.0 is the base size. */
    var arrowScale = 2.4f
        private set

    fun setArrowScale(f: Float) {
        arrowScale = f
        val st = style ?: return
        val im = theme == "immersive"
        try {
            (st.getLayer("dl-me-arrow") as? SymbolLayer)?.setProperties(PropertyFactory.iconSize((if (im) 0.25f else 0.625f) * f))
            (st.getLayer("dl-me-halo") as? CircleLayer)?.setProperties(PropertyFactory.circleRadius(15f * 0.625f * f))
            (st.getLayer("dl-me-disc") as? CircleLayer)?.setProperties(PropertyFactory.circleRadius(36f * f))
            (st.getLayer("dl-me-road") as? SymbolLayer)?.setProperties(PropertyFactory.iconOffset(arrayOf(0f, roadOffset())))
        } catch (e: Exception) { }
    }

    private var roadName = ""
    private var roadOffTilt = -99.0

    /** How far below the locator the road pill sits: further down when the view is flat (ring is round), closer when tilted. */
    private fun roadOffset(): Float {
        val r = (if (theme == "immersive") 40f else 9.4f) * arrowScale
        val c = Math.cos(Math.toRadians(tiltNow))
        return (r * (0.2 + 0.22 * c) + 2f).toFloat()
    }

    private fun roadBitmap(name: String): Bitmap {
        val dark = (wantedStyle ?: "").contains("dark", true)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 30f; typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD); color = if (dark) 0xFFFFFFFF.toInt() else 0xFF2A2F45.toInt() }
        val txt = if (name.isBlank()) " " else name
        val w = (tp.measureText(txt) + 36f).coerceAtMost(420f)
        val bmp = Bitmap.createBitmap(w.toInt() + 8, 56, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rect = android.graphics.RectF(4f, 4f, bmp.width - 4f, 48f)
        c.drawRoundRect(rect.apply { offset(0f, 2f) }, 22f, 22f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33000000 })
        rect.offset(0f, -2f)
        c.drawRoundRect(rect, 22f, 22f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (dark) 0xEB252A47.toInt() else 0xF2FFFFFF.toInt() })
        val shown = if (tp.measureText(txt) > w - 36f) android.text.TextUtils.ellipsize(txt, android.text.TextPaint(tp), w - 36f, android.text.TextUtils.TruncateAt.END).toString() else txt
        c.drawText(shown, 18f, 34f, tp)
        return bmp
    }

    /** Shows the name of the road you are on in a small pill under the locator (empty hides it). */
    fun setRoadName(name: String) {
        if (name == roadName) return
        roadName = name
        val st = style ?: return
        try {
            if (name.isNotBlank()) st.addImage("dl-road", roadBitmap(name))
            (st.getLayer("dl-me-road") as? SymbolLayer)?.setProperties(PropertyFactory.visibility(if (name.isBlank()) Property.NONE else Property.VISIBLE))
        } catch (e: Exception) { }
    }

    /** The map itself is no longer capped separately: the glide already limits how often the camera moves, and a second cap on top of it makes frames arrive unevenly (judder). */
    fun setMaxFps(n: Int) { try { mapView.setMaximumFps(60) } catch (e: Exception) { } }

    private var doneEmpty = true

    /** The driven stretch of the route (a short trail behind the car), drawn in grey. */
    fun setDone(pts: List<LL>) {
        val s = src("dl-done") ?: return
        if (pts.size < 2) { if (!doneEmpty) { s.setGeoJson(empty()); doneEmpty = true }; return }
        doneEmpty = false
        s.setGeoJson(line(pts))
    }

    fun setMainOnly(mainPts: List<LL>, sev: IntArray? = null, firstSeg: Int = 0) { main = mainPts; mainSev = sev; mainOff = firstSeg; setLine(main) }
    fun setDest(p: LL?) { dest = p; pushDest() }
    private var meAnim: android.animation.ValueAnimator? = null
    private var lastMePush = 0L

    /** Moves the arrow smoothly from where it is now to [p] over [durationMs] (one GPS interval). */
    fun setMe(p: LL?, heading: Double = 0.0, durationMs: Long = 1000) {
        meAnim?.cancel()
        if (durationMs <= 0 && p != null) {
            val o = me
            if (o != null && Math.abs(o.lat - p.lat) < 1e-8 && Math.abs(o.lon - p.lon) < 1e-8 && Math.abs(meHeading - heading) < 0.2) return
        }
        val from = me
        if (p == null || from == null || durationMs <= 0 || Geo.dist(from, p) > 300) {
            me = p; meHeading = heading; pushMe(); return
        }
        val fromH = meHeading
        val dH = ((heading - fromH + 540.0) % 360.0) - 180.0
        meAnim = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { a ->
                val t = a.animatedFraction.toDouble()
                me = LL(from.lat + (p.lat - from.lat) * t, from.lon + (p.lon - from.lon) * t)
                meHeading = (fromH + dH * t + 360.0) % 360.0
                val now = android.os.SystemClock.uptimeMillis()
                if (now - lastMePush >= 66 || t >= 1.0) { lastMePush = now; pushMe() }
            }
            start()
        }
    }

    // ---- camera ----
    fun center(): LL? = map?.cameraPosition?.target?.let { LL(it.latitude, it.longitude) }

    fun cameraTo(c: LL, bearing: Double?, tilt: Double, zoom: Double, ms: Int, topPadFraction: Double, leftPadFraction: Double = 0.0) {
        val m = map ?: return
        val h = mapView.height
        val b = CameraPosition.Builder().target(LatLng(c.lat, c.lon)).tilt(tilt).zoom(zoom)
            .padding(mapView.width * leftPadFraction, h * topPadFraction, 0.0, 0.0)
        if (bearing != null) b.bearing(bearing)
        tiltNow = tilt
        m.easeCamera(CameraUpdateFactory.newCameraPosition(b.build()), ms, false)
    }

    /** Moves the camera instantly (no animation). Called every frame by the glide loop so motion never stalls between GPS fixes. */
    fun cameraSet(c: LL, bearing: Double, tilt: Double, zoom: Double, topPadFraction: Double, leftPadFraction: Double) {
        val m = map ?: return
        val b = CameraPosition.Builder().target(LatLng(c.lat, c.lon)).tilt(tilt).zoom(zoom).bearing(bearing)
            .padding(mapView.width * leftPadFraction, mapView.height * topPadFraction, 0.0, 0.0)
        tiltNow = tilt
        if (abs(tilt - roadOffTilt) > 3.0) {
            roadOffTilt = tilt
            try { (style?.getLayer("dl-me-road") as? SymbolLayer)?.setProperties(PropertyFactory.iconOffset(arrayOf(0f, roadOffset()))) } catch (e: Exception) { }
        }
        m.moveCamera(CameraUpdateFactory.newCameraPosition(b.build()))
    }

    private fun roadLike(id: String): Boolean {
        val s = id.lowercase()
        if (s.contains("traffic") || s.contains("flow") || s.contains("rail") || s.contains("path") || s.contains("foot") || s.contains("ferry") || s.contains("boundary") || s.contains("label")) return false
        return s.contains("road") || s.contains("street") || s.contains("motorway") || s.contains("highway") || s.contains("trunk") || s.contains("primary") ||
            s.contains("secondary") || s.contains("tertiary") || s.contains("residential") || s.contains("service") || s.contains("link") || s.contains("bridge") || s.contains("tunnel")
    }

    /** Moves a GPS position onto the nearest drawn road that runs the way you are heading, or returns null when none is close enough. */
    fun snapToRoad(p: LL, heading: Double): LL? {
        val m = map ?: return null
        val st = style ?: return null
        return try {
            val ids = roadLayerIds ?: st.layers.filter { it is LineLayer && !it.id.startsWith("dl-") && roadLike(it.id) }.map { it.id }.toTypedArray().also { roadLayerIds = it }
            if (ids.isEmpty()) return null
            val sp = m.projection.toScreenLocation(LatLng(p.lat, p.lon))
            val rr = 40f
            val feats = m.queryRenderedFeatures(android.graphics.RectF(sp.x - rr, sp.y - rr, sp.x + rr, sp.y + rr), *ids)
            val k = Math.cos(Math.toRadians(p.lat)) * 111320.0
            val k2 = 110574.0
            var best: LL? = null
            var bd = 24.0
            fun scan(pts: List<Point>) {
                for (i in 0 until pts.size - 1) {
                    val ax = (pts[i].longitude() - p.lon) * k; val ay = (pts[i].latitude() - p.lat) * k2
                    val bx = (pts[i + 1].longitude() - p.lon) * k; val by = (pts[i + 1].latitude() - p.lat) * k2
                    val dx = bx - ax; val dy = by - ay
                    val l2 = dx * dx + dy * dy
                    if (l2 < 0.01) continue
                    val t = (-(ax * dx + ay * dy) / l2).coerceIn(0.0, 1.0)
                    val d = Math.hypot(ax + dx * t, ay + dy * t)
                    if (d >= bd) continue
                    // only roads that run the way you are heading (either direction), so a parallel street or a crossing road is not chosen
                    val segB = (Math.toDegrees(Math.atan2(dx, dy)) + 360.0) % 360.0
                    var diff = Math.abs(segB - heading) % 360.0
                    if (diff > 180.0) diff = 360.0 - diff
                    if (diff > 35.0 && diff < 145.0) continue
                    bd = d
                    best = LL(p.lat + (ay + dy * t) / k2, p.lon + (ax + dx * t) / k)
                }
            }
            for (f in feats) {
                when (val g = f.geometry()) {
                    is LineString -> scan(g.coordinates())
                    is MultiLineString -> for (part in g.coordinates()) scan(part)
                    else -> { }
                }
            }
            best
        } catch (e: Exception) { null }
    }

    /** Current camera, as (lat, lon, bearing, tilt, zoom, topPadFraction, leftPadFraction). */
    fun cameraNow(): DoubleArray? {
        val m = map ?: return null
        val c = m.cameraPosition
        val t = c.target ?: return null
        val pd = c.padding
        val w = max(1, mapView.width).toDouble(); val h = max(1, mapView.height).toDouble()
        return doubleArrayOf(t.latitude, t.longitude, c.bearing, c.tilt, c.zoom, (pd?.getOrNull(1) ?: 0.0) / h, (pd?.getOrNull(0) ?: 0.0) / w)
    }

    fun setTilt(tilt: Double) {
        val m = map ?: return
        tiltNow = tilt
        m.easeCamera(CameraUpdateFactory.tiltTo(tilt), 500)
    }

    fun zoomBy(delta: Double) {
        map?.easeCamera(CameraUpdateFactory.zoomBy(delta), 250)
    }

    fun resetNorth() {
        val m = map ?: return
        m.easeCamera(CameraUpdateFactory.bearingTo(0.0), 400)
    }

    /** Smoothly zooms out (flat, north-up) so every point sits in the area above the route-preview panel. */
    fun fit(points: List<LL>) {
        val m = map ?: return
        if (points.size < 2) return
        val d = mapView.resources.displayMetrics.density.toDouble()
        val w = mapView.width / d
        val h = mapView.height / d
        if (w < 50 || h < 50) return
        fun mx(lon: Double) = (lon + 180.0) / 360.0
        fun my(lat: Double): Double {
            val r = Math.toRadians(lat.coerceIn(-85.0, 85.0))
            return (1.0 - Math.log(Math.tan(r) + 1.0 / Math.cos(r)) / Math.PI) / 2.0
        }
        val xs = points.map { mx(it.lon) }; val ys = points.map { my(it.lat) }
        val x0 = xs.min(); val x1 = xs.max(); val y0 = ys.min(); val y1 = ys.max()
        // visible area (dp): the bottom half is covered by the preview panel
        val pl = w * 0.07; val pr = w * 0.07; val pt = h * 0.10; val pb = h * 0.60
        val aw = w - pl - pr; val ah = h - pt - pb
        val fx = max(x1 - x0, 1e-7); val fy = max(y1 - y0, 1e-7)
        val z = min(Math.log(aw / (512.0 * fx)), Math.log(ah / (512.0 * fy))) / Math.log(2.0)
        val zoom = z.coerceIn(2.0, 17.0)
        val world = 512.0 * Math.pow(2.0, zoom)
        // bounds centre should land in the middle of the visible area, not the middle of the map
        val cx = (x0 + x1) / 2 + (w / 2 - (pl + aw / 2)) / world
        val cy = (y0 + y1) / 2 + (h / 2 - (pt + ah / 2)) / world
        val lon = cx * 360.0 - 180.0
        val lat = Math.toDegrees(Math.atan(Math.sinh(Math.PI * (1 - 2 * cy))))
        tiltNow = 0.0
        val cp = CameraPosition.Builder().target(LatLng(lat, lon)).zoom(zoom).tilt(0.0).bearing(0.0)
            .padding(0.0, 0.0, 0.0, 0.0).build()
        m.easeCamera(CameraUpdateFactory.newCameraPosition(cp), 1600)
    }
}
