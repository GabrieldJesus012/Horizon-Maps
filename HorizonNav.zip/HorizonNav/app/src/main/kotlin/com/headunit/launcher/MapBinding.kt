package com.headunit.launcher

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import android.content.Context
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapLibreMapOptions
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.Layer
import org.maplibre.android.style.layers.FillLayer
import org.maplibre.android.style.layers.BackgroundLayer
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.layers.FillExtrusionLayer
import org.maplibre.android.style.layers.RasterLayer
import org.maplibre.android.style.sources.RasterSource
import org.maplibre.android.style.sources.TileSet
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.MultiLineString
import org.maplibre.geojson.Point
import org.maplibre.geojson.Polygon
import org.maplibre.geojson.MultiPolygon

/** Owns the single native MapView so it can move between the Home preview and the full Navigation page. */
class MapBinding(private val ctx: Context, fast: Boolean = false, res: Float = 1f) : DefaultLifecycleObserver {
    val mapView: MapView
    var map: MapLibreMap? = null
        private set
    private var style: Style? = null
    private var wantedStyle: String? = null
    private var loadedStyle: String? = null

    private var main: List<LL> = emptyList()
    private var alts: List<List<LL>> = emptyList()
    private var dest: LL? = null
    private var me: LL? = null
    private var meHeading = 0.0

    var onLongPress: ((LL) -> Unit)? = null
    var onUserGesture: (() -> Unit)? = null
    var onStyleLoaded: (() -> Unit)? = null

    /** True once a map style is showing (so a failed switch can keep it on screen). */
    fun hasStyle(): Boolean = style != null
    /** Tapped one of the grey alternative routes (or its time bubble) while driving. */
    var onAltTap: ((Int) -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    private var satellite = false
    private var buildings3d = true
    private var lite = false
    private var hideTraffic = false
    private var routing = false
    private var roadLayerIds: Array<String>? = null
    private val origVisible = HashMap<String, Boolean>()
    private val origMin = HashMap<String, Float>()
    var tiltNow = 0.0
        private set

    init {
        MapLibre.getInstance(ctx)
        val opts = MapLibreMapOptions.createFromAttributes(ctx)
            .textureMode(!fast)
            .attributionEnabled(true)
            // labels from different map sources no longer have to be checked against each other every frame (a big CPU saving on slow units)
            .crossSourceCollisions(false)
            .logoEnabled(false)
            .camera(CameraPosition.Builder().target(LatLng(51.5072, -0.1276)).zoom(14.0).tilt(55.0).build())
        // a lower render resolution is the biggest single saving on a slow GPU
        if (res < 1f) opts.pixelRatio(Math.max(0.6f, ctx.resources.displayMetrics.density * res))
        mapView = MapView(ctx, opts)
        mapView.onCreate(null)
        mapView.addOnWillStartRenderingFrameListener { if (PerfStats.on) PerfStats.renders++ }
        mapView.addOnDidFailLoadingMapListener { msg -> onError?.invoke(msg ?: "Map failed to load") }
        mapView.getMapAsync { m ->
            map = m
            m.setMaxPitchPreference(75.0)
            m.uiSettings.isCompassEnabled = false
            m.uiSettings.attributionGravity = android.view.Gravity.TOP or android.view.Gravity.END
            m.uiSettings.setAttributionMargins(0, 150, 26, 0)
            m.uiSettings.isRotateGesturesEnabled = true
            m.uiSettings.isTiltGesturesEnabled = true
            m.addOnMapLongClickListener { p ->
                onLongPress?.invoke(LL(p.latitude, p.longitude)); true
            }
            m.addOnMapClickListener { p ->
                // a tap during the route fly-through skips straight to the overview
                flyDone?.let { d -> flyDone = null; flyToken++; d(); return@addOnMapClickListener true }
                if (liveLines.isEmpty()) return@addOnMapClickListener false
                try {
                    val sp = m.projection.toScreenLocation(p)
                    val r = 34f
                    val f = m.queryRenderedFeatures(android.graphics.RectF(sp.x - r, sp.y - r, sp.x + r, sp.y + r), "dl-live-bub", "dl-live-alts-line").firstOrNull()
                    val i = f?.getNumberProperty("i")?.toInt()
                    if (i != null) { onAltTap?.invoke(i); true } else false
                } catch (e: Exception) { false }
            }
            m.addOnCameraMoveStartedListener { reason ->
                if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) onUserGesture?.invoke()
            }
            m.addOnCameraMoveListener {
                refreshLamps(); refreshSignals()
                // the 3D locator is sized from the zoom: rebuild it when you zoom, even if you are standing still
                if (locatorStyle != "flat") pushModel(false)
                syncTreePitch()
            }
            m.addOnCameraIdleListener { refreshLamps(); refreshSignals(); refreshTrees() }
            wantedStyle?.let { loadStyle(it) }
        }
    }

    // ---- lifecycle ----
    override fun onStart(owner: LifecycleOwner) = mapView.onStart()
    override fun onResume(owner: LifecycleOwner) { mapView.onResume(); try { flowAnim?.resume() } catch (e: Exception) { } }
    override fun onPause(owner: LifecycleOwner) { try { flowAnim?.pause() } catch (e: Exception) { }; mapView.onPause() }
    override fun onStop(owner: LifecycleOwner) = mapView.onStop()
    override fun onDestroy(owner: LifecycleOwner) = mapView.onDestroy()

    // ---- style ----
    fun setStyleUrl(url: String) {
        wantedStyle = url
        if (map != null && url != loadedStyle) loadStyle(url)
        // the same style asked for again after it failed to load: load it again
        else if (map != null && style == null && url == loadedStyle) loadStyle(url)
    }

    /** "classic" or "immersive": changes the map colours, route, arrow and destination pin. Reloads the style when it changes. */
    var theme = "immersive"
        private set

    fun setTheme(t: String) {
        if (t == theme) return
        theme = t
        val w = wantedStyle
        if (map != null && w != null) { loadedStyle = null; loadStyle(w) }
    }

    private fun srcLayerOf(l: Layer): String = try {
        when (l) {
            is FillLayer -> l.sourceLayer
            is LineLayer -> l.sourceLayer
            is FillExtrusionLayer -> l.sourceLayer
            is SymbolLayer -> l.sourceLayer
            else -> ""
        } ?: ""
    } catch (e: Exception) { "" }

    /** Fill colour that is a slight green for grass, woods and parks and plain land colour for everything else, chosen per shape from its class. */
    private fun greenByClass(park: String, land: String): Expression {
        val kinds = arrayOf(
            "grass", "wood", "forest", "park", "garden", "meadow", "scrub", "heath", "farmland", "farm", "orchard", "vineyard", "recreation_ground", "recreation",
            "pitch", "golf_course", "golf", "cemetery", "nature_reserve", "village_green", "allotments", "common", "grassland", "tree", "trees", "wetland", "playground", "sports_centre", "green",
        )
        return Expression.match(
            Expression.downcase(Expression.toString(Expression.coalesce(Expression.get("class"), Expression.get("subclass"), Expression.get("kind"), Expression.get("type"), Expression.literal("")))),
            Expression.literal(kinds), Expression.color(android.graphics.Color.parseColor(park)),
            Expression.color(android.graphics.Color.parseColor(land)),
        )
    }

    /** Paints the base map in soft, light tones (or a deep blue-grey at night) by matching layer names to land, water, parks, roads and buildings. */
    private fun recolour(st: Style) {
        val dark = (wantedStyle ?: "").contains("dark", true)
        // gentle, even lighting on buildings: low contrast between wall faces, so they read as soft blocks rather than hard shapes
        try {
            val li = st.light
            li?.setIntensity(if (dark) 0.36f else 0.3f)
            li?.setPosition(org.maplibre.android.style.light.Position(1.25f, 215f, 48f))
        } catch (e: Exception) { }
        // day: soft and warm like Google Maps (off-white land, gentle greens, pale blue water, white roads with faint edges, light buildings)
        val land = if (dark) "#2D3358" else "#F4F2EE"
        val water = if (dark) "#2A6682" else "#AADAF5"
        val park = if (dark) "#2E5C5E" else "#CDEBC4"
        val bld = if (dark) "#454C78" else "#E7E5E1"
        val ext = if (dark) "#59618E" else "#E9E7E3"
        val roadFill = if (dark) "#464E7C" else "#FFFFFF"
        val roadCase = if (dark) "#262B4B" else "#DCDAD5"
        val hwyFill = if (dark) "#5E67A0" else "#FFFFFF"
        val hwyCase = if (dark) "#2B3052" else "#CFCCC6"
        val rail = if (dark) "#454C70" else "#D2D0CB"
        val text = if (dark) "#C9CEE8" else "#5F6368"
        val halo = if (dark) "#2D3358" else "#FFFFFF"
        val parkWords = listOf("park", "green", "forest", "wood", "grass", "vegetation", "nature", "garden", "golf", "cemetery", "recreation", "pitch", "meadow", "scrub", "farm")
        val roadWords = listOf("road", "street", "motorway", "trunk", "highway", "primary", "secondary", "tertiary", "residential", "service", "link", "ramp", "track", "bridge", "tunnel", "path", "pedestrian", "transportation")
        val hwyWords = listOf("motorway", "trunk", "highway", "freeway", "expressway")
        // the wide blurred glow under the route is one of the most expensive things to draw; the light map leaves it out
        try { st.getLayer("dl-route-glow")?.setProperties(PropertyFactory.visibility(if (lite) Property.NONE else Property.VISIBLE)) } catch (e: Exception) { }
        for (l in st.layers) {
            val id = l.id
            if (id.startsWith("dl-")) continue
            val key = (id + " " + srcLayerOf(l)).lowercase()
            if (key.contains("traffic") || key.contains("flow") || key.contains("incident")) continue
            try {
                when (l) {
                    is BackgroundLayer -> l.setProperties(PropertyFactory.backgroundColor(land))
                    is FillLayer -> when {
                        key.contains("water") -> l.setProperties(PropertyFactory.fillColor(water))
                        parkWords.any { key.contains(it) } -> l.setProperties(PropertyFactory.fillColor(park))
                        key.contains("building") -> l.setProperties(PropertyFactory.fillColor(bld))
                        // generic land-cover / land-use layers hold grass, woods and parks together with plain ground: tint by each shape's class
                        listOf("landcover", "land cover", "landuse", "land use", "vegetation", "natural", "leisure", "green").any { key.contains(it) } ->
                            l.setProperties(PropertyFactory.fillColor(greenByClass(park, land)))
                        listOf("land", "background", "landuse", "urban", "residential", "commercial", "industrial").any { key.contains(it) } -> l.setProperties(PropertyFactory.fillColor(land))
                    }
                    is FillExtrusionLayer -> {
                        // taller buildings are a little deeper in tone, walls shade towards the ground and the light comes from one side, so blocks read as solid shapes
                        val h = Expression.switchCase(
                            Expression.has("render_height"), Expression.toNumber(Expression.get("render_height")),
                            Expression.has("height"), Expression.toNumber(Expression.get("height")),
                            Expression.literal(10),
                        )
                        val cols = if (dark) intArrayOf(0xFF3C4370.toInt(), 0xFF454C7E.toInt(), 0xFF51598F.toInt(), 0xFF5F68A0.toInt())
                                   else intArrayOf(0xFFF1EFEB.toInt(), 0xFFE9E7E3.toInt(), 0xFFE0DED9.toInt(), 0xFFD6D4CF.toInt())
                        l.setProperties(
                            PropertyFactory.fillExtrusionColor(Expression.interpolate(Expression.linear(), h,
                                Expression.stop(0, Expression.color(cols[0])), Expression.stop(20, Expression.color(cols[1])),
                                Expression.stop(60, Expression.color(cols[2])), Expression.stop(150, Expression.color(cols[3])))),
                            PropertyFactory.fillExtrusionOpacity(if (dark) 0.9f else 0.96f), PropertyFactory.fillExtrusionVerticalGradient(true))
                    }
                    is LineLayer -> {
                        val casing = key.contains("casing") || key.contains("case") || key.contains("outline") || key.contains("stroke")
                        val hwy = hwyWords.any { key.contains(it) }
                        when {
                            key.contains("water") || key.contains("river") || key.contains("stream") || key.contains("canal") -> l.setProperties(PropertyFactory.lineColor(water))
                            key.contains("rail") || key.contains("subway") || key.contains("transit") -> l.setProperties(PropertyFactory.lineColor(rail))
                            roadWords.any { key.contains(it) } -> l.setProperties(PropertyFactory.lineColor(if (casing) (if (hwy) hwyCase else roadCase) else (if (hwy) hwyFill else roadFill)))
                        }
                    }
                    is SymbolLayer -> l.setProperties(PropertyFactory.textColor(text), PropertyFactory.textHaloColor(halo), PropertyFactory.textHaloWidth(1.4f))
                    else -> {}
                }
            } catch (e: Exception) { }
        }
    }

    /** Google-style destination pin: red teardrop with a white centre. */
    private fun pinBitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(96, 128, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val path = Path().apply {
            addCircle(48f, 44f, 34f, Path.Direction.CW)
            moveTo(22f, 66f); lineTo(48f, 120f); lineTo(74f, 66f); close()
        }
        c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF000000.toInt(); setShadowLayer(8f, 0f, 4f, 0x66000000) })
        c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFEA4335.toInt(); style = Paint.Style.FILL })
        c.drawCircle(48f, 44f, 13f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8C1D18.toInt() })
        c.drawCircle(48f, 44f, 11f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() })
        return bmp
    }

    private var locatorCache: Pair<String, Bitmap>? = null

    /** The same locator picture the map uses (for the current map colours), for drawing it small elsewhere. Points up. */
    fun locatorBitmap(): Bitmap {
        locatorCache?.let { if (it.first == theme) return it.second }
        val b = if (theme == "immersive") arrowBitmapImmersive() else arrowBitmap()
        locatorCache = theme to b
        return b
    }

    /** Google Maps locator: a chunky white chevron with a visible edge, lying flat on the map. Points up; the badge is rotated by heading. */
    private fun arrowBitmapImmersive(): Bitmap {
        // the whole locator in one picture (translucent ring plus a soft 3D slab arrow), laid flat on the map, so the ring and the arrow always keep the
        // same proportions and squash together as the view tilts. Drawn 4x larger than it is shown (the layer's icon size scales it back down).
        val n = 384
        val cx = 192f; val cy = 192f
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val ringR = 160f
        c.drawCircle(cx, cy, ringR - 3f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB02F78AE.toInt() })
        c.drawCircle(cx, cy, ringR - 3f, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 7f; color = 0xB39ED0E2.toInt() })
        val top = Path().apply {
            moveTo(cx, cy - 125f)
            lineTo(cx + 91f, cy + 33f)
            lineTo(cx, cy + 11f)
            lineTo(cx - 91f, cy + 33f)
            close()
        }
        val round = android.graphics.CornerPathEffect(26f)
        val h = 34
        c.drawPath(Path(top).apply { offset(0f, h + 22f) }, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66102040; pathEffect = round; maskFilter = android.graphics.BlurMaskFilter(18f, android.graphics.BlurMaskFilter.Blur.NORMAL) })
        // the slab's wall: lighter at the top edge, darker towards the ground, so it reads as a solid block
        for (d in h downTo 1) {
            val t = d / h.toFloat()
            val col = android.graphics.Color.rgb((0xA4 - 0x3A * t).toInt(), (0xA5 - 0x3A * t).toInt(), (0xC8 - 0x38 * t).toInt())
            c.drawPath(Path(top).apply { offset(0f, d.toFloat()) }, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col; pathEffect = round })
        }
        c.drawPath(top, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            pathEffect = round
            shader = android.graphics.LinearGradient(0f, cy - 125f, 0f, cy + 33f, 0xFFF2F2F6.toInt(), 0xFFC4C5D0.toInt(), android.graphics.Shader.TileMode.CLAMP)
        })
        // a thin bright edge round the top face
        c.drawPath(top, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = 0x99FFFFFF.toInt(); pathEffect = round })
        return bmp
    }

    private fun loadStyle(url: String) {
        val m = map ?: return
        loadedStyle = url
        style = null
        m.setStyle(if (url.startsWith("{")) Style.Builder().fromJson(url) else Style.Builder().fromUri(url)) { st ->
            style = st
            install(st)
            onStyleLoaded?.invoke()
            try { tuneRoads(st) } catch (e: Throwable) { }
        }
    }

    /** A small street lamp standing upright: slim pole, curved arm, bright head, with its foot at the bottom of the image. */
    private fun lampBitmap(): Bitmap {
        val w = 96; val h = 192
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val foot = h - 6f
        val pole = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8C93A3.toInt(); style = Paint.Style.STROKE; strokeWidth = 7f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        val path = Path().apply { moveTo(34f, foot); lineTo(34f, 52f); quadTo(34f, 28f, 62f, 28f) }
        c.drawPath(path, Paint(pole).apply { color = 0x66000000; strokeWidth = 11f })
        c.drawPath(path, pole)
        c.drawCircle(62f, 30f, 26f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = android.graphics.RadialGradient(62f, 30f, 26f, intArrayOf(0xCCFFE2A0.toInt(), 0x55FFC860, 0x00FFC060), floatArrayOf(0f, 0.45f, 1f), android.graphics.Shader.TileMode.CLAMP)
        })
        c.drawRoundRect(android.graphics.RectF(50f, 24f, 74f, 33f), 4f, 4f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFF4D2.toInt() })
        return bmp
    }

    private fun lampAngle(q: DoubleArray): Double =
        if (q.size > 2) q[2] else (Math.abs(Math.round(q[0] * 1e5) * 31 + Math.round(q[1] * 1e5) * 17) % 4) * Math.PI / 2

    /** Where the lamp head hangs: about 1.8 m out along the arm. */
    private fun lampHead(q: DoubleArray): DoubleArray {
        val a = lampAngle(q)
        val dLat = 1.0 / 111320.0
        return doubleArrayOf(q[0] + Math.sin(a) * 2.0 * dLat, q[1] + Math.cos(a) * 2.0 * dLat / Math.cos(Math.toRadians(q[0])))
    }

    /** A 3D street lamp: round stepped pole on a flared base, a curved arm and a cobra-head lantern with a bright lens and a faint glow around it. Drawn a little bigger than life. */
    /** A round light sprite that fades out smoothly (Gaussian-like), warm white. */
    private fun glowBitmap(): Bitmap {
        val n = 256
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val steps = 16
        val cols = IntArray(steps + 1); val pos = FloatArray(steps + 1)
        for (k in 0..steps) {
            val r = k / steps.toFloat()
            val a = Math.exp(-Math.pow(r / 0.42, 2.0)).toFloat() * (1f - r * r * r * r)
            cols[k] = (Math.round(a.coerceIn(0f, 1f) * 255f) shl 24) or 0xFFF2DD
            pos[k] = r
        }
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = android.graphics.RadialGradient(n / 2f, n / 2f, n / 2f, cols, pos, android.graphics.Shader.TileMode.CLAMP)
        Canvas(bmp).drawRect(0f, 0f, n.toFloat(), n.toFloat(), p)
        return bmp
    }

    private fun lampSolids(lat: Double, lon: Double, ang: Double): Pair<List<Feature>, List<Feature>> {
        val dLat = 1.0 / 111320.0
        val dLon = dLat / Math.cos(Math.toRadians(lat))
        val ca = Math.cos(ang); val sa = Math.sin(ang)
        fun fin(ring: List<Pair<Double, Double>>, base: Double, top: Double, col: String): Feature {
            val pts = (ring + ring[0]).map { org.maplibre.geojson.Point.fromLngLat(lon + (it.first * ca - it.second * sa) * dLon, lat + (it.first * sa + it.second * ca) * dLat) }
            val f = Feature.fromGeometry(org.maplibre.geojson.Polygon.fromLngLats(listOf(pts)))
            f.addStringProperty("c", col); f.addNumberProperty("b", base); f.addNumberProperty("h", top)
            return f
        }
        fun box(x0: Double, x1: Double, y0: Double, y1: Double, base: Double, top: Double, col: String) =
            fin(listOf(x0 to y0, x1 to y0, x1 to y1, x0 to y1), base, top, col)
        fun round(r: Double, base: Double, top: Double, col: String) =
            fin((0 until 16).map { k -> val t = k * 2 * Math.PI / 16; r * Math.cos(t) to r * Math.sin(t) }, base, top, col)
        fun ell(cx: Double, rx: Double, ry: Double, base: Double, top: Double, col: String) =
            fin((0 until 14).map { k -> val t = k * 2 * Math.PI / 14; (cx + rx * Math.cos(t)) to ry * Math.sin(t) }, base, top, col)
        // height of the arm's centre line: it rises out of the pole in a smooth curve, then levels off and dips slightly toward the lantern
        fun armZ(x: Double) = if (x < 1.1) 6.3 + 0.72 * Math.sin(x / 1.1 * Math.PI / 2) else 7.02 - 0.14 * (x - 1.1) / 0.9
        val solid = ArrayList<Feature>()
        solid += round(0.40, 0.0, 0.14, "#3A404B")             // flared foot
        solid += round(0.29, 0.14, 0.42, "#454C59")
        solid += round(0.23, 0.42, 0.58, "#5E6675")            // collar
        // pole tapers upward in small steps so it reads as one smooth tube
        for (k in 0 until 6) {
            val r = 0.19 - 0.065 * k / 5.0
            val z0 = 0.58 + k * 0.97
            solid += round(r, z0, z0 + 0.99, if (k < 3) "#7F8798" else "#929AAB")
        }
        // curved arm made of short overlapping pieces that follow the curve
        for (k in 0 until 11) {
            val x0 = k * 0.17; val x1 = x0 + 0.2
            val zc = armZ((x0 + x1) / 2)
            solid += box(x0 - 0.05, x1, -0.065, 0.065, zc - 0.08, zc + 0.08, "#A3ABBA")
        }
        // cobra-head lantern: rounded, tapering shell with a bright lens underneath
        solid += ell(2.45, 0.66, 0.33, 6.62, 6.80, "#4A515D")
        solid += ell(2.45, 0.54, 0.27, 6.80, 6.92, "#5B6270")
        solid += ell(2.5, 0.58, 0.29, 6.54, 6.62, "#2F343E")
        solid += ell(2.55, 0.5, 0.25, 6.47, 6.54, "#FFFEF6")      // lit lens
        val halo = listOf(
            ell(2.55, 0.85, 0.5, 6.1, 6.47, "#FFF4DC"),
            ell(2.55, 1.15, 0.7, 5.7, 6.1, "#FFF4DC"),
        )
        return Pair(solid, halo)
    }

    private var lampLat = 999.0
    private var lampLon = 0.0
    private var lampZ = 0
    private var lampAt = 0L
    private var lampBusy = false
    private var lampRetry = false

    /** Loads the real street lamps around the screen into the night map (only when the pack has lamps.tsv). */
    /** Set when the last run never finished (the app froze or crashed inside the lamp code): lamps then switch themselves off. */
    var lampsOn = true
    var lampTripped = false
    private val guard by lazy { ctx.getSharedPreferences("lampguard", Context.MODE_PRIVATE) }
    fun initLampGuard() {
        if (guard.getBoolean("busy", false)) { lampsOn = false; lampTripped = true; guard.edit().putBoolean("busy", false).apply() }
    }
    fun lampsEnabled(on: Boolean) {
        lampsOn = on
        if (!on) { try { (style?.getSource("dl-lamp-src") as? GeoJsonSource)?.setGeoJson(empty()); (style?.getSource("dl-lamp-3d") as? GeoJsonSource)?.setGeoJson(empty()); (style?.getSource("dl-lamp-halo") as? GeoJsonSource)?.setGeoJson(empty()) } catch (e: Throwable) { } }
        else { lampLat = 999.0; lampAt = 0L }
    }

    // ---- trees in green spaces ----
    private var treesOn = true
    private var treeBusy = false
    private var treeAt = 0L
    private var treeIds: Array<String>? = null
    /** Every tree placed so far, by grid cell (lat, lon, size), so trees never move or pop as you pan and zoom. */
    private val treeCache = object : LinkedHashMap<Long, DoubleArray>(512, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, DoubleArray>?) = size > 6000
    }
    private var treeShownSig = 0L
    private val greenKinds = setOf("grass", "wood", "forest", "park", "garden", "meadow", "scrub", "heath", "orchard", "recreation_ground", "recreation",
        "golf_course", "golf", "cemetery", "nature_reserve", "village_green", "allotments", "common", "grassland", "playground", "green", "pitch")
    private val greenWords = listOf("park", "green", "forest", "wood", "grass", "vegetation", "nature", "garden", "golf", "cemetery", "recreation", "meadow", "scrub")

    fun treesEnabled(on: Boolean) {
        treesOn = on
        try { style?.getLayer("dl-trees-l")?.setProperties(PropertyFactory.visibility(if (on && !satellite && buildings3d) Property.VISIBLE else Property.NONE)) } catch (e: Exception) { }
        if (on) { treeAt = 0L; refreshTrees() }
    }

    private var treeNight = false
    private var treePitchImg = -1
    private val TREE_PX_PER_M = 12.0

    /** Picks the tree picture for the current tilt (in 10 degree steps), drawing it the first time it's needed. */
    private fun syncTreePitch() {
        val m = map ?: return
        val st = style ?: return
        val bucket = (Math.round(m.cameraPosition.tilt / 10.0) * 10).toInt().coerceIn(0, 70)
        if (bucket == treePitchImg) return
        try {
            val name = "dl-tree-$bucket"
            if (st.getImage(name) == null) st.addImage(name, treeSprite(bucket.toDouble(), treeNight))
            st.getLayer("dl-trees-l")?.setProperties(PropertyFactory.iconImage(name))
            treePitchImg = bucket
        } catch (e: Exception) { }
    }

    /**
     * A tree in the Google Maps immersive style, seen from a camera tilted by [pitch]: a short trunk and an egg-shaped canopy (wide and
     * full low down, narrowing to a rounded top), with flat, matte shading: a lit side and a shaded side, a little darker underneath,
     * no shine. Seen from straight above it's a round blob; as the view tilts the canopy stands up. The ground point is the picture's centre.
     */
    private fun treeSprite(pitch: Double, night: Boolean): Bitmap {
        val k = TREE_PX_PER_M.toFloat()
        val w = 112; val h = 260
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        b.density = android.util.DisplayMetrics.DENSITY_DEFAULT
        val c = Canvas(b)
        val gx = w / 2f; val gy = h / 2f
        val sp = Math.sin(Math.toRadians(pitch)).toFloat(); val cp = Math.cos(Math.toRadians(pitch)).toFloat()
        val W = 6.4f * k          // canopy width
        val H = 8.4f * k          // canopy height
        val base = 1.4f * k       // canopy starts this high above the ground
        val trunkW = 0.8f * k
        // soft ground shadow
        c.drawOval(RectF(gx - W * 0.46f, gy - W * 0.46f * cp, gx + W * 0.46f, gy + W * 0.46f * cp), Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = android.graphics.RadialGradient(gx, gy, W * 0.5f, intArrayOf(if (night) 0x55000000 else 0x33203A22, 0x00000000), floatArrayOf(0.35f, 1f), android.graphics.Shader.TileMode.CLAMP)
        })
        // trunk
        val by = gy - base * sp
        if (sp > 0.05f) c.drawRect(RectF(gx - trunkW / 2, by - H * 0.15f * sp, gx + trunkW / 2, gy), Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (night) 0xFF2A2934.toInt() else 0xFF84654A.toInt()
        })
        // canopy outline: the side profile (stretched by the tilt) joined with the round top view (squashed by the tilt)
        val prof = Path().apply {
            moveTo(gx, by)
            cubicTo(gx - W * 0.56f, by, gx - W * 0.53f, by - H * 0.6f * sp, gx - W * 0.2f, by - H * 0.93f * sp)
            quadTo(gx, by - H * 1.03f * sp, gx + W * 0.2f, by - H * 0.93f * sp)
            cubicTo(gx + W * 0.53f, by - H * 0.6f * sp, gx + W * 0.56f, by, gx, by)
            close()
        }
        val wideY = by - H * 0.36f * sp
        val top = Path().apply { addOval(RectF(gx - W * 0.5f, wideY - W * 0.5f * cp, gx + W * 0.5f, wideY + W * 0.5f * cp), Path.Direction.CW) }
        val canopy = Path(prof).apply { op(top, Path.Op.UNION) }
        // matte two-tone: lit from the left, shaded on the right, a touch darker towards the bottom; no highlight
        val lit = if (night) 0xFF22524A.toInt() else 0xFF8BCF7E.toInt()
        val mid = if (night) 0xFF1A4339.toInt() else 0xFF6EBA63.toInt()
        val shadeC = if (night) 0xFF11302A.toInt() else 0xFF51984C.toInt()
        val bounds = RectF(); canopy.computeBounds(bounds, true)
        c.drawPath(canopy, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = android.graphics.LinearGradient(bounds.left, 0f, bounds.right, 0f, intArrayOf(lit, mid, shadeC), floatArrayOf(0.15f, 0.55f, 1f), android.graphics.Shader.TileMode.CLAMP)
        })
        c.drawPath(canopy, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = android.graphics.LinearGradient(0f, bounds.top, 0f, bounds.bottom, intArrayOf(0x00000000, 0x00000000, if (night) 0x33000000 else 0x22183018), floatArrayOf(0f, 0.6f, 1f), android.graphics.Shader.TileMode.CLAMP)
        })
        return b
    }

    /**
     * Puts trees in the green areas on screen (parks, grass, woods, gardens, playing fields, cemeteries...), never on ordinary land:
     * a fixed grid over the whole country, about one tree per 24 m cell where a cell's own fixed random number says so, so the same park
     * always gets the same trees. Trees are remembered once placed, so panning and zooming never make them move or pop.
     */
    private fun refreshTrees() {
        if (!treesOn || satellite || !buildings3d || treeBusy) return
        val m = map ?: return
        val st = style ?: return
        // the map view is taken off screen while a settings page is open; asking a detached map about its features can block
        if (!mapView.isAttachedToWindow || !mapView.isShown || mapView.width < 50 || mapView.height < 50 || mapView.windowVisibility != android.view.View.VISIBLE) return
        val cam = m.cameraPosition
        if (cam.zoom < 15.3) return
        val now = android.os.SystemClock.uptimeMillis()
        if (now - treeAt < 800) return
        treeAt = now
        // two kinds of map layer: ones that are green by name (parks, woods, grass) where every shape counts, and general land-use /
        // land-cover layers where a shape only counts if its own class says it's green (so housing and industrial areas get no trees)
        val fills = st.layers.filterIsInstance<FillLayer>().filter { l -> val k = (l.id + " " + srcLayerOf(l)).lowercase(); !l.id.startsWith("dl-") && !k.contains("water") && !k.contains("building") }
        val greenIds = fills.filter { l -> val k = (l.id + " " + srcLayerOf(l)).lowercase(); greenWords.any { k.contains(it) } }.map { it.id }.toTypedArray()
        val ids = treeIds ?: fills.filter { l -> val k = (l.id + " " + srcLayerOf(l)).lowercase(); listOf("landuse", "land use", "landcover", "land cover", "leisure", "natural").any { k.contains(it) } && l.id !in greenIds }.map { it.id }.toTypedArray().also { treeIds = it }
        if (ids.isEmpty() && greenIds.isEmpty()) return
        // only the lower part of the screen (closer in): far-off shapes at the horizon aren't worth the work
        val rect = android.graphics.RectF(0f, mapView.height * 0.25f, mapView.width.toFloat(), mapView.height.toFloat())
        val byName = try { if (greenIds.isEmpty()) emptyList() else m.queryRenderedFeatures(rect, *greenIds) } catch (e: Throwable) { return }
        val byClass = try { if (ids.isEmpty()) emptyList() else m.queryRenderedFeatures(rect, *ids) } catch (e: Throwable) { return }
        val polys = ArrayList<List<List<Point>>>()
        for ((fromName, f) in byName.map { true to it } + byClass.map { false to it }) {
            val cls = (f.getStringProperty("class") ?: f.getStringProperty("subclass") ?: f.getStringProperty("kind") ?: f.getStringProperty("type") ?: f.getStringProperty("category") ?: "").lowercase()
            val clsGreen = cls.isNotEmpty() && (cls in greenKinds || greenWords.any { cls.contains(it) })
            val clsOther = cls.isNotEmpty() && !clsGreen
            val green = if (fromName) !clsOther || clsGreen else clsGreen
            if (!green) continue
            when (val g = f.geometry()) {
                is Polygon -> polys += g.coordinates()
                is MultiPolygon -> polys.addAll(g.coordinates())
                else -> { }
            }
            if (polys.size > 160) break
        }
        val c = cam.target ?: return
        treeBusy = true
        Thread {
            try {
                val cell = 24.0
                val kLat = 110574.0; val kLon = 111320.0 * Math.cos(Math.toRadians(c.latitude))
                fun inRing(r: List<Point>, lat: Double, lon: Double): Boolean {
                    var inside = false; var j = r.size - 1
                    for (i in r.indices) {
                        val yi = r[i].latitude(); val yj = r[j].latitude(); val xi = r[i].longitude(); val xj = r[j].longitude()
                        if ((yi > lat) != (yj > lat) && lon < (xj - xi) * (lat - yi) / (yj - yi + 1e-15) + xi) inside = !inside
                        j = i
                    }
                    return inside
                }
                fun hash(a: Long, b: Long, salt: Long): Double {
                    var h = a * 0x9E3779B97F4A7C15uL.toLong() xor (b + salt) * 0xC2B2AE3D27D4EB4FuL.toLong()
                    h = h xor (h ushr 31); h *= 0x165667B19E3779F9L; h = h xor (h ushr 29)
                    return ((h ushr 11).toDouble() / (1L shl 53).toDouble())
                }
                val fresh = HashMap<Long, DoubleArray>()
                for (rings in polys) {
                    val outer = rings.firstOrNull() ?: continue
                    if (outer.size < 4) continue
                    var minLa = 90.0; var maxLa = -90.0; var minLo = 180.0; var maxLo = -180.0
                    for (p in outer) { minLa = minOf(minLa, p.latitude()); maxLa = maxOf(maxLa, p.latitude()); minLo = minOf(minLo, p.longitude()); maxLo = maxOf(maxLo, p.longitude()) }
                    val y0 = Math.floor(minLa * kLat / cell).toLong(); val y1 = Math.floor(maxLa * kLat / cell).toLong()
                    val x0 = Math.floor(minLo * kLon / cell).toLong(); val x1 = Math.floor(maxLo * kLon / cell).toLong()
                    if ((y1 - y0 + 1) * (x1 - x0 + 1) > 4000) continue
                    for (iy in y0..y1) for (ix in x0..x1) {
                        val key = iy * 1_000_003L + ix
                        if (fresh.containsKey(key)) continue
                        if (hash(ix, iy, 1) > 0.42) continue
                        val lat = (iy + 0.2 + 0.6 * hash(ix, iy, 2)) * cell / kLat
                        val lon = (ix + 0.2 + 0.6 * hash(ix, iy, 3)) * cell / kLon
                        if (!inRing(outer, lat, lon)) continue
                        if (rings.drop(1).any { inRing(it, lat, lon) }) continue
                        // keep a little away from the shape's edge so trees don't stand on paths and roads
                        var nearEdge = false
                        for (q in outer) if (Math.abs(q.latitude() - lat) * kLat < 5.0 && Math.abs(q.longitude() - lon) * kLon < 5.0) { nearEdge = true; break }
                        if (nearEdge) continue
                        fresh[key] = doubleArrayOf(lat, lon, 0.85 + 0.35 * hash(ix, iy, 4))
                    }
                }
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try {
                        for ((k, v) in fresh) if (!treeCache.containsKey(k)) treeCache[k] = v
                        // show the remembered trees within a fixed distance of the view's centre (not the nearest N, which changes with every
                        // small move and made trees flicker); drawn back to front
                        val reach = when { cam.zoom >= 17.5 -> 500.0; cam.zoom >= 16.5 -> 800.0; else -> 1100.0 }
                        val shown = treeCache.entries.filter { (_, t) -> Math.abs(t[0] - c.latitude) * kLat < reach && Math.abs(t[1] - c.longitude) * kLon < reach }.take(300)
                        var sig = shown.size.toLong()
                        for ((k, _) in shown) sig = sig * 31 + k
                        if (sig != treeShownSig) {
                            treeShownSig = sig
                            // painted back to front for the current view direction, so nearer trees overlap farther ones correctly
                            val br = Math.toRadians(cam.bearing)
                            val fx = Math.sin(br); val fy = Math.cos(br)
                            val sorted = shown.sortedByDescending { (_, t) -> (t[1] - c.longitude) * kLon * fx + (t[0] - c.latitude) * kLat * fy }
                            val out = ArrayList<Feature>(sorted.size)
                            for ((_, t) in sorted) out += Feature.fromGeometry(Point.fromLngLat(t[1], t[0])).also { it.addNumberProperty("s", t[2]) }
                            src("dl-trees")?.setGeoJson(FeatureCollection.fromFeatures(out))
                        }
                    } catch (e: Exception) { }
                    treeBusy = false
                }
            } catch (e: Throwable) {
                android.os.Handler(android.os.Looper.getMainLooper()).post { treeBusy = false }
            }
        }.start()
    }

    // ---- traffic lights (OpenStreetMap), fetched one map tile at a time and kept ----
    var signalsOn = true
    private val signalTiles = object : LinkedHashMap<Long, List<LL>>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, List<LL>>?) = size > 40
    }
    private val signalFailed = HashMap<Long, Long>()
    private var signalBusy = false
    private var signalAt = 0L
    private var signalPts: List<LL> = emptyList()
    private var signalErr = ""
    private var signalToken = 0
    private var signalStage = "not started"

    /** One line for the settings page: how many lights are known and whether the last fetch worked. */
    fun signalInfo(): String {
        if (!signalsOn) return "off"
        if (main.size < 2) return "no route (lights only show on your route)"
        val onR = try { signalFeatures().features()?.size ?: 0 } catch (e: Throwable) { 0 }
        return "$onR on route, ${signalPts.size} nearby, ${signalTiles.size} area(s) loaded" + (if (signalErr.isNotEmpty()) ", last error: $signalErr" else "") + ", status: $signalStage"
    }

    fun signalsEnabled(on: Boolean) {
        signalsOn = on
        if (on) { signalAt = 0L; refreshSignals() } else { signalPts = emptyList(); pushSignals() }
    }

    private fun signalBitmap(): Bitmap {
        // drawn at twice the size (and shown at half) so it stays sharp now that it's bigger on screen
        val bmp = Bitmap.createBitmap(96, 192, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(2f, 2f)
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xF21B2029.toInt() }
        c.drawRoundRect(RectF(4f, 4f, 44f, 92f), 14f, 14f, body)
        val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = 0x55FFFFFF }
        c.drawRoundRect(RectF(4f, 4f, 44f, 92f), 14f, 14f, edge)
        val dot = Paint(Paint.ANTI_ALIAS_FLAG)
        dot.color = 0xFFFF5A52.toInt(); c.drawCircle(24f, 22f, 10f, dot)
        dot.color = 0xFFFFC043.toInt(); c.drawCircle(24f, 48f, 10f, dot)
        dot.color = 0xFF3DDC84.toInt(); c.drawCircle(24f, 74f, 10f, dot)
        return bmp
    }

    // only the lights on the road you are following are drawn: the route is turned into a set of small grid cells, and a light counts if it sits in or next to one
    private var cellsFor: List<LL>? = null
    private val routeCells = HashSet<Long>()
    private fun cellKey(lat: Double, lon: Double) = Math.floor(lat / 0.0002).toLong() * 1000003L + Math.floor(lon / 0.0003).toLong()

    private fun rebuildCells(r: List<LL>) {
        routeCells.clear()
        for (i in r.indices) {
            val a = r[i]
            routeCells.add(cellKey(a.lat, a.lon))
            if (i + 1 < r.size) {
                val b = r[i + 1]
                val steps = (Geo.dist(a, b) / 15.0).toInt()
                for (k in 1..steps) { val t = k / (steps + 1.0); routeCells.add(cellKey(a.lat + (b.lat - a.lat) * t, a.lon + (b.lon - a.lon) * t)) }
            }
        }
        cellsFor = r
    }

    private fun onRoute(p: LL): Boolean {
        val k = Math.floor(p.lat / 0.0002).toLong() * 1000003L + Math.floor(p.lon / 0.0003).toLong()
        for (dy in -1..1) for (dx in -1..1) if (routeCells.contains(k + dy * 1000003L + dx)) return true
        return false
    }

    private fun signalFeatures(): FeatureCollection {
        val r = main
        if (r.size < 2) return empty()
        if (cellsFor !== r) rebuildCells(r)
        // only lights that stand on the route's own road (within ~10 m of the line), and at each junction only the first one you reach:
        // a junction usually has a light on every arm, but only the one on your approach matters
        val near = signalPts.filter { onRoute(it) }
        if (near.isEmpty()) return empty()
        val cum = DoubleArray(r.size)
        for (i in 1 until r.size) cum[i] = cum[i - 1] + Geo.dist(r[i - 1], r[i])
        val placed = ArrayList<Pair<Double, LL>>()
        for (p in near) {
            val kx = Math.cos(Math.toRadians(p.lat)) * 111320.0; val ky = 110574.0
            var bd = 10.0; var bo = -1.0
            for (i in 0 until r.size - 1) {
                val ax = (r[i].lon - p.lon) * kx; val ay = (r[i].lat - p.lat) * ky
                val bx = (r[i + 1].lon - p.lon) * kx; val by = (r[i + 1].lat - p.lat) * ky
                if ((ax > bd && bx > bd) || (ax < -bd && bx < -bd) || (ay > bd && by > bd) || (ay < -bd && by < -bd)) continue
                val dx = bx - ax; val dy = by - ay
                val l2 = dx * dx + dy * dy
                val t = if (l2 > 0) (-(ax * dx + ay * dy) / l2).coerceIn(0.0, 1.0) else 0.0
                val d = Math.hypot(ax + dx * t, ay + dy * t)
                if (d < bd) { bd = d; bo = cum[i] + (cum[i + 1] - cum[i]) * t }
            }
            if (bo >= 0) placed += bo to p
        }
        placed.sortBy { it.first }
        val keep = ArrayList<Feature>()
        var lastOff = -1e9
        for ((off, p) in placed) {
            if (off - lastOff < 70.0) { lastOff = off; continue }   // same junction: you have already passed its first light
            lastOff = off
            keep += Feature.fromGeometry(Point.fromLngLat(p.lon, p.lat))
            if (keep.size >= 150) break
        }
        return FeatureCollection.fromFeatures(keep)
    }

    private fun pushSignals() {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try { (style?.getSource("dl-signals") as? GeoJsonSource)?.setGeoJson(signalFeatures()) } catch (e: Throwable) { }
        }
    }

    private fun refreshSignals() {
        if (!signalsOn || main.size < 2) return
        try {
            val m = map ?: return
            if (style == null) { signalStage = "waiting for the map style"; return }
            if (signalBusy) { signalStage = "loading lights…"; return }
            if (!mapView.isAttachedToWindow || !mapView.isShown || mapView.width < 50 || mapView.height < 50) return
            val cam = m.cameraPosition
            if (cam.zoom < 13.5) { signalStage = "zoomed out too far (zoom ${cam.zoom.toInt()})"; return }
            val c = cam.target ?: return
            val now = android.os.SystemClock.uptimeMillis()
            if (now - signalAt < 1200) return
            // tiles are about 1.5 km on a side
            val tx = Math.floor((c.longitude + 180.0) / 360.0 * 16384.0).toLong()
            val ty = Math.floor((1.0 - Math.log(Math.tan(Math.toRadians(c.latitude)) + 1.0 / Math.cos(Math.toRadians(c.latitude))) / Math.PI) / 2.0 * 16384.0).toLong()
            val centreKey = tx * 100000L + ty
            // the tile under the camera plus its neighbours, whichever are already known
            val have = ArrayList<LL>()
            for (dx in -1..1) for (dy in -1..1) signalTiles[(tx + dx) * 100000L + (ty + dy)]?.let { have.addAll(it) }
            val merged = have.distinctBy { Math.round(it.lat * 1e6) * 1000003L + Math.round(it.lon * 1e6) }
                .sortedBy { Math.abs(it.lat - c.latitude) + Math.abs(it.lon - c.longitude) }.take(400)
            if (merged.size != signalPts.size) { signalPts = merged; pushSignals() }
            if (signalTiles.containsKey(centreKey)) return
            val failedAt = signalFailed[centreKey]
            if (failedAt != null && now - failedAt < 20_000L) return
            signalBusy = true; signalAt = now; signalStage = "loading lights…"
            val token = ++signalToken
            // if the request has not come back after 30 s, give up on it so the next attempt can start
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                if (signalBusy && token == signalToken) { signalBusy = false; signalFailed[centreKey] = android.os.SystemClock.uptimeMillis(); signalErr = "timed out (" + Overpass.lastNote.take(80) + ")" }
            }, 30_000L)
            fun lonOf(x: Double) = x / 16384.0 * 360.0 - 180.0
            fun latOf(y: Double) = Math.toDegrees(Math.atan(Math.sinh(Math.PI * (1.0 - 2.0 * y / 16384.0))))
            val minLon = lonOf(tx - 0.4); val maxLon = lonOf(tx + 1.4)
            val maxLat = latOf(ty - 0.4); val minLat = latOf(ty + 1.4)
            Thread {
                try {
                    val offline = OfflineRouter.hasSignals(ctx)
                    val pts = if (offline) OfflineRouter.lamps(ctx, minLat, minLon, maxLat, maxLon, "signals.tsv").map { LL(it[0], it[1]) } else Overpass.signals(minLat, minLon, maxLat, maxLon)
                    if (offline) Overpass.lastNote = "offline pack"
                    android.os.Handler(android.os.Looper.getMainLooper()).post { signalTiles[centreKey] = pts; if (token == signalToken) signalBusy = false; signalErr = ""; signalStage = "loaded ${pts.size} lights (${Overpass.lastNote})"; signalAt = 0L; refreshSignals() }
                } catch (e: Throwable) {
                    val msg = (e.message ?: e.javaClass.simpleName).take(80)
                    android.os.Handler(android.os.Looper.getMainLooper()).post { signalFailed[centreKey] = android.os.SystemClock.uptimeMillis(); if (token == signalToken) signalBusy = false; signalErr = msg }
                }
            }.start()
        } catch (e: Throwable) { signalBusy = false; signalErr = "internal: " + (e.message ?: e.javaClass.simpleName).take(60) }
    }

    private fun refreshLamps() {
        if (!lampsOn) return
        try { refreshLampsInner() } catch (e: Throwable) { lampBusy = false; guard.edit().putBoolean("busy", false).apply() }
    }

    private fun refreshLampsInner() {
        val m = map ?: return
        val st = style ?: return
        if (!nightStyle || lampBusy || st.getSource("dl-lamp-src") == null) return
        // the map view is taken off screen while a settings page is open; asking a detached map about its features can block forever
        if (!mapView.isAttachedToWindow || !mapView.isShown || mapView.width < 50 || mapView.height < 50 || mapView.windowVisibility != android.view.View.VISIBLE) return
        val cam = m.cameraPosition
        val z = cam.zoom
        if (z < 15.0) return
        val now = android.os.SystemClock.uptimeMillis()
        val c = cam.target ?: return
        val moved = Math.hypot((c.latitude - lampLat) * 111000.0, (c.longitude - lampLon) * 111000.0 * Math.cos(Math.toRadians(c.latitude)))
        if (moved < (if (OfflineRouter.hasLamps(ctx)) 150.0 else 30.0) && (z * 2).toInt() == lampZ && lampLat != 999.0) return
        if (now - lampAt < 2500) {
            // too soon: try again once the pause is over, so lamps never wait for the next camera move
            if (!lampRetry) { lampRetry = true; android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ lampRetry = false; refreshLamps() }, 2600L - (now - lampAt)) }
            return
        }
        val b = try { m.projection.visibleRegion.latLngBounds } catch (e: Throwable) { return }
        val padLat = (b.latitudeNorth - b.latitudeSouth) * 0.4
        val padLon = (b.longitudeEast - b.longitudeWest) * 0.4
        lampBusy = true; lampAt = now; lampLat = c.latitude; lampLon = c.longitude; lampZ = (z * 2).toInt()
        // the "busy" mark is only held while the map itself is being asked or told something, so an unrelated crash elsewhere is not blamed on the lamps
        guard.edit().putBoolean("busy", true).commit()
        val roadFeats = try { if (OfflineRouter.hasLamps(ctx)) null else queryLampRoads(m) } finally { guard.edit().putBoolean("busy", false).commit() }
        val cLat = c.latitude; val cLon = c.longitude
        Thread {
          try {
            val pts = if (roadFeats != null) keepNearby(guessLamps(roadFeats), cLat, cLon) else thin(OfflineRouter.lamps(ctx, b.latitudeSouth - padLat, b.longitudeWest - padLon, b.latitudeNorth + padLat, b.longitudeEast + padLon))
            val solids = ArrayList<Feature>()
            val halos = ArrayList<Feature>()
            if (z >= 16.5) for (q in pts.sortedBy { Math.abs(it[0] - cLat) + Math.abs(it[1] - cLon) }.take(36)) { val pr = lampSolids(q[0], q[1], lampAngle(q)); solids.addAll(pr.first); halos.addAll(pr.second) }
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                lampBusy = false
                guard.edit().putBoolean("busy", true).commit()
                try {
                    val fc = FeatureCollection.fromFeatures(ArrayList(pts.take(250).map { q -> val h = lampHead(q); Feature.fromGeometry(org.maplibre.geojson.Point.fromLngLat(h[1], h[0])) }))
                    (style?.getSource("dl-lamp-src") as? GeoJsonSource)?.setGeoJson(fc)
                    (style?.getSource("dl-lamp-3d") as? GeoJsonSource)?.setGeoJson(FeatureCollection.fromFeatures(solids))
                    (style?.getSource("dl-lamp-halo") as? GeoJsonSource)?.setGeoJson(FeatureCollection.fromFeatures(halos))
                } catch (e: Throwable) { }
                guard.edit().putBoolean("busy", false).commit()
            }
          } catch (e: Throwable) {
            android.os.Handler(android.os.Looper.getMainLooper()).post { lampBusy = false; guard.edit().putBoolean("busy", false).apply() }
          }
        }.start()
    }

    /** Set by the engine: true when the night style is showing. */
    var nightStyle = true

    /** Day: nudge road fills a little darker so they separate from the land. Night: faint lamp glows along the roads (drawn from the road geometry, not surveyed lamp positions). */
    private fun tuneRoads(st: Style) {
        val roads = st.layers.filter { it is LineLayer && !it.id.startsWith("dl-") && roadLike(it.id) }.map { it as LineLayer }
        if (!nightStyle) {
            for (l in roads) {
                val id = l.id.lowercase()
                if (id.contains("casing") || id.contains("outline")) continue
                try {
                    val c = l.lineColorAsInt
                    val f = 0.80f
                    val r = ((c shr 16 and 255) * f).toInt(); val g = ((c shr 8 and 255) * f).toInt(); val b = ((c and 255) * f).toInt()
                    l.setProperties(PropertyFactory.lineColor(0xFF000000.toInt() or (r shl 16) or (g shl 8) or b))
                } catch (e: Throwable) { }
            }
            return
        }
        st.addSource(GeoJsonSource("dl-lamp-src", empty()))
        // light: a soft, smoothly fading sprite (not stacked rings), laid on the ground as a pool, plus a small glow around the lamp head
        st.addImage("dl-lamp-glow-img", glowBitmap())
        // the light keeps growing with the map when you zoom right in (it used to stop at zoom 19 and shrink to a dot next to a big lamp)
        fun glowLayer(id: String, ground: Boolean, z16: Float, z19: Float, op: Float) {
            st.addLayerBelow(SymbolLayer(id, "dl-lamp-src").withProperties(
                PropertyFactory.iconImage("dl-lamp-glow-img"),
                PropertyFactory.iconAllowOverlap(true), PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconPitchAlignment(if (ground) Property.ICON_PITCH_ALIGNMENT_MAP else Property.ICON_PITCH_ALIGNMENT_VIEWPORT),
                PropertyFactory.iconRotationAlignment(if (ground) Property.ICON_ROTATION_ALIGNMENT_MAP else Property.ICON_ROTATION_ALIGNMENT_VIEWPORT),
                PropertyFactory.iconOpacity(op),
                PropertyFactory.iconSize(Expression.interpolate(Expression.exponential(2), Expression.zoom(), Expression.stop(16, z16), Expression.stop(19, z19), Expression.stop(22, z19 * 8f))),
            ).also { it.minZoom = 16f }, "dl-alts-line")
        }
        // a wide warm pool on the road, a softer halo, and a small bright core
        glowLayer("dl-lamp-pool", true, 0.09f, 0.72f, 0.75f)
        glowLayer("dl-lamp-halo2", false, 0.05f, 0.36f, 0.42f)
        glowLayer("dl-lamp-bulb", false, 0.012f, 0.1f, 0.9f)
        st.addSource(GeoJsonSource("dl-lamp-3d", empty()))
        st.addLayerBelow(org.maplibre.android.style.layers.FillExtrusionLayer("dl-lamp-core", "dl-lamp-3d").withProperties(
            PropertyFactory.fillExtrusionColor(Expression.toColor(Expression.get("c"))),
            PropertyFactory.fillExtrusionHeight(Expression.get("h")),
            PropertyFactory.fillExtrusionBase(Expression.get("b")),
            PropertyFactory.fillExtrusionOpacity(1f),
            PropertyFactory.fillExtrusionVerticalGradient(false),
        ).also { it.minZoom = 16.5f }, "dl-alts-line")
        st.addSource(GeoJsonSource("dl-lamp-halo", empty()))
        st.addLayerBelow(org.maplibre.android.style.layers.FillExtrusionLayer("dl-lamp-halo-l", "dl-lamp-halo").withProperties(
            PropertyFactory.fillExtrusionColor(0xFFFFF4DC.toInt()),
            PropertyFactory.fillExtrusionHeight(Expression.get("h")),
            PropertyFactory.fillExtrusionBase(Expression.get("b")),
            PropertyFactory.fillExtrusionOpacity(0.2f),
            PropertyFactory.fillExtrusionVerticalGradient(false),
        ).also { it.minZoom = 16.5f }, "dl-alts-line")
        lampIds = roads.filter { l -> val id = l.id.lowercase(); !(id.contains("casing") || id.contains("outline") || id.contains("tunnel") || id.contains("motorway") || id.contains("trunk")) }.map { it.id }.toTypedArray()
        lampLat = 999.0
    }

    private var lampCache: List<DoubleArray> = emptyList()

    /** Lamps stay where they were first put: new road pieces from the map only fill gaps, so zooming out and in (when the map redraws the roads from different tiles) never moves them. */
    private fun keepNearby(fresh: List<DoubleArray>, cLat: Double, cLon: Double): List<DoubleArray> {
        val cell = Math.max(6.0, lampGap * 0.6)
        val grid = HashMap<Long, ArrayList<DoubleArray>>()
        val out = ArrayList<DoubleArray>()
        val kx = 111320.0 * Math.cos(Math.toRadians(cLat))
        fun cellOf(q: DoubleArray) = longArrayOf(Math.floor(q[0] * 111320.0 / cell).toLong(), Math.floor(q[1] * kx / cell).toLong())
        fun near(q: DoubleArray): Boolean {
            val c = cellOf(q)
            for (dy in -1L..1L) for (dx in -1L..1L) {
                val l = grid[(c[0] + dy) * 1000003L + (c[1] + dx)] ?: continue
                for (o in l) if (Math.hypot((o[0] - q[0]) * 111320.0, (o[1] - q[1]) * kx) < cell) return true
            }
            return false
        }
        fun add(q: DoubleArray) {
            val c = cellOf(q)
            grid.getOrPut(c[0] * 1000003L + c[1]) { ArrayList() }.add(q); out.add(q)
        }
        lampCache.forEach { add(it) }
        for (q in fresh) if (!near(q)) add(q)
        val res = if (out.size > 3000) out.sortedBy { Math.abs(it[0] - cLat) + Math.abs(it[1] - cLon) }.take(3000) else out
        lampCache = res
        return res
    }

    private var lampIds: Array<String> = emptyArray()

    /** How far apart lamps are placed, in metres (the user's setting). */
    var lampGap = 40.0
    fun applyLampGap(m: Double) {
        if (m == lampGap) return
        lampGap = m; lampLat = 999.0; lampAt = 0L; lampCache = emptyList()
    }

    /** Lamps at guessed positions: walks along the roads drawn on screen and puts one on alternate sides every [lampGap] metres. */
    private fun queryLampRoads(m: MapLibreMap): List<Feature> {
        if (lampIds.isEmpty()) return emptyList()
        val w = mapView.width.toFloat(); val h = mapView.height.toFloat()
        val rect = android.graphics.RectF(0f, 0f, w, h)
        return try { m.queryRenderedFeatures(rect, *lampIds.take(6).toTypedArray()).take(120) } catch (e: Throwable) { emptyList() }
    }

    private fun guessLamps(feats: List<Feature>): List<DoubleArray> {
        val out = ArrayList<DoubleArray>()
        val seen = HashSet<Long>()
        var side = 1.0
        fun walk(pts: List<org.maplibre.geojson.Point>) {
            var carry = lampGap / 2
            for (i in 0 until pts.size - 1) {
                val la0 = pts[i].latitude(); val lo0 = pts[i].longitude()
                val k = Math.cos(Math.toRadians(la0)) * 111320.0
                val dx = (pts[i + 1].longitude() - lo0) * k; val dy = (pts[i + 1].latitude() - la0) * 111320.0
                val len = Math.hypot(dx, dy)
                if (len < 0.5) continue
                var d = carry
                while (d < len) {
                    val t = d / len
                    val nx = -dy / len; val ny = dx / len
                    val sd = side; val off = 5.0 * sd; side = -sd
                    val ang = Math.atan2(-ny * sd, -nx * sd)
                    val la = la0 + (dy * t + ny * off) / 111320.0
                    val lo = lo0 + (dx * t + nx * off) / k
                    val key = Math.round(la * 30000.0) * 1000003L + Math.round(lo * 30000.0)
                    if (seen.add(key)) out.add(doubleArrayOf(la, lo, ang))
                    d += lampGap
                }
                carry = d - len
            }
        }
        for (f in feats) {
            when (val g = f.geometry()) {
                is org.maplibre.geojson.LineString -> walk(g.coordinates())
                is org.maplibre.geojson.MultiLineString -> for (ln in g.coordinates()) walk(ln)
                else -> { }
            }
            if (out.size > 500) break
        }
        return out
    }

    /** Keeps at most one real lamp per [lampGap] metres square. */
    private fun thin(pts: List<DoubleArray>): List<DoubleArray> {
        if (lampGap <= 12) return pts
        val seen = HashSet<Long>()
        val out = ArrayList<DoubleArray>()
        for (q in pts) {
            val gx = Math.floor(q[1] * 111320.0 * Math.cos(Math.toRadians(q[0])) / lampGap).toLong()
            val gy = Math.floor(q[0] * 111320.0 / lampGap).toLong()
            if (seen.add(gy * 1000003L + gx)) out.add(q)
        }
        return out
    }

    /** Waze-style arrow: fat rounded chevron, blue fill, thick white outline and a soft shadow. Points up; rotated by heading. */
    private fun arrowBitmap(): Bitmap {
        val n = 128
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val path = Path().apply {
            moveTo(64f, 14f)
            quadTo(70f, 14f, 74f, 22f)
            lineTo(100f, 92f)
            quadTo(104f, 104f, 92f, 100f)
            lineTo(64f, 84f)
            lineTo(36f, 100f)
            quadTo(24f, 104f, 28f, 92f)
            lineTo(54f, 22f)
            quadTo(58f, 14f, 64f, 14f)
            close()
        }
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x00000000; style = Paint.Style.FILL; setShadowLayer(10f, 0f, 5f, 0x80000000.toInt())
        }
        c.drawPath(path, shadow)
        val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 12f; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
        }
        c.drawPath(path, edge)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = android.graphics.LinearGradient(0f, 14f, 0f, 104f, 0xFF3AA0FF.toInt(), 0xFF1263E0.toInt(), android.graphics.Shader.TileMode.CLAMP)
        }
        c.drawPath(path, fill)
        return bmp
    }

    private fun empty() = FeatureCollection.fromFeatures(ArrayList<Feature>())

    private fun install(st: Style) {
        val im = theme == "immersive"
        val dayLook = !(nightStyle || (wantedStyle ?: "").contains("dark", true))
        if (im && !(wantedStyle ?: "").startsWith("{")) recolour(st)
        // little 3D trees in parks and green spaces (filled in from what's on screen, close in only)
        st.addSource(GeoJsonSource("dl-trees", empty()))
        treeIds = null; treeShownSig = 0L
        val night = nightStyle || (wantedStyle ?: "").contains("dark", true)
        // 3D trees: a trunk and a round canopy built from stacked slices of a ball, darker underneath and lighter towards the top
        // trees: each one is a picture of a 3D tree (a round, smoothly shaded ball of leaves on a trunk) drawn for the camera's current
        // tilt, so it looks exactly like a solid round tree from any angle. Pictures for each 10 degrees of tilt are drawn when needed.
        treeNight = night; treePitchImg = -1
        val m1 = 1.0 / (40075016.686 * Math.cos(Math.toRadians(52.0)) / 512.0)   // map pixels per metre at zoom 0 (UK latitude)
        fun sz(z: Int) = (m1 * Math.pow(2.0, z.toDouble()) / TREE_PX_PER_M).toFloat()
        st.addLayer(SymbolLayer("dl-trees-l", "dl-trees").withProperties(
            PropertyFactory.iconImage("dl-tree-0"),
            PropertyFactory.iconAllowOverlap(true), PropertyFactory.iconIgnorePlacement(true),
            PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_VIEWPORT),
            PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_VIEWPORT),
            // real size on the map (doubles with each zoom level), each tree slightly different
            PropertyFactory.iconSize(Expression.interpolate(Expression.exponential(2f), Expression.zoom(),
                Expression.stop(15, Expression.product(Expression.toNumber(Expression.get("s")), Expression.literal(sz(15)))),
                Expression.stop(22, Expression.product(Expression.toNumber(Expression.get("s")), Expression.literal(sz(22)))))),
            PropertyFactory.iconOpacity(Expression.interpolate(Expression.linear(), Expression.zoom(), Expression.stop(15.5, 0f), Expression.stop(16.1, 1f))),
            PropertyFactory.visibility(if (treesOn && !satellite && buildings3d) Property.VISIBLE else Property.NONE),
        ).also { it.minZoom = 15.5f })
        syncTreePitch()
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ treeAt = 0L; refreshTrees() }, 1500L)
        st.addSource(GeoJsonSource("dl-alts", empty()))
        st.addSource(GeoJsonSource("dl-live-alts", empty()))
        st.addSource(GeoJsonSource("dl-live-bub", empty()))
        bubImgs.clear()
        st.addSource(GeoJsonSource("dl-route", empty()))
        st.addSource(GeoJsonSource("dl-flow", empty(), org.maplibre.android.style.sources.GeoJsonOptions().withLineMetrics(true)))
        st.addSource(GeoJsonSource("dl-done", empty()))
        st.addSource(GeoJsonSource("dl-dest", empty()))
        st.addSource(GeoJsonSource("dl-hazards", empty()))
        st.addSource(GeoJsonSource("dl-me", empty()))
        // the 3D locator (arrow or car) and its flat parts (ring, shadow); no simplification, so small shapes keep their corners
        // the arrow at the next turn, drawn on the route
        st.addSource(GeoJsonSource("dl-turn", empty(), org.maplibre.android.style.sources.GeoJsonOptions().withTolerance(0.1f)))
        st.addSource(GeoJsonSource("dl-turn-head", empty()))
        st.addSource(GeoJsonSource("dl-lanes", empty()))
        laneImgs.clear()
        // lane bands: each lane drawn as a strip along the road before a junction, the lane(s) you need lit, the others dimmed, with dashed dividers
        st.addSource(GeoJsonSource("dl-lane-bands", empty()))
        st.addSource(GeoJsonSource("dl-lane-divs", empty()))
        st.addLayer(
            LineLayer("dl-alts-line", "dl-alts").withProperties(
                PropertyFactory.lineColor(if (im) "#9AA7B8" else "#8fa3bd"), PropertyFactory.lineWidth(if (im) 8f else 7f), PropertyFactory.lineOpacity(0.85f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        // other ways to go while driving: grey, under the route
        st.addLayer(
            LineLayer("dl-live-alts-line", "dl-live-alts").withProperties(
                PropertyFactory.lineColor(if (im) "#8E9AAE" else "#8a97ab"), PropertyFactory.lineWidth(routeW(0.75f)), PropertyFactory.lineOpacity(0.8f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            LineLayer("dl-route-glow", "dl-route").withProperties(
                PropertyFactory.lineColor(sevColor(im, dayLook)), PropertyFactory.lineWidth(routeW(if (im) 1.45f else 1.3f)), PropertyFactory.lineBlur(4f),
                PropertyFactory.lineOpacity(if (im) 0.62f else 0.4f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            LineLayer("dl-route-casing", "dl-route").withProperties(
                PropertyFactory.lineColor(if (dayLook) "#D3E4FB" else if (im) "#D4F4FF" else "#eaf2ff"), PropertyFactory.lineWidth(routeW(if (im) 1.5f else 1.25f)), PropertyFactory.lineOpacity(if (im) 0.95f else 0.92f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            LineLayer("dl-route-line", "dl-route").withProperties(
                PropertyFactory.lineColor(sevColor(im, dayLook)), PropertyFactory.lineWidth(routeW(if (im) 1.0f else 0.85f)),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        // a band of light that runs along the route towards the destination
        st.addLayer(
            LineLayer("dl-flow-line", "dl-flow").withProperties(
                PropertyFactory.lineWidth(routeW(if (im) 0.6f else 0.5f)), PropertyFactory.lineBlur(3f),
                PropertyFactory.lineGradient(flowGradient(0.5f)),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
                PropertyFactory.visibility(if (flowOn) Property.VISIBLE else Property.NONE),
            )
        )
        // the part of the route you have already driven turns grey, drawn over the blue
        // small direction chevrons along the route line (only close in, where they help)
        st.addImage("dl-chev", chevronBitmap())
        st.addLayer(
            SymbolLayer("dl-route-chev", "dl-route").withProperties(
                PropertyFactory.symbolPlacement(Property.SYMBOL_PLACEMENT_LINE),
                PropertyFactory.iconImage("dl-chev"),
                PropertyFactory.symbolSpacing(110f),
                PropertyFactory.iconAllowOverlap(true), PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
                PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP),
                PropertyFactory.iconOpacity(0.75f),
                PropertyFactory.iconSize(Expression.interpolate(Expression.linear(), Expression.zoom(), Expression.stop(15, 0.28f), Expression.stop(18, 0.5f), Expression.stop(20, 0.7f))),
            ).also { it.minZoom = 15f }
        )
        // the turn arrow: (by day) a soft dark halo so it stands out on the light map, a dark edge, a white shaft and a white head
        if (dayLook) st.addLayer(LineLayer("dl-turn-soft", "dl-turn").withProperties(
            PropertyFactory.lineColor("#16467A"), PropertyFactory.lineWidth(routeW(1.62f)), PropertyFactory.lineBlur(routeW(0.3f)), PropertyFactory.lineOpacity(0.35f),
            PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
        ).also { it.minZoom = 13f })
        st.addLayer(LineLayer("dl-turn-case", "dl-turn").withProperties(
            PropertyFactory.lineColor("#16467A"), PropertyFactory.lineWidth(routeW(1.28f)),
            PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
        ).also { it.minZoom = 13f })
        st.addLayer(LineLayer("dl-turn-line", "dl-turn").withProperties(
            PropertyFactory.lineColor("#FFFFFF"), PropertyFactory.lineWidth(routeW(1.08f)),
            PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
        ).also { it.minZoom = 13f })
        st.addImage("dl-turn-head-img", turnHeadBitmap(dayLook))
        st.addLayer(SymbolLayer("dl-turn-head", "dl-turn-head").withProperties(
            PropertyFactory.iconImage("dl-turn-head-img"),
            PropertyFactory.iconRotate(Expression.get("b")),
            PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
            PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP),
            PropertyFactory.iconAllowOverlap(true), PropertyFactory.iconIgnorePlacement(true),
            // the head's base sits exactly on the end of the shaft, and grows with the zoom the same way the line does
            PropertyFactory.iconAnchor(Property.ICON_ANCHOR_BOTTOM),
            PropertyFactory.iconSize(Expression.interpolate(Expression.exponential(1.7f), Expression.zoom(),
                Expression.stop(10, headSize(3f)), Expression.stop(13, headSize(6.5f)), Expression.stop(15, headSize(10f)), Expression.stop(17, headSize(16f)), Expression.stop(19, headSize(24f)), Expression.stop(22, headSize(40f)))),
        ).also { it.minZoom = 13f })
        st.addLayer(
            LineLayer("dl-done-casing", "dl-done").withProperties(
                PropertyFactory.lineColor(if (im) "#B4B9CE" else "#C3C8D8"), PropertyFactory.lineWidth(routeW(if (im) 1.5f else 1.25f)), PropertyFactory.lineOpacity(0.9f),
                PropertyFactory.lineCap(Property.LINE_CAP_BUTT), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            LineLayer("dl-done-line", "dl-done").withProperties(
                PropertyFactory.lineColor(if (im) "#7E849F" else "#8C92AC"), PropertyFactory.lineWidth(routeW(if (im) 1.0f else 0.85f)),
                PropertyFactory.lineCap(Property.LINE_CAP_BUTT), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        // lane ribbons: the lane you need is a solid teal ribbon that fades away into the distance, the others are quiet road-coloured strips
        val onCol = if (nightStyle) "#2FC9B8" else "#1FB5A8"
        val offCol = if (nightStyle) "#4A5062" else "#FBFAF7"
        st.addLayer(FillLayer("dl-lane-fill", "dl-lane-bands").withProperties(
            PropertyFactory.fillColor(Expression.switchCase(Expression.eq(Expression.get("on"), Expression.literal(1)), Expression.color(android.graphics.Color.parseColor(onCol)), Expression.color(android.graphics.Color.parseColor(offCol)))),
            PropertyFactory.fillOpacity(Expression.product(Expression.get("a"), Expression.switchCase(Expression.eq(Expression.get("on"), Expression.literal(1)), Expression.literal(0.95), Expression.literal(if (nightStyle) 0.75 else 0.85)))),
        ).also { it.minZoom = 15.5f })
        val lineCol = if (nightStyle) "#FFFFFF" else "#6A7080"
        st.addLayer(LineLayer("dl-lane-edge", "dl-lane-divs").withFilter(Expression.eq(Expression.get("s"), Expression.literal(1))).withProperties(
            PropertyFactory.lineColor(lineCol), PropertyFactory.lineOpacity(0.7f),
            PropertyFactory.lineWidth(Expression.interpolate(Expression.exponential(2), Expression.zoom(), Expression.stop(15, 0.15f), Expression.stop(20, 2.5f))),
        ).also { it.minZoom = 15.5f })
        st.addLayer(LineLayer("dl-lane-div", "dl-lane-divs").withFilter(Expression.eq(Expression.get("s"), Expression.literal(0))).withProperties(
            PropertyFactory.lineColor(lineCol), PropertyFactory.lineOpacity(0.75f),
            PropertyFactory.lineDasharray(arrayOf(3f, 4f)),
            PropertyFactory.lineWidth(Expression.interpolate(Expression.exponential(2), Expression.zoom(), Expression.stop(15, 0.15f), Expression.stop(20, 2f))),
        ).also { it.minZoom = 15.5f })
        for ((id, on) in listOf("dl-lanes-off" to 0, "dl-lanes-on" to 1)) {
            st.addLayer(
                SymbolLayer(id, "dl-lanes").withFilter(Expression.eq(Expression.get("on"), Expression.literal(on))).withProperties(
                    PropertyFactory.iconImage(Expression.get("img")),
                    PropertyFactory.iconRotate(Expression.get("rot")),
                    PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
                    PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP),
                    PropertyFactory.iconAllowOverlap(true),
                    PropertyFactory.iconIgnorePlacement(true),
                    PropertyFactory.iconSize(Expression.interpolate(Expression.exponential(2), Expression.zoom(), Expression.stop(15, 0.1f), Expression.stop(20, 2.6f))),
                )
            )
        }
        if (im) {
            st.addImage("dl-pin", pinBitmap())
            st.addLayer(
                SymbolLayer("dl-dest-dot", "dl-dest").withProperties(
                    PropertyFactory.iconImage("dl-pin"), PropertyFactory.iconAnchor(Property.ICON_ANCHOR_BOTTOM),
                    PropertyFactory.iconAllowOverlap(true), PropertyFactory.iconIgnorePlacement(true), PropertyFactory.iconSize(0.6f),
                )
            )
        } else st.addLayer(
            CircleLayer("dl-dest-dot", "dl-dest").withProperties(
                PropertyFactory.circleRadius(10f), PropertyFactory.circleColor("#ff3b30"),
                PropertyFactory.circleStrokeColor("#ffffff"), PropertyFactory.circleStrokeWidth(3f),
            )
        )
        if (!im) {
        st.addLayer(
            CircleLayer("dl-me-halo", "dl-me").withProperties(
                PropertyFactory.circleRadius(15f * 0.625f * arrowScale), PropertyFactory.circleColor(if (im) "#3C8BC9" else "#2e8bff"), PropertyFactory.circleOpacity(if (im) 0.36f else 0.25f),
                PropertyFactory.circleStrokeColor("#9ED0E2"), PropertyFactory.circleStrokeWidth(if (im) 2.5f else 0f), PropertyFactory.circleStrokeOpacity(if (im) 0.6f else 0f),
                PropertyFactory.circleBlur(if (im) 0.2f else 0f),
                PropertyFactory.circlePitchAlignment(Property.CIRCLE_PITCH_ALIGNMENT_MAP), PropertyFactory.circlePitchScale(Property.CIRCLE_PITCH_SCALE_MAP),
            )
        )
        // Immersive: a second, tighter translucent disc so the base reads as a soft glow that flattens as the view tilts
        if (im) st.addLayer(
            CircleLayer("dl-me-disc", "dl-me").withProperties(
                PropertyFactory.circleRadius(36f * arrowScale), PropertyFactory.circleColor("#2F78AE"), PropertyFactory.circleOpacity(0.66f),
                PropertyFactory.circlePitchAlignment(Property.CIRCLE_PITCH_ALIGNMENT_MAP), PropertyFactory.circlePitchScale(Property.CIRCLE_PITCH_SCALE_MAP),
            )
        )
        }
        // traffic lights
        st.addImage("dl-signal", signalBitmap())
        st.addSource(GeoJsonSource("dl-signals", signalFeatures()))
        st.addLayer(
            SymbolLayer("dl-signals", "dl-signals").withProperties(
                PropertyFactory.iconImage("dl-signal"),
                PropertyFactory.iconAllowOverlap(true), PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_VIEWPORT),
                // big enough to read at a glance (they were hard to make out before)
                PropertyFactory.iconSize(Expression.interpolate(Expression.linear(), Expression.zoom(), Expression.stop(15, 0.21f), Expression.stop(17, 0.34f), Expression.stop(19, 0.48f), Expression.stop(21, 0.58f))),
                PropertyFactory.iconAnchor(Property.ICON_ANCHOR_BOTTOM),
            ).also { it.minZoom = 15f }
        )
        // speed cameras, roadworks and closures on the route
        for ((kind, nm) in hazardNames.withIndex()) st.addImage(nm, hazardBitmap(kind))
        st.addLayer(
            SymbolLayer("dl-hazards", "dl-hazards").withProperties(
                PropertyFactory.iconImage(Expression.get("img")),
                PropertyFactory.iconAllowOverlap(true), PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconSize(Expression.interpolate(Expression.linear(), Expression.zoom(), Expression.stop(11, 0.3f), Expression.stop(15, 0.5f), Expression.stop(18, 0.7f))),
            )
        )
        // the "+4 min" / "−2 min" bubbles on the alternatives
        st.addLayer(
            SymbolLayer("dl-live-bub", "dl-live-bub").withProperties(
                PropertyFactory.iconImage(Expression.get("img")),
                PropertyFactory.iconAnchor(Property.ICON_ANCHOR_BOTTOM),
                PropertyFactory.iconAllowOverlap(true), PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_VIEWPORT),
                PropertyFactory.iconSize(0.5f),
            )
        )
        st.addImage("dl-arrow", if (im) arrowBitmapImmersive() else arrowBitmap())
        st.addLayer(
            SymbolLayer("dl-me-arrow", "dl-me").withProperties(
                PropertyFactory.iconImage("dl-arrow"),
                PropertyFactory.iconRotate(Expression.get("h")),
                PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
                PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP),
                PropertyFactory.iconAllowOverlap(true),
                PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconSize((if (im) 0.25f else 0.625f) * arrowScale),
            )
        )
        // the 3D locator: drawn as a picture of the 3D model seen from the current camera angle (re-drawn when the angle changes),
        // so it always looks solid from any view, and it is drawn on top of the map so it never sinks into buildings
        st.addLayer(
            SymbolLayer("dl-me-sprite", "dl-me").withProperties(
                PropertyFactory.iconImage(spriteName ?: "dl-arrow"),
                PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_VIEWPORT),
                PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_VIEWPORT),
                PropertyFactory.iconAllowOverlap(true), PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconSize(spriteSize()),
                PropertyFactory.visibility(if (locatorStyle == "flat") Property.NONE else Property.VISIBLE),
            )
        )
        spriteImgs.clear(); spriteName = null
        // road-name pill under the locator
        st.addImage("dl-road", roadBitmap(roadName))
        st.addLayer(
            SymbolLayer("dl-me-road", "dl-me").withProperties(
                PropertyFactory.iconImage("dl-road"),
                PropertyFactory.iconSize(0.5f),
                PropertyFactory.iconAnchor(Property.ICON_ANCHOR_TOP),
                PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_VIEWPORT),
                PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_VIEWPORT),
                PropertyFactory.iconAllowOverlap(true),
                PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconOffset(arrayOf(0f, roadOffset())),
                PropertyFactory.visibility(if (roadName.isBlank()) Property.NONE else Property.VISIBLE),
            )
        )
        try { streetLabels(st) } catch (e: Throwable) { }
        applyLocatorVisibility(st)
        if (!chevOn) setRouteArrows(false)
        // remember which style layers were visible originally, so toggles never reveal hidden ones
        origVisible.clear(); origMin.clear()
        roadLayerIds = null
        for (l in st.layers) origVisible[l.id] = l.visibility.value != Property.NONE
        applyView()
        pushAll()
    }

    /**
     * Street names along the roads and house numbers on the buildings, only when zoomed in close enough to need them.
     * If the map style already has road labels they are kept (and shown a little earlier); otherwise our own are drawn from the
     * style's road data. They sit under the route and the arrow, and labels never overlap each other or anything placed before them.
     */
    private fun streetLabels(st: Style) {
        val syms = st.layers.filterIsInstance<SymbolLayer>().filter { !it.id.startsWith("dl-") }
        val font = syms.firstNotNullOfOrNull { l -> try { l.textFont.value?.takeIf { it.isNotEmpty() } } catch (e: Throwable) { null } } ?: return
        fun key(l: Layer) = (l.id + " " + srcLayerOf(l)).lowercase()
        val roadLabel = syms.filter { l ->
            val k = key(l)
            val line = try { l.symbolPlacement.value == Property.SYMBOL_PLACEMENT_LINE } catch (e: Throwable) { false }
            line && (k.contains("road") || k.contains("street") || k.contains("transportation") || k.contains("highway") || k.contains("motorway") || k.contains("path"))
        }
        val houseNo = syms.filter { l -> val k = key(l); k.contains("housenum") || k.contains("house number") || k.contains("building number") || k.contains("address") }
        // the style's own: house numbers from zoom 17, road names from 14 for main roads and 15.5 for streets
        for (l in houseNo) try { if (l.minZoom > 17f) l.minZoom = 17f } catch (e: Throwable) { }
        for (l in roadLabel) try { if (l.minZoom > 15.5f) l.minZoom = 15.5f } catch (e: Throwable) { }
        val text = if ((wantedStyle ?: "").contains("dark", true) || nightStyle) "#D3D8F0" else "#3E4459"
        val halo = if ((wantedStyle ?: "").contains("dark", true) || nightStyle) "#252A48" else "#F4F6FB"
        val name = Expression.coalesce(Expression.get("name:en"), Expression.get("name_en"), Expression.get("name"), Expression.get("street_name"), Expression.get("road_name"), Expression.literal(""))
        if (roadLabel.isEmpty()) {
            // one label layer per road source-layer (casings left out), copying each road layer's filter so only real roads get names
            val roads = st.layers.filterIsInstance<LineLayer>().filter { l ->
                val id = l.id.lowercase()
                !l.id.startsWith("dl-") && roadLike(l.id) && !(id.contains("casing") || id.contains("outline") || id.contains("case")) && l.sourceLayer.isNotBlank()
            }.distinctBy { it.sourceId + "|" + it.sourceLayer + "|" + (try { it.filter?.toString() } catch (e: Throwable) { "" }) }.take(12)
            roads.forEachIndexed { i, rl ->
                val id = rl.id.lowercase()
                val major = id.contains("motorway") || id.contains("trunk") || id.contains("primary") || id.contains("major")
                val lab = SymbolLayer("dl-st-name-$i", rl.sourceId).withSourceLayer(rl.sourceLayer).withProperties(
                    PropertyFactory.symbolPlacement(Property.SYMBOL_PLACEMENT_LINE),
                    PropertyFactory.textField(name),
                    PropertyFactory.textFont(font),
                    PropertyFactory.textSize(Expression.interpolate(Expression.linear(), Expression.zoom(), Expression.stop(14, 11f), Expression.stop(17, 13.5f), Expression.stop(19, 16f))),
                    PropertyFactory.textColor(text), PropertyFactory.textHaloColor(halo), PropertyFactory.textHaloWidth(1.6f),
                    PropertyFactory.textMaxAngle(30f), PropertyFactory.textPadding(6f), PropertyFactory.symbolSpacing(320f),
                    PropertyFactory.textLetterSpacing(0.02f),
                    PropertyFactory.textPitchAlignment(Property.TEXT_PITCH_ALIGNMENT_VIEWPORT),
                    PropertyFactory.textRotationAlignment(Property.TEXT_ROTATION_ALIGNMENT_MAP),
                )
                try { rl.filter?.let { lab.setFilter(it) } } catch (e: Throwable) { }
                lab.minZoom = if (major) 14f else 15.5f
                if (st.getLayer("dl-alts-line") != null) st.addLayerBelow(lab, "dl-alts-line") else st.addLayer(lab)
            }
        }
    }

    fun setView(sat: Boolean, b3d: Boolean) {
        satellite = sat
        buildings3d = b3d
        applyView()
        treesEnabled(treesOn)
    }

    /** While a route is on the map, traffic colours on every other road can be hidden so the route line stands out (the route itself shows its own traffic). */
    fun setHideOtherTraffic(b: Boolean) {
        if (hideTraffic == b) return
        hideTraffic = b
        applyView()
    }

    /** Light map: no points of interest and no route glow, so there is less to draw and place every frame. 3D buildings have their own switch in the map layers. */
    private var poiMoving = false

    /** Set by the engine as you start and stop moving, so the full map can rest its shop labels while driving. */
    fun setMoving(m: Boolean) {
        if (m == poiMoving) return
        poiMoving = m
        if (!lite) applyView()
    }

    fun setLite(b: Boolean) {
        if (lite == b) return
        lite = b
        try { style?.getLayer("dl-route-glow")?.setProperties(PropertyFactory.visibility(if (lite) Property.NONE else Property.VISIBLE)) } catch (e: Exception) { }
        applyView()
    }

    private fun isPoiLayer(id: String): Boolean {
        val s = id.lowercase()
        // house numbers stay, even on the light map
        if (s.contains("number") || s.contains("housenum") || s.contains("address")) return false
        return s.contains("poi") || s.contains("landmark") || s.contains("transit") || s.contains("airport") || s.contains("building")
    }

    /** Satellite imagery under the labels, and 3D building on/off. Safe to call repeatedly. */
    private fun applyView() {
        val st = style ?: return
        val has = st.getLayer("dl-sat") != null
        if (satellite && !has) {
            val ts = TileSet("2.2.0", "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}")
            ts.maxZoom = 19f
            ts.attribution = "Imagery © Esri"
            st.addSource(RasterSource("dl-sat-src", ts, 256))
            st.addLayerAt(RasterLayer("dl-sat", "dl-sat-src"), 0)
        } else if (!satellite && has) {
            st.removeLayer("dl-sat")
            st.removeSource("dl-sat-src")
        }
        for (l in st.layers) {
            val id = l.id
            if (id.startsWith("dl-")) continue
            val orig = origVisible[id] ?: true
            val keep = l is SymbolLayer || id.contains("traffic", true) || id.contains("flow", true)
            val isTraffic = id.contains("traffic", true) || id.contains("flow", true)
            if (routing && hideTraffic && isTraffic) { l.setProperties(PropertyFactory.visibility(Property.NONE)); continue }
            val show = if (l is FillExtrusionLayer) orig && !satellite && buildings3d else if (lite && l is SymbolLayer && isPoiLayer(id)) false else orig && (!satellite || keep)
            l.setProperties(PropertyFactory.visibility(if (show) Property.VISIBLE else Property.NONE))
            // with the full map, shop and place labels only appear once you're zoomed in to street level:
            // placing hundreds of them across a tilted view is what made the full map stutter
            if (l is SymbolLayer && isPoiLayer(id)) try {
                val base = origMin.getOrPut(id) { l.minZoom }
                l.minZoom = if (lite) base else maxOf(base, 16.5f)
                // full map: shop and place labels rest while you're on the move (placing them every frame is the costly part) and come back when you stop
                if (!lite && poiMoving && show) l.setProperties(PropertyFactory.visibility(Property.NONE))
            } catch (e: Throwable) { }
        }
    }

    /** Line width that grows with zoom the way road widths do: clearly wider than the road under it, but always well under the locator arrow's width. */
    private fun routeW(scale: Float): Expression = Expression.interpolate(
        Expression.exponential(1.7f), Expression.zoom(),
        Expression.stop(10, 3f * scale), Expression.stop(13, 6.5f * scale), Expression.stop(15, 10f * scale), Expression.stop(17, 16f * scale), Expression.stop(19, 24f * scale),
    )

    private fun line(p: List<LL>): Feature =
        Feature.fromGeometry(LineString.fromLngLats(p.map { Point.fromLngLat(it.lon, it.lat) }))

    private fun lineSev(p: List<LL>, level: Int): Feature {
        val f = line(p)
        f.addNumberProperty("sev", level)
        return f
    }

    private var mainSev: IntArray? = null
    private var mainOff = 0

    /** Route colour: blue normally, amber where traffic is slow, red where it is heavy. */
    /** Route colour: blue (a deeper blue by day, like the progress bar), amber where traffic is slow, red where it's heavy. */
    private fun sevColor(im: Boolean = false, day: Boolean = false): Expression = Expression.switchCase(
        Expression.eq(Expression.get("sev"), Expression.literal(2)), Expression.color(android.graphics.Color.parseColor(if (im) "#D93025" else "#FF4D4D")),
        Expression.eq(Expression.get("sev"), Expression.literal(1)), Expression.color(android.graphics.Color.parseColor(if (im) "#F9AB00" else "#FFB020")),
        Expression.color(android.graphics.Color.parseColor(if (day) "#2A7BE4" else if (im) "#2FC4F5" else "#4CC9FF")),
    )

    private fun pushAll() {
        pushLive(); pushRadar(); pushTurn()
        pushRoute(); pushDest(); pushMe(); pushHazards()
    }

    private fun src(id: String): GeoJsonSource? = style?.getSourceAs<GeoJsonSource>(id)

    private fun setLine(pts: List<LL>) {
        val s = src("dl-route") ?: return
        try { src("dl-flow")?.setGeoJson(if (pts.size < 2) FeatureCollection.fromFeatures(ArrayList<Feature>()) else FeatureCollection.fromFeatures(arrayListOf(line(pts)))) } catch (e: Exception) { }
        if (pts.size < 2) { s.setGeoJson(empty()); return }
        val sev = mainSev
        fun level(j: Int) = if (sev != null && mainOff + j in sev.indices) sev[mainOff + j] else 0
        // where the turn arrow is drawn, the route line underneath is left out (cut at the exact points where the arrow starts and ends,
        // not at the nearest route point), so none of it shows round the arrow's edges
        val cut = turnCut
        val feats = ArrayList<Feature>()
        fun addRun(seg: List<LL>, firstIdx: Int) {
            if (seg.size < 2) return
            var start = 0; var cur = level(firstIdx)
            for (j in 1 until seg.size - 1) {
                val l = level(firstIdx + j)
                if (l != cur) { feats += lineSev(seg.subList(start, j + 1), cur); start = j; cur = l }
            }
            feats += lineSev(seg.subList(start, seg.size), cur)
        }
        val pa = cut?.firstOrNull()?.let { projectOn(pts, it) }
        val pb = cut?.lastOrNull()?.let { projectOn(pts, it) }
        if (pa != null && pb != null && pb.first > pa.first) {
            // before the arrow: up to the arrow's start point
            addRun(pts.subList(0, pa.first + 1) + pa.second, 0)
            // after the arrow: from its end point on
            addRun(listOf(pb.second) + pts.subList(pb.first + 1, pts.size), pb.first)
        } else addRun(pts, 0)
        s.setGeoJson(FeatureCollection.fromFeatures(feats))
    }

    /** The segment of [pts] nearest to [q] (index of its first point) and the exact nearest point on it; null if it's more than 40 m away. */
    private fun projectOn(pts: List<LL>, q: LL): Pair<Int, LL>? {
        val kx = Math.cos(Math.toRadians(q.lat)) * 111320.0; val ky = 110574.0
        var bd = 40.0; var bi = -1; var bp: LL? = null
        for (i in 0 until pts.size - 1) {
            val ax = (pts[i].lon - q.lon) * kx; val ay = (pts[i].lat - q.lat) * ky
            val bx = (pts[i + 1].lon - q.lon) * kx; val by = (pts[i + 1].lat - q.lat) * ky
            if ((ax > bd && bx > bd) || (ax < -bd && bx < -bd) || (ay > bd && by > bd) || (ay < -bd && by < -bd)) continue
            val dx = bx - ax; val dy = by - ay
            val l2 = dx * dx + dy * dy
            val t = if (l2 > 0) (-(ax * dx + ay * dy) / l2).coerceIn(0.0, 1.0) else 0.0
            val d = Math.hypot(ax + dx * t, ay + dy * t)
            if (d < bd) { bd = d; bi = i; bp = LL(pts[i].lat + (pts[i + 1].lat - pts[i].lat) * t, pts[i].lon + (pts[i + 1].lon - pts[i].lon) * t) }
        }
        return if (bi >= 0 && bp != null) bi to bp else null
    }

    private fun pushRoute() {
        setLine(main)
        src("dl-alts")?.setGeoJson(FeatureCollection.fromFeatures(ArrayList(alts.filter { it.size >= 2 }.map { line(it) })))
    }

    private var hazards: List<Pair<LL, Int>> = emptyList()
    /** Map icons by kind: camera, roadworks, closure, police, accident, hazard, breakdown, mobile camera. */
    private val hazardNames = arrayOf("dl-hz-cam", "dl-hz-work", "dl-hz-closed", "dl-hz-police", "dl-hz-accident", "dl-hz-hazard", "dl-hz-breakdown", "dl-hz-mobilecam")

    /** Icons for speed cameras (0), roadworks (1) and closures (2) along the route. */
    fun setHazards(list: List<Pair<LL, Int>>) { hazards = list; pushHazards() }

    private fun pushHazards() {
        val s = src("dl-hazards") ?: return
        val fs = hazards.map { (p, k) ->
            Feature.fromGeometry(Point.fromLngLat(p.lon, p.lat)).also { it.addStringProperty("img", hazardNames[k.coerceIn(0, hazardNames.size - 1)]) }
        }
        s.setGeoJson(FeatureCollection.fromFeatures(fs))
    }

    /** Round badge with a simple glyph: camera on white with a red ring, amber warning triangle, red no-entry. */
    private fun hazardBitmap(kind: Int): Bitmap {
        val n = 96
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val cx = n / 2f
        fun p(col: Int, st: Paint.Style = Paint.Style.FILL, w: Float = 0f) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col; style = st; strokeWidth = w }
        // a round badge with a bold mark in the middle, for reports
        fun badge(ring: Int, fill: Int, mark: String) {
            c.drawCircle(cx, cx + 2f, 38f, p(0x55000000))
            c.drawCircle(cx, cx, 38f, p(0xFFFFFFFF.toInt()))
            c.drawCircle(cx, cx, 31f, p(fill))
            c.drawCircle(cx, cx, 38f, p(ring, Paint.Style.STROKE, 6f))
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); textSize = 46f; isFakeBoldText = true; textAlign = Paint.Align.CENTER }
            c.drawText(mark, cx, cx + 16f, tp)
        }
        when (kind) {
            4 -> badge(0xFFB71C1C.toInt(), 0xFFE53935.toInt(), "!")
            5 -> badge(0xFFE65100.toInt(), 0xFFF9A825.toInt(), "!")
            6 -> {
                badge(0xFFE65100.toInt(), 0xFFFB8C00.toInt(), "")
                // a small car
                c.drawRoundRect(android.graphics.RectF(cx - 18f, cx - 4f, cx + 18f, cx + 9f), 5f, 5f, p(0xFFFFFFFF.toInt()))
                c.drawRoundRect(android.graphics.RectF(cx - 11f, cx - 13f, cx + 11f, cx - 2f), 5f, 5f, p(0xFFFFFFFF.toInt()))
                c.drawCircle(cx - 10f, cx + 11f, 4.5f, p(0xFF37474F.toInt()))
                c.drawCircle(cx + 10f, cx + 11f, 4.5f, p(0xFF37474F.toInt()))
            }
            7 -> {
                c.drawCircle(cx, cx + 2f, 38f, p(0x55000000))
                c.drawCircle(cx, cx, 38f, p(0xFFFFFFFF.toInt()))
                c.drawCircle(cx, cx, 38f, p(0xFF1E66F5.toInt(), Paint.Style.STROKE, 7f))
                c.drawRoundRect(android.graphics.RectF(cx - 19f, cx - 9f, cx + 19f, cx + 15f), 5f, 5f, p(0xFF37474F.toInt()))
                c.drawRoundRect(android.graphics.RectF(cx - 8f, cx - 16f, cx + 8f, cx - 8f), 3f, 3f, p(0xFF37474F.toInt()))
                c.drawCircle(cx, cx + 3f, 8f, p(0xFFFFFFFF.toInt()))
                c.drawCircle(cx, cx + 3f, 4.5f, p(0xFF37474F.toInt()))
            }
            1 -> {
                val tri = Path().apply { moveTo(cx, 10f); lineTo(n - 8f, n - 14f); lineTo(8f, n - 14f); close() }
                val rounded = android.graphics.CornerPathEffect(10f)
                c.save(); c.translate(0f, 3f)
                c.drawPath(tri, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55000000; pathEffect = rounded })
                c.restore()
                c.drawPath(tri, p(0xFFFFFFFF.toInt()).apply { pathEffect = rounded })
                val inner = Path().apply { moveTo(cx, 22f); lineTo(n - 22f, n - 23f); lineTo(22f, n - 23f); close() }
                c.drawPath(inner, p(0xFFF9A825.toInt()).apply { pathEffect = android.graphics.CornerPathEffect(6f) })
                c.drawRoundRect(android.graphics.RectF(cx - 3.5f, 42f, cx + 3.5f, 62f), 3f, 3f, p(0xFF2B2B2B.toInt()))
                c.drawCircle(cx, 70f, 4.2f, p(0xFF2B2B2B.toInt()))
            }
            2 -> {
                c.drawCircle(cx, cx + 2f, 38f, p(0x55000000))
                c.drawCircle(cx, cx, 38f, p(0xFFFFFFFF.toInt()))
                c.drawCircle(cx, cx, 30f, p(0xFFE53935.toInt()))
                c.drawRoundRect(android.graphics.RectF(cx - 18f, cx - 5f, cx + 18f, cx + 5f), 4f, 4f, p(0xFFFFFFFF.toInt()))
            }
            3 -> {
                c.drawCircle(cx, cx + 2f, 38f, p(0x55000000))
                c.drawCircle(cx, cx, 38f, p(0xFFFFFFFF.toInt()))
                c.drawCircle(cx, cx, 38f, p(0xFF1E66F5.toInt(), Paint.Style.STROKE, 7f))
                // shield
                val sh = Path().apply {
                    moveTo(cx - 14f, cx - 15f); lineTo(cx + 14f, cx - 15f); lineTo(cx + 14f, cx + 2f)
                    quadTo(cx + 14f, cx + 14f, cx, cx + 20f); quadTo(cx - 14f, cx + 14f, cx - 14f, cx + 2f); close()
                }
                c.drawPath(sh, p(0xFF1E66F5.toInt()))
                c.drawCircle(cx, cx - 1f, 5f, p(0xFFFFFFFF.toInt()))
            }
            else -> {
                c.drawCircle(cx, cx + 2f, 38f, p(0x55000000))
                c.drawCircle(cx, cx, 38f, p(0xFFFFFFFF.toInt()))
                c.drawCircle(cx, cx, 38f, p(0xFFE53935.toInt(), Paint.Style.STROKE, 7f))
                // camera glyph: body, viewfinder bump and lens
                c.drawRoundRect(android.graphics.RectF(cx - 19f, cx - 9f, cx + 19f, cx + 15f), 5f, 5f, p(0xFF37474F.toInt()))
                c.drawRoundRect(android.graphics.RectF(cx - 8f, cx - 16f, cx + 8f, cx - 8f), 3f, 3f, p(0xFF37474F.toInt()))
                c.drawCircle(cx, cx + 3f, 8f, p(0xFFFFFFFF.toInt()))
                c.drawCircle(cx, cx + 3f, 4.5f, p(0xFF37474F.toInt()))
            }
        }
        return bmp
    }

    private fun pushDest() {
        val s = src("dl-dest") ?: return
        val d = dest
        if (d != null) s.setGeoJson(Feature.fromGeometry(Point.fromLngLat(d.lon, d.lat))) else s.setGeoJson(empty())
    }

    private fun pushMe() {
        pushModel(false)
        val s = src("dl-me") ?: return
        val p = me
        if (p != null) {
            val f = Feature.fromGeometry(Point.fromLngLat(p.lon, p.lat))
            f.addNumberProperty("h", meHeading)
            s.setGeoJson(f)
        } else s.setGeoJson(empty())
    }

    // ---- lane arrows painted on the road ----
    class LaneMark(val pt: LL, val bearing: Double, val dir: String, val on: Boolean)
    private val laneImgs = HashSet<String>()
    private var lanePulse: android.animation.ValueAnimator? = null

    private fun laneBitmap(dir: String, on: Boolean): Bitmap {
        val bmp = Bitmap.createBitmap(64, 80, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val ang = when (dir) {
            "SLIGHT_LEFT" -> -45f; "LEFT" -> -90f; "SHARP_LEFT" -> -135f; "LEFT_U_TURN" -> -180f
            "SLIGHT_RIGHT" -> 45f; "RIGHT" -> 90f; "SHARP_RIGHT" -> 135f; "RIGHT_U_TURN" -> 180f
            else -> 0f
        }
        fun draw(p: Paint) {
            c.drawLine(32f, 74f, 32f, 44f, p)
            c.save(); c.rotate(ang, 32f, 44f)
            c.drawLine(32f, 44f, 32f, 18f, p)
            c.drawLine(32f, 18f, 22f, 28f, p)
            c.drawLine(32f, 18f, 42f, 28f, p)
            c.restore()
        }
        val out = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = 12f; color = 0x66000000.toInt() }
        draw(out)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = 8f
            color = if (on) 0xFFFFFFFF.toInt() else 0x99FFFFFF.toInt()
        }
        draw(fill)
        return bmp
    }

    class LaneBand(val ring: List<LL>, val on: Boolean, val a: Double = 1.0)
    class LaneEdge(val pts: List<LL>, val solid: Boolean)

    /** Draws the lane strips and dividers (empty lists clear them). */
    fun setLaneBands(bands: List<LaneBand>, divs: List<LaneEdge>) {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            val st = style ?: return@post
            try {
                val bf = ArrayList<Feature>()
                for (b in bands) {
                    if (b.ring.size < 4) continue
                    val pts = (b.ring + b.ring[0]).map { Point.fromLngLat(it.lon, it.lat) }
                    val f = Feature.fromGeometry(org.maplibre.geojson.Polygon.fromLngLats(listOf(pts)))
                    f.addNumberProperty("on", if (b.on) 1 else 0)
                    f.addNumberProperty("a", b.a)
                    bf.add(f)
                }
                st.getSourceAs<GeoJsonSource>("dl-lane-bands")?.setGeoJson(FeatureCollection.fromFeatures(bf))
                val df = ArrayList<Feature>()
                for (d in divs) if (d.pts.size >= 2) df.add(Feature.fromGeometry(LineString.fromLngLats(d.pts.map { Point.fromLngLat(it.lon, it.lat) })).also { it.addNumberProperty("s", if (d.solid) 1 else 0) })
                st.getSourceAs<GeoJsonSource>("dl-lane-divs")?.setGeoJson(FeatureCollection.fromFeatures(df))
            } catch (e: Throwable) { }
        }
    }

    fun setLanes(marks: List<LaneMark>) {
        if (marks.isEmpty()) setLaneBands(emptyList(), emptyList())
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            val st = style ?: return@post
            val feats = ArrayList<Feature>()
            for (m in marks) {
                val name = "ln-${m.dir}-${if (m.on) 1 else 0}"
                if (laneImgs.add(name)) st.addImage(name, laneBitmap(m.dir, m.on))
                val f = Feature.fromGeometry(Point.fromLngLat(m.pt.lon, m.pt.lat))
                f.addStringProperty("img", name)
                f.addNumberProperty("rot", m.bearing)
                f.addNumberProperty("on", if (m.on) 1 else 0)
                feats.add(f)
            }
            st.getSourceAs<GeoJsonSource>("dl-lanes")?.setGeoJson(FeatureCollection.fromFeatures(feats))
            val layer = st.getLayerAs<SymbolLayer>("dl-lanes-on")
            lanePulse?.cancel(); lanePulse = null
            if (feats.isEmpty()) { layer?.setProperties(PropertyFactory.iconOpacity(1f)); return@post }
            lanePulse = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 600; repeatMode = android.animation.ValueAnimator.REVERSE; repeatCount = android.animation.ValueAnimator.INFINITE
                // only four brightness steps, so the map is not asked to redraw on every screen refresh just for a blink
                var lastStep = -1
                addUpdateListener {
                    val step = Math.round((it.animatedValue as Float) * 3f)
                    if (step != lastStep) { lastStep = step; layer?.setProperties(PropertyFactory.iconOpacity(0.7f + 0.3f * step / 3f)) }
                }
                start()
            }
        }
    }

    // ---- data from the engine ----
    fun setRoute(mainPts: List<LL>, altPts: List<List<LL>>, sev: IntArray? = null) {
        main = mainPts; alts = altPts; mainSev = sev; mainOff = 0; pushRoute(); pushSignals(); android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ refreshSignals() }, 1500L)
        val on = mainPts.isNotEmpty()
        if (on != routing) { routing = on; applyView() }
        syncFlow()
    }

    // ---- live alternatives while driving ----
    private var liveLines: List<List<LL>> = emptyList()
    private var liveBubs: List<LL> = emptyList()
    private var liveDiffs: List<Int> = emptyList()
    private val bubImgs = HashSet<String>()

    /** A rounded time bubble with a little tail: green when it is quicker, dark when it is slower. Drawn at 2x and shown at half size. */
    private fun bubbleBitmap(diff: Int): Bitmap {
        val d = mapView.resources.displayMetrics.density * 2f
        val text = if (diff < 0) "\u2212${-diff} min" else if (diff > 0) "+$diff min" else "Same"
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; textSize = 17f * d; typeface = android.graphics.Typeface.DEFAULT_BOLD }
        val tw = tp.measureText(text)
        val w = (tw + 28f * d).toInt(); val bh = 36f * d; val tail = 9f * d
        val b = Bitmap.createBitmap(w + (6 * d).toInt(), (bh + tail + 6 * d).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val ox = 3f * d; val oy = 3f * d
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (diff < 0) 0xFF1E9E5A.toInt() else 0xFF2B3142.toInt() }
        val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6FFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 2.2f * d }
        val path = Path().apply {
            addRoundRect(RectF(ox, oy, ox + w, oy + bh), bh / 2, bh / 2, Path.Direction.CW)
            moveTo(ox + w / 2f - tail, oy + bh - 1); lineTo(ox + w / 2f, oy + bh + tail); lineTo(ox + w / 2f + tail, oy + bh - 1); close()
        }
        c.drawPath(path, fill); c.drawPath(path, edge)
        c.drawText(text, ox + (w - tw) / 2f, oy + bh / 2f - (tp.descent() + tp.ascent()) / 2f, tp)
        return b
    }

    /** The other ways to go, in grey, with a bubble on each saying how it compares. Empty lists clear them. */
    fun setLiveAlts(lines: List<List<LL>>, bubbles: List<LL>, diffs: List<Int>) {
        liveLines = lines; liveBubs = bubbles; liveDiffs = diffs
        android.os.Handler(android.os.Looper.getMainLooper()).post { pushLive() }
    }

    private fun pushLive() {
        val st = style ?: return
        try {
            val fl = ArrayList<Feature>()
            liveLines.forEachIndexed { i, l -> if (l.size >= 2) fl += line(l).also { it.addNumberProperty("i", i) } }
            src("dl-live-alts")?.setGeoJson(FeatureCollection.fromFeatures(fl))
            val fb = ArrayList<Feature>()
            liveBubs.forEachIndexed { i, p ->
                val diff = liveDiffs.getOrElse(i) { 0 }
                val nm = "dl-bub-$diff"
                if (bubImgs.add(nm)) st.addImage(nm, bubbleBitmap(diff))
                fb += Feature.fromGeometry(Point.fromLngLat(p.lon, p.lat)).also { it.addNumberProperty("i", i); it.addStringProperty("img", nm) }
            }
            src("dl-live-bub")?.setGeoJson(FeatureCollection.fromFeatures(fb))
        } catch (e: Exception) { }
    }

    // ---- rain radar ----
    private var radarUrl: String? = null

    /** Shows the live rain radar tiles under the route ([url] with {z}/{x}/{y}), or hides it with null. */
    fun setRadar(url: String?) {
        radarUrl = url
        android.os.Handler(android.os.Looper.getMainLooper()).post { pushRadar() }
    }

    private fun pushRadar() {
        val st = style ?: return
        try {
            st.getLayer("dl-radar")?.let { st.removeLayer(it) }
            st.getSource("dl-radar")?.let { st.removeSource(it) }
            val u = radarUrl ?: return
            val ts = TileSet("2.2.0", u).apply { minZoom = 0f; maxZoom = 7f }
            st.addSource(RasterSource("dl-radar", ts, 256))
            val layer = RasterLayer("dl-radar", "dl-radar").withProperties(PropertyFactory.rasterOpacity(0.55f), PropertyFactory.rasterFadeDuration(0f))
            if (st.getLayer("dl-live-alts-line") != null) st.addLayerBelow(layer, "dl-live-alts-line") else st.addLayer(layer)
        } catch (e: Exception) { }
    }

    // ---- cinematic route preview ----
    private var flyToken = 0
    private var flyDone: (() -> Unit)? = null

    /**
     * A short fly-through of a new route: the camera swoops low along it in 3D (about 3 s), then [done] runs (the overview).
     * Touching the map stops it straight away and goes to the overview.
     */
    fun flyRoute(pts: List<LL>, cum: DoubleArray, len: Double, tilt: Double = 60.0, done: () -> Unit) {
        val m = map ?: run { done(); return }
        if (pts.size < 2) { done(); return }
        val token = ++flyToken
        flyDone = done
        val zoom = when { len < 5_000 -> 15.0; len < 30_000 -> 13.0; len < 120_000 -> 11.2; len < 300_000 -> 10.0; else -> 9.0 }
        fun at(f: Double): Pair<LL, Double> {
            val d = len * f
            var i = cum.indexOfFirst { it >= d }; if (i < 1) i = 1
            val a = pts[i - 1]; val b = pts[min(pts.size - 1, i + 3)]
            return pts[i] to Geo.bearing(a, b)
        }
        val frames = listOf(0.04 to 900, 0.45 to 1100, 0.9 to 1000)
        fun step(n: Int) {
            if (token != flyToken) return
            if (n >= frames.size) { flyDone = null; done(); return }
            val (f, ms) = frames[n]
            val (c, br) = at(f)
            tiltNow = tilt
            val cp = CameraPosition.Builder().target(LatLng(c.lat, c.lon)).zoom(zoom).tilt(tilt).bearing(br).padding(0.0, 0.0, 0.0, 0.0).build()
            m.easeCamera(CameraUpdateFactory.newCameraPosition(cp), ms, n != 0, object : MapLibreMap.CancelableCallback {
                override fun onFinish() { step(n + 1) }
                override fun onCancel() { if (token == flyToken) { flyToken++; flyDone = null; done() } }
            })
        }
        step(0)
    }

    /** Stops a fly-through without running its ending. */
    fun stopFly() { flyToken++; flyDone = null }

    // ---- flowing light along the route ----
    private var flowOn = false
    private var flowWanted = true
    private var flowAnim: android.animation.ValueAnimator? = null
    private var flowLastPush = 0L

    /** A soft band of white light that brightens towards the middle; [p] is where it is along the line (0..1). */
    private fun flowGradient(p: Float): Expression {
        val c = p.coerceIn(0.07f, 0.93f)
        return Expression.interpolate(
            Expression.linear(), Expression.lineProgress(),
            Expression.stop(0f, Expression.rgba(255, 255, 255, 0f)),
            Expression.stop(c - 0.06f, Expression.rgba(255, 255, 255, 0f)),
            Expression.stop(c, Expression.rgba(255, 255, 255, 0.7f)),
            Expression.stop(c + 0.06f, Expression.rgba(255, 255, 255, 0f)),
            Expression.stop(1f, Expression.rgba(255, 255, 255, 0f)),
        )
    }

    /** Switches the flowing light on or off (it only runs while there is a route). */
    fun setFlow(on: Boolean) { flowWanted = on; syncFlow() }

    private fun syncFlow() {
        val want = flowWanted && routing
        if (want == flowOn) return
        flowOn = want
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            flowAnim?.cancel(); flowAnim = null
            val st = style ?: return@post
            try { st.getLayer("dl-flow-line")?.setProperties(PropertyFactory.visibility(if (flowOn) Property.VISIBLE else Property.NONE)) } catch (e: Exception) { }
            if (!flowOn) return@post
            flowAnim = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 3200; repeatCount = android.animation.ValueAnimator.INFINITE
                interpolator = android.view.animation.LinearInterpolator()
                addUpdateListener { a ->
                    // about 15 updates a second is plenty for a soft moving glow, and keeps the head unit cool
                    val now = android.os.SystemClock.uptimeMillis()
                    if (now - flowLastPush < 66) return@addUpdateListener
                    flowLastPush = now
                    try { style?.getLayer("dl-flow-line")?.setProperties(PropertyFactory.lineGradient(flowGradient(a.animatedValue as Float))) } catch (e: Exception) { }
                }
                start()
            }
        }
    }

    /** Roads drawn on the map within [radiusM] of [p] (only what is on screen), for the junction overview. */
    fun roadsNear(p: LL, radiusM: Double): List<List<LL>> {
        val m = map ?: return emptyList()
        val st = style ?: return emptyList()
        return try {
            val ids = roadLayerIds ?: st.layers.filter { it is LineLayer && !it.id.startsWith("dl-") && roadLike(it.id) }.map { it.id }.toTypedArray().also { roadLayerIds = it }
            if (ids.isEmpty()) return emptyList()
            val a = m.projection.toScreenLocation(LatLng(p.lat, p.lon))
            val b = m.projection.toScreenLocation(LatLng(p.lat + radiusM / 111320.0, p.lon))
            val r = Math.hypot((a.x - b.x).toDouble(), (a.y - b.y).toDouble()).toFloat().coerceIn(30f, 600f)
            val feats = m.queryRenderedFeatures(android.graphics.RectF(a.x - r, a.y - r, a.x + r, a.y + r), *ids)
            val out = ArrayList<List<LL>>()
            for (f in feats) {
                when (val g = f.geometry()) {
                    is LineString -> out += g.coordinates().map { LL(it.latitude(), it.longitude()) }
                    is MultiLineString -> for (part in g.coordinates()) out += part.map { LL(it.latitude(), it.longitude()) }
                    else -> { }
                }
                if (out.size > 220) break
            }
            out
        } catch (e: Exception) { emptyList() }
    }
    private var pulseAnim: android.animation.ValueAnimator? = null

    /** Pulses the glow under the route line (used when a turn is close). */
    fun setTurnPulse(on: Boolean) {
        if (theme == "immersive") return      // the route glow stays steady for the whole route
        if (on == (pulseAnim != null)) return
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            pulseAnim?.cancel(); pulseAnim = null
            val layer = style?.getLayerAs<LineLayer>("dl-route-glow")
            if (!on) {
                layer?.setProperties(PropertyFactory.lineOpacity(0.4f), PropertyFactory.lineWidth(routeW(1.7f)))
            } else {
                pulseAnim = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 650; repeatMode = android.animation.ValueAnimator.REVERSE; repeatCount = android.animation.ValueAnimator.INFINITE
                    addUpdateListener {
                        val v = it.animatedValue as Float
                        layer?.setProperties(PropertyFactory.lineOpacity(0.35f + 0.55f * v), PropertyFactory.lineWidth(18f + 16f * v))
                    }
                    start()
                }
            }
        }
    }

    /** Size of the locator arrow (and its glow) relative to normal: 1.0 is the base size. */
    var arrowScale = 2.4f
        private set

    // ---- 3D locator ----
    /** "arrow" (3D arrow), "car" (3D car) or "flat" (the flat picture). */
    var locatorStyle = "arrow"
        private set
    private var locatorColor = "#F2F2F6"
    private var modelZoom = -1.0
    private var spriteName: String? = null
    private val spriteImgs = LinkedHashMap<String, Boolean>()

    fun setLocator(styleName: String, color: String) {
        locatorStyle = styleName; locatorColor = color
        val st = style ?: return
        applyLocatorVisibility(st)
        spriteName = null
        pushModel(true)
    }

    private fun applyLocatorVisibility(st: Style) {
        val flat = locatorStyle == "flat"
        try {
            st.getLayer("dl-me-arrow")?.setProperties(PropertyFactory.visibility(if (flat) Property.VISIBLE else Property.NONE))
            st.getLayer("dl-me-sprite")?.setProperties(PropertyFactory.visibility(if (flat) Property.NONE else Property.VISIBLE), PropertyFactory.iconSize(spriteSize()))
        } catch (e: Exception) { }
    }

    /** Sprites are drawn at 2.4x; this brings them to the same on-screen size the flat arrow had (the car a little longer). */
    private fun spriteSize(): Float = arrowScale * (if (locatorStyle == "car") 0.28f else 0.31f)

    private fun shade(hex: String, f: Float): Int {
        val c = try { android.graphics.Color.parseColor(hex) } catch (e: Exception) { -1 }
        fun ch(v: Int) = (v * f).toInt().coerceIn(0, 255)
        return android.graphics.Color.rgb(ch(android.graphics.Color.red(c)), ch(android.graphics.Color.green(c)), ch(android.graphics.Color.blue(c)))
    }

    /** A shape with soft corners: every corner of [pts] is replaced by a small curve of radius about [r] (in the same units). */
    private fun soften(pts: List<Pair<Double, Double>>, r: Double, steps: Int = 5): List<Pair<Double, Double>> {
        val n = pts.size
        val out = ArrayList<Pair<Double, Double>>()
        for (i in 0 until n) {
            val p0 = pts[(i - 1 + n) % n]; val p1 = pts[i]; val p2 = pts[(i + 1) % n]
            val d1 = Math.hypot(p1.first - p0.first, p1.second - p0.second); val d2 = Math.hypot(p2.first - p1.first, p2.second - p1.second)
            val rr = minOf(r, d1 * 0.45, d2 * 0.45)
            val a = (p1.first + (p0.first - p1.first) * rr / d1) to (p1.second + (p0.second - p1.second) * rr / d1)
            val b = (p1.first + (p2.first - p1.first) * rr / d2) to (p1.second + (p2.second - p1.second) * rr / d2)
            for (k in 0..steps) {
                val t = k / steps.toDouble(); val u = 1 - t
                out += (u * u * a.first + 2 * u * t * p1.first + t * t * b.first) to (u * u * a.second + 2 * u * t * p1.second + t * t * b.second)
            }
        }
        return out
    }

    private fun rrect(x0: Double, x1: Double, y0: Double, y1: Double, r: Double) = soften(listOf(x1 to y1, x0 to y1, x0 to y0, x1 to y0), r, 4)

    /** One solid piece of the model: a footprint pushed up from [z0] to [z1], in one colour. */
    private class Prism(val pts: List<Pair<Double, Double>>, val z0: Double, val z1: Double, val col: Int)

    private fun arrowParts(col: String): List<Prism> {
        // the same soft chevron as the flat arrow, now solid: a dark edge underneath and the arrow on top
        // (listed anticlockwise, so the walls face outwards)
        // very soft corners, like the flat arrow: a round nose, rounded wing tips and a smooth curve at the back
        // sized and shaped to match the flat arrow: it fills a little over half the ring's width, with a deep, smooth curve at the back
        val raw = listOf(0.0 to 0.58, -0.64 to -0.53, 0.0 to -0.28, 0.64 to -0.53)
        val soft = soften(soften(raw, 0.3, 8), 0.06, 2)
        // centre the arrow exactly on the ring: move it so the middle of its area sits on the centre point,
        // and mirror the right half onto the left so it is perfectly symmetrical from every angle
        var a2 = 0.0; var cyA = 0.0
        for (i in soft.indices) {
            val p0 = soft[i]; val p1 = soft[(i + 1) % soft.size]
            val cr = p0.first * p1.second - p1.first * p0.second
            a2 += cr; cyA += (p0.second + p1.second) * cr
        }
        val cy = if (Math.abs(a2) > 1e-9) cyA / (3.0 * a2) else 0.0
        val half = soft.filter { it.first <= 1e-9 }.map { 0.0.coerceAtMost(it.first) to it.second - cy }
        val right = half.reversed().map { -it.first to it.second }.filter { it.first > 1e-9 }
        val shape = if (half.size >= 3) half + right else soft.map { it.first to it.second - cy }
        return listOf(Prism(shape, 0.0, 0.19, shade(col, 1f)))
    }

    private fun carParts(col: String): List<Prism> {
        // a chunky, friendly, cartoon car in the style of the Google Maps one: short and wide, very rounded, a big domed glasshouse,
        // a fat white roof, tall red tail lights in the rear corners, a dark under-bumper and black mirrors. Length 4.4.
        val body = shade(col, 1f); val lower = shade(col, 0.9f); val roof = shade(col, 1.05f)
        val glass = 0xFF2C4F8C.toInt(); val dark = 0xFF1B1E26.toInt(); val red = 0xFFE3262F.toInt()
        val l = ArrayList<Prism>()
        for (sx in listOf(-1.0, 1.0)) for (sy in listOf(-1.38, 1.42)) l += Prism(rrect(sx * 0.98 - 0.13, sx * 0.98 + 0.13, sy - 0.36, sy + 0.36, 0.12), 0.0, 0.52, 0xFF101114.toInt())
        l += Prism(rrect(-0.92, 0.92, -2.24, -1.9, 0.3), 0.1, 0.36, dark)                // under-bumper
        l += Prism(rrect(-1.02, 1.02, -2.16, 2.2, 0.85), 0.24, 0.6, lower)             // lower body
        l += Prism(rrect(-1.08, 1.08, -2.12, 2.14, 0.95), 0.6, 0.98, body)             // big rounded shoulders
        l += Prism(rrect(-0.98, -0.66, -2.17, -1.92, 0.12), 0.46, 0.95, red)           // tall tail lights in the corners
        l += Prism(rrect(0.66, 0.98, -2.17, -1.92, 0.12), 0.46, 0.95, red)
        l += Prism(rrect(-1.22, -1.04, 0.42, 0.68, 0.08), 0.96, 1.1, dark)              // mirrors
        l += Prism(rrect(1.04, 1.22, 0.42, 0.68, 0.08), 0.96, 1.1, dark)
        l += Prism(rrect(-0.9, 0.9, -1.35, 0.95, 0.7), 0.98, 1.42, glass)             // domed glasshouse
        l += Prism(rrect(-0.8, 0.8, -1.05, 0.66, 0.62), 1.42, 1.58, roof)              // fat roof
        return l
    }

    /**
     * Draws the 3D model as seen from the camera: [yaw] is the model's heading relative to the top of the screen, [pitch] the map tilt.
     * Faces are flat-shaded (lit from the top left of the screen) and painted back to front.
     */
    private fun renderSprite(parts: List<Prism>, unitPx: Double, yaw: Double, pitch: Double, car: Boolean): Bitmap {
        val w = 300; val h = 300
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val ox = w / 2.0; val oy = h / 2.0
        val cy = Math.cos(Math.toRadians(yaw)); val sy = Math.sin(Math.toRadians(yaw))
        val cp = Math.cos(Math.toRadians(pitch)); val sp = Math.sin(Math.toRadians(pitch))
        fun rot(x: Double, y: Double) = (x * cy + y * sy) to (-x * sy + y * cy)
        fun proj(x: Double, y: Double, z: Double): Pair<Float, Float> {
            val (X, Y) = rot(x, y)
            return (ox + X * unitPx).toFloat() to (oy - (Y * cp + z * sp) * unitPx).toFloat()
        }
        fun depth(x: Double, y: Double, z: Double): Double { val (_, Y) = rot(x, y); return -Y * sp + z * cp }
        // soft glow / shadow on the road
        val glowR = if (car) 1.45 else 0.95
        val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (car) 0x667FC8FF else 0x9E2F78AE.toInt()
            if (car) maskFilter = android.graphics.BlurMaskFilter((unitPx * 0.45).toFloat(), android.graphics.BlurMaskFilter.Blur.NORMAL)
        }
        val ring = Path()
        for (k in 0..40) { val a = 2 * Math.PI * k / 40; val (px, py) = proj(Math.cos(a) * glowR, Math.sin(a) * glowR * (if (car) 2.0 else 1.0), 0.0); if (k == 0) ring.moveTo(px, py) else ring.lineTo(px, py) }
        ring.close()
        c.drawPath(ring, glowPaint)
        if (!car) c.drawPath(ring, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; color = 0xB39ED0E2.toInt() })
        // light comes from the viewer's upper left
        val lx = -0.35; val ly = 0.45
        // each face: its outline on screen, depth, base colour and how brightly it's lit; walls get a top-to-bottom shade, tops a soft sheen
        class Face(val path: Path, val d: Double, val col: Int, val top: Boolean, val y0: Float, val y1: Float)
        val faces = ArrayList<Face>()
        val silhouette = Path()
        for (pr in parts) {
            val n = pr.pts.size
            for (i in 0 until n) {
                val a = pr.pts[i]; val b = pr.pts[(i + 1) % n]
                // outward normal of this wall (footprints are anticlockwise), turned to the screen
                var nx = b.second - a.second; var ny = -(b.first - a.first)
                val nl = Math.hypot(nx, ny); if (nl < 1e-9) continue
                nx /= nl; ny /= nl
                val (NX, NY) = rot(nx, ny)
                // walls facing away from the camera can't be seen
                if (-NY * sp < -0.02 && pitch > 2) continue
                val bright = (0.62 + 0.38 * (NX * lx + NY * ly)).coerceIn(0.42, 1.04)
                val p1 = proj(a.first, a.second, pr.z0); val p2 = proj(b.first, b.second, pr.z0)
                val p3 = proj(b.first, b.second, pr.z1); val p4 = proj(a.first, a.second, pr.z1)
                val path = Path().apply { moveTo(p1.first, p1.second); lineTo(p2.first, p2.second); lineTo(p3.first, p3.second); lineTo(p4.first, p4.second); close() }
                val mx = (a.first + b.first) / 2; val my = (a.second + b.second) / 2
                faces += Face(path, depth(mx, my, (pr.z0 + pr.z1) / 2) - 0.001, scaleCol(pr.col, bright), false, minOf(p3.second, p4.second), maxOf(p1.second, p2.second))
            }
            val top = Path()
            var ty0 = Float.MAX_VALUE; var ty1 = -Float.MAX_VALUE
            pr.pts.forEachIndexed { i, q -> val (px, py) = proj(q.first, q.second, pr.z1); ty0 = minOf(ty0, py); ty1 = maxOf(ty1, py); if (i == 0) top.moveTo(px, py) else top.lineTo(px, py) }
            top.close()
            val cxm = pr.pts.sumOf { it.first } / n; val cym = pr.pts.sumOf { it.second } / n
            faces += Face(top, depth(cxm, cym, pr.z1) + 0.002, pr.col, true, ty0, ty1)
        }
        faces.sortBy { it.d }
        val fp = Paint(Paint.ANTI_ALIAS_FLAG)
        val seam = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.4f; strokeJoin = Paint.Join.ROUND }
        for (f in faces) {
            val lightC = if (f.top) scaleCol(f.col, 1.04) else scaleCol(f.col, 1.06)
            val darkC = if (f.top) scaleCol(f.col, 0.86) else scaleCol(f.col, 0.78)
            fp.shader = if (f.y1 - f.y0 > 1f) android.graphics.LinearGradient(0f, f.y0, 0f, f.y1, lightC, darkC, android.graphics.Shader.TileMode.CLAMP) else null
            fp.color = f.col
            c.drawPath(f.path, fp)
            // a hairline in the face colour hides tiny gaps between neighbouring faces
            seam.color = scaleCol(f.col, 0.95); c.drawPath(f.path, seam)
            try { silhouette.op(f.path, Path.Op.UNION) } catch (e: Throwable) { }
        }
        // a soft cartoon outline round the whole shape, and a gentle highlight along its top edge
        try {
            c.drawPath(silhouette, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = if (car) 3.2f else 3.6f; strokeJoin = Paint.Join.ROUND; color = 0x8A0E1A33.toInt() })
        } catch (e: Throwable) { }
        return bmp
    }

    private fun scaleCol(c: Int, f: Double): Int {
        fun ch(v: Int) = (v * f).toInt().coerceIn(0, 255)
        return android.graphics.Color.argb(android.graphics.Color.alpha(c), ch(android.graphics.Color.red(c)), ch(android.graphics.Color.green(c)), ch(android.graphics.Color.blue(c)))
    }

    /**
     * Picks (and if needed draws) the sprite for the current heading, map bearing and tilt. Angles are rounded to 4° of turn and 5° of
     * tilt, so a new picture is only drawn when the view really changes; recent ones are kept and reused.
     */
    private fun pushModel(force: Boolean) {
        if (locatorStyle == "flat") return
        val m = map ?: return
        val st = style ?: return
        val cam = m.cameraPosition
        modelZoom = cam.zoom
        val rel = ((meHeading - cam.bearing) % 360.0 + 360.0) % 360.0
        val yawB = (Math.round(rel / 4.0) * 4) % 360
        val pitB = Math.round(cam.tilt / 5.0) * 5
        val key = "dl-spr-$locatorStyle-${locatorColor.removePrefix("#")}-$yawB-$pitB"
        if (key == spriteName && !force) return
        try {
            if (!spriteImgs.containsKey(key)) {
                val car = locatorStyle == "car"
                val bmp = if (car) renderSprite(carParts(locatorColor), 300.0 / 4.4 * 0.6, yawB.toDouble(), pitB.toDouble(), true)
                          else renderSprite(arrowParts(locatorColor), 300.0 * 0.42, yawB.toDouble(), pitB.toDouble(), false)
                st.addImage(key, bmp)
                spriteImgs[key] = true
                // keep the last 90 pictures (about one full turn at one tilt)
                while (spriteImgs.size > 90) { val old = spriteImgs.keys.first(); spriteImgs.remove(old); if (old != key) try { st.removeImage(old) } catch (e: Exception) { } }
            } else { spriteImgs.remove(key); spriteImgs[key] = true }
            st.getLayer("dl-me-sprite")?.setProperties(PropertyFactory.iconImage(key))
            spriteName = key
        } catch (e: Exception) { }
    }

    /** A white chevron pointing along the line (to the right in the picture, which is "along the line" for line placement). */
    private fun chevronBitmap(): Bitmap {
        val b = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 10f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        c.drawPath(Path().apply { moveTo(20f, 12f); lineTo(42f, 32f); lineTo(20f, 52f) }, p)
        return b
    }

    /** Icon size for the arrow head at a zoom where the route line is [w] map pixels wide: about 2.4 times the shaft's width. */
    private fun headSize(w: Float): Float = 2.4f * 1.28f * w / 196f

    /**
     * The head of the turn arrow, pointing up, with its flat base along the bottom edge so it joins the shaft as one piece:
     * white with the same dark edge as the shaft, slightly rounded. Drawn at 1:1 map pixels (200 wide).
     */
    private fun turnHeadBitmap(day: Boolean): Bitmap {
        // the triangle is 196 wide inside a 220 wide picture, leaving room round it for the soft halo; its base is the bottom edge
        val b = Bitmap.createBitmap(220, 162, Bitmap.Config.ARGB_8888)
        b.density = android.util.DisplayMetrics.DENSITY_DEFAULT
        val c = Canvas(b)
        val ox = 12f; val top = 12f; val bot = 162f
        // the dark edge matches the shaft's: the shaft's edge is 0.1 of a route width each side, and the head is 3.07 route widths across
        val edgeW = 196f / 3.072f * 0.1f * 1.4f
        val outer = Path().apply { moveTo(ox + 98f, top); lineTo(ox + 196f, bot); lineTo(ox, bot); close() }
        if (day) c.drawPath(outer, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x5916467A; style = Paint.Style.STROKE; strokeWidth = 12f; strokeJoin = Paint.Join.ROUND
            pathEffect = android.graphics.CornerPathEffect(30f); maskFilter = android.graphics.BlurMaskFilter(6f, android.graphics.BlurMaskFilter.Blur.NORMAL)
        })
        c.drawPath(outer, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF16467A.toInt(); pathEffect = android.graphics.CornerPathEffect(30f) })
        val inset = edgeW
        val inner = Path().apply { moveTo(ox + 98f, top + inset * 1.8f); lineTo(ox + 196f - inset * 1.7f, bot); lineTo(ox + inset * 1.7f, bot); close() }
        c.drawPath(inner, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); pathEffect = android.graphics.CornerPathEffect(24f) })
        return b
    }

    private var chevOn = true
    /** Set by the engine: whether the turn arrow is switched on (so the route line is only cut when the arrow is really there). */
    var turnArrowsShown = true

    /** Chevrons along the route on or off (the turn arrow has its own setting, checked in the engine). */
    fun setRouteArrows(on: Boolean) {
        chevOn = on
        try { style?.getLayer("dl-route-chev")?.setProperties(PropertyFactory.visibility(if (on) Property.VISIBLE else Property.NONE)) } catch (e: Exception) { }
    }

    /** The arrow at the next turn, drawn along the route through the junction; an empty list clears it. */
    private var turnCut: List<LL>? = null

    private var turnPath: List<LL> = emptyList()

    /** Puts the remembered turn arrow back (after the map style reloads, e.g. day to night, its layers start empty). */
    private fun pushTurn() {
        val path = turnPath
        try {
            if (path.size < 2) { src("dl-turn")?.setGeoJson(empty()); src("dl-turn-head")?.setGeoJson(empty()); return }
            src("dl-turn")?.setGeoJson(line(path))
            val a = path[path.size - 2]; val b = path.last()
            src("dl-turn-head")?.setGeoJson(Feature.fromGeometry(Point.fromLngLat(b.lon, b.lat)).also { it.addNumberProperty("b", Geo.bearing(a, b)) })
        } catch (e: Exception) { }
    }

    fun setTurnArrow(path: List<LL>) {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            turnPath = path
            turnCut = if (path.size >= 2 && turnArrowsShown) path else null
            try { setLine(main) } catch (e: Exception) { }
            try {
                if (path.size < 2) { src("dl-turn")?.setGeoJson(empty()); src("dl-turn-head")?.setGeoJson(empty()); return@post }
                // the shaft runs right to the end, where the head's flat base sits on it
                src("dl-turn")?.setGeoJson(line(path))
                val a = path[path.size - 2]; val b = path.last()
                src("dl-turn-head")?.setGeoJson(Feature.fromGeometry(Point.fromLngLat(b.lon, b.lat)).also { it.addNumberProperty("b", Geo.bearing(a, b)) })
            } catch (e: Exception) { }
        }
    }

    fun setArrowScale(f: Float) {
        arrowScale = f
        val st = style ?: return
        val im = theme == "immersive"
        try {
            (st.getLayer("dl-me-arrow") as? SymbolLayer)?.setProperties(PropertyFactory.iconSize((if (im) 0.25f else 0.625f) * f))
            (st.getLayer("dl-me-halo") as? CircleLayer)?.setProperties(PropertyFactory.circleRadius(15f * 0.625f * f))
            (st.getLayer("dl-me-disc") as? CircleLayer)?.setProperties(PropertyFactory.circleRadius(36f * f))
            (st.getLayer("dl-me-road") as? SymbolLayer)?.setProperties(PropertyFactory.iconOffset(arrayOf(0f, roadOffset())))
        } catch (e: Exception) { }
        try { (st.getLayer("dl-me-sprite") as? SymbolLayer)?.setProperties(PropertyFactory.iconSize(spriteSize())) } catch (e: Exception) { }
    }

    private var roadName = ""
    private var roadOffTilt = -99.0

    /** How far below the locator the road pill sits: further down when the view is flat (ring is round), closer when tilted. */
    private fun roadOffset(): Float {
        val r = (if (theme == "immersive") 40f else 9.4f) * arrowScale
        val c = Math.cos(Math.toRadians(tiltNow))
        // (doubled: the offset is scaled by the pill's icon size of 0.5)
        return ((r * (0.2 + 0.22 * c) + 2f) * 2.0).toFloat()
    }

    /** The road you're on, in a Google-style pill: deep blue, fully rounded, bold white text, a soft shadow. Drawn at 2x (shown at half). */
    private fun roadBitmap(name: String): Bitmap {
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 40f; typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD); color = 0xFFFFFFFF.toInt(); letterSpacing = 0.02f }
        val txt = if (name.isBlank()) " " else name
        val maxText = 640f
        val shown = if (tp.measureText(txt) > maxText) android.text.TextUtils.ellipsize(txt, android.text.TextPaint(tp), maxText, android.text.TextUtils.TruncateAt.END).toString() else txt
        val w = tp.measureText(shown) + 64f
        val hgt = 80f
        val bmp = Bitmap.createBitmap((w + 16f).toInt(), (hgt + 18f).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rect = android.graphics.RectF(8f, 6f, 8f + w, 6f + hgt)
        c.drawRoundRect(android.graphics.RectF(rect).apply { offset(0f, 4f) }, hgt / 2, hgt / 2, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55000000; maskFilter = android.graphics.BlurMaskFilter(6f, android.graphics.BlurMaskFilter.Blur.NORMAL) })
        c.drawRoundRect(rect, hgt / 2, hgt / 2, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = android.graphics.LinearGradient(0f, rect.top, 0f, rect.bottom, 0xFF3B8BD0.toInt(), 0xFF2A72B5.toInt(), android.graphics.Shader.TileMode.CLAMP)
        })
        c.drawRoundRect(android.graphics.RectF(rect).apply { inset(1.5f, 1.5f) }, hgt / 2, hgt / 2, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f; color = 0x40FFFFFF })
        c.drawText(shown, rect.left + 32f, rect.centerY() - (tp.descent() + tp.ascent()) / 2, tp)
        return bmp
    }

    /** Shows the name of the road you are on in a small pill under the locator (empty hides it). */
    fun setRoadName(name: String) {
        if (name == roadName) return
        roadName = name
        val st = style ?: return
        try {
            if (name.isNotBlank()) st.addImage("dl-road", roadBitmap(name))
            (st.getLayer("dl-me-road") as? SymbolLayer)?.setProperties(PropertyFactory.visibility(if (name.isBlank()) Property.NONE else Property.VISIBLE))
        } catch (e: Exception) { }
    }

    /** The map itself is no longer capped separately: the glide already limits how often the camera moves, and a second cap on top of it makes frames arrive unevenly (judder). */
    fun setMaxFps(n: Int) { try { mapView.setMaximumFps(60) } catch (e: Exception) { } }

    private var doneEmpty = true

    /** The driven stretch of the route (a short trail behind the car), drawn in grey. */
    fun setDone(pts: List<LL>) {
        val s = src("dl-done") ?: return
        if (pts.size < 2) { if (!doneEmpty) { s.setGeoJson(empty()); doneEmpty = true }; return }
        doneEmpty = false
        s.setGeoJson(line(pts))
    }

    fun setMainOnly(mainPts: List<LL>, sev: IntArray? = null, firstSeg: Int = 0) { main = mainPts; mainSev = sev; mainOff = firstSeg; setLine(main) }
    fun setDest(p: LL?) { dest = p; pushDest() }
    private var meAnim: android.animation.ValueAnimator? = null
    private var lastMePush = 0L

    /** Moves the arrow smoothly from where it is now to [p] over [durationMs] (one GPS interval). */
    fun setMe(p: LL?, heading: Double = 0.0, durationMs: Long = 1000) {
        meAnim?.cancel()
        if (durationMs <= 0 && p != null) {
            val o = me
            if (o != null && Math.abs(o.lat - p.lat) < 1e-8 && Math.abs(o.lon - p.lon) < 1e-8 && Math.abs(meHeading - heading) < 0.2) return
        }
        val from = me
        if (p == null || from == null || durationMs <= 0 || Geo.dist(from, p) > 300) {
            me = p; meHeading = heading; pushMe(); return
        }
        val fromH = meHeading
        val dH = ((heading - fromH + 540.0) % 360.0) - 180.0
        meAnim = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { a ->
                val t = a.animatedFraction.toDouble()
                me = LL(from.lat + (p.lat - from.lat) * t, from.lon + (p.lon - from.lon) * t)
                meHeading = (fromH + dH * t + 360.0) % 360.0
                val now = android.os.SystemClock.uptimeMillis()
                if (now - lastMePush >= 66 || t >= 1.0) { lastMePush = now; pushMe() }
            }
            start()
        }
    }

    // ---- camera ----
    fun center(): LL? = map?.cameraPosition?.target?.let { LL(it.latitude, it.longitude) }

    fun cameraTo(c: LL, bearing: Double?, tilt: Double, zoom: Double, ms: Int, topPadFraction: Double, leftPadFraction: Double = 0.0) {
        val m = map ?: return
        val h = mapView.height
        val b = CameraPosition.Builder().target(LatLng(c.lat, c.lon)).tilt(tilt).zoom(zoom)
            .padding(mapView.width * leftPadFraction, h * topPadFraction, 0.0, 0.0)
        if (bearing != null) b.bearing(bearing)
        tiltNow = tilt
        m.easeCamera(CameraUpdateFactory.newCameraPosition(b.build()), ms, false)
    }

    /** Moves the camera instantly (no animation). Called every frame by the glide loop so motion never stalls between GPS fixes. */
    fun cameraSet(c: LL, bearing: Double, tilt: Double, zoom: Double, topPadFraction: Double, leftPadFraction: Double) {
        val m = map ?: return
        val b = CameraPosition.Builder().target(LatLng(c.lat, c.lon)).tilt(tilt).zoom(zoom).bearing(bearing)
            .padding(mapView.width * leftPadFraction, mapView.height * topPadFraction, 0.0, 0.0)
        tiltNow = tilt
        if (abs(tilt - roadOffTilt) > 3.0) {
            roadOffTilt = tilt
            try { (style?.getLayer("dl-me-road") as? SymbolLayer)?.setProperties(PropertyFactory.iconOffset(arrayOf(0f, roadOffset()))) } catch (e: Exception) { }
        }
        m.moveCamera(CameraUpdateFactory.newCameraPosition(b.build()))
    }

    private fun roadLike(id: String): Boolean {
        val s = id.lowercase()
        if (s.contains("traffic") || s.contains("flow") || s.contains("rail") || s.contains("path") || s.contains("foot") || s.contains("ferry") || s.contains("boundary") || s.contains("label")) return false
        return s.contains("road") || s.contains("street") || s.contains("motorway") || s.contains("highway") || s.contains("trunk") || s.contains("primary") ||
            s.contains("secondary") || s.contains("tertiary") || s.contains("residential") || s.contains("service") || s.contains("link") || s.contains("bridge") || s.contains("tunnel")
    }

    /** Moves a GPS position onto the nearest drawn road that runs the way you are heading, or returns null when none is close enough. */
    fun snapToRoad(p: LL, heading: Double): LL? {
        val m = map ?: return null
        val st = style ?: return null
        return try {
            val ids = roadLayerIds ?: st.layers.filter { it is LineLayer && !it.id.startsWith("dl-") && roadLike(it.id) }.map { it.id }.toTypedArray().also { roadLayerIds = it }
            if (ids.isEmpty()) return null
            val sp = m.projection.toScreenLocation(LatLng(p.lat, p.lon))
            val rr = 40f
            val feats = m.queryRenderedFeatures(android.graphics.RectF(sp.x - rr, sp.y - rr, sp.x + rr, sp.y + rr), *ids)
            val k = Math.cos(Math.toRadians(p.lat)) * 111320.0
            val k2 = 110574.0
            var best: LL? = null
            var bd = 24.0
            fun scan(pts: List<Point>) {
                for (i in 0 until pts.size - 1) {
                    val ax = (pts[i].longitude() - p.lon) * k; val ay = (pts[i].latitude() - p.lat) * k2
                    val bx = (pts[i + 1].longitude() - p.lon) * k; val by = (pts[i + 1].latitude() - p.lat) * k2
                    val dx = bx - ax; val dy = by - ay
                    val l2 = dx * dx + dy * dy
                    if (l2 < 0.01) continue
                    val t = (-(ax * dx + ay * dy) / l2).coerceIn(0.0, 1.0)
                    val d = Math.hypot(ax + dx * t, ay + dy * t)
                    if (d >= bd) continue
                    // only roads that run the way you are heading (either direction), so a parallel street or a crossing road is not chosen
                    val segB = (Math.toDegrees(Math.atan2(dx, dy)) + 360.0) % 360.0
                    var diff = Math.abs(segB - heading) % 360.0
                    if (diff > 180.0) diff = 360.0 - diff
                    if (diff > 35.0 && diff < 145.0) continue
                    bd = d
                    best = LL(p.lat + (ay + dy * t) / k2, p.lon + (ax + dx * t) / k)
                }
            }
            for (f in feats) {
                when (val g = f.geometry()) {
                    is LineString -> scan(g.coordinates())
                    is MultiLineString -> for (part in g.coordinates()) scan(part)
                    else -> { }
                }
            }
            best
        } catch (e: Exception) { null }
    }

    /** Current camera, as (lat, lon, bearing, tilt, zoom, topPadFraction, leftPadFraction). */
    fun cameraNow(): DoubleArray? {
        val m = map ?: return null
        val c = m.cameraPosition
        val t = c.target ?: return null
        val pd = c.padding
        val w = max(1, mapView.width).toDouble(); val h = max(1, mapView.height).toDouble()
        return doubleArrayOf(t.latitude, t.longitude, c.bearing, c.tilt, c.zoom, (pd?.getOrNull(1) ?: 0.0) / h, (pd?.getOrNull(0) ?: 0.0) / w)
    }

    fun setTilt(tilt: Double) {
        val m = map ?: return
        tiltNow = tilt
        m.easeCamera(CameraUpdateFactory.tiltTo(tilt), 500)
    }

    fun zoomBy(delta: Double) {
        map?.easeCamera(CameraUpdateFactory.zoomBy(delta), 250)
    }

    fun resetNorth() {
        val m = map ?: return
        m.easeCamera(CameraUpdateFactory.bearingTo(0.0), 400)
    }

    /** Smoothly zooms out (flat, north-up) so every point sits in the area above the route-preview panel. */
    fun fit(points: List<LL>) {
        val m = map ?: return
        if (points.size < 2) return
        val d = mapView.resources.displayMetrics.density.toDouble()
        val w = mapView.width / d
        val h = mapView.height / d
        if (w < 50 || h < 50) return
        fun mx(lon: Double) = (lon + 180.0) / 360.0
        fun my(lat: Double): Double {
            val r = Math.toRadians(lat.coerceIn(-85.0, 85.0))
            return (1.0 - Math.log(Math.tan(r) + 1.0 / Math.cos(r)) / Math.PI) / 2.0
        }
        val xs = points.map { mx(it.lon) }; val ys = points.map { my(it.lat) }
        val x0 = xs.min(); val x1 = xs.max(); val y0 = ys.min(); val y1 = ys.max()
        // visible area (dp): the bottom half is covered by the preview panel
        val pl = w * 0.07; val pr = w * 0.07; val pt = h * 0.10; val pb = h * 0.60
        val aw = w - pl - pr; val ah = h - pt - pb
        val fx = max(x1 - x0, 1e-7); val fy = max(y1 - y0, 1e-7)
        val z = min(Math.log(aw / (512.0 * fx)), Math.log(ah / (512.0 * fy))) / Math.log(2.0)
        val zoom = z.coerceIn(2.0, 17.0)
        val world = 512.0 * Math.pow(2.0, zoom)
        // bounds centre should land in the middle of the visible area, not the middle of the map
        val cx = (x0 + x1) / 2 + (w / 2 - (pl + aw / 2)) / world
        val cy = (y0 + y1) / 2 + (h / 2 - (pt + ah / 2)) / world
        val lon = cx * 360.0 - 180.0
        val lat = Math.toDegrees(Math.atan(Math.sinh(Math.PI * (1 - 2 * cy))))
        tiltNow = 0.0
        val cp = CameraPosition.Builder().target(LatLng(lat, lon)).zoom(zoom).tilt(0.0).bearing(0.0)
            .padding(0.0, 0.0, 0.0, 0.0).build()
        m.easeCamera(CameraUpdateFactory.newCameraPosition(cp), 1600)
    }
}
