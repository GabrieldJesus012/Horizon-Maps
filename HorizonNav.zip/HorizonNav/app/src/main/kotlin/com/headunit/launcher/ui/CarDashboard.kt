package com.headunit.launcher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.LL
import com.headunit.launcher.NavEngine
import com.headunit.launcher.NowPlaying
import com.headunit.launcher.Weather
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** Text sized from the card, the same whatever the phone's own font size setting is (so it always fits its card). */
@Composable
private fun Float.tsp(): androidx.compose.ui.unit.TextUnit = (this / androidx.compose.ui.platform.LocalDensity.current.fontScale).sp

// the dashboard's own look: deep navy with glowing blue edges (always, day or night)
private val DBg = Brush.verticalGradient(listOf(Color(0xFF0B1636), Color(0xFF07102A)))
private val DCard = Brush.verticalGradient(listOf(Color(0xFF15275A), Color(0xFF0D1A3E)))
private val DEdge = Color(0xFF2F5BD8)
private val DText = Color(0xFFF2F6FF)
private val DSub = Color(0xFF9DB2E6)
private val DBlue = Color(0xFF3D8BFF)
private val DTrack = Color(0xFF223463)
private val DFont = FontFamily.SansSerif

/**
 * The car screen's home dashboard (shown when the app opens on Android Auto and whenever no route is running): the time and
 * date, your speed, the weather where you are, the distance driven today, the car's fuel and range, the music playing with its
 * controls, a window onto the live map, and the main actions. The car in the middle, or "Mapa", opens the full map.
 */
@Composable
internal fun CarDashboard(
    engine: NavEngine, actions: CarActions,
    left: Dp, top: Dp, right: Dp, bottom: Dp,
    vL: Float, vT: Float, vW: Float, vH: Float,
) {
    val ctx = LocalContext.current.applicationContext
    var win by remember { mutableStateOf<Rect?>(null) }
    val corner = 20.dp

    // a smaller arrow in the small map window, back to its size when the dashboard closes
    DisposableEffect(Unit) {
        val full = engine.prefs.i("cararrowpct", 160).coerceIn(60, 300) / 100f
        try { engine.map.setArrowScale(full * 0.45f) } catch (e: Exception) { }
        // flat, without 3D buildings (unless switched off in Ajustes), and centred on the car
        val flat = engine.prefs.b("dash2d", true)
        if (flat) try { engine.map.setFlat(true) } catch (e: Exception) { }
        if (engine.fix != null) engine.recenter() else engine.following = true
        onDispose {
            try { engine.map.setArrowScale(full) } catch (e: Exception) { }
            if (flat) try { engine.map.setFlat(false) } catch (e: Exception) { }
        }
    }
    // the weather where you are (refreshed every 20 minutes)
    var wx by remember { mutableStateOf<Weather.Now?>(null) }
    var city by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            val p: LL? = engine.fix?.pos
            if (p != null) {
                val w = withContext(Dispatchers.IO) { try { Weather.fetch(p) } catch (e: Exception) { null } }
                // the town you're in, from Android's own address lookup (blank when it can't tell)
                withContext(Dispatchers.IO) {
                    try {
                        @Suppress("DEPRECATION")
                        val a = android.location.Geocoder(ctx, java.util.Locale("pt", "BR")).getFromLocation(p.lat, p.lon, 1)?.firstOrNull()
                        (a?.locality ?: a?.subAdminArea)?.let { city = it }
                    } catch (e: Exception) { }
                }
                if (w != null) { wx = w; delay(20 * 60_000L) } else delay(60_000L)
            } else delay(5_000L)
        }
    }
    // the clock, and the song playing
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            try { NowPlaying.refresh(ctx) } catch (e: Exception) { }
            delay(1000L)
        }
    }

    // everything but the map window is covered, so the live map shows only through it
    Box(
        Modifier.fillMaxSize().graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen).drawBehind {
            drawRect(DBg)
            win?.let { r -> drawRoundRect(Color.Transparent, r.topLeft, r.size, CornerRadius(corner.toPx()), blendMode = BlendMode.Clear) }
        },
    ) {
        Column(
            Modifier.fillMaxSize().padding(start = left, top = top, end = right, bottom = bottom),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            // ---- top: the clock with the weather, and the music ----
            Row(Modifier.fillMaxWidth().weight(0.20f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ClockCard(now, wx, city, Modifier.weight(0.44f).fillMaxHeight())
                MusicCard(ctx, Modifier.weight(0.56f).fillMaxHeight())
            }
            // ---- middle: speed and the road's limit | the live map | km today and this week ----
            Row(Modifier.fillMaxWidth().weight(0.68f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SpeedGauge(engine, Modifier.weight(1f).fillMaxWidth())
                    LimitGauge(engine, Modifier.weight(1f).fillMaxWidth())
                }
                Box(
                    Modifier.weight(2.6f).fillMaxHeight().border(2.dp, DEdge, RoundedCornerShape(corner))
                        .onGloballyPositioned { lc ->
                            val r = lc.boundsInRoot()
                            win = r
                            // the camera keeps your arrow in the middle of this window
                            engine.dashLeft = (2.0 * ((r.center.x - vL) / vW) - 1.0).coerceIn(-0.9, 0.9)
                            engine.dashPad = (2.0 * ((r.center.y - vT) / vH) - 1.0).coerceIn(0.0, 0.9)
                        }
                        .carTap("dash-window") { engine.carDash = false },
                ) {
                    Text("TOQUE PARA ABRIR O MAPA", color = DSub, fontSize = 10f.tsp(), fontWeight = FontWeight.Bold, fontFamily = DFont, letterSpacing = 1.sp, maxLines = 1,
                        modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp).clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0B1636).copy(alpha = 0.85f)).border(1.dp, DEdge, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 3.dp))
                }
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TodayGauge(engine, Modifier.weight(1f).fillMaxWidth().carTap("dash-today") { engine.showToday() })
                    WeekCard(engine, Modifier.weight(1f).fillMaxWidth())
                }
            }
            // ---- bottom: the main actions ----
            Row(Modifier.fillMaxWidth().weight(0.12f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DashButton(Icons.Rounded.Search, "Buscar", "dash-search", Modifier.weight(1f)) { actions.search() }
                DashButton(Icons.Rounded.Star, "Locais", "dash-places", Modifier.weight(1f)) { actions.places() }
                DrivingTile(engine, Modifier.weight(1.6f).fillMaxHeight())
                DashButton(Icons.Rounded.LocalGasStation, "Postos", "dash-fuel", Modifier.weight(1f)) { actions.nearby("fuel") }
                DashButton(Icons.Rounded.Settings, "Ajustes", "dash-settings", Modifier.weight(1f)) { actions.settings() }
            }
        }
    }
}

@Composable
private fun DashCard(modifier: Modifier, content: @Composable BoxScope.() -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Box(modifier.clip(shape).background(DCard).border(1.5.dp, DEdge.copy(alpha = 0.85f), shape)) { content() }
}

@Composable
private fun ClockCard(now: Long, wx: Weather.Now?, city: String, modifier: Modifier) {
    val br = java.util.Locale("pt", "BR")
    val time = java.text.SimpleDateFormat("HH:mm", br).format(java.util.Date(now))
    val day = java.text.SimpleDateFormat("EEEE", br).format(java.util.Date(now)).uppercase(br)
    val date = java.text.SimpleDateFormat("d 'de' MMMM 'de' yyyy", br).format(java.util.Date(now))
    DashCard(modifier) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val mh = maxHeight.value
            val big = (mh * 0.58f).coerceIn(18f, 44f).tsp()
            Row(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(time, color = DText, fontSize = big, fontWeight = FontWeight.Bold, fontFamily = DFont, maxLines = 1)
                Box(Modifier.padding(horizontal = 14.dp).width(2.dp).fillMaxHeight(0.6f).background(DBlue))
                Column(Modifier.weight(1f)) {
                    Text(day, color = DBlue, fontSize = (mh * 0.2f).coerceIn(9f, 14f).tsp(), fontWeight = FontWeight.Bold, fontFamily = DFont, letterSpacing = 1.sp, maxLines = 1)
                    Text(date, color = DText, fontSize = (mh * 0.25f).coerceIn(10f, 17f).tsp(), fontFamily = DFont, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                // the weather where you are: icon and temperature, with the town and the sky under it
                if (wx != null) Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(start = 10.dp)) {
                    Text(wxEmoji(wx.code) + " " + Math.round(wx.tempC) + "°", color = DText, fontSize = (mh * 0.42f).coerceIn(14f, 32f).tsp(), fontWeight = FontWeight.Bold, fontFamily = DFont, maxLines = 1)
                    Text(listOf(city, wxText(wx.code)).filter { it.isNotBlank() }.joinToString(" · "), color = DSub, fontSize = (mh * 0.19f).coerceIn(9f, 14f).tsp(), fontFamily = DFont, maxLines = 1)
                }
            }
        }
    }
}

/**
 * A round gauge sized to its tile: the label on top, a 240° track with the value's arc in [colors] (a gradient), the figure in
 * the middle of the ring and a note under it. All sizes follow the tile, so it reads the same on any car screen.
 */
@Composable
private fun Gauge(label: String, value: String, unit: String, frac: Float, colors: List<Color>, foot: String?, modifier: Modifier) {
    DashCard(modifier) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val h = maxHeight.value; val w = maxWidth.value
            val labelSp = (h * 0.11f).coerceIn(8f, 12f)
            val footSp = (h * 0.12f).coerceIn(8f, 13f)
            // three bands that never overlap: the label on top, the ring in the middle (its open ends sit just above the note), the note
            val ringTop = h * 0.19f
            // the note sits on the bottom edge and the ring makes room for its full height (on smaller car screens too)
            val footH = footSp * 1.45f
            val footTop = if (foot.isNullOrEmpty()) h * 0.96f else h - footH - h * 0.05f
            // the ring's height from its top to its open ends is 1.5 × its radius
            val r = minOf(w * 0.40f, (footTop - ringTop) / 1.5f)
            val d = 2f * r
            val cx = w / 2f; val cy = ringTop + r
            Canvas(Modifier.fillMaxSize()) {
                val px = density
                val rp = r * px
                val stroke = (d * px * 0.085f).coerceAtLeast(3f)
                val tl = Offset(cx * px - rp + stroke / 2f, cy * px - rp + stroke / 2f)
                val sz = Size(2f * rp - stroke, 2f * rp - stroke)
                drawArc(DTrack, 150f, 240f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
                val f = frac.coerceIn(0f, 1f)
                if (f > 0.005f) drawArc(Brush.horizontalGradient(colors, startX = tl.x, endX = tl.x + sz.width), 150f, 240f * f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            }
            Text(label, color = DSub, fontSize = labelSp.tsp(), fontWeight = FontWeight.Bold, fontFamily = DFont, letterSpacing = 1.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = (h * 0.04f).dp, start = 6.dp, end = 6.dp))
            // the figure in the middle of the ring, with its unit small beside it (no second line, so nothing can collide)
            val valSp = (d * 0.30f).coerceIn(10f, 32f)
            Text(
                androidx.compose.ui.text.buildAnnotatedString {
                    append(value)
                    if (unit.isNotEmpty()) {
                        pushStyle(androidx.compose.ui.text.SpanStyle(fontSize = (valSp * 0.36f).tsp(), color = DSub, fontWeight = FontWeight.Normal))
                        append(" " + unit)
                        pop()
                    }
                },
                color = DText, fontSize = valSp.tsp(), fontWeight = FontWeight.Bold, fontFamily = DFont, maxLines = 1,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = (cy - valSp * 0.62f).coerceAtLeast(0f).dp),
            )
            if (!foot.isNullOrEmpty()) Text(foot, color = DText.copy(alpha = 0.85f), fontSize = footSp.tsp(), fontWeight = FontWeight.Medium, fontFamily = DFont,
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, lineHeight = (footSp * 1.15f).tsp(),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = (h * 0.05f).dp, start = 8.dp, end = 8.dp))
        }
    }
}

private val GBlue = listOf(Color(0xFF1E6BFF), Color(0xFF5CC8FF))
private val GOrange = listOf(Color(0xFFFFC14D), Color(0xFFFF7A1A))
private val GGreen = listOf(Color(0xFF22C55E), Color(0xFFB6F35A))
private val GRed = listOf(Color(0xFFFF8A4D), Color(0xFFFF3B3B))

@Composable
private fun SpeedGauge(engine: NavEngine, modifier: Modifier) {
    val kmh = ((engine.fix?.speed ?: 0.0) * 3.6).coerceAtLeast(0.0)
    val lim = engine.speedLimit?.let { Math.round(it * 3.6).toInt() }
    val over = lim != null && kmh > lim + 3
    Gauge("VELOCIDADE", "${Math.round(kmh)}", "km/h", (kmh / 160.0).toFloat(), if (over) GRed else GBlue,
        null, modifier)
}

private fun wxText(code: Int): String = when (code) {
    0 -> "Céu limpo"; 1, 2 -> "Poucas nuvens"; 3 -> "Nublado"; 45, 48 -> "Neblina"
    in 51..57 -> "Garoa"; in 61..67 -> "Chuva"; in 71..77 -> "Neve"; in 80..82 -> "Pancadas de chuva"
    in 95..99 -> "Tempestade"; else -> ""
}

private fun wxEmoji(code: Int): String = when (code) {
    0 -> "☀"; 1, 2 -> "⛅"; 3 -> "☁"; 45, 48 -> "🌫"; in 51..67, in 80..82 -> "🌧"; in 71..77 -> "❄"; in 95..99 -> "⛈"; else -> "🌡"
}

@Composable
private fun TodayGauge(engine: NavEngine, modifier: Modifier) {
    @Suppress("UNUSED_VARIABLE") val tick = engine.tripDist   // re-read as you drive
    val (m, secs) = engine.kmToday()
    val km = m / 1000.0
    val mins = (secs / 60L).toInt()
    Gauge("KM HOJE", if (km < 10) String.format(java.util.Locale("pt", "BR"), "%.1f", km) else "${Math.round(km)}", "km",
        (km / 100.0).toFloat(), GGreen, null, modifier)
}

/** The road's limit, with the next speed camera under it. */
@Composable
private fun LimitGauge(engine: NavEngine, modifier: Modifier) {
    val lim = engine.speedLimit?.let { Math.round(it * 3.6).toInt() }
    val cam = engine.cameraDist
    Gauge("LIMITE DA VIA", lim?.toString() ?: "--", "km/h", ((lim ?: 0) / 120.0).toFloat(), GRed,
        if (cam != null) "radar a ${com.headunit.launcher.Geo.fmtDist(cam.toDouble(), false)}" else if (lim != null && engine.limitEstimated) "estimado" else null, modifier)
}

/** How long you've driven today, as a line of text in the bottom row (minutes, then hours and minutes). */
@Composable
private fun DrivingTile(engine: NavEngine, modifier: Modifier) {
    @Suppress("UNUSED_VARIABLE") val tick = engine.tripDist   // re-read as you drive
    val mins = (engine.kmToday().second / 60L).toInt()
    val time = when {
        mins <= 0 -> null
        mins < 60 -> "$mins min"
        else -> "${mins / 60} h" + if (mins % 60 > 0) " ${"%02d".format(mins % 60)} min" else ""
    }
    DashCard(modifier) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val h = maxHeight.value
            Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Timer, null, tint = Color(0xFFB6F35A), modifier = Modifier.size((h * 0.42f).coerceIn(14f, 26f).dp))
                Text(androidx.compose.ui.text.buildAnnotatedString {
                    if (time != null) {
                        append(time)
                        pushStyle(androidx.compose.ui.text.SpanStyle(color = DSub, fontWeight = FontWeight.Normal, fontSize = (h * 0.26f).coerceIn(9f, 14f).tsp())); append(" dirigindo hoje"); pop()
                    } else {
                        pushStyle(androidx.compose.ui.text.SpanStyle(color = DSub, fontWeight = FontWeight.Normal)); append("nenhuma viagem hoje"); pop()
                    }
                }, color = DText, fontSize = (h * 0.34f).coerceIn(11f, 19f).tsp(), fontWeight = FontWeight.Bold, fontFamily = DFont, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 8.dp))
            }
        }
    }
}

/** This week's driving (Monday to today): the total, and a bar per day with today's in green. */
@Composable
private fun WeekCard(engine: NavEngine, modifier: Modifier) {
    @Suppress("UNUSED_VARIABLE") val tick = engine.tripDist   // re-read as you drive
    val days = remember(engine.tripDist.toLong() / 200L) { weekKm(engine) }
    val today = (java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7   // 0 = Monday
    val total = days.sum() / 1000.0
    DashCard(modifier) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val h = maxHeight.value; val w = maxWidth.value
            Text("KM DA SEMANA", color = DSub, fontSize = (h * 0.11f).coerceIn(8f, 12f).tsp(), fontWeight = FontWeight.Bold, fontFamily = DFont, letterSpacing = 1.sp, maxLines = 1,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = (h * 0.04f).dp))
            val valSp = (h * 0.2f).coerceIn(12f, 30f)
            Text(androidx.compose.ui.text.buildAnnotatedString {
                append(if (total < 10) String.format(java.util.Locale("pt", "BR"), "%.1f", total) else "${Math.round(total)}")
                pushStyle(androidx.compose.ui.text.SpanStyle(fontSize = (valSp * 0.4f).tsp(), color = DSub, fontWeight = FontWeight.Normal)); append(" km"); pop()
            }, color = DText, fontSize = valSp.tsp(), fontWeight = FontWeight.Bold, fontFamily = DFont, maxLines = 1,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = (h * 0.17f).dp))
            // the bars: one per day, Monday to Sunday
            val max = (days.maxOrNull() ?: 0.0).coerceAtLeast(1000.0)
            val letters = listOf("S", "T", "Q", "Q", "S", "S", "D")
            val barsTop = h * 0.50f; val barsH = h * 0.30f
            val bw = (w * 0.84f) / 7f
            Canvas(Modifier.fillMaxSize()) {
                val px = density
                for (i in 0 until 7) {
                    val x = (w * 0.08f + i * bw + bw * 0.18f) * px
                    val bwPx = bw * 0.64f * px
                    drawRoundRect(DTrack, Offset(x, barsTop * px), Size(bwPx, barsH * px), CornerRadius(bwPx * 0.25f))
                    val f = (days[i] / max).toFloat().coerceIn(0f, 1f)
                    if (f > 0f) {
                        val bh = (barsH * f).coerceAtLeast(barsH * 0.08f) * px
                        drawRoundRect(if (i == today) Color(0xFFB6F35A) else DBlue, Offset(x, barsTop * px + barsH * px - bh), Size(bwPx, bh), CornerRadius(bwPx * 0.25f))
                    }
                }
            }
            Row(Modifier.align(Alignment.TopStart).padding(top = (barsTop + barsH + h * 0.02f).dp, start = (w * 0.08f).dp).width((w * 0.84f).dp)) {
                for (i in 0 until 7) Text(letters[i], color = if (i == today) Color(0xFFB6F35A) else DSub, fontSize = (h * 0.09f).coerceIn(7f, 11f).tsp(),
                    fontWeight = if (i == today) FontWeight.Bold else FontWeight.Normal, fontFamily = DFont, textAlign = TextAlign.Center, maxLines = 1, modifier = Modifier.weight(1f))
            }
        }
    }
}

/** Metres driven on each day of this week, Monday first (today's includes the trip being driven now). */
private fun weekKm(engine: NavEngine): DoubleArray {
    val out = DoubleArray(7)
    val cal = java.util.Calendar.getInstance()
    val today = (cal.get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7
    cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
    val todayStart = cal.timeInMillis
    cal.add(java.util.Calendar.DAY_OF_MONTH, -today)
    val monday = cal.timeInMillis
    try {
        for (tr in engine.trips.all()) {
            if (tr.start < monday || tr.start >= todayStart) continue
            val c = java.util.Calendar.getInstance().apply { timeInMillis = tr.start }
            val d = (c.get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7
            if (d in 0 until today) out[d] += tr.dist
        }
    } catch (e: Exception) { }
    out[today] = engine.kmToday().first
    return out
}

@Composable
private fun DashButton(icon: ImageVector, label: String, id: String, modifier: Modifier, action: () -> Unit) {
    // icon only (the label is kept for screen readers)
    DashCard(modifier.fillMaxHeight().carTap(id, action)) {
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Icon(icon, label, tint = DBlue, modifier = Modifier.size((maxHeight.value * 0.55f).coerceIn(16f, 32f).dp))
        }
    }
}

@Composable
private fun MusicCard(ctx: android.content.Context, modifier: Modifier) {
    DashCard(modifier) {
        // the card runs to the edge, but its contents keep clear of Android Auto's own search and settings buttons in this corner
        BoxWithConstraints(Modifier.fillMaxSize()) {
          val endRoom = (maxWidth.value * 0.13f).coerceIn(56f, 130f)
          BoxWithConstraints(Modifier.fillMaxSize().padding(start = 14.dp, end = endRoom.dp, top = 8.dp, bottom = 8.dp)) {
            val h = maxHeight.value
            if (!NowPlaying.allowed) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.MusicNote, null, tint = DBlue, modifier = Modifier.size(20.dp))
                        Text("MÚSICA", color = DBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = DFont, letterSpacing = 1.sp, modifier = Modifier.padding(start = 8.dp))
                    }
                    Text("Para mostrar a música aqui, permita no celular: Configurações › Sobre e backup › Android Auto › Música no painel.",
                        color = DSub, fontSize = 11f.tsp(), fontFamily = DFont, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                }
                return@BoxWithConstraints
            }
            // only the song and how long is left (play/pause and skip are on Android Auto's own bar), so the map gets the room
            val artSize = (h * 0.5f).coerceIn(28f, 52f)
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val art = NowPlaying.art
                    Box(Modifier.size(artSize.dp).clip(RoundedCornerShape(9.dp)).background(DTrack), contentAlignment = Alignment.Center) {
                        if (art != null) Image(art.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        else Icon(Icons.Rounded.MusicNote, null, tint = DSub, modifier = Modifier.size((artSize * 0.45f).dp))
                    }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text((NowPlaying.app.ifBlank { "Música" }).uppercase(), color = DBlue, fontSize = 10f.tsp(), fontWeight = FontWeight.Bold, fontFamily = DFont, letterSpacing = 1.sp, maxLines = 1)
                        val title = NowPlaying.title.ifBlank { "Nada tocando" }
                        Text(androidx.compose.ui.text.buildAnnotatedString {
                            append(title)
                            if (NowPlaying.artist.isNotBlank()) {
                                pushStyle(androidx.compose.ui.text.SpanStyle(color = DSub, fontWeight = FontWeight.Normal, fontSize = (h * 0.13f).coerceIn(10f, 15f).tsp()))
                                append(" · " + NowPlaying.artist); pop()
                            }
                        }, color = DText, fontSize = (h * 0.16f).coerceIn(11f, 18f).tsp(), fontWeight = FontWeight.Bold, fontFamily = DFont, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                val d = NowPlaying.duration
                val pos = NowPlaying.position.coerceIn(0L, if (d > 0) d else Long.MAX_VALUE)
                val f = if (d > 0) (pos.toFloat() / d).coerceIn(0f, 1f) else 0f
                Column {
                    Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(DTrack)) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(f).background(Brush.horizontalGradient(GBlue)))
                    }
                    if (d > 0) Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        val small = (h * 0.11f).coerceIn(9f, 12f).tsp()
                        Text(mmss(pos), color = DSub, fontSize = small, fontFamily = DFont, maxLines = 1)
                        Text("faltam " + mmss(d - pos), color = DText, fontSize = small, fontWeight = FontWeight.Bold, fontFamily = DFont, maxLines = 1)
                    }
                }
            }
        }
    }
  }
}

private fun mmss(ms: Long): String { val s = (ms / 1000L).coerceAtLeast(0L); return "%d:%02d".format(s / 60, s % 60) }

/** On the map, while today's driven roads are shown (tap "KM HOJE" on the dashboard): what it is, and a button back. */
@Composable
internal fun DayPathBanner(engine: NavEngine, modifier: Modifier) {
    LaunchedEffect(engine.route) { if (engine.route != null) engine.hideToday() }
    val (m, secs) = engine.kmToday()
    val km = m / 1000.0
    val mins = (secs / 60L).toInt()
    val time = if (mins >= 60) "${mins / 60} h ${mins % 60} min" else "$mins min"
    Row(modifier.clip(RoundedCornerShape(18.dp)).background(DCard).border(1.dp, DEdge, RoundedCornerShape(18.dp))
        .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(12.dp).clip(CircleShape).background(DBlue))
        Column(Modifier.padding(start = 12.dp, end = 16.dp)) {
            Text(if (engine.todayPaths().isEmpty()) "Nenhum trajeto registrado hoje" else "Trajeto de hoje", color = Color.White, fontSize = 18f.tsp(), fontWeight = FontWeight.Bold, maxLines = 1)
            Text(String.format(java.util.Locale("pt", "BR"), "%.1f km", km) + " · " + time + " dirigindo", color = DSub, fontSize = 14f.tsp(), maxLines = 1)
        }
        Box(Modifier.clip(RoundedCornerShape(14.dp)).background(Brush.verticalGradient(GBlue)).carTap("day-close") { engine.hideToday() }
            .padding(horizontal = 18.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
            Text("Voltar", color = Color.White, fontSize = 16f.tsp(), fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}
