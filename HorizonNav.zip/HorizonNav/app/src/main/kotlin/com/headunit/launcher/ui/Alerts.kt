package com.headunit.launcher.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CarCrash
import androidx.compose.material.icons.rounded.Coffee
import androidx.compose.material.icons.rounded.Construction
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PriorityHigh
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Eco
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.LocalPolice
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.AlertInfo
import com.headunit.launcher.NavEngine

private fun alertColor(kind: String): Color = when (kind) {
    "camera", "limit", "avg", "wrongway" -> Bad
    "plan" -> NavBlue
    "rain" -> NavBlue
    "zone" -> Good
    else -> Warn
}

private fun alertLabel(kind: String): String = when (kind) {
    "camera" -> "SPEED CAMERA"
    "limit" -> "SPEED LIMIT"
    "incident" -> "HAZARD AHEAD"
    "rain" -> "WEATHER"
    "break" -> "TAKE A BREAK"
    "avg" -> "AVERAGE SPEED CHECK"
    "bump" -> "SPEED BUMP"
    "school" -> "SCHOOL"
    "zone" -> "CLEAN AIR ZONE"
    "report" -> "REPORTED AHEAD"
    "wrongway" -> "WRONG WAY"
    "plan" -> "PLANNED TRIP"
    else -> "ALERT"
}

private fun alertIcon(a: AlertInfo): ImageVector {
    val t = a.text.lowercase()
    return when (a.kind) {
        "camera" -> Icons.Rounded.CameraAlt
        "incident" -> when {
            t.contains("work") -> Icons.Rounded.Construction
            t.contains("accident") || t.contains("crash") || t.contains("collision") -> Icons.Rounded.CarCrash
            else -> Icons.Rounded.PriorityHigh
        }
        "rain" -> if (t.startsWith("snow")) Icons.Rounded.AcUnit else Icons.Rounded.WaterDrop
        "break" -> Icons.Rounded.Coffee
        "avg" -> Icons.Rounded.Speed
        "bump" -> Icons.Rounded.Warning
        "school" -> Icons.Rounded.School
        "zone" -> Icons.Rounded.Eco
        "plan" -> Icons.Rounded.Schedule
        "report" -> if (t.startsWith("accident")) Icons.Rounded.CarCrash else if (t.startsWith("police")) Icons.Rounded.LocalPolice else Icons.Rounded.PriorityHigh
        else -> Icons.Rounded.Notifications
    }
}

/** A road-sign style badge for an alert: speed-limit roundel, warning triangle, or a coloured disc. */
@Composable
fun AlertSign(a: AlertInfo, size: Dp) {
    val col = alertColor(a.kind)
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        when (a.kind) {
            "limit" -> {
                val n = Regex("\\d+").find(a.text)?.value ?: ""
                Box(Modifier.fillMaxSize().clip(CircleShape).background(Color.White).border(size * 0.09f, Bad, CircleShape), contentAlignment = Alignment.Center) {
                    Text(n, color = Color.Black, fontSize = (size.value * (if (n.length >= 3) 0.30f else 0.40f)).sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
            "wrongway" -> {
                // the no-entry sign
                Box(Modifier.fillMaxSize().clip(CircleShape).background(Bad).border(size * 0.05f, Color.White, CircleShape), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(width = size * 0.62f, height = size * 0.16f).background(Color.White))
                }
            }
            "camera", "incident", "bump", "school", "report", "avg" -> {
                Canvas(Modifier.fillMaxSize()) {
                    val w = this.size.width
                    val h = this.size.height
                    val p = Path().apply {
                        moveTo(w * 0.5f, h * 0.08f)
                        lineTo(w * 0.95f, h * 0.90f)
                        lineTo(w * 0.05f, h * 0.90f)
                        close()
                    }
                    drawPath(p, Color.White)
                    drawPath(p, Bad, style = Stroke(w * 0.09f, join = StrokeJoin.Round))
                }
                Icon(alertIcon(a), null, tint = Color.Black, modifier = Modifier.size(size * 0.40f).offset(y = size * 0.10f))
            }
            else -> {
                Box(Modifier.fillMaxSize().clip(CircleShape).background(col.copy(alpha = 0.18f)).border(2.dp, col, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(alertIcon(a), null, tint = col, modifier = Modifier.size(size * 0.54f))
                }
            }
        }
    }
}

/** Large alert banner with a road-sign badge and a countdown bar. */
@Composable
fun AlertBanner(a: AlertInfo, modifier: Modifier = Modifier) {
    val col = alertColor(a.kind)
    val prog = remember(a) { Animatable(1f) }
    LaunchedEffect(a) { prog.animateTo(0f, tween(a.ms.toInt().coerceAtLeast(500), easing = LinearEasing)) }
    // compact, so it fits between the turn card and the buttons on the right without covering either
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.widthIn(max = 420.dp).shadow(14.dp, shape).clip(shape)
            .background(Color(0xF2121922)).border(1.5.dp, col.copy(alpha = 0.7f), shape),
    ) {
        Row(Modifier.padding(start = 12.dp, end = 18.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            AlertSign(a, 54.dp)
            Column(Modifier.padding(start = 12.dp)) {
                Text(alertLabel(a.kind), color = col, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, maxLines = 1)
                Text(a.text, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 22.sp)
            }
        }
        Box(Modifier.fillMaxWidth().height(4.dp).background(Color.White.copy(alpha = 0.08f))) {
            Box(Modifier.fillMaxWidth(prog.value).fillMaxHeight().background(col))
        }
    }
}

/** Compact road-sign badge with the distance underneath, for hazards ahead on the map. */
@Composable
fun HazardBadge(kind: String, label: String, dist: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        // a rounded square rather than a circle, so the corners of a warning triangle are never cut off
        val tile = RoundedCornerShape(18.dp)
        Box(Modifier.shadow(8.dp, tile).clip(tile).background(Color(0xE6121922)).padding(7.dp)) {
            AlertSign(AlertInfo(kind, label), 50.dp)
        }
        Text(dist, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 4.dp).clip(RoundedCornerShape(50)).background(Color(0xE6121922)).padding(horizontal = 8.dp, vertical = 2.dp))
    }
}

/** UK-style speed limit roundel for the current road; pulses when the limit changes and tints when you're over it. */
@Composable
fun SpeedLimitSign(engine: NavEngine, size: Dp, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    val l = engine.speedLimit ?: return
    val k = if (engine.imperial) 2.23694 else 3.6
    val n = (Math.round(l * k / 5.0) * 5).toInt()
    val pulse by rememberPulse(engine.limitPulse, 450, 1f, 1.18f)
    val sc = if (engine.limitPulse) pulse else 1f
    Box(
        modifier.graphicsLayer { scaleX = sc; scaleY = sc }.size(size).shadow(8.dp, CircleShape).clip(CircleShape)
            .background(if (engine.overLimit) Color(0xFFFFC9C9) else Color.White)
            .border(size * 0.095f, Bad, CircleShape)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        Text("$n", color = if (engine.limitEstimated) Color(0xFF4A4A4A) else Color.Black, fontSize = (size.value * (if (n >= 100) 0.33f else 0.41f)).sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}
