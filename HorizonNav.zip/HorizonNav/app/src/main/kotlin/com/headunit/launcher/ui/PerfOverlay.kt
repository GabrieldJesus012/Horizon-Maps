package com.headunit.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.PerfStats
import kotlinx.coroutines.delay

/** Small readout of how the map and the main thread are coping, refreshed once a second. */
@Composable
fun PerfOverlay(modifier: Modifier = Modifier) {
    var text by remember { mutableStateOf("measuring…") }
    LaunchedEffect(Unit) {
        PerfStats.on = true
        try {
            while (true) {
                PerfStats.renders = 0; PerfStats.ticks = 0; PerfStats.tickNsSum = 0L; PerfStats.tickNsMax = 0L; PerfStats.gapMsMax = 0L
                delay(1000)
                val t = PerfStats.ticks
                val avg = if (t > 0) PerfStats.tickNsSum / t / 1_000_000.0 else 0.0
                text = "map ${PerfStats.renders} fps   updates $t/s\nupdate cost avg ${"%.1f".format(avg)} ms, worst ${PerfStats.tickNsMax / 1_000_000} ms\nlongest UI stall ${PerfStats.gapMsMax} ms"
            }
        } finally { PerfStats.on = false }
    }
    Text(
        text, color = Color.White, fontSize = 13.sp,
        modifier = modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xCC000000)).padding(horizontal = 10.dp, vertical = 6.dp),
    )
}
