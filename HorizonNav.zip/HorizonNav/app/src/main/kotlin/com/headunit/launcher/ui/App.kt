package com.headunit.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.MapBinding
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import kotlinx.coroutines.delay

internal fun findActivity(c: android.content.Context): android.app.Activity? {
    var x: android.content.Context = c
    while (x is android.content.ContextWrapper) {
        if (x is android.app.Activity) return x
        x = x.baseContext
    }
    return null
}

/** The whole app: the map full screen with its overlays, and the settings screen on top when it is open. */
@Composable
fun App(prefs: Prefs, engine: NavEngine, map: MapBinding) {
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(60_000); nowMs = System.currentTimeMillis() } }
    val dark = resolveDark(prefs.s("theme", "auto"), prefs.s("lastlat", "").toDoubleOrNull(), prefs.s("lastlon", "").toDoubleOrNull(), nowMs)
    val hostCtx = androidx.compose.ui.platform.LocalContext.current

    // screen brightness (per window, no permission needed) incl. dimming at night, and keeping the screen on
    val bright = prefs.i("bright", 100)
    val dimNight = prefs.b("dimnight", false)
    val keepOn = prefs.b("keepon", true)
    LaunchedEffect(bright, dimNight, dark, keepOn) {
        val win = findActivity(hostCtx)?.window ?: return@LaunchedEffect
        val dim = dimNight && dark
        val v = if (bright >= 100 && !dim) -1f else (bright / 100f * (if (dim) 0.5f else 1f)).coerceIn(0.03f, 1f)
        val lp = win.attributes
        lp.screenBrightness = v
        win.attributes = lp
        if (keepOn) win.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else win.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // map look and behaviour follow the settings as soon as they change
    val style = prefs.s("mapstyle", "tomtom")
    val traffic = prefs.b("traffic", true)
    val key = prefs.s("apikey", "")
    val gkey = prefs.s("gkey", "")
    val mapTheme = prefs.s("maptheme", "immersive")
    LaunchedEffect(mapTheme) { map.setTheme(mapTheme) }
    val mapFps = prefs.s("mapfps", "30").toIntOrNull() ?: 30
    LaunchedEffect(mapFps) { map.setMaxFps(mapFps) }
    val mapLite = prefs.b("maplite", true)
    LaunchedEffect(mapLite) { map.setLite(mapLite) }
    val hideTraffic = prefs.b("routetrafficonly", true)
    LaunchedEffect(hideTraffic) { map.setHideOtherTraffic(hideTraffic) }
    val arrowPct = prefs.s("arrowpct", "240").toIntOrNull() ?: 240
    LaunchedEffect(arrowPct) { map.setArrowScale(arrowPct / 100f) }
    LaunchedEffect(dark, style, traffic, key, gkey) { engine.applyStyle(dark) }
    val sat = prefs.b("satellite", false)
    val b3d = prefs.b("buildings3d", true)
    LaunchedEffect(sat, b3d) { map.setView(sat, b3d) }
    val lampGap = prefs.s("lampgap", "40").toDoubleOrNull() ?: 40.0
    LaunchedEffect(Unit) {
        map.initLampGuard()
        if (map.lampTripped) { prefs.put("lamps", false); engine.toast("Street lamps were switched off because they crashed the app. You can turn them back on in Settings.", 7000) }
    }
    val lampsOn = prefs.b("lamps", true)
    LaunchedEffect(lampsOn) { map.lampsEnabled(lampsOn) }
    LaunchedEffect(lampGap) { delay(1200); map.applyLampGap(lampGap) }
    val signalsOn = prefs.b("signals", true)
    LaunchedEffect(signalsOn) { map.signalsEnabled(signalsOn) }

    val scale = prefs.i("uiscale", 100).coerceIn(60, 140) / 100f
    val baseDensity = androidx.compose.ui.platform.LocalDensity.current
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(baseDensity.density * scale, baseDensity.fontScale),
    ) {
        VwTheme(dark) {
            val c = LocalVw.current
            var settings by rememberSaveable { mutableStateOf(false) }
            // Back closes the settings; on the map it sends the app to the background instead of closing it,
            // so a route in progress keeps going (and the map is ready straight away when you come back).
            BackHandler(enabled = settings) { settings = false }
            BackHandler(enabled = !settings) { findActivity(hostCtx)?.moveTaskToBack(true) }

            Box(Modifier.fillMaxSize().background(c.bg)) {
                if (settings) {
                    // the map is taken off screen while the settings are open, so it is not drawing underneath them
                    SettingsScreen(prefs, engine, onClose = { settings = false })
                } else {
                    MapHost(map, Modifier.fillMaxSize())
                    val wxCode = engine.weather?.code
                    if (prefs.b("rainfx", false) && wxCode != null && (wxCode in 51..67 || wxCode in 80..82 || wxCode in 95..99)) RainOverlay(Modifier.fillMaxSize())
                    NavOverlays(engine, onSettings = { settings = true })
                    if (prefs.b("perfmon", false)) PerfOverlay(Modifier.align(Alignment.BottomCenter).padding(bottom = 90.dp))
                }
                // short messages (saved, sent, no signal...) show over everything
                engine.message?.let { m ->
                    Box(
                        Modifier.align(if (settings) Alignment.BottomCenter else Alignment.TopCenter).padding(top = 12.dp, bottom = 18.dp)
                            .clip(RoundedCornerShape(50)).background(Color(0xE6101820)).border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(50)).padding(horizontal = 22.dp, vertical = 11.dp),
                    ) { Text(m, color = Color.White, fontSize = 15.sp) }
                }
                // alerts (camera, speed limit, incident, rain, break) get a large banner that is hard to miss
                if (!settings) {
                    val curAlert = engine.alert
                    val lastAlert = remember { mutableStateOf(curAlert) }
                    if (curAlert != null) lastAlert.value = curAlert
                    androidx.compose.animation.AnimatedVisibility(
                        visible = curAlert != null,
                        modifier = Modifier.align(Alignment.TopCenter).padding(top = 14.dp),
                        enter = androidx.compose.animation.slideInVertically(initialOffsetY = { -it }) + androidx.compose.animation.fadeIn(),
                        exit = androidx.compose.animation.slideOutVertically(targetOffsetY = { -it }) + androidx.compose.animation.fadeOut(),
                    ) { lastAlert.value?.let { AlertBanner(it) } }
                }
            }
        }
    }
}
