package com.headunit.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.MapBinding
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import kotlinx.coroutines.delay

internal fun findActivity(c: android.content.Context): android.app.Activity? {
    var x: android.content.Context = c
    while (x is android.content.ContextWrapper) {
        if (x is android.app.Activity) return x
        x = x.baseContext
    }
    return null
}

/** The whole app: the map full screen with its overlays, and the settings screen on top when it is open. */
@Composable
fun App(prefs: Prefs, engine: NavEngine, map: MapBinding) {
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(60_000); nowMs = System.currentTimeMillis() } }
    val dark = resolveDark(prefs.s("theme", "auto"), prefs.s("lastlat", "").toDoubleOrNull(), prefs.s("lastlon", "").toDoubleOrNull(), nowMs)
    val hostCtx = androidx.compose.ui.platform.LocalContext.current

    // screen brightness (per window, no permission needed) incl. dimming at night, and keeping the screen on
    val bright = prefs.i("bright", 100)
    val dimNight = prefs.b("dimnight", false)
    val keepOn = prefs.b("keepon", true)
    LaunchedEffect(bright, dimNight, dark, keepOn) {
        val win = findActivity(hostCtx)?.window ?: return@LaunchedEffect
        val dim = dimNight && dark
        val v = if (bright >= 100 && !dim) -1f else (bright / 100f * (if (dim) 0.5f else 1f)).coerceIn(0.03f, 1f)
        val lp = win.attributes
        lp.screenBrightness = v
        win.attributes = lp
        if (keepOn) win.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else win.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // map look and behaviour follow the settings as soon as they change
    val style = prefs.s("mapstyle", com.headunit.launcher.BuildConfig.DEFAULT_MAP)
    val traffic = prefs.b("traffic", true)
    val key = prefs.s("apikey", "")
    val gkey = prefs.s("gkey", "")
    // the Classic look was retired: everyone gets the Modern map
    LaunchedEffect(Unit) { if (prefs.s("maptheme", "immersive") != "immersive") prefs.put("maptheme", "immersive") }
    LaunchedEffect(Unit) { map.setTheme("immersive") }
    // your locator: 3D arrow, 3D car or the flat arrow, in the colour you picked
    val locStyle = prefs.s("locator", "arrow")
    val locColor = prefs.s(if (locStyle == "car") "carcolour" else "arrowcolour", if (locStyle == "car") "#F4F5F7" else "#F2F2F6")
    LaunchedEffect(locStyle, locColor) { map.setLocator(locStyle, locColor) }
    val routeArrows = prefs.b("routechevrons", true)
    LaunchedEffect(routeArrows) { map.setRouteArrows(routeArrows) }
    val mapFps = prefs.s("mapfps", "30").toIntOrNull() ?: 30
    LaunchedEffect(mapFps) { map.setMaxFps(mapFps) }
    val mapLite = prefs.b("maplite", true)
    LaunchedEffect(mapLite) { map.setLite(mapLite) }
    val hideTraffic = prefs.b("routetrafficonly", true)
    LaunchedEffect(hideTraffic) { map.setHideOtherTraffic(hideTraffic) }
    val arrowPct = prefs.s("arrowpct", "240").toIntOrNull() ?: 240
    LaunchedEffect(arrowPct) { map.setArrowScale(arrowPct / 100f) }
    LaunchedEffect(dark, style, traffic, key, gkey) { engine.applyStyle(dark) }
    val sat = prefs.b("satellite", false)
    val b3d = prefs.b("buildings3d", true)
    LaunchedEffect(sat, b3d) { map.setView(sat, b3d) }
    val lampGap = prefs.s("lampgap", "40").toDoubleOrNull() ?: 40.0
    LaunchedEffect(Unit) {
        map.initLampGuard()
        if (map.lampTripped) { prefs.put("lamps", false); engine.toast("Street lamps were switched off because they crashed the app. You can turn them back on in Settings.", 7000) }
    }
    val lampsOn = prefs.b("lamps", true)
    LaunchedEffect(lampsOn) { map.lampsEnabled(lampsOn) }
    LaunchedEffect(lampGap) { delay(1200); map.applyLampGap(lampGap) }
    val treesOn = prefs.b("trees", true)
    LaunchedEffect(treesOn) { map.treesEnabled(treesOn) }
    val signalsOn = prefs.b("signals", true)
    LaunchedEffect(signalsOn) { map.signalsEnabled(signalsOn) }
    // light flowing along the route line while guiding (off while the route is only being previewed)
    val flowOn = prefs.b("routeflow", true) && engine.route != null && !engine.previewing
    LaunchedEffect(flowOn) { map.setFlow(flowOn) }
    // live rain radar layer (map options)
    val radarOn = prefs.b("radar", false)
    LaunchedEffect(radarOn) { engine.setRadarOn(radarOn) }

    val scale = prefs.i("uiscale", 100).coerceIn(60, 140) / 100f
    val baseDensity = androidx.compose.ui.platform.LocalDensity.current
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(baseDensity.density * scale, baseDensity.fontScale),
    ) {
        VwTheme(dark) {
            val c = LocalVw.current
            var settings by rememberSaveable { mutableStateOf(false) }
            // a destination shared from another app brings the map back
            val tick = engine.externalTick
            LaunchedEffect(tick) { if (tick > 0) settings = false }
            // Back closes the settings; on the map it sends the app to the background instead of closing it,
            // so a route in progress keeps going (and the map is ready straight away when you come back).
            BackHandler(enabled = settings) { settings = false }
            BackHandler(enabled = !settings) { findActivity(hostCtx)?.moveTaskToBack(true) }

            Box(Modifier.fillMaxSize().background(c.bg)) {
                // first run: a short setup before the map (existing installs that are already set up skip it)
                LaunchedEffect(Unit) { if (prefs.s("place_home", "").isNotBlank() || prefs.s("habits", "").isNotBlank()) prefs.put("setupdone", true) }
                val setupDone = !prefs.b("forcesetup", false) && (prefs.b("setupdone", false) || prefs.s("place_home", "").isNotBlank() || prefs.s("habits", "").isNotBlank())
                if (!setupDone) {
                    SetupScreen(prefs, engine) { settings = false }
                } else if (settings) {
                    // the map is taken off screen while the settings are open, so it is not drawing underneath them.
                    // The settings rise and fade in over a moment, so opening them doesn't feel like a jump.
                    val inA = remember { androidx.compose.animation.core.Animatable(0f) }
                    LaunchedEffect(Unit) { inA.animateTo(1f, androidx.compose.animation.core.tween(240, easing = androidx.compose.animation.core.FastOutSlowInEasing)) }
                    Box(Modifier.fillMaxSize().graphicsLayer { alpha = inA.value; val s = 0.97f + 0.03f * inA.value; scaleX = s; scaleY = s }) {
                        SettingsScreen(prefs, engine, onClose = { settings = false })
                    }
                } else {
                    MapHost(map, Modifier.fillMaxSize())
                    // at night in 3D, stars and the real moon phase in the sky above the horizon
                    if (c.dark && engine.tilt3d && !sat && prefs.b("nightsky", true)) NightSky(Modifier.fillMaxWidth().fillMaxHeight(0.2f))
                    // in a tunnel (no GPS) the map is dimmed a little, as the car's own screen would be
                    if (engine.deadReckoning && !c.dark && prefs.b("tunneldim", true)) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)))
                    val wxCode = engine.weather?.code
                    // rain, snow or fog over the map to match the real weather where you are
                    if (prefs.b("rainfx", false) && wxCode != null) WeatherFx(wxCode, Modifier.fillMaxSize())
                    NavOverlays(engine, onSettings = { settings = true })
                    if (engine.deadReckoning) DeadReckoningChip(Modifier.align(Alignment.BottomCenter).padding(bottom = 84.dp))
                    else if (engine.cruising && engine.following && prefs.b("cruise", true)) CruisePill(engine, Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp))
                    // coming back from the settings, the map fades up from the background instead of flashing in
                    val back = remember { androidx.compose.animation.core.Animatable(1f) }
                    LaunchedEffect(Unit) { back.animateTo(0f, androidx.compose.animation.core.tween(320)) }
                    if (back.value > 0.01f) Box(Modifier.fillMaxSize().graphicsLayer { alpha = back.value }.background(c.bg))
                }
                // short messages (saved, sent, no signal...) show over everything
                val curMsg = engine.message
                val lastMsg = remember { mutableStateOf(curMsg) }
                if (curMsg != null) lastMsg.value = curMsg
                androidx.compose.animation.AnimatedVisibility(
                    visible = curMsg != null,
                    modifier = Modifier.align(if (settings) Alignment.BottomCenter else Alignment.TopCenter).padding(top = 12.dp, bottom = 18.dp),
                    enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(180)) + androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(240)) { if (settings) it / 2 else -it / 2 },
                    exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(200)),
                ) {
                    Box(
                        Modifier.shadow(10.dp, RoundedCornerShape(50)).clip(RoundedCornerShape(50)).background(navVw(c).surface).border(1.dp, navVw(c).line, RoundedCornerShape(50)).padding(horizontal = 22.dp, vertical = 11.dp),
                    ) { Text(lastMsg.value ?: "", color = navVw(c).text, fontSize = 15.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium) }
                }
                // alerts (camera, speed limit, incident, rain, break) get a large banner that is hard to miss
                if (!settings) {
                    val curAlert = engine.alert
                    val lastAlert = remember { mutableStateOf(curAlert) }
                    if (curAlert != null) lastAlert.value = curAlert
                    // landscape: centred in the gap between the turn card (left) and the round buttons (right), so it never covers them.
                    // Portrait: just above the trip card at the bottom.
                    androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxSize()) {
                        val narrow = maxWidth < 720.dp
                        Box(
                            if (narrow) Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 250.dp)
                            else Modifier.align(Alignment.TopStart).fillMaxWidth().padding(start = 412.dp, end = 290.dp, top = 16.dp),
                            contentAlignment = if (narrow) Alignment.BottomCenter else Alignment.TopCenter,
                        ) {
                            androidx.compose.animation.AnimatedVisibility(
                                visible = curAlert != null,
                                enter = androidx.compose.animation.slideInVertically(initialOffsetY = { if (narrow) it else -it }) + androidx.compose.animation.fadeIn(),
                                exit = androidx.compose.animation.slideOutVertically(targetOffsetY = { if (narrow) it else -it }) + androidx.compose.animation.fadeOut(),
                            ) { lastAlert.value?.let { AlertBanner(it) } }
                        }
                    }
                }
            }
        }
    }
}
