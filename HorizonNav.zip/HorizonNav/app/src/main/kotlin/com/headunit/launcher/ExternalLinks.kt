package com.headunit.launcher

import android.content.Intent
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

/** A destination handed over by another app: exact coordinates, or text to search for. */
class SharedTarget(val pos: LL?, val name: String, val query: String?)

/**
 * Reads destinations shared from other apps: geo: links, google.navigation: links, Google Maps web links
 * (including short maps.app.goo.gl links, which are followed to the full address) and plain shared text.
 */
object ExternalLinks {
    private val coordRe = Regex("(-?\\d{1,2}\\.\\d{3,})\\s*,\\s*(-?\\d{1,3}\\.\\d{3,})")
    private val placeRe = Regex("!3d(-?\\d+\\.\\d+)!4d(-?\\d+\\.\\d+)")
    private val atRe = Regex("@(-?\\d+\\.\\d+),(-?\\d+\\.\\d+)")
    private val urlRe = Regex("https?://\\S+")

    /** Text or link carried by an intent, or null when it is not a destination. */
    fun textOf(i: Intent?): String? {
        if (i == null) return null
        return when (i.action) {
            Intent.ACTION_VIEW -> i.dataString
            Intent.ACTION_SEND -> listOfNotNull(i.getStringExtra(Intent.EXTRA_SUBJECT), i.getStringExtra(Intent.EXTRA_TEXT)).joinToString("\n").ifBlank { null }
            else -> null
        }
    }

    private fun dec(s: String) = try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }

    private fun param(u: String, name: String): String? {
        val q = u.substringAfter('?', "").substringBefore('#')
        for (part in q.split('&')) {
            val k = part.substringBefore('=')
            if (k.equals(name, true)) return dec(part.substringAfter('=', "")).ifBlank { null }
        }
        return null
    }

    private fun ll(s: String?): LL? {
        val m = coordRe.find(s ?: return null) ?: return null
        val a = m.groupValues[1].toDoubleOrNull() ?: return null
        val b = m.groupValues[2].toDoubleOrNull() ?: return null
        if (a !in -90.0..90.0 || b !in -180.0..180.0 || (a == 0.0 && b == 0.0)) return null
        return LL(a, b)
    }

    /** Follows a short link's redirects to the full Google Maps address (blocking, needs signal). */
    private fun expand(url: String): String {
        var u = url
        repeat(5) {
            val host = try { URL(u).host.lowercase() } catch (e: Exception) { return u }
            if (!(host.endsWith("goo.gl") || host == "g.co")) return u
            val c = URL(u).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 8000; c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) HorizonNav/1.0")
            val loc = c.getHeaderField("Location")
            c.disconnect()
            if (loc.isNullOrBlank()) return u
            u = if (loc.startsWith("http")) loc else URL(URL(u), loc).toString()
        }
        return u
    }

    private fun isGoogle(u: String): Boolean = try {
        val h = URL(u).host.lowercase()
        Regex("^(www\\.|maps\\.)?google\\.[a-z.]{2,8}$").matches(h)
    } catch (e: Exception) { false }

    /**
     * The coordinates of the place a Google Maps link shows, read from the Google Maps page itself, for links that only carry an
     * address (e.g. "?q=Av. Tiúba, 1810B&ftid=…"), so the route goes straight there instead of re-searching the text.
     * Null when it can't be read (no signal, or the page changed). Blocking.
     */
    private fun pagePos(u: String): LL? {
        if (!isGoogle(u)) return null
        return try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = true
            c.connectTimeout = 8000; c.readTimeout = 10000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36")
            c.setRequestProperty("Accept-Language", "pt-BR,pt;q=0.9")
            val html = c.inputStream.use { s ->
                val b = ByteArray(1_500_000); var n = 0
                while (n < b.size) { val r = s.read(b, n, b.size - n); if (r < 0) break; n += r }
                String(b, 0, n, Charsets.UTF_8)
            }
            val fin = c.url.toString()
            c.disconnect()
            fun ok(a: String, b: String): LL? {
                val la = a.toDoubleOrNull() ?: return null; val lo = b.toDoubleOrNull() ?: return null
                return if (la in -90.0..90.0 && lo in -180.0..180.0 && !(la == 0.0 && lo == 0.0)) LL(la, lo) else null
            }
            // the exact place (in the final address or in the page), then the static preview image's centre, then the page's start view
            placeRe.find(fin)?.let { m -> ok(m.groupValues[1], m.groupValues[2])?.let { return it } }
            placeRe.find(html)?.let { m -> ok(m.groupValues[1], m.groupValues[2])?.let { return it } }
            Regex("staticmap\\?center=(-?\\d+\\.\\d+)(?:%2C|,)(-?\\d+\\.\\d+)").find(html)?.let { m -> ok(m.groupValues[1], m.groupValues[2])?.let { return it } }
            atRe.find(fin)?.let { m -> ok(m.groupValues[1], m.groupValues[2])?.let { return it } }
            Regex("APP_INITIALIZATION_STATE=\\[\\[\\[-?\\d+(?:\\.\\d+)?,(-?\\d+\\.\\d+),(-?\\d+\\.\\d+)\\]").find(html)?.let { m -> ok(m.groupValues[2], m.groupValues[1])?.let { return it } }
            null
        } catch (e: Exception) { null }
    }

    /** Works out where to go (blocking: may follow a short link over the network). */
    fun parse(raw: String): SharedTarget? {
        val text = raw.trim()
        if (text.isEmpty()) return null
        val lower = text.lowercase()
        if (lower.startsWith("geo:")) {
            val q = param(text, "q")
            val label = q?.let { Regex("\\(([^)]*)\\)").find(it)?.groupValues?.get(1) }.orEmpty()
            val qp = ll(q)
            if (qp != null) return SharedTarget(qp, label.ifBlank { "Local compartilhado" }, null)
            if (!q.isNullOrBlank()) return SharedTarget(null, q, q.replace(Regex("\\([^)]*\\)"), "").trim())
            val p = ll(text.removePrefix("geo:").substringBefore('?'))
            return if (p != null) SharedTarget(p, "Local compartilhado", null) else null
        }
        if (lower.startsWith("google.navigation:")) {
            val q = param(text.replaceFirst(":", ":?"), "q") ?: text.substringAfter(':').substringAfter("q=").substringBefore('&').let { dec(it) }
            val p = ll(q)
            return if (p != null) SharedTarget(p, "Local compartilhado", null) else if (q.isNotBlank()) SharedTarget(null, q, q) else null
        }
        // a link (on its own, or inside shared text such as "Place name\nAddress\nhttps://maps.app.goo.gl/…")
        val link = urlRe.find(text)?.value
        val before = if (link != null) text.substringBefore(link).trim().lines().firstOrNull { it.isNotBlank() }?.trim().orEmpty() else ""
        if (link != null) {
            var u = try { expand(link) } catch (e: Exception) { link }
            // a cookie-consent stop on the way: the real address is in its "continue"
            if (try { URL(u).host.lowercase().startsWith("consent.") } catch (e: Exception) { false }) u = param(u, "continue") ?: u
            val name = Regex("/place/([^/@]+)").find(u)?.groupValues?.get(1)?.let { dec(it).replace('+', ' ') }.orEmpty().ifBlank { before }
            placeRe.find(u)?.let { m -> return SharedTarget(LL(m.groupValues[1].toDouble(), m.groupValues[2].toDouble()), name.ifBlank { "Local compartilhado" }, null) }
            for (k in listOf("daddr", "destination", "q", "query", "ll", "center")) {
                val v = param(u, k) ?: continue
                val p = ll(v)
                if (p != null) return SharedTarget(p, name.ifBlank { "Local compartilhado" }, null)
                if (k != "ll" && k != "center") {
                    // only an address in the link: take the exact spot from Google's page, and search the text only if that fails
                    pagePos(u)?.let { return SharedTarget(it, name.ifBlank { v }, null) }
                    return SharedTarget(null, name.ifBlank { v }, v)
                }
            }
            atRe.find(u)?.let { m -> return SharedTarget(LL(m.groupValues[1].toDouble(), m.groupValues[2].toDouble()), name.ifBlank { "Local compartilhado" }, null) }
            pagePos(u)?.let { return SharedTarget(it, name.ifBlank { before.ifBlank { "Local compartilhado" } }, null) }
            if (name.isNotBlank()) return SharedTarget(null, name, name)
            if (before.isNotBlank()) return SharedTarget(null, before, before)
            return null
        }
        ll(text)?.let { return SharedTarget(it, "Local compartilhado", null) }
        // plain text: search for it (the first line is usually the name, the rest the address)
        val q = text.lines().map { it.trim() }.filter { it.isNotEmpty() }.take(2).joinToString(", ")
        return if (q.length >= 2) SharedTarget(null, q, q.take(120)) else null
    }
}
