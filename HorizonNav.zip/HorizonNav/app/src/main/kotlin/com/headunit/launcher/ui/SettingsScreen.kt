package com.headunit.launcher.ui

import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.BuildConfig
import com.headunit.launcher.FuelFinder
import com.headunit.launcher.Geo
import com.headunit.launcher.NavEngine
import com.headunit.launcher.OfflinePlaces
import com.headunit.launcher.Place
import com.headunit.launcher.Prefs
import com.headunit.launcher.Zones
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private class Section(val title: String, val sub: String, val icon: ImageVector, val tint: Color)

private val sections = listOf(
    Section("Map", "Look, layers and colours", Icons.Rounded.Map, Color(0xFF4C8DFF)),
    Section("Navigation", "Routes and what's on screen", Icons.Rounded.Navigation, Color(0xFF12A4B4)),
    Section("Alerts & sound", "Voice, cameras and warnings", Icons.Rounded.NotificationsActive, Color(0xFFEA4335)),
    Section("Places & trips", "Home, work, favourites, trip log", Icons.Rounded.Star, Color(0xFFF29900)),
    Section("Fuel & sharing", "Fuel prices, cost, share ETA", Icons.Rounded.LocalGasStation, Color(0xFF34A853)),
    Section("Offline maps", "Maps and routes with no signal", Icons.Rounded.CloudDownload, Color(0xFF8E5CF0)),
    Section("Display", "Brightness, size, units, speed", Icons.Rounded.BrightnessMedium, Color(0xFFFFB020)),
    Section("Search & keys", "Search area and map accounts", Icons.Rounded.VpnKey, Color(0xFF9CA4BF)),
    Section("About & backup", "Permissions, sharing, backup", Icons.Rounded.Info, Color(0xFF9CA4BF)),
)

/** Every setting in one screen: sections on the left, the chosen section on the right, in the map screen's soft style. */
@Composable
fun SettingsScreen(prefs: Prefs, engine: NavEngine, onClose: () -> Unit) {
    val base = LocalVw.current
    val v = remember(base) { navVw(base) }
    CompositionLocalProvider(LocalVw provides v) { SettingsBody(prefs, engine, onClose) }
}

@Composable
private fun SettingsBody(prefs: Prefs, engine: NavEngine, onClose: () -> Unit) {
    val c = LocalVw.current
    var cat by rememberSaveable { mutableIntStateOf(0) }
    // portrait / narrow: one pane at a time (the section list, or the open section with a back arrow)
    val narrowS = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp < 720
    var showList by rememberSaveable { mutableStateOf(true) }
    androidx.activity.compose.BackHandler(enabled = narrowS && !showList) { showList = true }
    var query by remember { mutableStateOf("") }
    var highlight by remember { mutableStateOf<String?>(null) }
    val focus = androidx.compose.ui.platform.LocalFocusManager.current
    val words = query.trim().lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }
    val matches = remember(query) {
        if (words.isEmpty()) emptyList() else settingsIndex.filter { r ->
            val hay = (r.title + " " + r.sub + " " + r.group + " " + sections[r.section].title).lowercase()
            words.all { hay.contains(it) }
        }.sortedBy { if (it.title.lowercase().startsWith(words[0])) 0 else if (it.title.lowercase().contains(words[0])) 1 else 2 }.take(40)
    }
    Row(Modifier.fillMaxSize().background(c.bg).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        // the list of sections
        if (!narrowS || showList) Column(
            Modifier.then(if (narrowS) Modifier.fillMaxWidth() else Modifier.width(290.dp)).fillMaxHeight().clip(RoundedCornerShape(28.dp)).background(c.panel).border(1.dp, c.line, RoundedCornerShape(28.dp)).verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 4.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).clip(CircleShape).background(c.tile).pressClick(onClose), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.ArrowBack, "Back to the map", tint = c.text, modifier = Modifier.size(24.dp))
                }
                Text("Settings", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 14.dp))
            }
            // search every setting by name
            Row(
                Modifier.fillMaxWidth().padding(bottom = 8.dp).height(46.dp).clip(RoundedCornerShape(50)).background(c.tile).padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Search, null, tint = c.sub, modifier = Modifier.size(20.dp))
                Box(Modifier.weight(1f).padding(start = 10.dp), contentAlignment = Alignment.CenterStart) {
                    if (query.isEmpty()) Text("Search settings", color = c.sub, fontSize = 15.sp)
                    androidx.compose.foundation.text.BasicTextField(
                        value = query, onValueChange = { query = it; highlight = null }, singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = c.text, fontSize = 15.sp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(c.accent),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                        keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { focus.clearFocus() }),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (query.isNotEmpty()) Icon(Icons.Rounded.Close, "Clear", tint = c.sub, modifier = Modifier.size(20.dp).clickable { query = ""; focus.clearFocus() })
            }
            if (words.isNotEmpty()) {
                if (matches.isEmpty()) Text("Nothing matches \"${query.trim()}\"", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(10.dp))
                matches.forEach { r ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable {
                            cat = r.section; highlight = r.title; query = ""; focus.clearFocus(); showList = false
                        }.padding(horizontal = 12.dp, vertical = 9.dp),
                    ) {
                        Text(r.title, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(sections[r.section].title + (if (r.group.isNotBlank()) " · " + r.group else ""), color = c.sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            } else sections.forEachIndexed { i, s ->
                val on = i == cat
                val rowBg by androidx.compose.animation.animateColorAsState(if (on) c.accent.copy(alpha = 0.16f) else Color.Transparent, androidx.compose.animation.core.tween(200), label = "secBg")
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(rowBg).clickable { cat = i; highlight = null; showList = false }.padding(horizontal = 10.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(38.dp).clip(CircleShape).background(s.tint.copy(alpha = if (on) 0.26f else 0.16f)), contentAlignment = Alignment.Center) {
                        Icon(s.icon, null, tint = s.tint, modifier = Modifier.size(21.dp))
                    }
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(s.title, color = if (on) c.accent else c.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text(s.sub, color = c.sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        // the chosen section (each opens at the top), sliding up gently into place
        if (!narrowS || !showList) androidx.compose.animation.AnimatedContent(
            targetState = cat,
            modifier = Modifier.weight(1f).fillMaxHeight(),
            transitionSpec = {
                (androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(220, delayMillis = 60)) +
                    androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(260)) { it / 24 }) togetherWith
                    androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120))
            },
            label = "section",
        ) { cat ->
          CompositionLocalProvider(LocalSettingHighlight provides highlight) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 4.dp, vertical = 4.dp)) {
                if (narrowS) Row(Modifier.padding(bottom = 6.dp).clip(RoundedCornerShape(50)).clickable { showList = true }.padding(end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(c.tile), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.ArrowBack, "All settings", tint = c.text, modifier = Modifier.size(22.dp))
                    }
                    Text("Settings", color = c.sub, fontSize = 15.sp, modifier = Modifier.padding(start = 10.dp))
                }
                Text(sections[cat].title, color = c.text, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp, top = 6.dp))
                Text(sections[cat].sub, color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp, bottom = 16.dp))
                Column(Modifier.widthIn(max = 820.dp)) {
                    when (cat) {
                        0 -> MapSection(prefs)
                        1 -> NavigationSection(prefs)
                        2 -> AlertsSection(prefs, engine)
                        3 -> PlacesSection(engine)
                        4 -> FuelSection(prefs)
                        5 -> { OfflineMapsContent(prefs, engine); OfflinePlacesGroup(engine) }
                        6 -> DisplaySection(prefs, engine)
                        7 -> KeysSection(prefs, engine)
                        else -> AboutSection(prefs)
                    }
                }
            }
          }
        }
    }
}

// ------------------------------------------------------------------ Map

@Composable
private fun MapSection(prefs: Prefs) {
    SGroup("Look") {
        SChoice("Day and night", listOf("auto" to "Auto", "day" to "Day", "night" to "Night", "sun" to "Sun times"), prefs.s("theme", "auto"),
            "Auto follows the system's dark mode; Sun times switches at sunrise and sunset where you are") { prefs.put("theme", it) }
        SChoice("Map colours", listOf("immersive" to "Modern", "classic" to "Classic"), prefs.s("maptheme", "immersive"),
            "Modern: soft colours, a blue route with traffic on it and a chunky arrow") { prefs.put("maptheme", it) }
        SChoice("Map source", listOf("tomtom" to "TomTom", "osm" to "OpenStreetMap", "google" to "Google"), prefs.s("mapstyle", "tomtom"),
            "Google needs its own key (Search & keys)") { prefs.put("mapstyle", it) }
        SToggle(prefs, "Glass panels", "glass", true, "See-through cards tinted by the map. Off gives solid cards")
    }
    SGroup("On the map") {
        SToggle(prefs, "Live traffic", "traffic", true)
        SToggle(prefs, "Satellite", "satellite", false)
        SToggle(prefs, "3D buildings", "buildings3d", true)
        SToggle(prefs, "Traffic lights", "signals", true)
        SToggle(prefs, "Speed cameras and roadworks", "hazardicons", true)
        SToggle(prefs, "Street lamps at night", "lamps", true)
        if (prefs.b("lamps", true)) SSlider("Street lamp spacing", prefs.s("lampgap", "40").toFloatOrNull() ?: 40f, 15f..120f, " m", reset = 40f) { prefs.put("lampgap", it.toString()) }
        SToggle(prefs, "Weather effects on the map", "rainfx", false, "Rain, snow or fog to match the weather where you are")
        SToggle(prefs, "Rain radar layer", "radar", false, "Live radar from RainViewer, under the route")
    }
    SGroup("Your arrow") {
        SSlider("Arrow size", prefs.s("arrowpct", "240").toFloatOrNull() ?: 240f, 100f..500f, "%", reset = 240f) { prefs.put("arrowpct", it.toString()) }
    }
}

// ------------------------------------------------------------------ Navigation

@Composable
private fun NavigationSection(prefs: Prefs) {
    SGroup("Routes", footer = "Changes apply to the next route you plan. \"Avoid this road\" on the map only lasts for that trip.") {
        SToggle(prefs, "Avoid toll roads", "avoid_toll", false)
        SToggle(prefs, "Avoid motorways", "avoid_motorway", false)
        SToggle(prefs, "Avoid ferries", "avoid_ferry", false)
        SToggle(prefs, "Avoid unpaved roads", "avoid_unpaved", true)
        SToggle(prefs, "Avoid Clean Air Zones and ULEZ", "avoidzones", false, "A zone you start or finish in can't be avoided")
        SToggle(prefs, "Eco routes", "route_eco", false, "Fuel-efficient instead of fastest")
        ZonesItem()
    }
    SGroup("While you drive") {
        SToggle(prefs, "Offer faster routes", "fasterroute", true)
        if (prefs.b("fasterroute", true)) SToggle(prefs, "Keep other routes on the map", "livealts", true, "Grey lines with +/− minutes you can tap any time. Off shows a \"Faster route found\" card instead")
        SToggle(prefs, "Fly along a new route", "cinematic", true, "A 3-second 3D fly-through before the overview. Tap the map to skip")
        SToggle(prefs, "Arrival moment", "arrivalfx", true, "The camera swoops to your destination and shows the nearest parking")
        SToggle(prefs, "Suggest where you're going", "predict", true, "With the live journey time, including home and work at your usual times")
        SToggle(prefs, "Weather on the route", "routewx", true)
        SToggle(prefs, "Fewer buttons while driving", "drivesimple", true)
        SToggle(prefs, "Lock typing while driving", "drivelock", true, "Voice search still works")
    }
    SGroup("On screen") {
        SToggle(prefs, "Route bar on the trip card", "routebar", true, "Traffic, cameras, services and stops, with your progress")
        SToggle(prefs, "Next services card", "servicescard", true)
        SToggle(prefs, "Your speed next to the limit", "mapspeed", true)
        SToggle(prefs, "Speedometer ring", "speedring", true, "Fills towards the limit, turning amber then red")
        SToggle(prefs, "Hazard radar", "hazardradar", false, "The next 2 miles: bends, crossings, schools, bumps, cameras and checks")
        SToggle(prefs, "UK road signs on the turn card", "uksigns", true)
        SToggle(prefs, "Road and heading when driving without a route", "cruise", true)
        SToggle(prefs, "Dim the map in tunnels", "tunneldim", true)
        SToggle(prefs, "Living turn card", "livecard", true, "Grows and glows as the turn gets close")
        SToggle(prefs, "Flowing light along the route", "routeflow", true)
        SToggle(prefs, "Night sky in 3D", "nightsky", true, "Twinkling stars above the horizon after dark")
    }
    SGroup("Junctions and lanes") {
        SToggle(prefs, "Lane guidance on the turn card", "lanestrip", true)
        if (prefs.b("lanestrip", true)) SChoice("Lane guidance style", listOf("hero" to "Lane hero view", "classic" to "Classic strip"), prefs.s("lanestyle", "hero"),
            if (prefs.s("lanestyle", "hero") == "hero") "Before junctions with two or more lanes the turn card shows a big lane picture with yours lit" else "The small lane strip at every junction") { prefs.put("lanestyle", it) }
        SToggle(prefs, "Lanes painted on the map", "lanemap", true)
        SToggle(prefs, "Zoom in on lanes before a junction", "laneview", true)
        SToggle(prefs, "Flatten the map to 2D at turns", "turn2d", true)
        SToggle(prefs, "Tilt with speed", "speedtilt", true, "Flatter when slow, a longer view at speed")
        SToggle(prefs, "Keep the arrow on the road with no route", "snaproad", true)
        SToggle(prefs, "Only show traffic on your route while navigating", "routetrafficonly", true)
    }
    SGroup("Demo") {
        SToggle(prefs, "Demo drive button", "demo", false, "Plays a route back so you can try the guidance while parked")
    }
}

/** What the app knows about clean air zones, with a button to download them again. */
@Composable
private fun ZonesItem() {
    val ctx = LocalContext.current
    val sc = rememberCoroutineScope()
    var st by remember { mutableStateOf(Zones.all(ctx).let { z -> if (z.isEmpty()) "Not downloaded yet" else "${z.size} zones: " + z.joinToString(", ") { it.name }.take(140) }) }
    var busy by remember { mutableStateOf(false) }
    SItem("Clean air zones on this unit", st) {
        SButton(if (busy) "Updating…" else "Update") {
            if (!busy) { busy = true; sc.launch { withContext(Dispatchers.IO) { Zones.fetch(ctx) }; st = Zones.status; busy = false } }
        }
    }
}

// ------------------------------------------------------------------ Alerts & sound

@Composable
private fun AlertsSection(prefs: Prefs, engine: NavEngine) {
    val ctx = LocalContext.current
    SGroup("Sound") {
        SChoice("Spoken guidance", listOf("0" to "All", "1" to "Alerts only", "2" to "Off"), engine.soundMode.toString(),
            "Alerts only skips turn-by-turn but still speaks cameras, limits and hazards") { prefs.put("soundmode", it.toInt()) }
        SToggle(prefs, "Smarter directions", "smartvoice", true, "Junction numbers and sign destinations, the next move when it comes straight after, and fewer early prompts on roads you drive a lot")
        SItem("Voice and language", "Uses the system text-to-speech voice") { SButton("Open") { openSystemSettings(ctx, "com.android.settings.TTS_SETTINGS") } }
        SItem("Volume") { SButton("Open") { openSystemSettings(ctx, Settings.ACTION_SOUND_SETTINGS) } }
    }
    SGroup("Speed") {
        SToggle(prefs, "Warn when over the limit", "speedwarn", true)
        if (prefs.b("speedwarn", true)) SChoice("Warn when over by", listOf("0", "5", "10").map { it to it + if (engine.imperial) " mph" else " km/h" }, prefs.s("warntol", "5")) { prefs.put("warntol", it) }
        SToggle(prefs, "Say when the limit changes", "limitchange", true)
        SToggle(prefs, "Speed cameras", "cameras", true)
        SToggle(prefs, "Average speed checks", "avgzones", true, "Shows your average against the limit")
    }
    SGroup("On the road", footer = "Average speed checks, speed bumps, schools and clean air zones come from OpenStreetMap, so some may be missing.") {
        SToggle(prefs, "Roadworks and incidents", "incidents", true)
        SToggle(prefs, "Wrong-way warning", "wrongway", true, "If you turn the wrong way into a one-way street")
        SToggle(prefs, "Speed bumps", "bumps", true)
        SToggle(prefs, "Schools at school-run times", "schools", true)
        SToggle(prefs, "Clean Air Zones and ULEZ", "zonewarn", true)
        SToggle(prefs, "Break reminder after 2 hours", "breakremind", true)
    }
    SGroup("Your reports", footer = "Make a report from the map options button. Reports stay on this unit and fade after a few hours.") {
        SToggle(prefs, "Warn about reports ahead", "policealerts", true)
        SItem("Reports still active", "${engine.reportsActive().size}") { SButton("Clear", danger = true) { engine.clearReports() } }
    }
}

// ------------------------------------------------------------------ Places & trips

@Composable
private fun PlaceItem(label: String, p: Place?, onClear: () -> Unit) {
    SItem(label, p?.let { it.name + (if (it.sub.isNotBlank()) ", " + it.sub else "") } ?: "Not set") { if (p != null) SButton("Clear", danger = true, onClick = onClear) }
}

@Composable
private fun PlacesSection(engine: NavEngine) {
    val pl = engine.places
    SGroup("Saved places", footer = "To set Home or Work, tap Set home / Set work under the search bar, or the house or briefcase on the route options.") {
        PlaceItem("Home", pl.slot("home")) { pl.clearSlot("home") }
        PlaceItem("Work", pl.slot("work")) { pl.clearSlot("work") }
    }
    // your own labelled places: rename, reorder or remove
    val raw = engine.prefs.s("places_custom", "")
    val mine = remember(raw) { pl.customs() }
    var renaming by remember { mutableStateOf<String?>(null) }
    var adding by remember { mutableStateOf(false) }
    SGroup("Your places", footer = "Shown as pills under the search bar, after Home and Work. Add one with the + pill there, or the bookmark on the route options.") {
        if (mine.isEmpty()) SNote("No places of your own yet.")
        mine.forEachIndexed { i, lp ->
            if (renaming == lp.label) {
                var t by remember(lp.label) { mutableStateOf(lp.label) }
                SItem("Rename ${lp.label}") {
                    SField(t, { t = it.take(24) }, width = 220.dp)
                    SButton("Save", primary = true) { pl.renameCustom(lp.label, t); renaming = null }
                }
            } else SItem(lp.label, lp.place.name + if (lp.place.sub.isNotBlank()) ", " + lp.place.sub else "") {
                if (i > 0) SButton("↑") { pl.moveCustom(lp.label, -1) }
                SButton("Rename") { renaming = lp.label }
                SButton("Remove", danger = true) { pl.removeCustom(lp.label) }
            }
        }
        SItem("Add a place") { SButton("Add", primary = true) { adding = true } }
    }
    if (adding) AddPlaceDialog(engine, null) { adding = false }
    val favs = pl.favourites()
    SGroup("Favourites") {
        if (favs.isEmpty()) SNote("No favourites yet. Tap the star on a destination to add one.")
        favs.forEach { f -> SItem(f.name, f.sub) { SButton("Remove") { pl.toggleFavourite(f) } } }
        if (favs.size > 1) SItem("Remove every favourite") { SButton("Remove all", danger = true) { pl.clearFavourites() } }
    }
    SGroup("History") {
        SItem("Recent destinations", "${pl.recents().size} recent, plus places remembered for searching without signal") {
            SButton("Clear", danger = true) { pl.clearHistory(); engine.toast("History cleared", 2000) }
        }
    }
    TripsGroup(engine)
}

@Composable
private fun TripsGroup(engine: NavEngine) {
    var shown by remember { mutableStateOf(engine.trips.all()) }
    val fmt = java.text.SimpleDateFormat("EEE d MMM, HH:mm", java.util.Locale.UK)
    val k = if (engine.imperial) 2.23694 else 3.6
    val unit = if (engine.imperial) "mph" else "km/h"
    SGroup("Trip log") {
        if (shown.isEmpty()) SNote("No trips yet. Every drive is recorded here when you park.")
        else SItem("${shown.size} trips", Geo.fmtDist(shown.sumOf { it.dist }, engine.imperial) + " in all") { SButton("Clear", danger = true) { engine.trips.clear(); shown = emptyList() } }
        shown.take(50).forEach { t ->
            val mins = ((t.end - t.start) / 60000L).toInt()
            SItem(
                fmt.format(java.util.Date(t.start)) + (if (t.to.isNotBlank()) " → ${t.to}" else ""),
                "${Geo.fmtDur(mins * 60.0)} · moving ${Geo.fmtDur(t.moving.toDouble())} · top ${Math.round(t.maxSpeed * k)} $unit",
            ) { Text(Geo.fmtDist(t.dist, engine.imperial), color = LocalVw.current.text, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

// ------------------------------------------------------------------ Fuel & sharing

@Composable
private fun FuelSection(prefs: Prefs) {
    val ctx = LocalContext.current
    val sc = rememberCoroutineScope()
    SGroup("Fuel prices", footer = "Live prices come from the government's Fuel Finder scheme. It's free: on gov.uk search \"Fuel Finder\", register as an information recipient with a GOV.UK One Login, then paste the client ID and secret here. Without them the fuel list still works, just without prices.") {
        SChoice("Your fuel", listOf("E10" to "Unleaded", "E5" to "Super", "B7" to "Diesel"), prefs.s("fueltype", "E10")) { prefs.put("fueltype", it) }
        SToggle(prefs, "Suggest a fuel stop on long trips", "smartfuel", true, "Over about 95 miles, the best-value station along the way")
        SFieldItem("Client ID", prefs.s("ffid", "")) { prefs.put("ffid", it.trim()) }
        SFieldItem("Client secret", prefs.s("ffsecret", ""), password = true) { prefs.put("ffsecret", it.trim()) }
        var st by remember { mutableStateOf(FuelFinder.status) }
        var busy by remember { mutableStateOf(false) }
        SItem("Prices", st.ifBlank { if (FuelFinder.configured(prefs)) "Not downloaded yet" else "Add your details first" }) {
            SButton(if (busy) "Updating…" else "Update now", primary = true) {
                if (!busy && FuelFinder.configured(prefs)) {
                    busy = true; st = "Downloading stations and prices (the first time takes a minute)…"
                    sc.launch {
                        try { withContext(Dispatchers.IO) { FuelFinder.refresh(ctx, prefs, force = true) } } catch (e: Exception) { }
                        st = FuelFinder.status; busy = false
                    }
                }
            }
        }
        SItem("Spotted a wrong price?") { SButton("Report it") { openSystemSettings(ctx, android.content.Intent.ACTION_VIEW, android.net.Uri.parse(FuelFinder.REPORT_URL)) } }
    }
    SGroup("Fuel cost on the route options", footer = "With both filled in, each route shows roughly what it will cost in fuel.") {
        SFieldItem("Fuel economy (miles per gallon)", prefs.s("fuelmpg", ""), placeholder = "e.g. 45", number = true) { s -> prefs.put("fuelmpg", s.filter { it.isDigit() || it == '.' }.take(5)) }
        SFieldItem("Fuel price (pence per litre)", prefs.s("fuelppl", ""), placeholder = "e.g. 139.9", number = true) { s -> prefs.put("fuelppl", s.filter { it.isDigit() || it == '.' }.take(6)) }
    }
    SGroup("Share your ETA", footer = "The share button on the trip card texts your arrival time and a map link. On a head unit without a SIM it opens your messaging app instead.") {
        val pickEta = rememberEtaContactPicker(prefs)
        SItem("Send it to", prefs.s("etaname", "").ifBlank { "No one chosen yet" }) {
            SButton(if (prefs.s("etanum", "").isBlank()) "Choose" else "Change") { pickEta() }
            if (prefs.s("etanum", "").isNotBlank()) SButton("Clear", danger = true) { prefs.put("etanum", ""); prefs.put("etaname", "") }
        }
    }
}

/** UK town and village names, so search works with no signal even without the full pack. */
@Composable
private fun OfflinePlacesGroup(engine: NavEngine) {
    val ctx = LocalContext.current
    val sc = rememberCoroutineScope()
    var state by remember { mutableStateOf(if (OfflinePlaces.installed(ctx)) "Installed (%.1f MB)".format(OfflinePlaces.sizeMb(ctx)) else "Not downloaded") }
    var busy by remember { mutableStateOf(false) }
    SGroup("Place names", footer = "A small download of UK towns and villages, so you can search for them without signal even without the full pack.") {
        SItem("Towns and villages", state) {
            SButton(if (busy) "Downloading…" else if (OfflinePlaces.installed(ctx)) "Update" else "Download", primary = !OfflinePlaces.installed(ctx)) {
                if (!busy) {
                    busy = true; state = "Downloading (needs signal)…"
                    sc.launch {
                        try {
                            val n = withContext(Dispatchers.IO) { OfflinePlaces.download(ctx) }
                            state = "Installed: $n places"; engine.toast("Offline places ready", 3000)
                        } catch (e: Exception) { state = "Failed: ${e.message}" } finally { busy = false }
                    }
                }
            }
            if (OfflinePlaces.installed(ctx) && !busy) SButton("Remove", danger = true) { OfflinePlaces.delete(ctx); state = "Not downloaded" }
        }
    }
}

// ------------------------------------------------------------------ Display

@Composable
private fun DisplaySection(prefs: Prefs, engine: NavEngine) {
    SGroup("Screen") {
        SSlider("Brightness", prefs.i("bright", 100).toFloat(), 10f..100f, "%", sub = "100% leaves it to the system", live = true) { prefs.put("bright", it) }
        SToggle(prefs, "Dim the screen at night", "dimnight", false)
        SToggle(prefs, "Keep the screen on", "keepon", true)
        SSlider("Text and button size", prefs.i("uiscale", 100).toFloat(), 60f..140f, "%", steps = 15, reset = 100f) { prefs.put("uiscale", it) }
    }
    SGroup("Units") {
        SChoice("Distance and speed", listOf("mi" to "Miles", "km" to "Kilometres"), if (engine.imperial) "mi" else "km") { prefs.put("distunit", it) }
        SChoice("Temperature", listOf("C" to "°C", "F" to "°F"), if (isImperial(prefs)) "F" else "C") { prefs.put("tempunit", it) }
    }
    SGroup("Smoothness", footer = "Lower these if the map feels slow or the head unit gets warm. Sharpness and fast drawing apply after restarting the app.") {
        SChoice("Map sharpness", listOf("100" to "Full", "80" to "Balanced", "65" to "Light", "50" to "Lowest"), prefs.s("mapres", "80")) { prefs.put("mapres", it) }
        SChoice("Frame rate", listOf("20" to "20", "30" to "30", "45" to "45", "60" to "60"), prefs.s("mapfps", "30"), "Lower is lighter on the head unit") { prefs.put("mapfps", it) }
        SToggle(prefs, "Fast map drawing", "mapfast", true)
        SToggle(prefs, "Light map", "maplite", true, "Hides points of interest and the route glow, and lowers the tilt")
    }
}

// ------------------------------------------------------------------ Search & keys

@Composable
private fun KeysSection(prefs: Prefs, engine: NavEngine) {
    SGroup("Search") {
        SChoice("Search results", listOf("GB" to "UK first", "" to "Anywhere"), prefs.s("country", "GB")) { prefs.put("country", it) }
    }
    SGroup("Map accounts", footer = "Search also finds places you saved or went to before. With no signal, routes, the map and search come from the offline pack.") {
        SFieldItem("TomTom API key", prefs.s("apikey", ""), if (engine.hasKey) "Using the key built into this app unless you paste another" else "Needed for online search, routing and traffic",
            placeholder = "Paste a key") { prefs.put("apikey", it.trim()) }
        SFieldItem("Google Maps API key", prefs.s("gkey", ""), "Only for the Google map source (Map Tiles API)", placeholder = "Paste a key") { prefs.put("gkey", it.trim()) }
    }
}

// ------------------------------------------------------------------ About & backup

@Composable
private fun AboutSection(prefs: Prefs) {
    val ctx = LocalContext.current
    val pkg = android.net.Uri.parse("package:" + ctx.packageName)
    SGroup("Horizon Nav") {
        SItem("Version", BuildConfig.VERSION_NAME)
        SItem("Setup", "Go through the first-run steps again: map key, home and work, offline maps, permissions") { SButton("Run setup") { prefs.put("setupdone", false); prefs.put("forcesetup", true) } }
    }
    SGroup("Permissions", footer = "While a route is running, guidance carries on when you switch apps and a notification shows. Allow notifications so it can appear.") {
        val hasLoc = ctx.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        SItem("Location", if (hasLoc) "Allowed" else "Not allowed: navigation needs it") {
            SButton("App permissions", primary = !hasLoc) { openSystemSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg) }
        }
        SItem("Location services") { SButton("Open") { openSystemSettings(ctx, Settings.ACTION_LOCATION_SOURCE_SETTINGS) } }
    }
    SGroup("Places from other apps", footer = "Share a place to Horizon Nav from Google Maps, WhatsApp, Contacts or a web page and it plans the route. To open Google Maps links here straight away, tap Open by default and add the links.") {
        SItem("Google Maps links") {
            SButton("Open by default") {
                if (android.os.Build.VERSION.SDK_INT >= 31) openSystemSettings(ctx, Settings.ACTION_APP_OPEN_BY_DEFAULT_SETTINGS, pkg)
                else openSystemSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)
            }
        }
    }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(prefs.exportJson().toByteArray()) }
                true
            } catch (e: Exception) { false }
            android.widget.Toast.makeText(ctx, if (ok) "Backup saved" else "Could not save the backup", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val msg = try {
                val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                "Restored ${prefs.importJson(text)} settings"
            } catch (e: Exception) { "That file is not a valid backup" }
            android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show()
        }
    }
    SGroup("Backup", footer = "Includes settings and saved places, not the API key or the offline pack. A backup from Horizon Launcher can be restored here too.") {
        SItem("Settings and saved places") {
            SButton("Back up") { exporter.launch("horizon-nav-backup.json") }
            SButton("Restore") { importer.launch(arrayOf("application/json", "text/plain", "*/*")) }
        }
    }
    val cf = java.io.File(ctx.filesDir, "lastcrash.txt")
    var rep by remember { mutableStateOf(if (cf.exists()) cf.readText() else "") }
    if (rep.isNotBlank()) SGroup("Problem report", footer = "The app closed unexpectedly last time. Send a photo of this so it can be fixed.") {
        Text(rep.take(900), color = LocalVw.current.text, fontSize = 10.sp, modifier = Modifier.padding(vertical = 6.dp))
        SItem("Clear the report") { SButton("Clear") { cf.delete(); rep = "" } }
    }
}
