package com.headunit.launcher.ui

import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.BuildConfig
import com.headunit.launcher.FuelFinder
import com.headunit.launcher.Geo
import com.headunit.launcher.NavEngine
import com.headunit.launcher.OfflinePlaces
import com.headunit.launcher.Place
import com.headunit.launcher.Prefs
import com.headunit.launcher.mapSource
import com.headunit.launcher.mapDetail
import com.headunit.launcher.setApiKey
import com.headunit.launcher.Zones
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private class Section(val title: String, val sub: String, val icon: ImageVector, val tint: Color)

private val sections = listOf(
    Section("Mapa", "Visual, camadas e cores", Icons.Rounded.Map, Color(0xFF4C8DFF)),
    Section("Navegação", "Rotas e o que aparece na tela", Icons.Rounded.Navigation, Color(0xFF12A4B4)),
    Section("Alertas e som", "Voz, radares e avisos", Icons.Rounded.NotificationsActive, Color(0xFFEA4335)),
    Section("Locais e viagens", "Casa, trabalho, favoritos, histórico de viagens", Icons.Rounded.Star, Color(0xFFF29900)),
    Section("Combustível e compartilhamento", "Combustível, custo em reais, etanol x gasolina, compartilhar chegada", Icons.Rounded.LocalGasStation, Color(0xFF34A853)),
    Section("Mapas offline", "Mapas e rotas sem sinal", Icons.Rounded.CloudDownload, Color(0xFF8E5CF0)),
    Section("Tela", "Brilho, tamanho, unidades, velocidade", Icons.Rounded.BrightnessMedium, Color(0xFFFFB020)),
    Section("Busca e chaves", "Área de busca e contas de mapa", Icons.Rounded.VpnKey, Color(0xFF9CA4BF)),
    Section("Sobre e backup", "Permissões, compartilhamento, backup", Icons.Rounded.Info, Color(0xFF9CA4BF)),
)

/** Every setting in one screen: sections on the left, the chosen section on the right, in the map screen's soft style. */
@Composable
fun SettingsScreen(prefs: Prefs, engine: NavEngine, onClose: () -> Unit) {
    val base = LocalVw.current
    val v = remember(base) { navVw(base) }
    CompositionLocalProvider(LocalVw provides v) { SettingsBody(prefs, engine, onClose) }
}

@Composable
private fun SettingsBody(prefs: Prefs, engine: NavEngine, onClose: () -> Unit) {
    val c = LocalVw.current
    var cat by rememberSaveable { mutableIntStateOf(0) }
    // portrait / narrow: one pane at a time (the section list, or the open section with a back arrow)
    val narrowS = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp < 720
    var showList by rememberSaveable { mutableStateOf(true) }
    androidx.activity.compose.BackHandler(enabled = narrowS && !showList) { showList = true }
    var query by remember { mutableStateOf("") }
    var highlight by remember { mutableStateOf<String?>(null) }
    val focus = androidx.compose.ui.platform.LocalFocusManager.current
    val words = query.trim().lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }
    val matches = remember(query) {
        if (words.isEmpty()) emptyList() else settingsIndex.filter { r ->
            val hay = (r.title + " " + r.sub + " " + r.group + " " + sections[r.section].title).lowercase()
            words.all { hay.contains(it) }
        }.sortedBy { if (it.title.lowercase().startsWith(words[0])) 0 else if (it.title.lowercase().contains(words[0])) 1 else 2 }.take(40)
    }
    Row(Modifier.fillMaxSize().background(c.bg).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        // the list of sections
        if (!narrowS || showList) Column(
            Modifier.then(if (narrowS) Modifier.fillMaxWidth() else Modifier.width(290.dp)).fillMaxHeight().clip(RoundedCornerShape(28.dp)).background(c.panel).border(1.dp, c.line, RoundedCornerShape(28.dp)).verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 4.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).clip(CircleShape).background(c.tile).pressClick(onClose), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.ArrowBack, "Voltar ao mapa", tint = c.text, modifier = Modifier.size(24.dp))
                }
                Text("Configurações", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 14.dp))
            }
            // search every setting by name
            Row(
                Modifier.fillMaxWidth().padding(bottom = 8.dp).height(46.dp).clip(RoundedCornerShape(50)).background(c.tile).padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Search, null, tint = c.sub, modifier = Modifier.size(20.dp))
                Box(Modifier.weight(1f).padding(start = 10.dp), contentAlignment = Alignment.CenterStart) {
                    if (query.isEmpty()) Text("Buscar configurações", color = c.sub, fontSize = 15.sp)
                    androidx.compose.foundation.text.BasicTextField(
                        value = query, onValueChange = { query = it; highlight = null }, singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = c.text, fontSize = 15.sp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(c.accent),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                        keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { focus.clearFocus() }),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (query.isNotEmpty()) Icon(Icons.Rounded.Close, "Limpar", tint = c.sub, modifier = Modifier.size(20.dp).clickable { query = ""; focus.clearFocus() })
            }
            if (words.isNotEmpty()) {
                if (matches.isEmpty()) Text("Nada corresponde a \"${query.trim()}\"", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(10.dp))
                matches.forEach { r ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable {
                            cat = r.section; highlight = r.title; query = ""; focus.clearFocus(); showList = false
                        }.padding(horizontal = 12.dp, vertical = 9.dp),
                    ) {
                        Text(r.title, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(sections[r.section].title + (if (r.group.isNotBlank()) " · " + r.group else ""), color = c.sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            } else sections.forEachIndexed { i, s ->
                val on = i == cat
                val rowBg by androidx.compose.animation.animateColorAsState(if (on) c.accent.copy(alpha = 0.16f) else Color.Transparent, androidx.compose.animation.core.tween(200), label = "secBg")
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(rowBg).clickable { cat = i; highlight = null; showList = false }.padding(horizontal = 10.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(38.dp).clip(CircleShape).background(s.tint.copy(alpha = if (on) 0.26f else 0.16f)), contentAlignment = Alignment.Center) {
                        Icon(s.icon, null, tint = s.tint, modifier = Modifier.size(21.dp))
                    }
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(s.title, color = if (on) c.accent else c.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text(s.sub, color = c.sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        // the chosen section (each opens at the top), sliding up gently into place
        if (!narrowS || !showList) androidx.compose.animation.AnimatedContent(
            targetState = cat,
            modifier = Modifier.weight(1f).fillMaxHeight(),
            transitionSpec = {
                (androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(220, delayMillis = 60)) +
                    androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(260)) { it / 24 }) togetherWith
                    androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120))
            },
            label = "section",
        ) { cat ->
          CompositionLocalProvider(LocalSettingHighlight provides highlight) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 4.dp, vertical = 4.dp)) {
                if (narrowS) Row(Modifier.padding(bottom = 6.dp).clip(RoundedCornerShape(50)).clickable { showList = true }.padding(end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(c.tile), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.ArrowBack, "Todas as configurações", tint = c.text, modifier = Modifier.size(22.dp))
                    }
                    Text("Configurações", color = c.sub, fontSize = 15.sp, modifier = Modifier.padding(start = 10.dp))
                }
                Text(sections[cat].title, color = c.text, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp, top = 6.dp))
                Text(sections[cat].sub, color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp, bottom = 16.dp))
                Column(Modifier.widthIn(max = 820.dp)) {
                    when (cat) {
                        0 -> MapSection(prefs, engine)
                        1 -> NavigationSection(prefs)
                        2 -> AlertsSection(prefs, engine)
                        3 -> PlacesSection(engine)
                        4 -> FuelSection(prefs)
                        5 -> { OfflineMapsContent(prefs, engine); OfflinePlacesGroup(engine) }
                        6 -> DisplaySection(prefs, engine)
                        7 -> KeysSection(prefs, engine)
                        else -> AboutSection(prefs, engine)
                    }
                }
            }
          }
        }
    }
}

// ------------------------------------------------------------------ Map

@Composable
private fun MapSection(prefs: Prefs, engine: NavEngine) {
    SGroup("Visual") {
        SChoice("Dia e noite", listOf("auto" to "Automático", "lights" to "Faróis", "sun" to "Nascer/pôr do sol", "times" to "Meus horários", "day" to "Dia", "night" to "Noite"), prefs.s("theme", "auto"),
            "Automático segue o modo noturno da própria central depois que ela muda para ele, e o nascer e o pôr do sol até lá. Faróis segue o modo noturno da central quando ele muda junto com as luzes (ative a opção de modo noturno pelos faróis ou pela iluminação), com os horários do sol até lá. Nascer/pôr do sol muda no nascer e no pôr do sol. Meus horários muda nos horários que você definir") { prefs.put("theme", it) }
        if (prefs.s("theme", "auto") == "times") {
            SFieldItem("Noite começa às", prefs.s("nightfrom", "19:00"), "Relógio de 24 horas, por exemplo 19:30", placeholder = "19:00") { prefs.put("nightfrom", it.trim()) }
            SFieldItem("Dia começa às", prefs.s("dayfrom", "07:00"), "Relógio de 24 horas, por exemplo 06:45", placeholder = "07:00") { prefs.put("dayfrom", it.trim()) }
        }
        SChoice("Fonte do mapa", listOf("mapbox" to "Mapbox", "tomtom" to "TomTom", "osm" to "OpenStreetMap"), prefs.mapSource(),
            "Mapbox: o mapa 3D. TomTom: o mapa da TomTom com as cores do Horizon (precisa de chave da TomTom). Todos precisam do token da Mapbox, porque é o motor da Mapbox que desenha") { prefs.put("mapstyle", it) }
        if (prefs.mapSource() == "mapbox") {
            SChoice("Detalhe do mapa", listOf("full" to "3D completo", "lite" to "Leve", "lightest" to "Mais leve"), prefs.mapDetail(),
                "3D completo: prédios, pontos turísticos, árvores e sombras. Leve: prédios planos, sem pontos turísticos nem sombras. Mais leve: o mapa 2D simples da Mapbox, para centrais lentas") { prefs.put("mapdetail", it) }
            MapColoursPicker(prefs.s("mapcolours", "mapbox")) { prefs.put("mapcolours", it) }
        }
        SToggle(prefs, "Painéis de vidro", "glass", true, "Cartões translúcidos tingidos pelo mapa. Desligado deixa os cartões sólidos")
    }
    SGroup("No mapa") {
        SToggle(prefs, "Trânsito ao vivo", "traffic", true)
        SToggle(prefs, "Satélite", "satellite", false)
        SToggle(prefs, "Prédios 3D", "buildings3d", true)
        SToggle(prefs, "Fachadas detalhadas", "facades", true, "Janelas, portas e vitrines nos prédios, onde a Mapbox tiver (principalmente em centros de cidade)")
        SToggle(prefs, "Pontos turísticos em 3D", "landmarks3d", true, "Modelos detalhados de prédios, pontes e estádios conhecidos")
        SToggle(prefs, "Calçadas e trilhas", "paths", true, "Desligue para um mapa de direção mais limpo")
        SToggle(prefs, "Morros e vales em 3D", "terrain", false, "Relevo real. Lindo em regiões montanhosas, mas pesa numa central lenta")
        SToggle(prefs, "Faixa da rota", "ribbon", true, "Uma sombra suave sob a linha da rota, e a rota aparecendo de leve através dos prédios 3D à frente dela")
        SToggle(prefs, "Neblina e céu", "skyweather", true, "Névoa no horizonte de acordo com o clima: cinza quando nublado, mais densa na chuva, espessa na neblina")
        SToggle(prefs, "Faixas de pedestre", "zebras", true, "Faixas de pedestre da sua rota pintadas na via (de perto)")
        SToggle(prefs, "Manter a via à frente visível", "clearview", true, "As árvores e pontos turísticos 3D da Mapbox são ocultados perto da sua seta e na via logo à frente, para nunca escondê-la")
        SToggle(prefs, "Tocar para destacar", "tapselect", true, "Toque num prédio para destacá-lo; toque numa loja ou local e segure para ir até lá")
        SToggle(prefs, "Postes, semáforos e radares em 3D", "furniture3d", true, "Modelos 3D em tamanho real com lâmpadas acesas (3D completo). Desligado: ícones e blocos simples")
        SToggle(prefs, "Semáforos", "signals", true, if (prefs.b("signals", true)) "Só os da sua rota. Agora: " + engine.map.signalInfo() else null)
        SToggle(prefs, "Radares e obras", "hazardicons", true)
        SToggle(prefs, "Postes de luz", "lamps", true, if (prefs.b("lamps", true)) "Agora: " + engine.map.lampInfo() else null)
        SToggle(prefs, "Árvores nos parques", "trees", true, "Árvores 3D da Mapbox em parques e ao longo das ruas")
        if (prefs.b("lamps", true)) SSlider("Espaçamento dos postes", prefs.s("lampgap", "40").toFloatOrNull() ?: 40f, 15f..120f, " m", reset = 40f) { prefs.put("lampgap", it.toString()) }
        SToggle(prefs, "Efeitos de clima no mapa", "rainfx", false, "Chuva e neve caindo no mapa (e neblina) de acordo com o clima onde você está")
        SToggle(prefs, "Camada de radar de chuva", "radar", false, "Radar ao vivo do RainViewer, por baixo da rota")
        SChoice("Posição do logo da Mapbox", listOf("tl" to "Superior esquerdo", "tr" to "Superior direito", "bl" to "Inferior esquerdo", "br" to "Inferior direito"), prefs.s("mblogo", "tr"),
            "A Mapbox exige o logo dela no mapa; escolha o canto que combina com o seu layout") { prefs.put("mblogo", it) }
    }
    SGroup("Sua seta", footer = "Modelo 3D real: desenhado no próprio mapa, com luz e sombra como os prédios (só no 3D completo; nos outros modos é usada a imagem da mesma forma). A seta 3D e o carro são imagens de formas 3D. A seta plana é a mais leve para uma central lenta.") {
        val loc = prefs.s("locator", "arrow")
        val ctx = LocalContext.current
        val hasPic = prefs.s("locimg", "").isNotBlank() && java.io.File(ctx.filesDir, "locator.png").exists()
        val pickPic = rememberLocatorImagePicker { ok ->
            if (ok) { prefs.put("locimg", System.currentTimeMillis().toString()); prefs.put("locator", "custom") }
            else android.widget.Toast.makeText(ctx, "Não foi possível ler essa imagem (tente PNG ou JPG)", android.widget.Toast.LENGTH_SHORT).show()
        }
        fun choosePic() { if (!pickPic()) android.widget.Toast.makeText(ctx, "Nenhum app neste aparelho consegue escolher uma imagem (instale um gerenciador de arquivos ou uma galeria)", android.widget.Toast.LENGTH_LONG).show() }
        SChoice("Indicador de posição", listOf("arrow" to "Seta 3D", "car" to "Carro", "model" to "Modelo 3D real", "flat" to "Seta plana", "custom" to "Sua imagem"), loc) {
            if (it == "custom" && !hasPic) choosePic() else prefs.put("locator", it)
        }
        if (loc == "model") {
            SChoice("Formato do modelo", listOf("arrow" to "Seta", "car" to "Carro"), prefs.s("modelshape", "arrow")) { prefs.put("modelshape", it) }
            SToggle(prefs, "Realce", "modelglow", true, "Um brilho azul suave em volta do modelo, e o modelo bem iluminado")
            if (prefs.mapDetail() != "full") SNote("O modelo 3D real aparece com Detalhe do mapa: 3D completo. Em Leve e Mais leve é usada a imagem da mesma forma.")
        }
        val shapeCar = loc == "car" || (loc == "model" && prefs.s("modelshape", "arrow") == "car")
        val shapeArrow = loc == "arrow" || (loc == "model" && !shapeCar)
        if (loc == "custom") {
            SItem("Imagem", "Um PNG com fundo transparente fica melhor. Aponte o topo da imagem para o sentido em que você dirige") { SButton(if (hasPic) "Mudar" else "Escolher") { choosePic() } }
            SToggle(prefs, "Gira com você", "locimgturn", true, "Fica deitada na via e gira enquanto você dirige, como a seta. Desligado mantém em pé")
            SToggle(prefs, "Recorte redondo", "locimgcircle", false, "Recorta num círculo com borda branca (bom para fotos)")
        }
        if (shapeCar) SColours("Cor do carro", listOf(
            "#F4F5F7" to "Branco", "#B9BEC8" to "Prata", "#7A808C" to "Cinza", "#3E434D" to "Grafite", "#2A2D34" to "Preto", "#1E2A4A" to "Azul-marinho",
            "#2F6BDF" to "Azul", "#5FB3E8" to "Azul-celeste", "#1FA39A" to "Verde-azulado", "#2E8B57" to "Verde", "#6E8B3D" to "Oliva", "#F2C230" to "Amarelo",
            "#F07C28" to "Laranja", "#D7263D" to "Vermelho", "#8E1B2E" to "Vinho", "#7B4FC9" to "Roxo", "#E86FA8" to "Rosa", "#C9A27A" to "Champanhe", "#6B4A35" to "Marrom",
        ), prefs.s("carcolour", "#F4F5F7")) { prefs.put("carcolour", it) }
        else if (shapeArrow) SColours("Cor da seta", listOf(
            "#F2F2F6" to "Branco", "#C2C6D0" to "Prata", "#8A909C" to "Cinza", "#3E434D" to "Grafite", "#4C8DFF" to "Azul", "#6FD0FF" to "Azul-celeste",
            "#1FC7A6" to "Verde-azulado", "#3DDC84" to "Verde", "#B5E34A" to "Verde-limão", "#FFD54A" to "Amarelo", "#FF9A3C" to "Laranja", "#FF4D5E" to "Vermelho",
            "#FF6FB5" to "Rosa", "#A56BFF" to "Roxo",
        ), prefs.s("arrowcolour", "#F2F2F6")) { prefs.put("arrowcolour", it) }
        SSlider(if (shapeCar) "Tamanho do carro" else if (loc == "custom") "Tamanho da imagem" else "Tamanho da seta", prefs.s("arrowpct", "240").toFloatOrNull() ?: 240f, 100f..500f, "%", reset = 240f) { prefs.put("arrowpct", it.toString()) }
        SToggle(prefs, "Seta de manobra na rota", "turnarrows", true, "Uma seta branca atravessando o próximo cruzamento ou rotatória")
        SToggle(prefs, "Setinhas ao longo da rota", "routechevrons", true, "Pequenas setas ao longo da linha com zoom aproximado")
    }
}

// ------------------------------------------------------------------ Navigation

@Composable
private fun NavigationSection(prefs: Prefs) {
    SGroup("Rotas", footer = "As mudanças valem para a próxima rota planejada. \"Evitar esta via\" no mapa vale só para aquela viagem.") {
        SToggle(prefs, "Evitar pedágios", "avoid_toll", false)
        SToggle(prefs, "Evitar rodovias", "avoid_motorway", false)
        SToggle(prefs, "Evitar balsas", "avoid_ferry", false)
        SToggle(prefs, "Evitar estradas de terra", "avoid_unpaved", true)
        SToggle(prefs, "Rotas econômicas", "route_eco", false, "Que gastam menos combustível em vez das mais rápidas")
    }
    SGroup("Enquanto você dirige") {
        SToggle(prefs, "Oferecer rotas mais rápidas", "fasterroute", true)
        if (prefs.b("fasterroute", true)) SToggle(prefs, "Manter outras rotas no mapa", "livealts", true, "Linhas cinza com +/− minutos que você pode tocar a qualquer momento. Desligado mostra um cartão \"Rota mais rápida encontrada\"")
        SToggle(prefs, "Sobrevoar uma nova rota", "cinematic", true, "Um sobrevoo 3D de 3 segundos antes da visão geral. Toque no mapa para pular")
        SToggle(prefs, "Momento da chegada", "arrivalfx", true, "A câmera desce até o seu destino e mostra o estacionamento mais próximo")
        SToggle(prefs, "Estacionamento perto do destino", "parkprompt", true, "Cerca de 1,5 km antes de chegar, estacionamentos próximos com a caminhada de cada um")
        SToggle(prefs, "Sugerir para onde você vai", "predict", true, "Com o tempo de viagem ao vivo, incluindo casa e trabalho nos seus horários de costume")
        SToggle(prefs, "Clima na rota", "routewx", true)
        SToggle(prefs, "Menos botões enquanto dirige", "drivesimple", true)
        SToggle(prefs, "Bloquear digitação enquanto dirige", "drivelock", true, "A busca por voz continua funcionando")
    }
    SGroup("Na tela") {
        SToggle(prefs, "Barra da rota no cartão da viagem", "routebar", true, "Trânsito, radares, pontos de parada e paradas, com o seu progresso")
        SToggle(prefs, "Cartão do próximo ponto de parada", "servicescard", true)
        SToggle(prefs, "Cruzamento em close", "junctionview", true, "Em acessos, bifurcações e divisões de faixa a visão desce e se aproxima nos últimos 200 m")
        SToggle(prefs, "Botão de sobrevoar a rota", "flyover", true, "Nas opções de rota: um voo 3D por todo o trajeto antes de sair")
        SToggle(prefs, "Rota de volta", "routeback", true, "No cartão de chegada: um toque para voltar ao ponto de partida")
        SToggle(prefs, "Avisos de clima", "wxadvice", true, "Um aviso discreto com chuva forte, neve, neblina ou gelo quando você estiver perto do limite")
        SToggle(prefs, "Passagens de nível e travessias de rio", "railford", true, "Uma placa e um aviso falado para passagens de nível e travessias de rio na sua rota")
        SToggle(prefs, "Sua velocidade ao lado do limite", "mapspeed", true)
        SToggle(prefs, "Anel do velocímetro", "speedring", true, "Enche em direção ao limite, ficando âmbar e depois vermelho")
        SSlider("Tamanho do limite e do velocímetro", prefs.i("speedsize", 100).toFloat(), 50f..200f, "%", sub = "No celular e na tela do carro", steps = 29, reset = 100f) { prefs.put("speedsize", it) }
        SToggle(prefs, "Radar de perigos", "hazardradar", false, "Os próximos 3 km: curvas, travessias, escolas, lombadas, radares e controles")
        SToggle(prefs, "Via e direção ao dirigir sem rota", "cruise", true)
        SToggle(prefs, "Escurecer o mapa em túneis", "tunneldim", true)
        SToggle(prefs, "Cartão de manobra animado", "livecard", true, "Cresce e brilha conforme a manobra se aproxima")
        SToggle(prefs, "Luz correndo ao longo da rota", "routeflow", true)
        SToggle(prefs, "Céu noturno em 3D", "nightsky", true, "Estrelas piscando acima do horizonte depois que escurece")
    }
    SGroup("Cruzamentos e faixas") {
        SToggle(prefs, "Indicação de faixa no cartão de manobra", "lanestrip", true)
        if (prefs.b("lanestrip", true)) SChoice("Estilo da indicação de faixa", listOf("hero" to "Visão grande das faixas", "classic" to "Faixa clássica"), prefs.s("lanestyle", "hero"),
            if (prefs.s("lanestyle", "hero") == "hero") "Antes de cruzamentos com duas ou mais faixas, o cartão de manobra mostra um desenho grande das faixas com a sua acesa" else "A faixinha de pistas em todo cruzamento") { prefs.put("lanestyle", it) }
        SChoice("Próxima manobra no cartão", listOf("close" to "Quando próxima", "always" to "Sempre", "off" to "Desligado"), prefs.s("thenmode", "close"),
            when (prefs.s("thenmode", "close")) { "close" -> "Só quando a manobra seguinte vem logo depois (em uns 15 segundos)"; "always" -> "A manobra depois da próxima, o tempo todo"; else -> null }) { prefs.put("thenmode", it) }
        if (prefs.s("thenmode", "close") != "off") SChoice("Mostrar como", listOf("row" to "Uma linha sob o cartão", "icon" to "Uma setinha"), prefs.s("thenstyle", "row")) { prefs.put("thenstyle", it) }
        SToggle(prefs, "Faixas pintadas no mapa", "lanemap", true)
        SToggle(prefs, "Aproximar das faixas antes de um cruzamento", "laneview", true)
        SToggle(prefs, "Deixar o mapa em 2D nas manobras", "turn2d", true)
        SToggle(prefs, "Inclinar conforme a velocidade", "speedtilt", true, "Mais plano devagar, visão mais longa em velocidade")
        SToggle(prefs, "Manter a seta na via sem rota", "snaproad", true)
        SToggle(prefs, "Mostrar só o trânsito da sua rota durante a navegação", "routetrafficonly", true)
    }
    SGroup("Demonstração") {
        SToggle(prefs, "Botão de direção de demonstração", "demo", false, "Reproduz uma rota para você testar a navegação parado")
    }
}

/** What the app knows about clean air zones, with a button to download them again. */
@Composable
private fun ZonesItem() {
    val ctx = LocalContext.current
    val sc = rememberCoroutineScope()
    var st by remember { mutableStateOf(Zones.all(ctx).let { z -> if (z.isEmpty()) "Ainda não baixado" else "${z.size} zonas: " + z.joinToString(", ") { it.name }.take(140) }) }
    var busy by remember { mutableStateOf(false) }
    SItem("Zonas de ar limpo neste aparelho", st) {
        SButton(if (busy) "Atualizando…" else "Atualizar") {
            if (!busy) { busy = true; sc.launch { withContext(Dispatchers.IO) { Zones.fetch(ctx) }; st = Zones.status; busy = false } }
        }
    }
}

// ------------------------------------------------------------------ Alerts & sound

@Composable
private fun AlertsSection(prefs: Prefs, engine: NavEngine) {
    val ctx = LocalContext.current
    SGroup("Som") {
        SChoice("Orientação falada", listOf("0" to "Tudo", "1" to "Só alertas", "2" to "Desligado"), engine.soundMode.toString(),
            "Só alertas pula as manobras, mas ainda fala radares, limites e perigos") { prefs.put("soundmode", it.toInt()) }
        SToggle(prefs, "Direções mais inteligentes", "smartvoice", true, "Números de saída e destinos das placas, a manobra seguinte quando vem logo depois e menos avisos antecipados em vias que você usa muito")
        SItem("Voz e idioma", "Usa a voz de texto para fala do sistema") { SButton("Abrir") { openSystemSettings(ctx, "com.android.settings.TTS_SETTINGS") } }
        SItem("Volume") { SButton("Abrir") { openSystemSettings(ctx, Settings.ACTION_SOUND_SETTINGS) } }
    }
    SGroup("Velocidade") {
        SToggle(prefs, "Avisar ao passar do limite", "speedwarn", true)
        if (prefs.b("speedwarn", true)) SChoice("Avisar quando passar", listOf("0", "5", "10").map { it to it + if (engine.imperial) " mph" else " km/h" }, prefs.s("warntol", "5")) { prefs.put("warntol", it) }
        SToggle(prefs, "Falar quando o limite mudar", "limitchange", true)
        SToggle(prefs, "Mostrar limites estimados", "limitest", false, "Onde não há limite mapeado, mostra o habitual para aquele tipo de via (em cinza). Desligado não mostra placa em vez de um palpite")
        SToggle(prefs, "Radares", "cameras", true)
        if (prefs.b("cameras", true)) SToggle(prefs, "Desligar onde são proibidos", "cambanobey", true, "França, Alemanha e Suíça não permitem avisos de radar, então eles se desligam sozinhos lá")
        SToggle(prefs, "Controles de velocidade média", "avgzones", true, "Mostra sua média em relação ao limite")
    }
    SGroup("Na via", footer = "Controles de velocidade média, lombadas, escolas e zonas de ar limpo vêm do OpenStreetMap, então alguns podem estar faltando.") {
        SToggle(prefs, "Obras e ocorrências", "incidents", true)
        SToggle(prefs, "Aviso de contramão", "wrongway", true, "Se você entrar na contramão numa rua de mão única")
        SToggle(prefs, "Lombadas", "bumps", true)
        SToggle(prefs, "Escolas em horário de entrada e saída", "schools", true)
        SToggle(prefs, "Lembrete de pausa após 2 horas", "breakremind", true)
    }
    SGroup("Seus relatos", footer = "Faça um relato pelo botão de opções do mapa. Os relatos ficam neste aparelho e somem depois de algumas horas.") {
        SToggle(prefs, "Avisar sobre relatos à frente", "policealerts", true)
        SItem("Relatos ainda ativos", "${engine.reportsActive().size}") { SButton("Limpar", danger = true) { engine.clearReports() } }
    }
}

// ------------------------------------------------------------------ Places & trips

@Composable
private fun PlaceItem(label: String, p: Place?, onClear: () -> Unit) {
    SItem(label, p?.let { it.name + (if (it.sub.isNotBlank()) ", " + it.sub else "") } ?: "Não definido") { if (p != null) SButton("Limpar", danger = true, onClick = onClear) }
}

@Composable
private fun PlacesSection(engine: NavEngine) {
    val pl = engine.places
    SGroup("Locais salvos", footer = "Para definir Casa ou Trabalho, toque em Definir casa / Definir trabalho sob a barra de busca, ou na casa ou na maleta nas opções de rota.") {
        PlaceItem("Casa", pl.slot("home")) { pl.clearSlot("home") }
        PlaceItem("Trabalho", pl.slot("work")) { pl.clearSlot("work") }
    }
    // your own labelled places: rename, reorder or remove
    val raw = engine.prefs.s("places_custom", "")
    val mine = remember(raw) { pl.customs() }
    var renaming by remember { mutableStateOf<String?>(null) }
    var adding by remember { mutableStateOf(false) }
    SGroup("Seus locais", footer = "Aparecem como botões sob a barra de busca, depois de Casa e Trabalho. Adicione um pelo botão + ali, ou pelo marcador nas opções de rota.") {
        if (mine.isEmpty()) SNote("Nenhum local seu ainda.")
        mine.forEachIndexed { i, lp ->
            if (renaming == lp.label) {
                var t by remember(lp.label) { mutableStateOf(lp.label) }
                SItem("Renomear ${lp.label}") {
                    SField(t, { t = it.take(24) }, width = 220.dp)
                    SButton("Salvar", primary = true) { pl.renameCustom(lp.label, t); renaming = null }
                }
            } else SItem(lp.label, lp.place.name + if (lp.place.sub.isNotBlank()) ", " + lp.place.sub else "") {
                if (i > 0) SButton("↑") { pl.moveCustom(lp.label, -1) }
                SButton("Renomear") { renaming = lp.label }
                SButton("Remover", danger = true) { pl.removeCustom(lp.label) }
            }
        }
        SItem("Adicionar um local") { SButton("Adicionar", primary = true) { adding = true } }
    }
    if (adding) AddPlaceDialog(engine, null) { adding = false }
    val favs = pl.favourites()
    SGroup("Favoritos") {
        if (favs.isEmpty()) SNote("Nenhum favorito ainda. Toque na estrela de um destino para adicionar.")
        favs.forEach { f -> SItem(f.name, f.sub) { SButton("Remover") { pl.toggleFavourite(f) } } }
        if (favs.size > 1) SItem("Remover todos os favoritos") { SButton("Remover tudo", danger = true) { pl.clearFavourites() } }
    }
    SGroup("Histórico", footer = "Deslize um local para o lado na lista Salvos e recentes para tirá-lo.") {
        SToggle(engine.prefs, "Salvos e recentes sob a barra de busca", "quicklist", true, "A lista de favoritos e locais recentes no mapa")
        SItem("Destinos recentes", "${pl.recents().size} recentes, mais locais guardados para buscar sem sinal") {
            SButton("Limpar", danger = true) { pl.clearHistory(); engine.toast("Histórico apagado", 2000) }
        }
    }
    TripsGroup(engine)
}

@Composable
private fun TripsGroup(engine: NavEngine) {
    var shown by remember { mutableStateOf(engine.trips.all()) }
    val fmt = java.text.SimpleDateFormat("EEE d MMM, HH:mm", java.util.Locale("pt", "BR"))
    val k = if (engine.imperial) 2.23694 else 3.6
    val unit = if (engine.imperial) "mph" else "km/h"
    SGroup("Histórico de viagens") {
        if (shown.isEmpty()) SNote("Nenhuma viagem ainda. Cada trajeto é registrado aqui quando você estaciona.")
        else SItem("${shown.size} viagens", Geo.fmtDist(shown.sumOf { it.dist }, engine.imperial) + " no total") { SButton("Limpar", danger = true) { engine.trips.clear(); shown = emptyList() } }
        shown.take(50).forEach { t ->
            val mins = ((t.end - t.start) / 60000L).toInt()
            SItem(
                fmt.format(java.util.Date(t.start)) + (if (t.to.isNotBlank()) " → ${t.to}" else ""),
                "${Geo.fmtDur(mins * 60.0)} · em movimento ${Geo.fmtDur(t.moving.toDouble())} · máx. ${Math.round(t.maxSpeed * k)} $unit",
            ) { Text(Geo.fmtDist(t.dist, engine.imperial), color = LocalVw.current.text, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

// ------------------------------------------------------------------ Fuel & sharing

@Composable
private fun FuelSection(prefs: Prefs) {
    val fuel = prefs.s("fueltype", "GAS")
    fun num(s: String, n: Int) = s.replace(',', '.').filter { it.isDigit() || it == '.' }.take(n)
    SGroup("Combustível") {
        SChoice("Seu combustível", listOf("GAS" to "Gasolina", "GASAD" to "Aditivada", "ETANOL" to "Etanol", "B7" to "Diesel", "GNV" to "GNV", "EV" to "Elétrico"), fuel) { prefs.put("fueltype", it) }
        SToggle(prefs, "Sugerir parada para abastecer em viagens longas", "smartfuel", true,
            if (fuel == "EV") "Acima de uns 150 km, um ponto de recarga no caminho com o menor desvio" else "Acima de uns 150 km, um posto no caminho com o menor desvio")
    }
    if (fuel == "EV") SGroup("Custo da viagem nas opções de rota", footer = "Com os dois preenchidos, cada rota mostra mais ou menos quanto vai custar a recarga, em reais.") {
        SFieldItem("Consumo (km por kWh)", prefs.s("evkmkwh", ""), placeholder = "ex.: 6,5", number = true) { s -> prefs.put("evkmkwh", num(s, 5)) }
        SFieldItem("Preço da energia (R$ por kWh)", prefs.s("evrkwh", ""), placeholder = "ex.: 0,95", number = true) { s -> prefs.put("evrkwh", num(s, 6)) }
    } else {
        SGroup("Custo da viagem nas opções de rota", footer = "Com o consumo e o preço preenchidos, cada rota mostra mais ou menos quanto vai gastar de combustível, em reais. Se o preço ficar em branco, vale o preço da gasolina ou do etanol informado abaixo.") {
            SFieldItem("Consumo do carro (km/l)", prefs.s("brkml", ""), placeholder = "ex.: 12,5", number = true) { s -> prefs.put("brkml", num(s, 5)) }
            SFieldItem("Preço do combustível (R$/litro)", prefs.s("brppl", ""), placeholder = "ex.: 6,29", number = true) { s -> prefs.put("brppl", num(s, 6)) }
        }
        SGroup("Etanol ou gasolina?", footer = "Regra prática: o etanol compensa quando custa até 70% do preço da gasolina, porque rende cerca de 30% menos. Com o consumo do seu carro em cada um, a conta usa os números reais.") {
            SFieldItem("Preço da gasolina (R$/litro)", prefs.s("brgas", ""), placeholder = "ex.: 6,29", number = true) { s -> prefs.put("brgas", num(s, 6)) }
            SFieldItem("Preço do etanol (R$/litro)", prefs.s("bretanol", ""), placeholder = "ex.: 4,19", number = true) { s -> prefs.put("bretanol", num(s, 6)) }
            SFieldItem("Consumo com gasolina (km/l, opcional)", prefs.s("brkmlg", ""), placeholder = "ex.: 12,0", number = true) { s -> prefs.put("brkmlg", num(s, 5)) }
            SFieldItem("Consumo com etanol (km/l, opcional)", prefs.s("brkmle", ""), placeholder = "ex.: 8,5", number = true) { s -> prefs.put("brkmle", num(s, 5)) }
            etanolAdvice(prefs)?.let { SNote(it) }
        }
    }
    SGroup("Compartilhar sua chegada", footer = "O botão de compartilhar no cartão da viagem envia por SMS o horário de chegada e um link do mapa. Numa central sem chip, ele abre o app de mensagens.") {
        val pickEta = rememberEtaContactPicker(prefs)
        SItem("Enviar para", prefs.s("etaname", "").ifBlank { "Ninguém escolhido ainda" }) {
            SButton(if (prefs.s("etanum", "").isBlank()) "Escolher" else "Mudar") { pickEta() }
            if (prefs.s("etanum", "").isNotBlank()) SButton("Limpar", danger = true) { prefs.put("etanum", ""); prefs.put("etaname", "") }
        }
    }
}

/** Town and village names for your country, so search works with no signal even without the full pack. */
@Composable
private fun OfflinePlacesGroup(engine: NavEngine) {
    val ctx = LocalContext.current
    val sc = rememberCoroutineScope()
    // the country of the chosen pack, else the one you're in
    val cc = engine.chosenPack().country.ifBlank { engine.detectedCountry }.ifBlank { "BR" }
    val where = countryName(cc)
    var state by remember { mutableStateOf(if (OfflinePlaces.installed(ctx)) "Instalado (%.1f MB)".format(OfflinePlaces.sizeMb(ctx)) else "Não baixado") }
    var busy by remember { mutableStateOf(false) }
    SGroup("Nomes de lugares", footer = "Um download pequeno de cidades e vilarejos em $where, para buscar por eles sem sinal mesmo sem o pacote completo.") {
        SItem("Cidades e vilarejos", state) {
            SButton(if (busy) "Baixando…" else if (OfflinePlaces.installed(ctx)) "Atualizar" else "Baixar", primary = !OfflinePlaces.installed(ctx)) {
                if (!busy) {
                    busy = true; state = "Baixando (precisa de sinal)…"
                    sc.launch {
                        try {
                            val n = withContext(Dispatchers.IO) { OfflinePlaces.download(ctx, cc) }
                            state = "Instalado: $n locais"; engine.toast("Locais offline prontos", 3000)
                        } catch (e: Exception) { state = "Falhou: ${e.message}" } finally { busy = false }
                    }
                }
            }
            if (OfflinePlaces.installed(ctx) && !busy) SButton("Remover", danger = true) { OfflinePlaces.delete(ctx); state = "Não baixado" }
        }
    }
}

// ------------------------------------------------------------------ Display

@Composable
private fun DisplaySection(prefs: Prefs, engine: NavEngine) {
    SGroup("Tela") {
        SSlider("Brilho", prefs.i("bright", 100).toFloat(), 10f..100f, "%", sub = "100% deixa por conta do sistema", live = true) { prefs.put("bright", it) }
        SToggle(prefs, "Escurecer a tela à noite", "dimnight", false)
        SToggle(prefs, "Manter a tela ligada", "keepon", true)
        SSlider("Tamanho de textos e botões", prefs.i("uiscale", 100).toFloat(), 60f..140f, "%", steps = 15, reset = 100f) { prefs.put("uiscale", it) }
    }
    SGroup("Unidades") {
        SChoice("Distância e velocidade", listOf("mi" to "Milhas", "km" to "Quilômetros"), if (engine.imperial) "mi" else "km") { prefs.put("distunit", it) }
        SChoice("Temperatura", listOf("C" to "°C", "F" to "°F"), if (isImperial(prefs)) "F" else "C") { prefs.put("tempunit", it) }
        SChoice("Lado do motorista", listOf("" to "Automático", "rhd" to "Volante à direita", "lhd" to "Volante à esquerda"), prefs.s("drive", ""),
            when (prefs.s("drive", "")) {
                "rhd" -> "Motorista à direita (Reino Unido): cartões à esquerda, botões à direita"
                "lhd" -> "Motorista à esquerda (Brasil, EUA, Europa): a tela é espelhada, cartões à direita"
                else -> "Segue o país onde você está" + (if (engine.mirrored) ": volante à esquerda, tela espelhada" else ": volante à direita")
            }) { prefs.put("drive", it) }
    }
    SGroup("Fluidez", footer = "Diminua estes se o mapa parecer lento ou a central esquentar. Nitidez e desenho rápido valem depois de reiniciar o app.") {
        SChoice("Nitidez do mapa", listOf("100" to "Máxima", "80" to "Equilibrada", "65" to "Leve", "50" to "Mínima"), prefs.s("mapres", "80")) { prefs.put("mapres", it) }
        SChoice("Taxa de quadros", listOf("auto" to "Automático", "20" to "20", "30" to "30", "45" to "45", "60" to "60"), prefs.s("mapfps", "auto"),
            if (prefs.s("mapfps", "auto") == "auto") "Começa em 30 e diminui quando a central não acompanha, para o mapa se mover de forma uniforme" else "Menor é mais leve para a central") { prefs.put("mapfps", it) }
        SToggle(prefs, "Desenho rápido do mapa", "mapfast", true)
        // (the old "Light map" switch is now Settings > Map > Map detail)
        SToggle(prefs, "Medidor de desempenho", "perfmeter", false, "Uma linha no topo do mapa: quadros desenhados, movimentos de câmera e pausas. Útil para descobrir o que deixa o mapa lento")
    }
}

// ------------------------------------------------------------------ Search & keys

@Composable
private fun KeysSection(prefs: Prefs, engine: NavEngine) {
    SGroup("Busca") {
        SChoice("Resultados da busca", searchCountryOptions(engine), searchCountryValue(prefs)) { prefs.put("country", it) }
        if (engine.hasKey && engine.hasMapbox) SChoice("Buscar com", listOf("auto" to "TomTom", "mapbox" to "Mapbox"), if (prefs.s("searchwith", "auto") == "mapbox") "mapbox" else "auto",
            "A busca da TomTom é a padrão do Horizon Nav: a melhor para endereços e números de casas") { prefs.put("searchwith", it) }
        else if (!engine.hasKey) SNote("Para a busca de endereços mais precisa, adicione uma chave gratuita da TomTom abaixo.")
    }
    SGroup("Contas de mapa", footer = "A busca também encontra locais que você salvou ou visitou. Sem sinal, as rotas, o mapa e a busca vêm do pacote offline.") {
        SFieldItem("Chave de API da TomTom", prefs.s("apikey", ""), if (BuildConfig.TOMTOM_API_KEY.isNotBlank() && prefs.s("apikey", "").isBlank()) "Usando a chave embutida no app, a menos que você cole outra" else "Opcional: dá a busca de endereços mais precisa e uma reserva para rotas e trânsito. Grátis em developer.tomtom.com",
            placeholder = "Cole uma chave") { prefs.setApiKey(it) }
        SFieldItem("Token de acesso da Mapbox", prefs.s("mbtoken", ""), "Para o mapa da Mapbox, rotas com trânsito ao vivo e limites de velocidade, busca e imagens de satélite. Grátis em account.mapbox.com (o token público padrão, que começa com pk., serve)",
            placeholder = "Cole um token") { prefs.put("mbtoken", it.trim()) }
    }
    if (engine.hasKey && engine.hasMapbox) SGroup("Rotas, busca e trânsito", footer = "Automático usa a Mapbox enquanto o mapa da Mapbox estiver na tela, e a TomTom nos outros casos. Se o serviço em uso parar (limite diário, chave recusada, instabilidade), o outro assume sozinho por um tempo.") {
        SChoice("Usar", listOf("auto" to "Automático", "tomtom" to "TomTom", "mapbox" to "Mapbox"), prefs.s("dataprov", "auto")) { prefs.put("dataprov", it) }
    }
}

// ------------------------------------------------------------------ About & backup

@Composable
private fun AboutSection(prefs: Prefs, engine: NavEngine) {
    val ctx = LocalContext.current
    val pkg = android.net.Uri.parse("package:" + ctx.packageName)
    SGroup("Horizon Nav") {
        SItem("Versão", BuildConfig.VERSION_NAME)
        if (com.headunit.launcher.Updater.enabled) {
            SItem("Procurar atualizações", engine.updateStatus.ifBlank { null }) {
                val u = engine.appUpdate
                if (u != null && !engine.updateBusy) SButton("Atualizar para ${u.version}", primary = true) { engine.installAppUpdate() }
                else SButton(if (engine.updateBusy) "Atualizando…" else "Verificar agora") { engine.checkForUpdate(manual = true) }
            }
            SToggle(prefs, "Procurar atualizações sozinho", "updcheck", true, "Umas duas vezes por dia, quando houver conexão")
        }
        SItem("Configuração inicial", "Refazer os passos iniciais: chave do mapa, casa e trabalho, mapas offline, permissões") { SButton("Refazer configuração") { prefs.put("setupdone", false); prefs.put("forcesetup", true) } }
        var feedback by remember { mutableStateOf(false) }
        SItem("Sugestão ou problema", "Envia um relatório com a versão do app, seu aparelho e o último travamento, para facilitar a correção") { SButton("Relatar", primary = true) { feedback = true } }
        if (feedback) FeedbackDialog(engine) { feedback = false }
    }
    SGroup("Permissões", footer = "Com uma rota ativa, a navegação continua quando você troca de app e uma notificação aparece. Permita notificações para ela poder aparecer.") {
        val hasLoc = ctx.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        SItem("Localização", if (hasLoc) "Permitida" else "Não permitida: a navegação precisa dela") {
            SButton("Permissões do app", primary = !hasLoc) { openSystemSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg) }
        }
        SItem("Serviços de localização") { SButton("Abrir") { openSystemSettings(ctx, Settings.ACTION_LOCATION_SOURCE_SETTINGS) } }
    }
    SGroup("Locais de outros apps", footer = "Compartilhe um local com o Horizon Nav pelo Google Maps, WhatsApp, Contatos ou uma página da web e ele planeja a rota. Para abrir links do Google Maps direto aqui, toque em Abrir por padrão e adicione os links.") {
        SItem("Links do Google Maps") {
            SButton("Abrir por padrão") {
                if (android.os.Build.VERSION.SDK_INT >= 31) openSystemSettings(ctx, Settings.ACTION_APP_OPEN_BY_DEFAULT_SETTINGS, pkg)
                else openSystemSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)
            }
        }
    }
    // Android Auto only lists apps that weren't installed from Play when its own "Unknown sources" is on, and some phones hide them
    // anyway: the steps that get it showing, with shortcuts
    SGroup("Android Auto", footer = "Se o Horizon Nav não aparecer no Android Auto: 1. Abra as configurações do Android Auto, toque umas 10 vezes no número da versão lá embaixo, depois no menu do canto superior direito abra Configurações do desenvolvedor e ative Fontes desconhecidas. 2. De volta às configurações do Android Auto, abra Personalizar acesso rápido e confira se o Horizon Nav está marcado. 3. Force a parada do Android Auto (Informações do app abaixo), desconecte e conecte de novo. Se ainda não aparecer, o Android Auto do seu celular só lista apps instalados pela Play Store: instale o APK com um instalador que define a Play como origem (por exemplo \"adb install -i com.android.vending\", ou um app como AAAD ou Install with Options).") {
        val gh = "com.google.android.projection.gearhead"
        val ghUri = android.net.Uri.parse("package:$gh")
        val hasAa = remember { try { ctx.packageManager.getPackageInfo(gh, 0); true } catch (e: Exception) { false } }
        val source = remember {
            try {
                val inst = if (android.os.Build.VERSION.SDK_INT >= 30) ctx.packageManager.getInstallSourceInfo(ctx.packageName).installingPackageName
                    else @Suppress("DEPRECATION") ctx.packageManager.getInstallerPackageName(ctx.packageName)
                when (inst) {
                    "com.android.vending" -> "Google Play (o Android Auto lista sem passos extras)"
                    null -> "Desconhecida (instalado por arquivo): precisa de Fontes desconhecidas no Android Auto"
                    ctx.packageName -> "Atualizador do próprio Horizon Nav: precisa de Fontes desconhecidas no Android Auto"
                    else -> "$inst: precisa de Fontes desconhecidas no Android Auto"
                }
            } catch (e: Exception) { "Desconhecida" }
        }
        SSlider("Tamanho na tela do carro", prefs.i("carscale", 100).toFloat(), 60f..160f, "%", sub = "Ele se ajusta à tela do carro; isto aumenta ou diminui a partir daí", steps = 19, reset = 100f) { prefs.put("carscale", it) }
        SItem("Instalado por", source)
        SItem("Configurações do Android Auto", if (hasAa) null else "O Android Auto não está instalado neste celular") {
            if (hasAa) SButton("Abrir") {
                val i = ctx.packageManager.getLaunchIntentForPackage(gh)
                try {
                    if (i != null) ctx.startActivity(i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) else openSystemSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, ghUri)
                } catch (e: Exception) { openSystemSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, ghUri) }
            }
        }
        if (hasAa) SItem("Informações do app Android Auto", "Para forçar a parada depois de mudar as configurações") {
            SButton("Informações do app") { openSystemSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, ghUri) }
        }
    }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(prefs.exportJson().toByteArray()) }
                true
            } catch (e: Exception) { false }
            android.widget.Toast.makeText(ctx, if (ok) "Backup salvo" else "Não foi possível salvar o backup", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val msg = try {
                val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                "${prefs.importJson(text)} configurações restauradas"
            } catch (e: Exception) { "Esse arquivo não é um backup válido" }
            android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show()
        }
    }
    SGroup("Backup", footer = "Inclui configurações e locais salvos, mas não a chave de API nem o pacote offline. Um backup do Horizon Launcher também pode ser restaurado aqui.") {
        SItem("Configurações e locais salvos") {
            SButton("Fazer backup") { exporter.launch("horizon-nav-backup.json") }
            SButton("Restaurar") { importer.launch(arrayOf("application/json", "text/plain", "*/*")) }
        }
    }
    val cf = java.io.File(ctx.filesDir, "lastcrash.txt")
    var rep by remember { mutableStateOf(if (cf.exists()) cf.readText() else "") }
    if (rep.isNotBlank()) SGroup("Relatório de problema", footer = "O app fechou inesperadamente da última vez. Envie uma foto disto para que possa ser corrigido.") {
        Text(rep.take(900), color = LocalVw.current.text, fontSize = 10.sp, modifier = Modifier.padding(vertical = 6.dp))
        SItem("Apagar o relatório") { SButton("Limpar") { cf.delete(); rep = "" } }
    }
}

/** Readable name of a country code ("UK", "Norway"...). */
internal fun countryName(cc: String): String = when (cc.uppercase()) {
    "GB" -> "UK"; "US" -> "US"; "" -> ""
    else -> java.util.Locale("", cc).getDisplayCountry(java.util.Locale("pt", "BR")).ifBlank { cc }
}

/** Search limited to the country you're in (followed as you travel) or anywhere. */
internal fun searchCountryOptions(engine: NavEngine): List<Pair<String, String>> {
    val here = engine.detectedCountry
    return listOf("auto" to (if (here.isNotBlank()) "Só ${countryName(here)}" else "Só o meu país"), "" to "Qualquer lugar")
}

internal fun searchCountryValue(prefs: Prefs): String = if (prefs.s("country", "auto").isBlank()) "" else "auto"

/**
 * Feedback: say what happened in a line or two, then send it as a GitHub issue (the browser opens with it filled in) or copy it to
 * paste anywhere (Reddit, a message). Either way the app version, unit, main settings and the last crash go with it.
 */
@Composable
private fun FeedbackDialog(engine: NavEngine, onClose: () -> Unit) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    var note by remember { mutableStateOf("") }
    androidx.compose.ui.window.Dialog(onDismissRequest = onClose) {
        Column(Modifier.widthIn(max = 560.dp).fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(c.panel).padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Sugestão ou problema", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("O que aconteceu, ou o que você gostaria? Onde você estava e o que tocou ajuda.", color = c.sub, fontSize = 14.sp)
            SField(note, { note = it.take(600) }, placeholder = "ex.: Recalculou pelo caminho errado perto do centro", width = 516.dp, fill = true)
            Text("Vai junto: a versão do app, seu aparelho, as principais configurações, as regiões baixadas e o último travamento (sem locais nem chaves de API).", color = c.sub, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)) {
                SButton("Fechar") { onClose() }
                SButton("Copiar") {
                    val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                    cm?.setPrimaryClip(android.content.ClipData.newPlainText("Horizon Nav report", engine.feedbackReport(note)))
                    engine.toast("Relatório copiado: cole numa mensagem ou num comentário", 3500)
                }
                SButton("Enviar no GitHub", primary = true) {
                    val title = note.lineSequence().firstOrNull()?.take(80)?.ifBlank { null } ?: "Relatório do Horizon Nav ${com.headunit.launcher.BuildConfig.VERSION_NAME}"
                    // a link has a length limit, so a very long report is cut down (Copy always has all of it)
                    val body = engine.feedbackReport(note).take(5000)
                    val url = "https://github.com/${BuildConfig.UPDATE_REPO}/issues/new?title=" + android.net.Uri.encode(title) + "&body=" + android.net.Uri.encode(body)
                    try { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    catch (e: Exception) { engine.toast("Nenhum navegador neste aparelho: use Copiar", 3500) }
                    onClose()
                }
            }
        }
    }
}

/**
 * Settings > Map > Colours: a small picture of each colour set (land, water, park, roads, a building and the route), tap to pick.
 * Day colours are shown; each one has its night version.
 */
@Composable
private fun MapColoursPicker(value: String, onPick: (String) -> Unit) {
    val c = LocalVw.current
    // land, water, park, road, building
    val sets = listOf(
        Triple("mapbox", "Mapbox", listOf(0xFFEDEFE9, 0xFF9CCBF0, 0xFFC6E4B4, 0xFFFFFFFF, 0xFFDCDCE0)),
        Triple("horizon", "Horizon", listOf(0xFFF4F2EE, 0xFFAADAF5, 0xFFCDEBC4, 0xFFFFFFFF, 0xFFE7E5E1)),
        Triple("faded", "Suave", listOf(0xFFF1F1F1, 0xFFD9E2EA, 0xFFE2E8DE, 0xFFFFFFFF, 0xFFE6E6E6)),
        Triple("grey", "Cinza", listOf(0xFFE8E8E8, 0xFFCFCFCF, 0xFFDADADA, 0xFFFFFFFF, 0xFFD4D4D4)),
    )
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        SItem("Cores", "Horizon: o mapa da Mapbox com as cores suaves do próprio app. Mostradas as cores de dia; cada uma tem versão noturna")
        Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            for ((id, name, cols) in sets) {
                val sel = id == value
                Column(
                    Modifier.width(124.dp).clip(RoundedCornerShape(14.dp)).background(c.tile)
                        .border(2.dp, if (sel) c.accent else androidx.compose.ui.graphics.Color.Transparent, RoundedCornerShape(14.dp))
                        .clickable { onPick(id) },
                ) {
                    androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(76.dp)) {
                        val w = size.width; val h = size.height
                        fun col(i: Int) = androidx.compose.ui.graphics.Color(cols[i])
                        drawRect(col(0))
                        drawRect(col(1), topLeft = androidx.compose.ui.geometry.Offset(w * 0.68f, 0f), size = androidx.compose.ui.geometry.Size(w * 0.32f, h * 0.3f))
                        drawRect(col(2), topLeft = androidx.compose.ui.geometry.Offset(w * 0.06f, h * 0.62f), size = androidx.compose.ui.geometry.Size(w * 0.24f, h * 0.26f))
                        drawRect(col(4), topLeft = androidx.compose.ui.geometry.Offset(w * 0.47f, h * 0.1f), size = androidx.compose.ui.geometry.Size(w * 0.18f, h * 0.2f))
                        drawRect(col(3), topLeft = androidx.compose.ui.geometry.Offset(0f, h * 0.44f), size = androidx.compose.ui.geometry.Size(w, h * 0.12f))
                        drawRect(col(3), topLeft = androidx.compose.ui.geometry.Offset(w * 0.36f, 0f), size = androidx.compose.ui.geometry.Size(w * 0.06f, h))
                        drawRect(androidx.compose.ui.graphics.Color(0xFF2A7BE4), topLeft = androidx.compose.ui.geometry.Offset(w * 0.68f, 0f), size = androidx.compose.ui.geometry.Size(w * 0.05f, h))
                    }
                    Text(name, color = c.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                }
            }
        }
    }
}
