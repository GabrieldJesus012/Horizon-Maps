package com.headunit.launcher.ui

import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.BuildConfig
import com.headunit.launcher.NavEngine
import com.headunit.launcher.OfflinePlaces
import com.headunit.launcher.Place
import com.headunit.launcher.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Every setting of the app in one screen: a list of sections on the left, the chosen section on the right. */
@Composable
fun SettingsScreen(prefs: Prefs, engine: NavEngine, onClose: () -> Unit) {
    val c = LocalVw.current
    var cat by rememberSaveable { mutableIntStateOf(0) }
    val cats = listOf(
        "Map" to Icons.Rounded.Palette, "Route" to Icons.Rounded.Route, "Guidance" to Icons.Rounded.Visibility,
        "Alerts" to Icons.Rounded.NotificationsActive, "Voice & sound" to Icons.Rounded.VolumeUp, "Offline maps" to Icons.Rounded.CloudDownload,
        "Saved places" to Icons.Rounded.Star, "Driving" to Icons.Rounded.DirectionsCar, "Display" to Icons.Rounded.BrightnessMedium,
        "Units" to Icons.Rounded.Straighten, "Performance" to Icons.Rounded.Speed, "Search & keys" to Icons.Rounded.VpnKey,
        "About & backup" to Icons.Rounded.Info,
    )
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        VCard(Modifier.width(250.dp).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                // back to the map
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.accent).pressClick(onClose).padding(horizontal = 10.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.ChevronLeft, "Back to the map", tint = Color.White, modifier = Modifier.size(28.dp))
                    Text("Back to map", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 8.dp))
                }
                Box(Modifier.size(6.dp))
                cats.forEachIndexed { i, (label, icon) ->
                    val on = i == cat
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (on) c.tile else Color.Transparent).clickable { cat = i }.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(icon, null, tint = if (on) c.accent else c.sub, modifier = Modifier.size(24.dp))
                        Text(label, color = if (on) c.text else c.sub, fontSize = 16.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, modifier = Modifier.padding(start = 14.dp))
                    }
                }
            }
        }
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            // a fresh scroll position for each section, so a new section always opens at the top
            androidx.compose.runtime.key(cat) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
                    PageTitle(cats[cat].first, modifier = Modifier.padding(bottom = 8.dp))
                    when (cat) {
                        0 -> MapSection(prefs)
                        1 -> RouteSection(prefs)
                        2 -> GuidanceSection(prefs, engine)
                        3 -> AlertsSection(prefs, engine)
                        4 -> SoundSection(prefs, engine)
                        5 -> { OfflineMapsContent(prefs, engine); OfflinePlacesRow(engine) }
                        6 -> PlacesSection(engine)
                        7 -> DrivingSection(prefs)
                        8 -> DisplaySection(prefs)
                        9 -> UnitsSection(prefs, engine)
                        10 -> PerformanceSection(prefs)
                        11 -> KeysSection(prefs, engine)
                        else -> AboutSection(prefs)
                    }
                }
            }
        }
    }
}

@Composable
private fun Note(text: String) {
    Text(text, color = LocalVw.current.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, top = 4.dp, bottom = 8.dp))
}

@Composable
private fun Toggle(prefs: Prefs, title: String, key: String, def: Boolean) {
    Row2(title) { Switch(prefs.b(key, def), { prefs.put(key, it) }) }
}

@Composable
private fun fieldColors(): androidx.compose.material3.TextFieldColors {
    val c = LocalVw.current
    return TextFieldDefaults.colors(
        focusedContainerColor = c.tile, unfocusedContainerColor = c.tile,
        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
        focusedTextColor = c.text, unfocusedTextColor = c.text, cursorColor = c.accent,
    )
}

@Composable
private fun MapSection(prefs: Prefs) {
    val c = LocalVw.current
    Row2("Day / night") {
        val t = prefs.s("theme", "auto")
        Pill("Auto", t == "auto", { prefs.put("theme", "auto") })
        Pill("Day", t == "day", { prefs.put("theme", "day") })
        Pill("Night", t == "night", { prefs.put("theme", "night") })
        Pill("Sunrise/sunset", t == "sun", { prefs.put("theme", "sun") })
    }
    Note("Auto follows the system's dark mode. Sunrise/sunset switches by the real sun times where you are.")
    Row2("Map theme") {
        Pill("Modern", prefs.s("maptheme", "immersive") == "immersive", { prefs.put("maptheme", "immersive") })
        Pill("Classic", prefs.s("maptheme", "immersive") == "classic", { prefs.put("maptheme", "classic") })
    }
    Note("Modern recolours the map in soft, light tones, draws a blue route with traffic painted on it, a Google-style arrow and red destination pin, and turns the turn card green with a bold arrow. Both themes follow day and night.")
    Row2("Map source") {
        Pill("TomTom Orbis", prefs.s("mapstyle", "tomtom") == "tomtom", { prefs.put("mapstyle", "tomtom") })
        Pill("OpenStreetMap (free)", prefs.s("mapstyle", "tomtom") == "osm", { prefs.put("mapstyle", "osm") })
        Pill("Google Maps", prefs.s("mapstyle", "tomtom") == "google", { prefs.put("mapstyle", "google") })
    }
    Note("The Modern colours apply to the TomTom and OpenStreetMap styles. Google's own map picture keeps Google's colours, but the route, arrow and cards still change. Google needs its own key under Search & keys.")
    Toggle(prefs, "Live traffic on map", "traffic", true)
    Toggle(prefs, "Satellite", "satellite", false)
    Toggle(prefs, "3D buildings", "buildings3d", true)
    Toggle(prefs, "Traffic lights", "signals", true)
    Toggle(prefs, "Speed cameras & roadworks icons", "hazardicons", true)
    Toggle(prefs, "Night street lamps", "lamps", true)
    if (prefs.b("lamps", true)) Row2("Street lamp spacing") {
        var lv by remember { mutableStateOf(prefs.s("lampgap", "40").toFloatOrNull() ?: 40f) }
        androidx.compose.material3.Slider(
            value = lv, onValueChange = { lv = it },
            onValueChangeFinished = { prefs.put("lampgap", Math.round(lv).toString()) },
            valueRange = 15f..120f, modifier = Modifier.width(260.dp),
        )
        Text("${Math.round(lv)} m", color = c.text, fontSize = 16.sp, modifier = Modifier.width(56.dp))
        Pill("Reset", false, { lv = 40f; prefs.put("lampgap", "40") })
    }
    Row2("Locator arrow size") {
        var av by remember { mutableStateOf(prefs.s("arrowpct", "240").toFloatOrNull() ?: 240f) }
        androidx.compose.material3.Slider(
            value = av, onValueChange = { av = it },
            onValueChangeFinished = { prefs.put("arrowpct", Math.round(av).toString()) },
            valueRange = 100f..500f, modifier = Modifier.width(260.dp),
        )
        Text("${Math.round(av)}%", color = c.text, fontSize = 16.sp, modifier = Modifier.width(56.dp))
        Pill("Reset", false, { av = 240f; prefs.put("arrowpct", "240") })
    }
    Toggle(prefs, "Rain effect on the map when it is raining", "rainfx", false)
}

@Composable
private fun RouteSection(prefs: Prefs) {
    Toggle(prefs, "Avoid toll roads", "avoid_toll", false)
    Toggle(prefs, "Avoid motorways", "avoid_motorway", false)
    Toggle(prefs, "Avoid ferries", "avoid_ferry", false)
    Toggle(prefs, "Avoid unpaved roads", "avoid_unpaved", true)
    Toggle(prefs, "Eco route (fuel-efficient instead of fastest)", "route_eco", false)
    Toggle(prefs, "Suggest faster routes while driving", "fasterroute", true)
    Toggle(prefs, "Weather on route", "routewx", true)
    Note("Changes apply to the next route you plan.")
}

@Composable
private fun GuidanceSection(prefs: Prefs, engine: NavEngine) {
    val c = LocalVw.current
    Toggle(prefs, "Show my speed next to the limit sign", "mapspeed", true)
    Toggle(prefs, "Hide traffic colours on other roads while navigating (the route shows its own)", "routetrafficonly", true)
    Toggle(prefs, "Keep the arrow on the road when there is no route", "snaproad", true)
    Toggle(prefs, "Flatten the map to 2D for turns and junctions", "turn2d", true)
    Toggle(prefs, "Lane guidance strip", "lanestrip", true)
    Toggle(prefs, "Lane strips and arrows painted on the map", "lanemap", true)
    Toggle(prefs, "Zoom in on lanes before a junction", "laneview", true)
    Toggle(prefs, "Simplify the map controls while driving", "drivesimple", true)
    Toggle(prefs, "Lock typing while driving (voice search still works)", "drivelock", true)
    Text(
        "Lane data on the current route: " + (engine.route?.let { r -> if (r.lanes.isEmpty()) "none (TomTom only has lane data at some junctions, mostly bigger roads)" else r.lanes.size.toString() + " junction(s)" } ?: "no route"),
        color = c.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, top = 8.dp, bottom = 4.dp),
    )
    val sigInfo by androidx.compose.runtime.produceState(engine.map.signalInfo()) { while (true) { value = engine.map.signalInfo(); kotlinx.coroutines.delay(1000) } }
    Text("Traffic lights: $sigInfo", color = c.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
    SectionLabel("Testing", Modifier.padding(top = 10.dp, bottom = 4.dp))
    Toggle(prefs, "Show the demo-drive button on the map", "demo", false)
    Toggle(prefs, "Test lane view (pretend 4 lanes at every turn)", "lanedemo", false)
}

@Composable
private fun AlertsSection(prefs: Prefs, engine: NavEngine) {
    Toggle(prefs, "Speed camera alerts", "cameras", true)
    Toggle(prefs, "Speed limit warning", "speedwarn", true)
    Row2("Warn when over the limit by") {
        for (t in listOf("0", "5", "10")) Pill(t + if (engine.imperial) " mph" else " km/h", prefs.s("warntol", "5") == t, { prefs.put("warntol", t) })
    }
    Toggle(prefs, "Speed limit change alert", "limitchange", true)
    Toggle(prefs, "Roadworks & incident alerts", "incidents", true)
    Toggle(prefs, "Police reports (report one from the map options button)", "policealerts", true)
    Row2("Break reminder after 2 hours of driving") {
        Pill("On", prefs.b("breakremind", true), { prefs.put("breakremind", true) })
        Pill("Off", !prefs.b("breakremind", true), { prefs.put("breakremind", false) })
    }
    Row2("Test alert sound") { Pill("Play test alert", false, { engine.testAlert() }) }
}

@Composable
private fun SoundSection(prefs: Prefs, engine: NavEngine) {
    val ctx = LocalContext.current
    Row2("Sound") {
        Pill("All", engine.soundMode == 0, { prefs.put("soundmode", 0) })
        Pill("Alerts only", engine.soundMode == 1, { prefs.put("soundmode", 1) })
        Pill("Off", engine.soundMode == 2, { prefs.put("soundmode", 2) })
    }
    Note("Alerts only skips turn-by-turn voice but still speaks and chimes for speed cameras, speed limit changes, incidents, rain and break reminders. Music is turned down while the voice speaks.")
    Row2("Voice language and speed") {
        Pill("Text-to-speech settings", false, { openSystemSettings(ctx, "com.android.settings.TTS_SETTINGS") })
    }
    Row2("Volume") { Pill("Sound settings", false, { openSystemSettings(ctx, Settings.ACTION_SOUND_SETTINGS) }) }
    Row2("Check the voice") { Pill("Play test alert", false, { engine.testAlert() }) }
}

/** Offline town and village names, so search works with no signal even without the full pack. */
@Composable
private fun OfflinePlacesRow(engine: NavEngine) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val sc = rememberCoroutineScope()
    var state by remember { mutableStateOf(if (OfflinePlaces.installed(ctx)) "Installed (%.1f MB)".format(OfflinePlaces.sizeMb(ctx)) else "Not downloaded") }
    var busy by remember { mutableStateOf(false) }
    SectionLabel("Offline place names", Modifier.padding(top = 18.dp, bottom = 4.dp))
    Row2("UK towns and villages (small download, so you can search without signal)") {
        Text(state, color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(end = 12.dp))
        Pill(if (busy) "Downloading…" else if (OfflinePlaces.installed(ctx)) "Update" else "Download", false, {
            if (!busy) {
                busy = true; state = "Downloading (needs signal)…"
                sc.launch {
                    try {
                        val n = withContext(Dispatchers.IO) { OfflinePlaces.download(ctx) }
                        state = "Installed: $n places"; engine.toast("Offline places ready", 3000)
                    } catch (e: Exception) { state = "Failed: ${e.message}" } finally { busy = false }
                }
            }
        })
        if (OfflinePlaces.installed(ctx) && !busy) Pill("Remove", false, { OfflinePlaces.delete(ctx); state = "Not downloaded" })
    }
}

@Composable
private fun PlaceRow(label: String, p: Place?, onClear: () -> Unit) {
    val c = LocalVw.current
    Row2(label) {
        Text(p?.let { it.name + (if (it.sub.isNotBlank()) ", " + it.sub else "") } ?: "Not set", color = c.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.width(300.dp))
        if (p != null) Pill("Clear", false, onClear)
    }
}

@Composable
private fun PlacesSection(engine: NavEngine) {
    val c = LocalVw.current
    val pl = engine.places
    Note("To set Home or Work, tap Set home / Set work on the map and search for the address, or open a destination and tap the house or briefcase.")
    PlaceRow("Home", pl.slot("home")) { pl.clearSlot("home"); engine.toast("Home cleared", 2000) }
    PlaceRow("Work", pl.slot("work")) { pl.clearSlot("work"); engine.toast("Work cleared", 2000) }
    PlaceRow("Parked car (saved by itself when you park)", pl.parked()) { pl.clearParked() }
    val favs = pl.favourites()
    SectionLabel("Favourites (${favs.size})", Modifier.padding(top = 18.dp, bottom = 4.dp))
    if (favs.isEmpty()) Note("No favourites yet. Tap the star on a destination to add one.")
    favs.forEach { f ->
        Row2(f.name) {
            if (f.sub.isNotBlank()) Text(f.sub, color = c.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.width(240.dp))
            Pill("Remove", false, { pl.toggleFavourite(f) })
        }
    }
    if (favs.size > 1) Row2("Remove every favourite") { Pill("Remove all", false, { pl.clearFavourites() }) }
    SectionLabel("History", Modifier.padding(top = 18.dp, bottom = 4.dp))
    Row2("Recent destinations (${pl.recents().size}) and places remembered for searching without signal") {
        Pill("Clear history", false, { pl.clearHistory(); engine.toast("History cleared", 2000) })
    }
}

@Composable
private fun DrivingSection(prefs: Prefs) {
    Row2("Share ETA with (the share button on the trip card)") {
        val pickEta = rememberEtaContactPicker(prefs)
        Pill(prefs.s("etaname", "").ifBlank { "Choose contact" }, false, { pickEta() })
        if (prefs.s("etanum", "").isNotBlank()) Pill("Clear", false, { prefs.put("etanum", ""); prefs.put("etaname", "") })
    }
    Note("Your ETA and a map link are sent by text message from this device. On a head unit without a SIM it opens your messaging app instead.")
    SectionLabel("Fuel cost estimate", Modifier.padding(top = 18.dp, bottom = 4.dp))
    Row2("Fuel economy (miles per gallon)") {
        var v by remember { mutableStateOf(prefs.s("fuelmpg", "")) }
        TextField(
            value = v, onValueChange = { s -> val t = s.filter { it.isDigit() || it == '.' }.take(5); v = t; prefs.put("fuelmpg", t) },
            placeholder = { Text("e.g. 45") }, singleLine = true, colors = fieldColors(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.width(150.dp),
        )
    }
    Row2("Fuel price (pence per litre)") {
        var v by remember { mutableStateOf(prefs.s("fuelppl", "")) }
        TextField(
            value = v, onValueChange = { s -> val t = s.filter { it.isDigit() || it == '.' }.take(6); v = t; prefs.put("fuelppl", t) },
            placeholder = { Text("e.g. 139.9") }, singleLine = true, colors = fieldColors(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.width(150.dp),
        )
    }
    Note("With both filled in, the route options show roughly what the trip will cost in fuel. Leave them empty to hide it.")
}

@Composable
private fun DisplaySection(prefs: Prefs) {
    val c = LocalVw.current
    Row2("Brightness") {
        var b by remember { mutableStateOf(prefs.i("bright", 100).toFloat()) }
        androidx.compose.material3.Slider(
            value = b, onValueChange = { b = it; prefs.put("bright", it.roundToInt()) },
            valueRange = 10f..100f, modifier = Modifier.width(260.dp),
        )
        Text("${b.roundToInt()}%", color = c.text, fontSize = 16.sp, modifier = Modifier.width(56.dp))
    }
    Note("100% leaves the brightness to the system.")
    Toggle(prefs, "Dim the screen at night", "dimnight", false)
    Toggle(prefs, "Keep the screen on while the app is open", "keepon", true)
    Row2("Text and button size") {
        var sv by remember { mutableStateOf(prefs.i("uiscale", 100).toFloat()) }
        androidx.compose.material3.Slider(
            value = sv, onValueChange = { sv = it },
            onValueChangeFinished = { prefs.put("uiscale", sv.roundToInt()) },
            valueRange = 60f..140f, steps = 15, modifier = Modifier.width(260.dp),
        )
        Text("${sv.roundToInt()}%", color = c.text, fontSize = 16.sp, modifier = Modifier.width(56.dp))
        Pill("Reset", false, { sv = 100f; prefs.put("uiscale", 100) })
    }
}

@Composable
private fun UnitsSection(prefs: Prefs, engine: NavEngine) {
    Row2("Distance & speed") {
        Pill("Miles", engine.imperial, { prefs.put("distunit", "mi") })
        Pill("Kilometres", !engine.imperial, { prefs.put("distunit", "km") })
    }
    Row2("Temperature (weather on route)") {
        Pill("Celsius °C", !isImperial(prefs), { prefs.put("tempunit", "C") })
        Pill("Fahrenheit °F", isImperial(prefs), { prefs.put("tempunit", "F") })
    }
}

@Composable
private fun PerformanceSection(prefs: Prefs) {
    Note("Lower these if the map feels slow or the head unit gets warm. Sharpness and fast rendering apply after restarting the app.")
    Row2("Map sharpness (lower is smoother on a slow head unit)") {
        for ((n, l) in listOf("100" to "Full", "80" to "Balanced", "65" to "Light", "50" to "Lowest")) Pill(l, prefs.s("mapres", "80") == n, { prefs.put("mapres", n) })
    }
    Toggle(prefs, "Fast map rendering", "mapfast", true)
    Row2("Map frame rate (lower is lighter on the head unit)") {
        for (n in listOf("20", "30", "45", "60")) Pill(n, prefs.s("mapfps", "30") == n, { prefs.put("mapfps", n) })
    }
    Toggle(prefs, "Light map (hides points of interest and the route glow, and lowers the tilt)", "maplite", true)
    Toggle(prefs, "Show performance monitor (map fps and stalls)", "perfmon", false)
}

@Composable
private fun KeysSection(prefs: Prefs, engine: NavEngine) {
    Row2("Search results") {
        Pill("United Kingdom first", prefs.s("country", "GB") == "GB", { prefs.put("country", "GB") })
        Pill("Anywhere", prefs.s("country", "GB").isEmpty(), { prefs.put("country", "") })
    }
    Row2("TomTom API key") {
        var key by remember { mutableStateOf(prefs.s("apikey", "")) }
        TextField(
            value = key, onValueChange = { key = it; prefs.put("apikey", it.trim()) },
            placeholder = { Text(if (engine.hasKey) "Using the key built into this app" else "Paste a key to enable search & routing") },
            singleLine = true, colors = fieldColors(), modifier = Modifier.width(420.dp),
        )
    }
    Row2("Google Maps API key (only for the Google map source)") {
        var gk by remember { mutableStateOf(prefs.s("gkey", "")) }
        TextField(
            value = gk, onValueChange = { gk = it; prefs.put("gkey", it.trim()) },
            placeholder = { Text("Key with Map Tiles API enabled") },
            singleLine = true, colors = fieldColors(), modifier = Modifier.width(420.dp),
        )
    }
    Note("Search also finds places you saved or routed to before. With no signal, routes, the map and search for streets and shops come from the pack under Offline maps. Without a pack, a route you pick starts by itself when the connection returns.")
    if (!engine.hasKey) Text("No TomTom key: online search, routing and traffic are off until you add one.", color = Warn, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, top = 6.dp))
}

@Composable
private fun AboutSection(prefs: Prefs) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    Row2("Horizon Nav") { Text("Version ${BuildConfig.VERSION_NAME}", color = c.sub, fontSize = 14.sp) }
    SectionLabel("Permissions", Modifier.padding(top = 18.dp, bottom = 4.dp))
    val hasLoc = ctx.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
    Row2("Location: " + if (hasLoc) "allowed" else "not allowed (navigation needs it)") {
        Pill("App permissions", !hasLoc, { openSystemSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + ctx.packageName)) })
        Pill("Location settings", false, { openSystemSettings(ctx, Settings.ACTION_LOCATION_SOURCE_SETTINGS) })
    }
    Note("While a route is running the app keeps guiding you when you switch to another app (it shows a notification). Allow notifications for this app so that notification can appear.")
    SectionLabel("Backup", Modifier.padding(top = 18.dp, bottom = 4.dp))
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(prefs.exportJson().toByteArray()) }
                true
            } catch (e: Exception) { false }
            android.widget.Toast.makeText(ctx, if (ok) "Backup saved" else "Could not save the backup", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val msg = try {
                val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                "Restored ${prefs.importJson(text)} settings"
            } catch (e: Exception) { "That file is not a valid backup" }
            android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show()
        }
    }
    Row2("Settings and saved places") {
        Pill("Back up", false, { exporter.launch("horizon-nav-backup.json") })
        Pill("Restore", false, { importer.launch(arrayOf("application/json", "text/plain", "*/*")) })
    }
    Note("Backups include settings and saved places, but not the API key or the offline pack. A backup made in Horizon Launcher can be restored here too.")
    val cf = java.io.File(ctx.filesDir, "lastcrash.txt")
    var rep by remember { mutableStateOf(if (cf.exists()) cf.readText() else "") }
    if (rep.isNotBlank()) {
        SectionLabel("Last crash report", Modifier.padding(top = 18.dp, bottom = 4.dp))
        Text(rep.take(900), color = c.text, fontSize = 10.sp, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp))
        Pill("Clear report", false, { cf.delete(); rep = "" })
    }
}
