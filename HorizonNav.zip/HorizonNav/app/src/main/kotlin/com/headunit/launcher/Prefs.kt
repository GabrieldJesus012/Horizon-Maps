package com.headunit.launcher

import android.content.Context
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import org.json.JSONObject

/**
 * Tiny observable key/value store (Compose-aware).
 * Every key has its own state, so changing one setting only redraws the screens that actually read that setting
 * (a single shared map would redraw everything that read any setting).
 */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("drive_launcher", Context.MODE_PRIVATE)
    private val raw = HashMap<String, String>().apply { sp.all.forEach { (k, v) -> put(k, v.toString()) } }
    private val states = HashMap<String, MutableState<String?>>()

    @Synchronized private fun state(k: String): MutableState<String?> = states.getOrPut(k) { mutableStateOf(raw[k]) }

    fun s(k: String, d: String) = state(k).value ?: d
    fun b(k: String, d: Boolean) = state(k).value?.toBooleanStrictOrNull() ?: d
    fun i(k: String, d: Int) = state(k).value?.toIntOrNull() ?: d
    fun f(k: String, d: Float) = state(k).value?.toFloatOrNull() ?: d

    /** Everything except the API key, as JSON text (settings, saved places, logs...). */
    @Synchronized fun exportJson(): String {
        val o = JSONObject()
        raw.forEach { (k, v) -> if (k != "apikey") o.put(k, v) }
        return o.toString(2)
    }

    /** Restores values from [exportJson] output; returns how many entries were applied. */
    fun importJson(text: String): Int {
        val o = JSONObject(text)
        var n = 0
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k == "apikey") continue
            put(k, o.get(k))
            n++
        }
        return n
    }

    fun put(k: String, v: Any) {
        val s = v.toString()
        // nothing changed: no disk write and nothing on screen is redrawn
        synchronized(this) { if (raw[k] == s) return; raw[k] = s }
        state(k).value = s
        sp.edit().putString(k, s).apply()
    }
}

/**
 * The map source: whatever was picked in Settings; until something is picked, TomTom once a TomTom key has been entered
 * (otherwise this build's default).
 */
fun Prefs.mapSource(): String = s("mapstyle", if (s("apikey", "").isNotBlank()) "tomtom" else BuildConfig.DEFAULT_MAP)

/** Saves a TomTom key; entering one where there was none switches the map to TomTom (it can be switched back in Settings). */
fun Prefs.setApiKey(k: String) {
    val was = s("apikey", "").isNotBlank()
    put("apikey", k.trim())
    if (!was && k.isNotBlank()) put("mapstyle", "tomtom")
}
