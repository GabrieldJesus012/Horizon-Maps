package com.headunit.launcher.car

import android.app.Presentation
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.FrameLayout
import androidx.car.app.AppManager
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.constraints.ConstraintManager
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.DateTimeWithZone
import androidx.car.app.model.Distance
import androidx.car.app.model.ItemList
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.SearchTemplate
import androidx.car.app.model.Template
import androidx.car.app.navigation.NavigationManager
import androidx.car.app.navigation.NavigationManagerCallback
import androidx.car.app.navigation.model.Destination
import androidx.car.app.navigation.model.Maneuver
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.car.app.navigation.model.RoutingInfo
import androidx.car.app.navigation.model.Step
import androidx.car.app.navigation.model.TravelEstimate
import androidx.car.app.navigation.model.Trip
import androidx.car.app.validation.HostValidator
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.headunit.launcher.KEEP_LEFT
import com.headunit.launcher.MapBinding
import com.headunit.launcher.NavEngine
import com.headunit.launcher.NavService
import com.headunit.launcher.Place
import com.headunit.launcher.Prefs
import com.headunit.launcher.R
import com.headunit.launcher.TurnInfo
import java.util.TimeZone

/**
 * Horizon Nav on Android Auto. Android Auto connects to this service when the phone is plugged into the car; the car screen shows
 * the map (drawn by the app onto a surface Android Auto hands over) under Google's navigation layout: the turn card, the arrival
 * estimate and the buttons. Search and places use Google's list and search screens (third-party navigation apps can't use their own).
 *
 * The car has its own engine and map, separate from the app on the phone's screen, so it works with the phone locked.
 * (Sideloaded copies only appear in Android Auto with its developer setting "Unknown sources" turned on.)
 */
class CarNavService : CarAppService() {
    // any Android Auto host may connect: the app isn't distributed through Play, where Google would vouch for the host
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    override fun onCreateSession(): Session = CarNavSession()
}

/** The engine and map for one connection to the car. */
class CarHolder(val carContext: CarContext) {
    var engine: NavEngine? = null
    var map: MapBinding? = null
}

class CarNavSession : Session() {
    private lateinit var holder: CarHolder
    private lateinit var surface: CarSurface
    private var mapScreen: MapScreen? = null

    override fun onCreateScreen(intent: Intent): Screen {
        holder = CarHolder(carContext)
        val screen = MapScreen(carContext, holder)
        mapScreen = screen
        surface = CarSurface(carContext) { map -> startEngine(map) }
        try { carContext.getCarService(AppManager::class.java).setSurfaceCallback(surface) } catch (e: Exception) { }
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                screen.stop()
                try { holder.engine?.let { if (it.route != null) it.endRoute(); it.shutdown() } } catch (e: Exception) { }
                try { NavService.stop(carContext.applicationContext) } catch (e: Exception) { }
                CarTicks.tick = null
                surface.release()
                holder.engine = null; holder.map = null
            }
        })
        return screen
    }

    /** The map is on the car screen: start an engine for it, with the same settings as the app on the phone. */
    private fun startEngine(map: MapBinding) {
        val app = carContext.applicationContext
        val prefs = Prefs(app)
        map.setTheme("immersive")
        map.setArrowScale((prefs.s("arrowpct", "240").toIntOrNull() ?: 240) / 100f)
        val loc = prefs.s("locator", "arrow")
        map.setLocator(if (loc == "custom") "arrow" else loc, prefs.s(if (loc == "car") "carcolour" else "arrowcolour", if (loc == "car") "#F4F5F7" else "#F2F2F6"))
        val engine = NavEngine(app, prefs, map)
        holder.map = map; holder.engine = engine
        surface.engine = engine
        CarTicks.tick = { surface.tick() }
        engine.applyStyle(carContext.isDarkMode)
        try { engine.startLocation() } catch (e: Exception) { }
        mapScreen?.start()
    }

    override fun onCarConfigurationChanged(newConfiguration: Configuration) {
        // day / night on the car screen follows the car (its headlights or its own setting)
        holder.engine?.applyStyle(carContext.isDarkMode)
    }
}

/**
 * Puts the app's map on the car screen: Android Auto gives a surface; a private virtual display shows on it, and the map (a normal
 * map view with the locator and road name on top) runs on that display. Drags and pinches on the car screen move it.
 */
class CarSurface(private val carContext: CarContext, private val onReady: (MapBinding) -> Unit) : SurfaceCallback {
    private var display: VirtualDisplay? = null
    private var presentation: Presentation? = null
    private var map: MapBinding? = null
    private var speedView: SpeedView? = null
    var engine: NavEngine? = null
    private var width = 1; private var height = 1

    override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
        val s = surfaceContainer.surface ?: return
        width = surfaceContainer.width.coerceAtLeast(1); height = surfaceContainer.height.coerceAtLeast(1)
        val existing = display
        if (existing != null) {
            // the car screen came back or changed size: keep the same map, just point it at the new surface
            existing.surface = s
            existing.resize(width, height, surfaceContainer.dpi)
            return
        }
        try {
            val dm = carContext.getSystemService(DisplayManager::class.java)
            val vd = dm.createVirtualDisplay("HorizonNavCar", width, height, surfaceContainer.dpi, s, DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY)
            display = vd
            val p = Presentation(carContext, vd.display)
            val m = MapBinding(p.context, false, 1f)
            val sv = SpeedView(p.context)
            val root = FrameLayout(p.context)
            root.addView(m.mapView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            root.addView(m.roadView, FrameLayout.LayoutParams(1, 1))
            root.addView(m.locatorView, FrameLayout.LayoutParams(1, 1))
            val d = p.context.resources.displayMetrics.density
            root.addView(sv, FrameLayout.LayoutParams((150 * d).toInt(), (76 * d).toInt()))
            p.setContentView(root)
            p.show()
            m.mapView.onStart(); m.mapView.onResume()
            presentation = p; map = m; speedView = sv
            onReady(m)
        } catch (e: Exception) { android.util.Log.w("CarNav", "couldn't put the map on the car screen", e) }
    }

    override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
        display?.surface = null
    }

    override fun onVisibleAreaChanged(visibleArea: Rect) {
        // the turn card covers the left of the screen: keep the arrow in the clear part to its right
        val e = engine ?: return
        if (visibleArea.left > 0) e.setPanel(0, 0f, 0f, visibleArea.left.toFloat() / width, 1f) else e.setPanel(0, 0f, 0f, 0f, 0f)
        // the speed sign sits at the bottom left of the clear part
        speedView?.let { v ->
            v.translationX = visibleArea.left + 12f * v.resources.displayMetrics.density
            v.translationY = visibleArea.bottom - v.layoutParams.height - 12f * v.resources.displayMetrics.density
        }
    }

    override fun onStableAreaChanged(stableArea: Rect) {}

    override fun onScroll(distanceX: Float, distanceY: Float) {
        val m = map ?: return
        m.onUserGesture?.invoke()
        try { m.map?.scrollBy(distanceX, distanceY) } catch (e: Exception) { }
    }

    override fun onFling(velocityX: Float, velocityY: Float) {}

    override fun onScale(focusX: Float, focusY: Float, scaleFactor: Float) {
        val m = map ?: return
        m.onUserGesture?.invoke()
        // a double tap comes as a negative factor: zoom in one step
        val dz = if (scaleFactor <= 0f) 1.0 else Math.log(scaleFactor.toDouble()) / Math.log(2.0)
        try { m.map?.moveCamera(org.maplibre.android.camera.CameraUpdateFactory.zoomBy(dz, android.graphics.Point(focusX.toInt(), focusY.toInt()))) } catch (e: Exception) { }
    }

    /** Called about once a second: the speed sign. */
    fun tick() {
        val e = engine ?: return
        speedView?.update(e.speedLimit, e.fix?.speed, e.imperial)
    }

    fun release() {
        try { map?.mapView?.let { it.onPause(); it.onStop(); it.onDestroy() } } catch (e: Exception) { }
        try { presentation?.dismiss() } catch (e: Exception) { }
        try { display?.release() } catch (e: Exception) { }
        map = null; presentation = null; display = null
    }
}

/** The speed limit roundel and your speed, drawn on the car's map (Google's layout has no place for them). */
class SpeedView(ctx: android.content.Context) : View(ctx) {
    private var limit: Int? = null
    private var speed: Int? = null
    private var unit = "mph"
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun update(limitMs: Double?, speedMs: Double?, imperial: Boolean) {
        val k = if (imperial) 2.23694 else 3.6
        val l = limitMs?.let { (Math.round(it * k / 5.0) * 5).toInt() }
        val s = speedMs?.let { Math.round(it * k).toInt() }
        val u = if (imperial) "mph" else "km/h"
        if (l != limit || s != speed || u != unit) { limit = l; speed = s; unit = u; invalidate() }
    }

    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        val r = h * 0.46f
        var x = r + 2f
        val l = limit
        if (l != null) {
            p.style = Paint.Style.FILL; p.color = Color.WHITE
            c.drawCircle(x, h / 2, r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.22f; p.color = Color.rgb(224, 20, 43)
            c.drawCircle(x, h / 2, r - p.strokeWidth / 2, p)
            p.style = Paint.Style.FILL; p.color = Color.rgb(17, 17, 17); p.textAlign = Paint.Align.CENTER
            p.typeface = android.graphics.Typeface.DEFAULT_BOLD; p.textSize = r * (if (l >= 100) 0.62f else 0.8f)
            c.drawText(l.toString(), x, h / 2 + p.textSize * 0.36f, p)
            x += r + 10f
        }
        val s = speed
        if (s != null) {
            val over = l != null && s > l + 2
            p.style = Paint.Style.FILL; p.color = Color.argb(225, 18, 25, 34)
            val w = h * 0.95f
            c.drawRoundRect(x, h * 0.08f, x + w, h * 0.92f, h * 0.2f, h * 0.2f, p)
            p.color = if (over) Color.rgb(255, 90, 90) else Color.WHITE; p.textAlign = Paint.Align.CENTER
            p.typeface = android.graphics.Typeface.DEFAULT_BOLD; p.textSize = h * 0.36f
            c.drawText(s.toString(), x + w / 2, h * 0.52f, p)
            p.typeface = android.graphics.Typeface.DEFAULT; p.textSize = h * 0.16f; p.color = Color.argb(200, 255, 255, 255)
            c.drawText(unit, x + w / 2, h * 0.76f, p)
        }
    }
}

/** The main car screen: the map with the turn card and arrival estimate while navigating, and buttons for search and places. */
class MapScreen(carContext: CarContext, private val holder: CarHolder) : Screen(carContext) {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var lastSig = ""
    private var navigating = false
    private var autoDrive = false
    private val nav: NavigationManager? = try { carContext.getCarService(NavigationManager::class.java) } catch (e: Exception) { null }

    init {
        try {
            nav?.setNavigationManagerCallback(object : NavigationManagerCallback {
                // the car (or another navigation app) asked to stop
                override fun onStopNavigation() { holder.engine?.endRoute() }
                // Google's test tool: simulate driving to the chosen destination
                override fun onAutoDriveEnabled() { autoDrive = true }
            })
        } catch (e: Exception) { }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    fun start() { if (!running) { running = true; handler.post(tick) } }
    fun stop() {
        running = false; handler.removeCallbacks(tick)
        if (navigating) try { nav?.navigationEnded() } catch (e: Exception) { }
        navigating = false
    }

    private fun refresh() {
        val e = holder.engine ?: return
        val guiding = e.route != null && !e.previewing
        // tell Android Auto when navigation starts and ends (it shows turns in the car's dashboard and notifications)
        if (guiding != navigating) {
            navigating = guiding
            try {
                if (guiding) {
                    nav?.navigationStarted()
                    try { NavService.start(holder.carContext.applicationContext, "Navigating to ${e.dest?.name ?: "your destination"}") } catch (x: Exception) { }
                } else {
                    nav?.navigationEnded()
                    try { NavService.stop(holder.carContext.applicationContext) } catch (x: Exception) { }
                }
            } catch (x: Exception) { }
        }
        if (autoDrive && guiding && e.simMode == 0) e.cycleSim()
        val t = e.turn; val eta = e.eta
        val sig = "${guiding}|${e.busy}|${e.simMode}|${t?.maneuver}|${t?.street}|${t?.dist?.let { Math.round(it / 10) }}|${eta?.secs?.let { Math.round(it / 30) }}|${eta?.dist?.let { Math.round(it / 100) }}"
        if (sig != lastSig) {
            lastSig = sig
            invalidate()
            if (guiding && t != null && eta != null) try { nav?.updateTrip(trip(e, t, eta)) } catch (x: Exception) { }
        }
        CarTicks.tick?.invoke()
    }

    private fun icon(res: Int) = CarIcon.Builder(IconCompat.createWithResource(carContext, res)).build()

    override fun onGetTemplate(): Template {
        val e = holder.engine
        val guiding = e != null && e.route != null && !e.previewing
        val strip = ActionStrip.Builder()
        if (guiding) {
            strip.addAction(Action.Builder().setTitle("Stop").setOnClickListener { e?.endRoute(); invalidate() }.build())
        }
        // the demo drive (for trying it out parked): starts it, speeds it up, stops it
        if (guiding) strip.addAction(Action.Builder().setTitle(when (e?.simMode ?: 0) { 0 -> "Demo"; 1 -> "Faster"; else -> "End demo" })
            .setOnClickListener { e?.cycleSim(); invalidate() }.build())
        strip.addAction(Action.Builder().setTitle("Search").setOnClickListener { screenManager.push(SearchScreen(carContext, holder)) }.build())
        if (!guiding) strip.addAction(Action.Builder().setTitle("Places").setOnClickListener { screenManager.push(PlacesScreen(carContext, holder)) }.build())
        val mapStrip = ActionStrip.Builder()
            .addAction(Action.PAN)
            .addAction(Action.Builder().setIcon(icon(R.drawable.ic_car_plus)).setOnClickListener { e?.zoom(0.7) }.build())
            .addAction(Action.Builder().setIcon(icon(R.drawable.ic_car_minus)).setOnClickListener { e?.zoom(-0.7) }.build())
            .addAction(Action.Builder().setIcon(icon(R.drawable.ic_car_recenter)).setOnClickListener { e?.recenter() }.build())
            .build()
        val b = NavigationTemplate.Builder().setActionStrip(strip.build()).setMapActionStrip(mapStrip)
        if (e != null) {
            val t = e.turn; val eta = e.eta
            if (guiding && t != null) {
                b.setNavigationInfo(RoutingInfo.Builder().setCurrentStep(step(e, t, carContext), distance(t.dist, e.imperial)).build())
                if (eta != null) b.setDestinationTravelEstimate(estimate(eta.dist, eta.secs, e.imperial))
            } else if (e.busy) {
                b.setNavigationInfo(RoutingInfo.Builder().setLoading(true).build())
            }
        }
        return b.build()
    }

    private fun trip(e: NavEngine, t: TurnInfo, eta: com.headunit.launcher.EtaInfo): Trip {
        val est = estimate(eta.dist, eta.secs, e.imperial)
        val tb = Trip.Builder().addStep(step(e, t, carContext), estimate(t.dist, 0.0, e.imperial))
        val d = e.dest
        tb.addDestination(Destination.Builder().setName(d?.name ?: "Destination").setAddress(d?.sub ?: "").build(), est)
        if (e.roadNow.isNotBlank()) tb.setCurrentRoad(e.roadNow)
        return tb.build()
    }

    companion object {
        fun distance(m: Double, imperial: Boolean): Distance = if (imperial) {
            val mi = m / 1609.344
            if (mi >= 0.25) Distance.create(Math.round(mi * 10) / 10.0, Distance.UNIT_MILES)
            else Distance.create((Math.round(m * 1.09361 / 10.0) * 10).toDouble(), Distance.UNIT_YARDS)
        } else {
            if (m >= 1000) Distance.create(Math.round(m / 100.0) / 10.0, Distance.UNIT_KILOMETERS)
            else Distance.create((Math.round(m / 10.0) * 10).toDouble(), Distance.UNIT_METERS)
        }

        fun estimate(m: Double, secs: Double, imperial: Boolean): TravelEstimate {
            val arrive = System.currentTimeMillis() + (secs * 1000).toLong()
            return TravelEstimate.Builder(distance(m, imperial), DateTimeWithZone.create(arrive, TimeZone.getDefault()))
                .setRemainingTimeSeconds(secs.toLong().coerceAtLeast(0)).build()
        }

        /** The engine's turn as Android Auto's step: the kind of turn (for its arrow), what to do, and the road. */
        /** The arrow picture for each kind of turn (Android Auto only draws the turn card when the step has one). */
        private fun maneuverIcon(type: Int): Int = when (type) {
            Maneuver.TYPE_TURN_NORMAL_LEFT -> R.drawable.ic_man_turn_left
            Maneuver.TYPE_TURN_NORMAL_RIGHT -> R.drawable.ic_man_turn_right
            Maneuver.TYPE_TURN_SHARP_LEFT -> R.drawable.ic_man_sharp_left
            Maneuver.TYPE_TURN_SHARP_RIGHT -> R.drawable.ic_man_sharp_right
            Maneuver.TYPE_TURN_SLIGHT_LEFT, Maneuver.TYPE_OFF_RAMP_NORMAL_LEFT -> R.drawable.ic_man_slight_left
            Maneuver.TYPE_TURN_SLIGHT_RIGHT, Maneuver.TYPE_OFF_RAMP_NORMAL_RIGHT -> R.drawable.ic_man_slight_right
            Maneuver.TYPE_KEEP_LEFT -> R.drawable.ic_man_keep_left
            Maneuver.TYPE_KEEP_RIGHT -> R.drawable.ic_man_keep_right
            Maneuver.TYPE_U_TURN_LEFT -> R.drawable.ic_man_uturn_left
            Maneuver.TYPE_U_TURN_RIGHT -> R.drawable.ic_man_uturn_right
            Maneuver.TYPE_ROUNDABOUT_ENTER_AND_EXIT_CW, Maneuver.TYPE_ROUNDABOUT_ENTER_CW -> R.drawable.ic_man_roundabout_cw
            Maneuver.TYPE_ROUNDABOUT_ENTER_AND_EXIT_CCW, Maneuver.TYPE_ROUNDABOUT_ENTER_CCW -> R.drawable.ic_man_roundabout_ccw
            Maneuver.TYPE_DESTINATION, Maneuver.TYPE_DESTINATION_LEFT, Maneuver.TYPE_DESTINATION_RIGHT -> R.drawable.ic_man_destination
            else -> R.drawable.ic_man_straight
        }

        fun step(e: NavEngine, t: TurnInfo, ctx: CarContext): Step {
            val left = e.detectedCountry in KEEP_LEFT
            val m = t.maneuver.uppercase()
            val type = when {
                m.startsWith("ROUNDABOUT") -> if (t.exit > 0) (if (left) Maneuver.TYPE_ROUNDABOUT_ENTER_AND_EXIT_CW else Maneuver.TYPE_ROUNDABOUT_ENTER_AND_EXIT_CCW)
                                               else (if (left) Maneuver.TYPE_ROUNDABOUT_ENTER_CW else Maneuver.TYPE_ROUNDABOUT_ENTER_CCW)
                m == "TURN_LEFT" -> Maneuver.TYPE_TURN_NORMAL_LEFT
                m == "TURN_RIGHT" -> Maneuver.TYPE_TURN_NORMAL_RIGHT
                m == "SHARP_LEFT" -> Maneuver.TYPE_TURN_SHARP_LEFT
                m == "SHARP_RIGHT" -> Maneuver.TYPE_TURN_SHARP_RIGHT
                m == "BEAR_LEFT" -> Maneuver.TYPE_TURN_SLIGHT_LEFT
                m == "BEAR_RIGHT" -> Maneuver.TYPE_TURN_SLIGHT_RIGHT
                m == "KEEP_LEFT" -> Maneuver.TYPE_KEEP_LEFT
                m == "KEEP_RIGHT" -> Maneuver.TYPE_KEEP_RIGHT
                m.contains("UTURN") || m.contains("U_TURN") -> if (left) Maneuver.TYPE_U_TURN_RIGHT else Maneuver.TYPE_U_TURN_LEFT
                m.startsWith("MOTORWAY_EXIT_LEFT") -> Maneuver.TYPE_OFF_RAMP_NORMAL_LEFT
                m.startsWith("MOTORWAY_EXIT_RIGHT") -> Maneuver.TYPE_OFF_RAMP_NORMAL_RIGHT
                m == "ARRIVE_LEFT" -> Maneuver.TYPE_DESTINATION_LEFT
                m == "ARRIVE_RIGHT" -> Maneuver.TYPE_DESTINATION_RIGHT
                m.startsWith("ARRIVE") -> Maneuver.TYPE_DESTINATION
                m == "DEPART" -> Maneuver.TYPE_DEPART
                m.contains("FERRY") -> Maneuver.TYPE_FERRY_BOAT
                m == "STRAIGHT" || m == "FOLLOW" -> Maneuver.TYPE_STRAIGHT
                else -> Maneuver.TYPE_UNKNOWN
            }
            val mb = Maneuver.Builder(type).setIcon(CarIcon.Builder(IconCompat.createWithResource(ctx, maneuverIcon(type))).build())
            if (type == Maneuver.TYPE_ROUNDABOUT_ENTER_AND_EXIT_CW || type == Maneuver.TYPE_ROUNDABOUT_ENTER_AND_EXIT_CCW) mb.setRoundaboutExitNumber(t.exit.coerceAtLeast(1))
            val what = when {
                type == Maneuver.TYPE_ROUNDABOUT_ENTER_AND_EXIT_CW || type == Maneuver.TYPE_ROUNDABOUT_ENTER_AND_EXIT_CCW -> "Take exit ${t.exit}"
                m.startsWith("ARRIVE") -> "Arrive"
                t.tag.isNotBlank() -> t.tag
                else -> m.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }
            }
            val cue = if (t.street.isNotBlank()) "$what · ${t.street}" else what
            val sb = Step.Builder(cue).setManeuver(mb.build())
            if (t.street.isNotBlank()) sb.setRoad(t.street)
            return sb.build()
        }
    }
}

/** Lets the map screen's once-a-second tick also update the speed sign drawn on the map. */
object CarTicks { var tick: (() -> Unit)? = null }

/** Home, Work, your saved places, favourites and recent destinations: tap one to go. */
class PlacesScreen(carContext: CarContext, private val holder: CarHolder) : Screen(carContext) {
    override fun onGetTemplate(): Template {
        val e = holder.engine
        val limit = try { carContext.getCarService(ConstraintManager::class.java).getContentLimit(ConstraintManager.CONTENT_LIMIT_TYPE_LIST) } catch (x: Exception) { 6 }
        val list = ItemList.Builder().setNoItemsMessage(if (e == null) "Starting the map…" else "No saved or recent places yet")
        if (e != null) {
            val all = ArrayList<Pair<String, Place>>()
            e.places.slot("home")?.let { all += "Home" to it }
            e.places.slot("work")?.let { all += "Work" to it }
            for (c in e.places.customs()) all += c.label to c.place
            for (p in e.places.favourites()) all += p.name to p
            for (p in e.places.recents()) all += p.name to p
            val seen = HashSet<String>()
            for ((label, p) in all) {
                if (!seen.add("%.4f,%.4f".format(p.pos.lat, p.pos.lon))) continue
                if (seen.size > limit.coerceIn(1, 12)) break
                val r = Row.Builder().setTitle(label)
                val sub = if (label == p.name) p.sub else p.name
                if (sub.isNotBlank()) r.addText(sub)
                r.setOnClickListener { go(e, p) }
                list.addItem(r.build())
            }
        }
        return ListTemplate.Builder().setTitle("Places").setHeaderAction(Action.BACK).setSingleList(list.build()).build()
    }

    private fun go(e: NavEngine, p: Place) {
        e.startRoute(p, startNow = true)
        screenManager.popToRoot()
    }
}

/** Search with the car's keyboard or voice: results from the same search as the app (TomTom, or offline when there's no signal). */
class SearchScreen(carContext: CarContext, private val holder: CarHolder) : Screen(carContext) {
    private var query = ""
    private var shown: List<Place> = emptyList()
    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            val r = holder.engine?.results ?: emptyList()
            if (r !== shown) { shown = r; invalidate() }
            handler.postDelayed(this, 500)
        }
    }

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) { handler.post(poll) }
            override fun onStop(owner: LifecycleOwner) { handler.removeCallbacks(poll) }
        })
    }

    override fun onGetTemplate(): Template {
        val e = holder.engine
        val limit = try { carContext.getCarService(ConstraintManager::class.java).getContentLimit(ConstraintManager.CONTENT_LIMIT_TYPE_LIST) } catch (x: Exception) { 6 }
        val list = ItemList.Builder().setNoItemsMessage(if (query.length < 2) "Type a place, address or postcode" else "Searching…")
        if (query.length >= 2) for (p in shown.take(limit.coerceIn(1, 12))) {
            val r = Row.Builder().setTitle(p.name)
            if (p.sub.isNotBlank()) r.addText(p.sub)
            r.setOnClickListener { e?.startRoute(p, startNow = true); screenManager.popToRoot() }
            list.addItem(r.build())
        }
        return SearchTemplate.Builder(object : SearchTemplate.SearchCallback {
            override fun onSearchTextChanged(searchText: String) { query = searchText; e?.search(searchText) }
            override fun onSearchSubmitted(searchText: String) { query = searchText; e?.search(searchText) }
        }).setHeaderAction(Action.BACK).setSearchHint("Search for a place").setInitialSearchText(query)
            .setShowKeyboardByDefault(true).setItemList(list.build()).build()
    }
}
