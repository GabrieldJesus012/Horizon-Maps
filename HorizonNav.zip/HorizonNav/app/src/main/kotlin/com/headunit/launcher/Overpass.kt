package com.headunit.launcher

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Nearby(val place: Place, val dist: Double, val extra: String)

/** Free OpenStreetMap queries: speed limits, speed cameras and nearby fuel / charging / parking. */
object Overpass {
    private val endpoints = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter",
        "https://overpass.private.coffee/api/interpreter",
        "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
    )

    /** The server that answered last time is tried first. */
    @Volatile private var preferred = 0

    /** What the last quick query did, for the settings page. */
    @Volatile var lastNote = ""

    private fun run(query: String, connectMs: Int = 8000, readMs: Int = 18000, tries: Int = endpoints.size): JSONArray {
        val errors = ArrayList<String>()
        for (n in 0 until minOf(tries, endpoints.size)) {
            val idx = (preferred + n) % endpoints.size
            val ep = endpoints[idx]
            val host = ep.removePrefix("https://").substringBefore('/')
            try {
                val c = URL(ep).openConnection() as HttpURLConnection
                c.connectTimeout = connectMs
                c.readTimeout = readMs
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("User-Agent", "HorizonNav/1.0 (Android navigation app)")
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                c.outputStream.use { it.write(("data=" + URLEncoder.encode(query, "UTF-8")).toByteArray()) }
                val code = c.responseCode
                if (code !in 200..299) throw IOException("HTTP $code")
                val body = c.inputStream.bufferedReader().readText()
                val els = JSONObject(body).optJSONArray("elements") ?: JSONArray()
                preferred = idx
                lastNote = host.removePrefix("www.").substringBefore('.') + " ok"
                return els
            } catch (e: Exception) { errors += host.removePrefix("www.").substringBefore('.') + ": " + (e.message ?: e.javaClass.simpleName) }
        }
        lastNote = errors.joinToString("; ")
        throw IOException(errors.joinToString("; "))
    }

    private const val MPH = 0.44704

    /** Country of a position, from where it is rather than the head unit's language setting (which is often en-US). */
    fun countryAt(p: LL): String {
        val inGb = p.lat in 49.8..60.9 && p.lon in -8.7..1.8 &&
            !(p.lon < -5.4 && (p.lat < 54.0 || p.lon < -8.2 || (p.lon < -7.25 && p.lat > 54.65)))
        return if (inGb) "GB" else java.util.Locale.getDefault().country
    }

    /** UK limits are only ever 20, 30, 40, 50, 60 or 70 mph (plus 5, 10, 15 in car parks and yards). */
    private val gbMph = intArrayOf(5, 10, 15, 20, 30, 40, 50, 60, 70)
    private fun snapGb(ms: Double): Double {
        val mph = ms / MPH
        var best = gbMph[0]
        for (v in gbMph) if (Math.abs(v - mph) < Math.abs(best - mph) - 1e-9) best = v
        return best * MPH
    }

    private fun parseSpeed(s: String, country: String): Double? {
        val t = s.trim().lowercase()
        if (country == "GB") {
            when (t) {
                "gb:nsl_single", "uk:nsl_single" -> return 60 * MPH
                "gb:nsl_dual", "uk:nsl_dual", "gb:motorway", "uk:motorway" -> return 70 * MPH
                "gb:urban", "uk:urban" -> return 30 * MPH
            }
        }
        val m = Regex("^(\\d+)\\s*(mph|km/h|kmh|kph)?$").find(t) ?: return null
        val v = m.groupValues[1].toDouble()
        val unit = m.groupValues[2]
        // in Britain every limit is in mph, even when the mapper left the unit off
        if (country == "GB") return snapGb(if (unit == "mph" || unit.isEmpty()) v * MPH else v / 3.6)
        return if (unit == "mph") v * MPH else v / 3.6
    }

    class Limit(val ms: Double, val estimated: Boolean, val road: String = "")

    /** Set when the last speed-limit lookup failed (no network, server busy…), null when it worked. */
    @Volatile var lastError: String? = null

    private val driveable = setOf(
        "motorway", "motorway_link", "trunk", "trunk_link", "primary", "primary_link", "secondary", "secondary_link",
        "tertiary", "tertiary_link", "unclassified", "residential", "living_street", "service", "road",
    )

    /** Typical limit for a road without a posted one, from its type and the country (m/s). */
    private fun estimate(tags: JSONObject, country: String): Double? {
        val hw = tags.optString("highway")
        if (hw !in driveable) return null
        val link = hw.endsWith("_link")
        val base = hw.removeSuffix("_link")
        val lit = tags.optString("lit") == "yes"
        val oneway = tags.optString("oneway") == "yes"
        val mph = 0.44704
        val kmh = 1.0 / 3.6
        return when (country) {
            "GB" -> when (base) {
                "motorway" -> if (link) 50 * mph else 70 * mph
                "trunk", "primary", "secondary", "tertiary", "unclassified" ->
                    if (link) 40 * mph else if (lit) 30 * mph else if (oneway && (base == "trunk" || base == "primary")) 70 * mph else 60 * mph
                "residential" -> 30 * mph
                "living_street" -> 20 * mph
                "service" -> 10 * mph
                else -> 30 * mph
            }
            "US" -> when (base) {
                "motorway" -> if (link) 45 * mph else 65 * mph
                "trunk", "primary" -> if (lit) 35 * mph else 55 * mph
                "secondary", "tertiary" -> if (lit) 30 * mph else 45 * mph
                "unclassified" -> 35 * mph
                "residential" -> 25 * mph
                "living_street" -> 10 * mph
                else -> 15 * mph
            }
            else -> when (base) {
                "motorway" -> if (link) 60 * kmh else 130 * kmh
                "trunk", "primary" -> if (link) 60 * kmh else if (lit) 50 * kmh else 100 * kmh
                "secondary", "tertiary", "unclassified" -> if (link) 50 * kmh else if (lit) 50 * kmh else 80 * kmh
                "residential" -> 30 * kmh
                "living_street" -> 10 * kmh
                else -> 20 * kmh
            }
        }
    }

    private class Way(val tags: JSONObject, val g: List<LL>)
    private var cacheAt: LL? = null
    private var cacheWays: List<Way> = emptyList()

    private fun bearingOf(a: LL, b: LL): Double {
        val dy = b.lat - a.lat
        val dx = (b.lon - a.lon) * Math.cos(Math.toRadians(a.lat))
        return (Math.toDegrees(Math.atan2(dx, dy)) + 360.0) % 360.0
    }

    /** Loads the roads around [p] once and keeps them, so the next few hundred metres of lookups need no network at all. */
    private fun loadWays(centre: LL): List<Way> {
        val els = run("[out:json][timeout:10];way(around:160,${centre.lat},${centre.lon})[\"highway\"];out tags geom 90;")
        val out = ArrayList<Way>()
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            val tags = e.optJSONObject("tags") ?: continue
            if (tags.optString("highway") !in driveable) continue
            val g = e.optJSONArray("geometry") ?: continue
            val pts = (0 until g.length()).mapNotNull { n -> g.optJSONObject(n)?.let { o -> LL(o.getDouble("lat"), o.getDouble("lon")) } }
            if (pts.size >= 2) out += Way(tags, pts)
        }
        return out
    }

    /**
     * Speed limit of the road at [p]: the posted one when OpenStreetMap has it, otherwise the usual limit for that kind of road.
     * [heading] (degrees, or negative when unknown) is used to prefer the road you are driving along over one that crosses it.
     */
    fun speedLimit(p: LL, heading: Double = -1.0, country: String = countryAt(p)): Limit? = try {
        val c0 = cacheAt
        if (c0 == null || Geo.dist(c0, p) > 90.0) {
            // fetch a little ahead of the car so the next stretch is already known
            val ahead = if (heading >= 0) LL(p.lat + 60.0 * Math.cos(Math.toRadians(heading)) / 111320.0, p.lon + 60.0 * Math.sin(Math.toRadians(heading)) / (111320.0 * Math.cos(Math.toRadians(p.lat)))) else p
            try { cacheWays = loadWays(ahead); cacheAt = ahead }
            catch (e: Exception) { if (c0 == null || Geo.dist(c0, p) > 150.0) throw e }
        }
        var bestTags: JSONObject? = null
        var bd = 1e9
        val mLat = 111320.0
        val mLon = 111320.0 * Math.cos(Math.toRadians(p.lat))
        for (w in cacheWays) {
            var d = 1e9; var brg = 0.0
            for (n in 0 until w.g.size - 1) {
                val a = w.g[n]; val b = w.g[n + 1]
                val ax = (a.lon - p.lon) * mLon; val ay = (a.lat - p.lat) * mLat
                val bx = (b.lon - p.lon) * mLon; val by = (b.lat - p.lat) * mLat
                val dx = bx - ax; val dy = by - ay
                val l2 = dx * dx + dy * dy
                val t = if (l2 > 0) ((-ax * dx - ay * dy) / l2).coerceIn(0.0, 1.0) else 0.0
                val ex = ax + t * dx; val ey = ay + t * dy
                val dd = Math.hypot(ex, ey)
                if (dd < d) { d = dd; brg = bearingOf(a, b) }
            }
            var pen = if (w.tags.optString("highway") in setOf("service", "living_street")) 15.0 else 0.0
            if (heading >= 0 && d < 60.0) {
                val diff = Math.abs(((brg - heading + 540.0) % 360.0) - 180.0)   // 0 = same way, 180 = opposite
                val oneway = w.tags.optString("oneway") == "yes"
                val along = if (oneway) diff <= 30.0 else (diff >= 150.0 || diff <= 30.0)
                val back = oneway && diff >= 150.0
                if (back) pen += 40.0 else if (!along) pen += if (diff in 60.0..120.0) 25.0 else 8.0
            }
            if (d + pen < bd) { bd = d + pen; bestTags = w.tags }
        }
        lastError = null
        val t = if (bd <= 45.0) bestTags else null
        if (t == null) null
        else {
            val posted = parseSpeed(t.optString("maxspeed"), country)
            val ref = t.optString("ref").split(";").firstOrNull()?.trim().orEmpty()
            val nm = t.optString("name").trim()
            val major = t.optString("highway") in setOf("motorway", "trunk", "primary", "motorway_link", "trunk_link")
            val road = if (major && ref.isNotBlank()) ref else nm.ifBlank { ref }
            if (posted != null) Limit(posted, false, road)
            else estimate(t, country)?.let { Limit(if (country == "GB") snapGb(it) else it, true, road) }
        }
    } catch (e: Exception) { lastError = e.message ?: e.javaClass.simpleName; null }

    /** Traffic signals inside a box (used to draw traffic lights on the map). */
    fun signals(minLat: Double, minLon: Double, maxLat: Double, maxLon: Double): List<LL> = run("[out:json][timeout:15];node($minLat,$minLon,$maxLat,$maxLon)[\"highway\"=\"traffic_signals\"];out skel 400;", 10000, 20000, 2).let { els ->
        (0 until els.length()).mapNotNull {
            val e = els.getJSONObject(it)
            if (e.has("lat") && e.has("lon")) LL(e.getDouble("lat"), e.getDouble("lon")) else null
        }
    }

    fun cameras(p: LL, radius: Int): List<LL> = try {
        val els = run("[out:json][timeout:10];node(around:$radius,${p.lat},${p.lon})[\"highway\"=\"speed_camera\"];out;")
        (0 until els.length()).mapNotNull {
            val e = els.getJSONObject(it)
            if (e.has("lat") && e.has("lon")) LL(e.getDouble("lat"), e.getDouble("lon")) else null
        }
    } catch (e: Exception) { emptyList() }

    /** Speed cameras inside a bounding box (used to find the ones along a route). */
    fun camerasIn(minLat: Double, minLon: Double, maxLat: Double, maxLon: Double): List<LL> = try {
        val els = run("[out:json][timeout:15];node($minLat,$minLon,$maxLat,$maxLon)[\"highway\"=\"speed_camera\"];out;")
        (0 until els.length()).mapNotNull {
            val e = els.getJSONObject(it)
            if (e.has("lat") && e.has("lon")) LL(e.getDouble("lat"), e.getDouble("lon")) else null
        }
    } catch (e: Exception) { emptyList() }

    /** kind: "fuel", "charging" or "parking". */
    fun nearby(kind: String, c: LL, radius: Int): List<Nearby> {
        val f = when (kind) {
            "fuel" -> "[\"amenity\"=\"fuel\"]"
            "charging" -> "[\"amenity\"=\"charging_station\"]"
            else -> "[\"amenity\"=\"parking\"]"
        }
        val q = "[out:json][timeout:20];(node(around:$radius,${c.lat},${c.lon})$f;way(around:$radius,${c.lat},${c.lon})$f;);out center tags 80;"
        val els = run(q)
        val out = ArrayList<Nearby>()
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            val tags = e.optJSONObject("tags") ?: JSONObject()
            val pos = if (e.has("lat")) LL(e.getDouble("lat"), e.getDouble("lon"))
            else e.optJSONObject("center")?.let { LL(it.getDouble("lat"), it.getDouble("lon")) } ?: continue
            val label = when (kind) { "fuel" -> "Fuel station"; "charging" -> "Charging point"; else -> "Car park" }
            val name = tags.optString("name").ifBlank { tags.optString("brand") }.ifBlank { tags.optString("operator") }.ifBlank { label }
            val extra = ArrayList<String>()
            when (kind) {
                "fuel" -> {
                    tags.optString("brand").takeIf { it.isNotBlank() && it != name }?.let { extra += it }
                    tags.optString("opening_hours").takeIf { it.isNotBlank() }?.let { extra += it }
                }
                "charging" -> {
                    val sockets = ArrayList<String>()
                    val it2 = tags.keys()
                    while (it2.hasNext()) {
                        val k = it2.next()
                        if (k.startsWith("socket:") && k.count { ch -> ch == ':' } == 1) {
                            val nice = k.removePrefix("socket:").replace("_", " ")
                            val cnt = tags.optString(k)
                            sockets += if (cnt.toIntOrNull() != null) "$nice ×$cnt" else nice
                        }
                    }
                    if (sockets.isNotEmpty()) extra += sockets.take(3).joinToString(", ")
                    tags.optString("capacity").takeIf { it.isNotBlank() }?.let { extra += "$it points" }
                    tags.optString("operator").takeIf { it.isNotBlank() && it != name }?.let { extra += it }
                }
                else -> {
                    when (tags.optString("fee")) { "yes" -> extra += "Paid"; "no" -> extra += "Free" }
                    tags.optString("capacity").takeIf { it.isNotBlank() }?.let { extra += "$it spaces" }
                    when (tags.optString("parking")) { "multi-storey" -> extra += "Multi-storey"; "underground" -> extra += "Underground" }
                }
            }
            out += Nearby(Place(name, tags.optString("addr:street"), pos), Geo.dist(c, pos), extra.joinToString(" · "))
        }
        return out.sortedBy { it.dist }.take(40)
    }
}
