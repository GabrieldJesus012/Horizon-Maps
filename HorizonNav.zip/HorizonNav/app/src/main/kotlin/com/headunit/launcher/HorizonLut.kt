package com.headunit.launcher

/**
 * The Horizon colours on Mapbox's map: a colour look-up table (a 32x32x32 cube as a 1024x32 PNG) given to the Standard style as its
 * custom theme. It keeps Mapbox's own colours and adds a gentle purple-blue hint, strongest in the dark colours (so the night map
 * gets the deep blue-violet of the original app's map) and almost none in the light ones (day land, labels); greens are left mostly
 * alone so parks stay green. Made by tools/make_lut.py.
 */
object HorizonLut {
    const val BASE64: String =
        "iVBORw0KGgoAAAANSUhEUgAABAAAAAAgCAIAAAADnJ3xAAAasElEQVR42uVdXZPcuA0EZ3ed9Usqecn//5uxPeo8zJdEEkADhNa+i+uqbndn1JIIEOwGCbJ9" +
        "XP7zKfiEfMrtP3yX18+3H74/fnj+8Xv/hdfPe5APkW/tX58in4CJP7/c+M7tke74mHw0PO0ifqA1+O8o+PuvreJ/yL/cy9MW+RDs8AOvEMH/9/cjFHM52WKP" +
        "9nEbk3UYBb/MoN0rz/CTXXgZP9PFbvhkY8afQb4Jpvhph+m+c8SPvQKHf2sfJB6PabEBn7mcCSP3r3172RdVMd/DZwyqOkyHk8Vnv/PEL4zJU/+schgTv76L" +
        "Pf2zymE8/OIutrMvqmK+h1/Zxcrxuyix95+qmPy9989/7j6SY2fP4Xf+86Hh63dk//JN5GPhcgb/ffvHf6V9ExERyOt/95+Pvz3/2P+M4e/Py9CgffS6HHNY" +
        "42c8r23qRxN4/Rl0/L41BnyBeM+g/3zEnzUmhw/tXs18DCgW4VusGW8HQdhh+u80qLeG3qp8izWoHyHjkEH8sMP0LdaUxgRyDtn39rZvzCl+0GG6R2rKR4fG" +
        "j+J3/jl8DQsOw/g/Zn3Bx589akN/a1BGZFusof8I88vd1p77WAA/3MWO+Id2WonJx/h5Nv7xV3jxMNLFenxUOIzh/yZPSHax+/i+RBIU/Jf/9DRB6rqYjp+P" +
        "yYN/diPKakwe/RN1Djn6D0odZoIv03/IOUzvnyr+7I7+X0KXr9/xHZ8/NhFpH0a491sKqiXQfmyY4tNdyyapzXA7rmshTEBjoxeyBJHpWi4JdvC9YIQsARX4" +
        "XQtEpGj6rd1ghPgArDgSgw+egDKjF7hg14w4uIKvE1By9EKWgB4a0+pT/ug4JaDM6MVrv+aOHAM+TIeZDvChLgx6dIz45ww/SEAZfMS6+ZOAsjEZUQIaoTtY" +
        "IKBMFwOXFMjiI4wvO3wmk5UUYBT/5kgq758YjJskoOskwSagTEwG6zBQBNgSSTBodyOyPBHt17dYmzd3EF9/o+axbcRIfP+F5n05iC+DALhCfmwNIh8ZAupZ" +
        "AvgBER1/QdvdneYHRDYRkY/d01bhVyYDELtFONYb+CX5Nr3FtAbPOMx5yYD5gE0T0IzDIEtASasBBEFk8PWw3s5wmD0+JcDI0RHjj01W51h8fMagVFTBOGCH" +
        "CCiJjyxBJFvsNPyJ27bqmAyWgEoeP5kg8FsMFgEtiMnjdDpJQMkWC+Ij9DrIEtCItoSawFojCdrUUCuKyQgLsFhMxmqCwGox6DG2OVl/SrHAFWBrSXqDxHv4" +
        "vqKAdcm7fArkinse/aOcgAJXiIz4y8HoifMDIrh/+mEQUESD3R3nJ0S2++UfZcHo9TMCKXM/CzveAtWKRcN31MuyIipwGKPFEBRgDgGtk7hpjZdQLDhF4tpd" +
        "DLyGRMZJsGIRRFqvTrTjZHxaIdd0sSqHwTSN9yVdrAp/vATnd7HfFpMruliVQ+Y5xnKL1TrMb+lilQ4DPT6XxGTMWXHBIG7icxn9P2DZjxwEwPfbD9dN8ODQ" +
        "Z4yO123g6Anfmn3nevvdxac5TffWd4Gx3f/6Xjs6GvhBcvAXIKCuYjmbgIpOQCVGQM1lJxy+FHcxccUY1qaGShzmq0avs/j3YhdDsoudNDqiiCAy/lnvMKcl" +
        "BTLW+RoCmmqxWof5LV0sShKSBPSkFvurOUw0i5RwmHyiNh6TaxWLnV5PJekjlywqiu6Sd/l8/nq994b2fn83chUv1VI3fOzwa8piSvGnDnTFIVrgjl9WdvPz" +
        "MYPR40tNsPsx4H9o694yZTFtuoAhr1iMKc5xgQTWg904RY6AYvFZmoqfdpjjR+MUOUoJaBubrVSxtLL9Bua3a35JehBf9c/pfgOJLOk5+MobNdEXMFR0sVV8" +
        "r8XawbilpZA3/3QCWthhukuas9/AYouhwe1TMYdR8eti8v6jMD7Zxf4gAlrRYsVZpBT+IlE8q4vVSlx7LDkjr3+qoniXz/2bXA8c1O0DgbIYKPhi1xESi8zE" +
        "eH7HEUH61h4fLw6dL7vZ/9oLjIeG8fg3qK47CIyjxtNeny6L2eGDxmd3MpkQUDIWg66javEMJbIElJS4yBJQcvQKlSq2YCxGloCSsZgoz50TUAYfhMNoBJQZ" +
        "vZAloEv45uW8/4NOCnQEkSQHyBJQcvCOlCoeCCiTE0GMgO52yePoDrKUncGHROcVQfun8PsNTFssgJ8ioM3fb2CJgPr4Iom82yt+mo+HZY3XTPmBuMMM4zuz" +
        "n0FqC7Kn//hlCeG8W++f09hRQdkbdU1ahNxmAAaO23Bbi5IpS+/DOmb4IvJeUzuLCZ9+4jOOCIoqyQx/revKZAYJskF+Ptt/deUuRoEhe/vSXXcmf6EJjAN+" +
        "YuuxA3772amLx6ztG4kv9oAaJaDkOlGoA/CSwwy7ZCJEEMkW289RBAWYMDs/wCKgeYeZzlHE8Z03QpiAxhYWd/NQS/iibxAUIYh8i8EnoBmHmePTBJHsYpgT" +
        "0FWHmXUr4Qki2WJ6EWcywvSBIEVA+RZDlIByDqNnKg3/DHcx6BqviaymzOfyErT/Oy0GM2i03IwBnalskBT/hpOIx4Cf6mLwNF5bS9JbJP7mny2PT2wQdBcA" +
        "6Dho+/VYj+4vmXJq9TDF/wl5aoy1RWaTyHFFg4Iv4XV1EzV9q5nea6TYIrPZeN89/4vjZvnE7NF7+75Jik8csy/Xbh0lRPb+E3SYsRv3S6R2Nd/vq3zijo+J" +
        "hhFV40koA1pRRxWap67YH2ny2CsEVPQMaGr0irZYHQGddbHaDa+YVQSyGJOXN7wKdrESh1FLC1DvMBIsjQjG5K/uYosO419S6jDTrPjaIO41cqoLC7eoBgsO" +
        "w5YWnBCTv6CLWf5Z0sUWkgK2QyYS7qFrkLg8VxvwLALuLrzuOJbfUsRS6e7fBvm1z+Mul8W4+Cu+i9k8ADR8ifvu8ISPtUaWBiOLOyf2xcG+yxpv4kC39i/Q" +
        "eJCZwBCx8UEHu05gyFEM7DRSMtiNMyT7W0z9P+owpZu3UASUb96TCGioxVARYc7eXCV0EgKWI4xNQKWmxV7xs07iJgloxGFcArroMF/cxbDgMPbmKjjNYYzB" +
        "929CQCUQ9BhmVRyTZ29X38U4/FwX641b6jDTly2h7OPtWoWiUC/plgDt3/zFcde2o5k+B+TFcd84fh8ioE8NAJH3tSIPmBrDxk/nDw74Evddwic7DZMv5Fcs" +
        "MGqkco1ncWgy2GkCQ14a4y3oMB3+L2UG4zmP8ZbjE4+H/CkqeEDjqS3WmMX3Czs+NWGO+cx3MQ5f0sPDbQoYKxHGfJJmnwWeSwocazyQIaB0F8OCw/y5BDTv" +
        "MPQrpOiaEOcRLbZYkoAuvFGJw4QJ6JrGO4WAwvHPVYf58i6WVixGiwVukU0KIMfIEfjwiyYB9gJgwkHlxoFav9ZCKbth2BsIfHJAFW+7pOvdadrb8IzrBHTH" +
        "QdsbJm2QD3YKvuiVPXZv1O7y0Bjtbb4zTUbjgcSPbH1gawxIe+c2CJLgbr4bXv6jrRJ249cV5s6gB/9EVON1AuOpCrqa77exRcnwvcPHUR29/vLA5x1mWmS8" +
        "WqqonMTMEVBkCSh5UBSyBLSxR86lkgKgDkrDvHmpmNyI/kKXKs4FkuYwE6PFY3Lz+gvWCKh7UBq7QZDyRi2wnwERbZDCT8dkWDUkqCCgFn4FATUOMkM2KcDg" +
        "I+owjn9O9xtY0Hij/3Tj00pSYO6fIPYbCCZq50XAjlBQwp8eP/WovywS9tuATr+93R4CkzwxWapoa5oOXwKF/PDfEbKJ/JIGAl9MEWJpDGkY1wI5wQ7kcRKb" +
        "hy9GacFwUNcU/+Zkb7Gtx1iBusm9UPWNLiTiJngG/MDODyBnz26t9wsNM3wl2IHsiS/77vCJYNdHXktg3B+szefZ5m/Uj9m/xBQYj/a/UNvbDaWEj3IRGAul" +
        "ICJyofIxCBDQzM4PiBNQfnREioDyCa2pCGngX9/ebyBDQPkWQ5iA0gk8cwOozEm9oi0gsglobP/QQRzHCCLH732R0EKCcBaTkSKgfIshRUDJFoM3CdBSDqO8" +
        "wOQhW8phWBHiFPE7LQaCUjfeYYYWA6HBWjYmc7s4Rk8ChjFUWdt8s/hREXLYBlTTAGi3UfgtODw8jQQPX474ElhjR2gM3Cu1LywB9es9MMN/y2RA4djwsWnS" +
        "iM/pMT+RfrfvqPGoKU7CvnLAl9gaO0ZD9v7Dz0qBse+jE14yGVDCvh6+nfp17gOBtKvIRONxlHp7ZfpnAgP3QfRN5A28xnvZaCIw5CgwHn+IaLydgJnpFgx3" +
        "YTSeMwWPFQJq9bi8YvEzTNH+yMRkZxVKolJTmMWNiCfwIse4Vmg83bi0wzgxGZMURqHD8PgcAfVzusIvPOa6WOjT8KwU/E9LlkWxXUCSXWzun2tdTMyDOHNd" +
        "jFyIVR6Tkxn3lEPG8EOXTIuAZxx0locLrbFzOOhrvTgqTDvBv3GU7IDnaQzZc9AIASVo44DP90bKEXfE6xKPbn7GGwLIddBgoTV2gG/frMbziPTTfyIaz44U" +
        "c/t6Gs/uca59pxrP9U+m/97tO/oPQUC3KfWXXglAx7e71S+8HrJbwrT/FRENNlkitXtaDHcZ+1eGgK5Rdu2NYgQUpQS0giHF+NMiAcUfT0AXmzfxRudovN9D" +
        "QOMt5hLELyCgxUkBZDY7CsVkobdlX9VgZyQF1ioB/KQAHLYZ/mdc8qoBgHPVtq9ZDBZ52A/x2ilCwV8loA/8KzyOa7JAtx4AmHEI3rTm3118JkYz9r3Q0Q0R" +
        "98NOwxQT0Kd9FQ3GFy67+M/2j2ZAXXfdphwX2ZbHzL7i+afQM0dQ7EtrPNG22NLCEe4lPZcgAd3kmPXXhv0H/luIgD7P2egEhvSTGM9ZiEuIgO5rPJS7dPMz" +
        "lxDjjBLQxHhv90eUEtAgfwoT0GCL+eM9/jwCGnqjij1qYwQ0pfF+GwFdcxgGH8HmDTFOLB9cI9w8WJnDSI3DhLoYyb9XkgJJfu/+6w8CC3JQ3rQ8Bz1wlAoC" +
        "OmqMS1DgkjrsxgYOHBexZkEKP0P94duX743am7j2LSGgnX1JjSf2JJXZ/pdUsPO7wwxfIosKmP6L4DxbqP8+NUyIgIY0ZEKD8Rpy0zWYhk8JjL3G4DSe7E9P" +
        "37v3TGBADj8HcgRHgYGpbhn+EtBgaOQCvCwBtQ8ywzIBNfAh6wR0PGiJPuudI4hNuTtXxOnF5MlJ6mMxBVYIaPMrgJcI6OygsdhZ7PYDtNndEXUYq8YD3pFz" +
        "3EoBrQZjctb74jooOfrngL/mMN0DtMlLRxwGTv6u+bwnoYiC+GFJAEUAuLIDt2O2DI4yb+EJjs5RWs8hZp2SJIjQ8c1gh8ASpgkHbRfLtP7eCxZH2eGLWVaV" +
        "kWR3Dtp0DQbmsT0OyuJnOOiAL+7R6yn72rXR0YT91L5G2VOI+lv44hEm5kZQ/Qeq+0ciFXT7jsM2Yj6/f/NHjqBdDKqKcLwd+28zWh5jmftAHPR9pbbOP+fE" +
        "dXLOhiMwDjc6+g+MOs521SvIsU+DH2nxUSMhQEAzWXBYBHRxkcZQKEoQ0JBiQZyAenQNWqJ8ThAXduNxh6q2th0kPA3WUg6jZtI8AhpSLBB/U9eZ/1NpTZAE" +
        "NLt/KCzK2+Fntm8Cp8GaZFb1uLXRR/9x9/eEqTDF2CDVx7fGY3eIetYAgAO+PdO2zxMHJwFA4B/yoNkMpV7fWYOvBcdN7ucQXzi1Dcaqh2Md2zR0BZcDQb/V" +
        "y76JJUZYxwfVMiDwJbHGTmbY0O0b1PfGbbHjHFYe16mTc6XxvX1aBJ/7UMGPTQLA05aD/wTmwfzJnk1a6/zH3F46VvP9sO9lhi9OJQCpZdrW+Sfs9x3UmbOv" +
        "lOc/s3M2xqrr/a+9wPDw9154xWQd1KGqRGZTNPPcGkXRileh5AloLAVbVVxHzqMuvRHEyWEnKbXygqkN7HMOk7GX9wB8Rjm0CkWUQxJkYaE8mVRaWShPFaNG" +
        "FnolEqmLKwP9PGjVJICzDeiU1t3yNYjNNVNj4842mxGj/Y1PzsXX+s+Ifyk6U7qvGX1MxF+SBNRh1qN9GYII+h54LBfJaTBw+J1GSsg8RPBFitbSjP5Dr9EM" +
        "2fdC4K/Yt9lryZbty2uwVfsGNRJvXwY/vFwKgkfirkXGeyBjX3f43wZP9Q50EBn9B2pDhQXGK49CabCrsg5KXMmxa/+/IgHlH8DYDjL/Rra6+FsT0DSnrypN" +
        "EeUkckkvlDc1fEH1vCmZeM0Mj+PZv64nBeScU8bUL/jbgOqt9lwv6w4kicESj8WslwhBDFGuTR5jAKo5ygMfD/w0O4SJL8d9dLHc7IcxfsAXvkaC4KDNzcMV" +
        "cVA7fK9w0MZpsDQHjWqwFQ5qJJwQ9CeNgzoJJ8Tsi6gGQ9K+rEZC2L5T/PQYAMM/FxNarn0Rmh6M21d/7G0mhcEwBdyHAJsGXYkCj/mnkObGt8fWAmJWYogc" +
        "pzjkpTf4edQvJaAJSm0T0MVKzS8goCggoBJP0lMKs4KABvaiNV9QM2K6dFjMEJp3GFcjEUGYxw+H5ZLi4GkRsI/zWDN654ioYYfQ8KPymh5gmoaPpVZ9Pj9E" +
        "4bgQWTHfrn0ap8EyGmOHT2Uogy910xiXR/v4u5sFXwqysy+jwRB2V4Q0GDL9d/M0mPsBPA3cmARG3Jf2GjsXTJnGmftPUY6g67+V81SdfdeoORL4KLNv88Z7" +
        "ie9nd3/4uIbnw9FzHqyZw/NG8n59WGqKJnm+o7sNriE/Nl2DyW7vsn4yRGZzMorkaFZ4bLMRB/z2TZ5DtunnmRw8exI5VUrkJgXGg8zELPXJEtBmlPosElCZ" +
        "HISHlVkpzX+IUqLZHd2cfee8AOkhkcUsO//M4tv+E0iPJbYDsgUAUzO6ibSxpg0IwXkcdKhpA3IEdExL3PEh8FQAgu2LR4C+PFYVw37k+JD80BituWVPEqgM" +
        "6V552+HHm8HkKE//cffWyHGU3j9RzEF7/6ScMWrfy/35UbaKqbdla2PLx+WQ5T8K/qKe2dkXroZH0Ax7+zazLEQIBmzYt0m7jKWiqWPktbxgS0zMgrXvcxgn" +
        "aiTCGqPTwCXdytbA691qTEMY8wCb9uZGEe5xrLqYT7jZR+wpi5dGmqYUA7SrtiPtS73Akhw7muMQ0HAOHkECSkkUeGFAJ6CsRHGHEoWAJvFJARNURBBPtNsn" +
        "eZt3VFp+EuJaauEctCHD8h8W32FomgCmwxCtjKU7CAyZYHrnKFD78GIkxW5JaDrQExylIA9nchRqrcsCBx3wsdTsAwcdxgCsrmKacIgQAUXAvpM8buC0Z8e+" +
        "nf8Y/A9xG7z8x41/Kb364KBDKom2K0j/QWW3mthXTzgt9t/9SFiehVH9p4qDYsJBsdzsNn6ajofcGBX3OmikQGYuZl+D47KtoU9pdfF/XuQtEiA7Q9ba8J9N" +
        "5iXXBwTzU3nO1s6ScFdiHZRKoYhD2lcOESMIaNkptsaYmz5W2Vi2RD0VIckk1K1qZo30v9TMGs39J6TxhFv5GU1ahcPTOAOwmkeJEMSlPAoCGSxysr7NnHt9" +
        "yS/22YzSKfIpPpsnQ9C+UQ2GoH1xGkeZ4Uu6gMELXvUcxczD1cjIEo6i/7M5So19FY5SZl9+XMzad+l5iHDR1uqCGPy8q4OwL7HuPKFXn3GgIcYAyHyEVSmI" +
        "gv5rhKCyNJCmseELDP9JTI3ECAzqFI5p/MHrhMRx/ytExAzcehKJVwJECKiYkwASWLakt3RkEkBSirpi2ZKjQJaXLTkKJPoAjCKqH+xHAYA49GGXKATGAATD" +
        "T4dfnCfblQScwlFgcZSCG+FkjoL6iR0tbdNKqf8UX+rSk4Z9wwQUfuKHGmMSehXhFfMxvYp4lw/p1R1+S88QwpL6nYbMLJQi7DvR8Fjqv12zY9TYKO2/QQKa" +
        "6L8rDwrC9K2uQEXDl4oCFc2I5PiVjs+5/F1ee9MCIzFIsQJDvBNSjhqg37KPKb0wugxMjV1OQInaawkvxNclTbY2mlE4Yp5kzCoiT8cu7h+KqBvXUjF2G1C6" +
        "9Zc4ipsnQ9mLixJupKIpbPwkRwGRB91pmNzOtUxnsMcYxJsJRBaNGWXPtW8OH2W+tG//xVJOxr6IW4S8V+N6dE1QQmUXXl+2l17Cvt4aT3bSqlfSd1cFckCp" +
        "uyRyNFjoFH+ofaHad2UQ8YcDW2NHD8WYhSDLfyLHFU3/Ni6k3Cy2qBJxXsNtz0Bkr5LiaOMY0DZFvUBLPbjL0o/Rur86vmrFrWHoCiRj66AcBdKmR9OWLFuS" +
        "3aFM8PhIbtnS4/lPI778NqAM1Xg2evP2emaeGx6+VE+Ry4AfeOQc1UCxTbGcF2E4qGjBZZmj9By3aIq8C9yNk5Q5DdmWKVRIY5xr33IOes5mBqN9a9OTo4Zf" +
        "5aBg/adwRY1v3/j7IGTf1IRJFH8lH+HkaPhwwdkXJYPIjECfIe1w2irEMxT1b3mwPk+/FxgRgWhkLo7+0x4CAxIqw2BfrG3T+ZDJvZRjBB0S0hBdN08IMcwF" +
        "jEU5jBBl3qJJZtkSNRrMtkknzUe7+Tu+F3ceTp/lOQpR1rPEUXDMk6EyjkD8fQ+qYlw7J8DJsBBFSlfUlOdBc2PYeqH5KgcFZd8zlnTDO0AqJ1QY50SKUAfs" +
        "u7CkO4q/3n8TgT3DUSq6FWvf5W4FOrJ9GQc9m7Om7Yu1O4LQGDjBxA0nNyNOvgLnmhizqQN3t6iAFD/aF8+bhpZg0VJnE+/IC/Fruynt7b07uRA/feSCcKuM" +
        "WH0QILX6r8w5AIsc9Izg+P/AQSU+hdppmKWmgB/gWiqDhQh+4Co6wAE6R8lOkctxXxEyg5herS7rU+T0AFZPhnAyR4EjgBc5Cj/JU2/fkntNT3krvBdqtjhT" +
        "h8yT7SuRSTxIefOl9GrOvtlwwdo3ReXdHArWLM1ryJXhIHFVcrgv6Vb6ii+YVHUxH3QQMFUCQzyBEQRH3E9yy5YWh4zMP1cAJJZ0W4uFkPRINsDxEYfDb/xV" +
        "kUZQ82So6dXQCe4Xp6PWv49znk3VGCUcRU7mKF+SB5W/vn3Lm520wnq3avRX8YUWLTbWwgI8yr5YtW9+EKlzCHxhPz/DUtSF3NTZYtYfUfv+qZHzi+917oRG" +
        "BctXiROOG/5666AQjwjdQYE4/upLoLOTCPa//wEb95cJupGyGQAAAABJRU5ErkJggg=="
}
