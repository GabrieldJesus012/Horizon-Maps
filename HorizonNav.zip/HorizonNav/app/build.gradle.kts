plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val tomtomApiKey: String = (findProperty("tomtomApiKey") as String?) ?: ""

android {
    namespace = "com.headunit.launcher"
    compileSdk = 36

    defaultConfig {
        // its own app id, so it installs next to Horizon Launcher instead of replacing it
        applicationId = "com.headunit.nav"
        minSdk = 26
        targetSdk = 34
        // each GitHub build gets a higher version number, so Android always treats a new APK as an update
        val run = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0
        versionCode = 100 + run
        versionName = "1.0.$run"
        resValue("string", "app_name", "Horizon Nav BR")
        // only the chips head units and phones use (the Mapbox map comes with a copy for each, so this keeps the APK much smaller)
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    // Sign every build with our own key: horizon-br.keystore in the GitHub repo (found by looking up from the project folder).
    // The file itself can be public; it is useless without its password, which only lives in the repo secret KEYSTORE_PASSWORD.
    // Android only installs a new APK over the old one when both are signed with the same key.
    val repoKeystore = generateSequence(rootDir) { it.parentFile }.take(6).map { File(it, "horizon-br.keystore") }.firstOrNull { it.isFile }
    val keystorePassword = (System.getenv("KEYSTORE_PASSWORD") ?: providers.gradleProperty("KEYSTORE_PASSWORD").orNull ?: "").trim()
    signingConfigs {
        if (repoKeystore != null && keystorePassword.isNotEmpty()) create("stable") {
            storeFile = repoKeystore
            storeType = "PKCS12"
            storePassword = keystorePassword
            keyAlias = "horizonbr"
            keyPassword = keystorePassword
        }
    }

    buildFeatures { compose = true; buildConfig = true }
    // A release build runs noticeably faster than the debug one (no debug overhead, and the libraries' built-in speed-up profiles are applied).
    // It is signed with the debug key so it installs like before; code shrinking stays off to avoid breaking the map library.
    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            isDebuggable = false
            signingConfig = signingConfigs.findByName("stable") ?: signingConfigs.getByName("debug")
        }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    // Our own app id (com.headunit.nav.br) and name, so it installs next to the original Horizon Nav instead of replacing it, and
    // the original's updater can never install over it. Updates come from this repo's own "app" release. The map is drawn by Mapbox.
    flavorDimensions += "key"
    productFlavors {
        create("public") {
            dimension = "key"
            applicationIdSuffix = ".br"
            buildConfigField("String", "TOMTOM_API_KEY", "\"\"")
            buildConfigField("String", "DEFAULT_MAP", "\"mapbox\"")
            // where the build's "publish" option puts new versions (the "app" release); the app checks it for updates
            // the repo this is built in (GitHub sets GITHUB_REPOSITORY in Actions), so updates come from our own fork; blank = no updates
            buildConfigField("String", "UPDATE_REPO", "\"${System.getenv("GITHUB_REPOSITORY") ?: ""}\"")
            // the APK file the updater looks for in that release
            buildConfigField("String", "UPDATE_APK", "\"HorizonNav-BR.apk\"")
            // offline packs copied to this repo's releases (one per line in pacotes-espelho.txt at the repo root): the app downloads them from here
            val mirrored = generateSequence(rootDir) { it.parentFile }.take(6).map { File(it, "pacotes-espelho.txt") }.firstOrNull { it.isFile }
                ?.readLines()?.map { it.trim() }?.filter { it.isNotEmpty() && !it.startsWith("#") }?.joinToString(",") ?: ""
            buildConfigField("String", "MIRRORED_PACKS", "\"$mirrored\"")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
        // the Mapbox map and the offline router (Valhalla) both bring the C++ runtime: one copy is kept
        jniLibs.pickFirsts += "**/libc++_shared.so"
    }
}

kotlin { jvmToolchain(17) }

dependencies {
    val bom = platform("androidx.compose:compose-bom:2025.06.00")
    implementation(bom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.1")
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    // The map: Mapbox Maps SDK (v11, Standard style). Needs OpenGL ES 3.0; the app checks for it at start-up.
    implementation("com.mapbox.maps:android:11.32.1")
    // Android Auto: Google's car app library (the navigation layout, search and list screens, and the map surface)
    implementation("androidx.car.app:app:1.4.0")
    // Android Auto: the car's own data (fuel level and range) for the dashboard
    implementation("androidx.car.app:app-projected:1.4.0")
    // Offline routing engine (Valhalla) that runs on downloaded road data, with the libraries it needs at run time
    implementation("io.github.rallista:valhalla-mobile:0.6.4")
    implementation("com.squareup.moshi:moshi-kotlin:1.15.1")
}

// After a release build, put the APK in one folder with a clear name (HorizonNav-BR.apk), where the GitHub build picks it up.
val collectApks by tasks.registering(Copy::class) {
    from(layout.buildDirectory.dir("outputs/apk/public/release")) { include("*.apk"); rename { "HorizonNav-BR.apk" } }
    into(layout.buildDirectory.dir("outputs/apk/release"))
}
tasks.matching { it.name == "assembleRelease" }.configureEach { finalizedBy(collectApks) }
