plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val tomtomApiKey: String = (findProperty("tomtomApiKey") as String?) ?: ""

android {
    namespace = "com.headunit.launcher"
    compileSdk = 36

    defaultConfig {
        // its own app id, so it installs next to Horizon Launcher instead of replacing it
        applicationId = "com.headunit.nav"
        minSdk = 26
        targetSdk = 34
        // each GitHub build gets a higher version number, so Android always treats a new APK as an update
        val run = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0
        versionCode = 100 + run
        versionName = "1.0.$run"
        resValue("string", "app_name", "Horizon Nav")
    }

    // Sign every build with the same key: the signing.keystore file in your GitHub repo (found by looking up from the project folder).
    // Android only installs a new APK over the old one when both are signed with the same key.
    val repoKeystore = generateSequence(rootDir) { it.parentFile }.take(6).map { File(it, "signing.keystore") }.firstOrNull { it.isFile }
    signingConfigs {
        if (repoKeystore != null) create("stable") {
            storeFile = repoKeystore
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildFeatures { compose = true; buildConfig = true }
    // A release build runs noticeably faster than the debug one (no debug overhead, and the libraries' built-in speed-up profiles are applied).
    // It is signed with the debug key so it installs like before; code shrinking stays off to avoid breaking the map library.
    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            isDebuggable = false
            signingConfig = signingConfigs.findByName("stable") ?: signingConfigs.getByName("debug")
        }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    // two versions from the same code: "personal" has your TomTom key built in and uses TomTom by default; "public" is safe to give
    // to other people: no key inside (they can add their own in Settings) and OpenStreetMap by default
    flavorDimensions += "key"
    productFlavors {
        create("personal") {
            dimension = "key"
            buildConfigField("String", "TOMTOM_API_KEY", "\"$tomtomApiKey\"")
            buildConfigField("String", "DEFAULT_MAP", "\"tomtom\"")
            // never published, so it doesn't look for updates
            buildConfigField("String", "UPDATE_REPO", "\"\"")
        }
        create("public") {
            dimension = "key"
            // its own app id, so it can be installed next to your personal one
            applicationIdSuffix = ".public"
            buildConfigField("String", "TOMTOM_API_KEY", "\"\"")
            buildConfigField("String", "DEFAULT_MAP", "\"osm\"")
            // where the build's "publish" option puts new versions (the "app" release); the app checks it for updates
            buildConfigField("String", "UPDATE_REPO", "\"benbishop028-arch/Horizon-Maps\"")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

kotlin { jvmToolchain(17) }

dependencies {
    val bom = platform("androidx.compose:compose-bom:2025.06.00")
    implementation(bom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.1")
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    // Native vector map (OpenGL ES), used with the TomTom Orbis style
    implementation("org.maplibre.gl:android-sdk:11.8.0")
    // Android Auto: Google's car app library (the navigation layout, search and list screens, and the map surface)
    implementation("androidx.car.app:app:1.4.0")
    // Offline routing engine (Valhalla) that runs on downloaded road data, with the libraries it needs at run time
    implementation("io.github.rallista:valhalla-mobile:0.6.4")
    implementation("com.squareup.moshi:moshi-kotlin:1.15.1")
}

// After a release build, put both APKs in one folder with clear names (HorizonNav-personal.apk and HorizonNav-public.apk),
// so the GitHub build picks up both without any change to its workflow.
val collectApks by tasks.registering(Copy::class) {
    from(layout.buildDirectory.dir("outputs/apk/personal/release")) { include("*.apk"); rename { "HorizonNav-personal.apk" } }
    from(layout.buildDirectory.dir("outputs/apk/public/release")) { include("*.apk"); rename { "HorizonNav-public.apk" } }
    into(layout.buildDirectory.dir("outputs/apk/release"))
}
tasks.matching { it.name == "assembleRelease" }.configureEach { finalizedBy(collectApks) }
