plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val tomtomApiKey: String = (findProperty("tomtomApiKey") as String?) ?: ""

android {
    namespace = "com.headunit.launcher"
    compileSdk = 36

    defaultConfig {
        // its own app id, so it installs next to Horizon Launcher instead of replacing it
        applicationId = "com.headunit.nav"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
        resValue("string", "app_name", "Horizon Nav")
    }

    buildFeatures { compose = true; buildConfig = true }
    // A release build runs noticeably faster than the debug one (no debug overhead, and the libraries' built-in speed-up profiles are applied).
    // It is signed with the debug key so it installs like before; code shrinking stays off to avoid breaking the map library.
    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            isDebuggable = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    // two versions from the same code: "personal" has your TomTom key built in and uses TomTom by default; "public" is safe to give
    // to other people: no key inside (they can add their own in Settings) and OpenStreetMap by default
    flavorDimensions += "key"
    productFlavors {
        create("personal") {
            dimension = "key"
            buildConfigField("String", "TOMTOM_API_KEY", "\"$tomtomApiKey\"")
            buildConfigField("String", "DEFAULT_MAP", "\"tomtom\"")
        }
        create("public") {
            dimension = "key"
            // its own app id, so it can be installed next to your personal one
            applicationIdSuffix = ".public"
            buildConfigField("String", "TOMTOM_API_KEY", "\"\"")
            buildConfigField("String", "DEFAULT_MAP", "\"osm\"")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

kotlin { jvmToolchain(17) }

dependencies {
    val bom = platform("androidx.compose:compose-bom:2025.06.00")
    implementation(bom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.1")
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    // Native vector map (OpenGL ES), used with the TomTom Orbis style
    implementation("org.maplibre.gl:android-sdk:11.8.0")
    // Offline routing engine (Valhalla) that runs on downloaded road data, with the libraries it needs at run time
    implementation("io.github.rallista:valhalla-mobile:0.6.4")
    implementation("com.squareup.moshi:moshi-kotlin:1.15.1")
}
