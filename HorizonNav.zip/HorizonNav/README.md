# Horizon Maps
Horizon Maps: the Mapbox edition of Horizon Maps (app id com.headunit.nav.mapbox, installs alongside Horizon Maps).
The map is drawn by the Mapbox Maps SDK v11 with the Standard style (needs a Mapbox public token in Settings > Search & keys).
Standalone navigation app for an Android head unit:
search, routing, lane guidance, live traffic, speed limits, cameras and voice (TomTom REST API, key via -PtomtomApiKey
or Settings), plus offline map, search and routing from the England & Wales (or Great Britain) pack.

Extras:
- Average speed checks (your average against the limit), next motorway services, speed bump and school warnings,
  Clean Air Zone / ULEZ warnings and avoidance (OpenStreetMap data).
- Live UK fuel prices from the government's Fuel Finder scheme (needs your own free client ID and secret), sorted by
  price or distance; search along the route for fuel, chargers, food, coffee, toilets and services, with the detour time.
- Route bar, several stops with reordering, "avoid this road", destination side, reports (police, accident, hazard,
  breakdown, mobile camera), tunnel dead reckoning, a road/heading card when driving without a route, trip log.
- Destinations shared from other apps (Google Maps links, geo: links, addresses).
- Guidance keeps going in the background while a route is running (foreground service with a notification).

Build: gradle :app:assembleRelease -PtomtomApiKey=YOUR_KEY
