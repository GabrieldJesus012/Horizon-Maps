# Horizon Nav
Standalone navigation app for an Android head unit (made from Horizon Launcher's navigation): a full-screen native
MapLibre map with the TomTom Orbis style, search, routing, lane guidance, live traffic, speed limits, cameras and voice
(TomTom REST API, key via -PtomtomApiKey or Settings), plus offline map, search and routing from the England and Wales pack.

- The gear button on the map opens Settings (map, route, guidance, alerts, voice, offline maps, saved places, driving,
  display, units, performance, search & keys, about & backup). Back returns to the map.
- While a route is running, guidance carries on if you switch to another app (a notification shows; tap it to come back).
- Installs alongside Horizon Launcher (app id com.headunit.nav).

Build: gradle :app:assembleRelease -PtomtomApiKey=YOUR_KEY (GitHub Actions does this on every push to main).
